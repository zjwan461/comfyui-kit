from .wuji_upscaler_node import WujiUpscaler

NODE_CLASS_MAPPINGS = {
    "WujiUpscaler": WujiUpscaler
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "WujiUpscaler": "☯️无极放大器"
}
