import torch
import os
import sys
print(f"☯️ [无极工具箱] 正在加载 WujiUpscaler 节点文件... {__file__}")
import numpy as np
from PIL import Image
from PIL.PngImagePlugin import PngInfo
import folder_paths
from typing import Dict, Any

# ☯️ [无极工具箱] 导入内部放大引擎 (绿色版)
try:
    # 针对环境兼容性的极限处理：如果 xformers 损坏，尝试屏蔽它以允许引擎加载
    try:
        import xformers.ops
    except Exception:
        print("☯️ [无极工具箱] 检测到 xformers 环境损坏，正在启用兼容性屏蔽...")
        sys.modules["xformers"] = None
        sys.modules["xformers.ops"] = None

    from .engine.interfaces.dit_model_loader import SeedVR2LoadDiTModel
    from .engine.interfaces.vae_model_loader import SeedVR2LoadVAEModel
    from .engine.interfaces.video_upscaler import SeedVR2VideoUpscaler
    from .engine.utils.model_registry import DEFAULT_VAE, get_available_dit_models
    ENGINE_AVAILABLE = True
    print("☯️ [无极工具箱] 放大器引擎加载成功")
except Exception as e:
    # 如果还是失败，可能是其他依赖问题
    import traceback
    print(f"☯️ [无极工具箱] 警告：本地放大器引擎加载失败: {e}")
    # traceback.print_exc() # 生产环境建议关闭详细堆栈
    ENGINE_AVAILABLE = False

try:
    from ..common.wuji_optimizations import wuji_cache_and_fallback, cleanup_memory, WUJI_CTX, ensure_standard_image
except ImportError:
    # 如果导入失败，创建简化版本
    def wuji_cache_and_fallback(name):
        def decorator(func):
            return func
        return decorator
    
    def cleanup_memory(force=False):
        import gc
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    
    WUJI_CTX = None
    
    def ensure_standard_image(image):
        return image

class WujiUpscaler:
    """
    ☯️ 无极放大器 (绿色独立版)
    自包含核心算法引擎，不依赖外部 SeedVR2 插件。
    高性能视频/图像放大，支持 RTX 50 系列极致优化。
    """
    
    @classmethod
    def INPUT_TYPES(cls):
        dit_models = ["seedvr2_ema_3b_fp8_e4m3fn.safetensors"]
        if ENGINE_AVAILABLE:
            try:
                dit_models = get_available_dit_models()
            except: pass
            
        return {
            "required": {
                "图像": ("IMAGE",),
                "放大模型": (dit_models, {"default": dit_models[0]}),
                "最短边尺寸": ("INT", {"default": 1080, "min": 128, "max": 4096, "step": 8}),
                "颜色校对": (["lab", "wavelet", "wavelet_adaptive", "hsv", "adain", "none"], {"default": "lab"}),
                "预览开关": ("BOOLEAN", {"default": True}),
            },
            "hidden": {
                "unique_id": "UNIQUE_ID",
                "prompt": "PROMPT",
                "extra_pnginfo": "EXTRA_PNGINFO",
            }
        }

    RETURN_TYPES = ("IMAGE",)
    FUNCTION = "upscale"
    CATEGORY = "☯️无极工具箱"
    INPUT_IS_LIST = True
    OUTPUT_NODE = True

    @wuji_cache_and_fallback("upscaler")
    def upscale(self, 图像, 放大模型, 最短边尺寸, 颜色校对, 预览开关=True, unique_id=None, prompt=None, extra_pnginfo=None, **kwargs):
        # ☯️ [无极加速] 智能清理：仅在显存压力大时执行清理，避免频繁卸载模型
        print("☯️ [无极工具箱] 放大器接入：正在检查资源状态...")
        try:
            if torch.cuda.is_available():
                total_mem = torch.cuda.get_device_properties(0).total_memory
                used_mem = torch.cuda.memory_allocated(0)
                if used_mem > total_mem * 0.7:
                    print("☯️ [无极工具箱] 显存占用较高，正在执行轻量级清理...")
                    cleanup_memory(force=False)
        except:
            pass

        if not ENGINE_AVAILABLE:
            raise Exception("☯️ [无极工具箱] 错误：本地放大器引擎加载失败，无法使用放大功能。请检查插件目录结构。")

        # 0. 定义辅助提取函数 (处理各种包装类型)
        def _unwrap(obj):
            if obj is None: return None
            # 处理 ComfyUI 的 NodeOutput 或类似包装对象
            if hasattr(obj, "args") and isinstance(obj.args, tuple) and len(obj.args) > 0:
                return _unwrap(obj.args[0])
            if isinstance(obj, (list, tuple)) and len(obj) > 0:
                return _unwrap(obj[0])
            if hasattr(obj, "value"): 
                return _unwrap(getattr(obj, "value"))
            return obj

        model_name = _unwrap(放大模型)
        target_res = _unwrap(最短边尺寸)
        cc_mode = _unwrap(颜色校对)
        show_preview = _unwrap(预览开关)

        # 1. 预处理图像：支持图像批次(Batch)与图像列表(List)的混合输入
        # ☯️ [批次优化] 自动将所有输入转换为统一的批次张量，并支持分流处理
        input_list = 图像 if isinstance(图像, list) else [图像]
        processed_batches = []
        
        for img in input_list:
            if isinstance(img, torch.Tensor):
                if img.ndim == 3: # HWC -> BHWC
                    processed_batches.append(img.unsqueeze(0))
                elif img.ndim == 4: # BHWC
                    processed_batches.append(img)
        
        if not processed_batches: 
            return (torch.zeros([1, 64, 64, 3]),)
            
        # 确保所有帧尺寸一致 (以第一帧为准)
        first_shape = processed_batches[0].shape[1:3]
        consistent_images = []
        for img in processed_batches:
            if img.shape[1:3] != first_shape:
                # 使用高质量的双三次插值进行预缩放
                img = torch.nn.functional.interpolate(
                    img.permute(0, 3, 1, 2), 
                    size=first_shape, 
                    mode='bicubic', 
                    align_corners=False
                ).permute(0, 2, 3, 1)
            consistent_images.append(img)
        
        # 合并为大批次进行处理
        full_batch = torch.cat(consistent_images, dim=0)
        
        # 2. 自动配置 DiT (全自动静默加载)
        # ☯️ [加速] 使用单例加载器减少实例化开销
        if not hasattr(self, "dit_loader"):
            self.dit_loader = SeedVR2LoadDiTModel()
        
        dit_result = self.dit_loader.execute(
            model=model_name,
            device="cuda",
            offload_device="cpu", # 保持 CPU offload 以确保超大图放大不 OOM
            cache_model=True,
            blocks_to_swap=20, # 增加交换块数量以提升 40/50 系显卡性能
            swap_io_components=True
        )
        dit_config = _unwrap(dit_result)

        # 3. 自动配置 VAE
        if not hasattr(self, "vae_loader"):
            self.vae_loader = SeedVR2LoadVAEModel()
            
        vae_result = self.vae_loader.execute(
            model=DEFAULT_VAE,
            device="cuda",
            offload_device="cpu",
            cache_model=True,
            encode_tiled=True,
            encode_tile_size=512,
            encode_tile_overlap=64,
            decode_tiled=True,
            decode_tile_size=512,
            decode_tile_overlap=64
        )
        vae_config = _unwrap(vae_result)

        # 4. 执行放大核心逻辑
        # ☯️ [性能优化] 针对多图输入，根据显存情况自动调整内部 Batch 处理
        upscaler = SeedVR2VideoUpscaler()
        
        # 检查显存，如果显存充裕且是多图，可以尝试增大 batch_size
        internal_batch_size = 1
        try:
            if torch.cuda.is_available():
                free_mem = torch.cuda.mem_get_info()[0]
                if free_mem > 12 * 1024**3: # > 12GB 显存
                    internal_batch_size = 2
        except: pass

        result = upscaler.execute(
            image=full_batch,
            dit=dit_config,
            vae=vae_config,
            seed=42, 
            resolution=target_res,
            max_resolution=0,
            batch_size=internal_batch_size,
            uniform_batch_size=True,
            temporal_overlap=2,
            prepend_frames=0,
            color_correction=cc_mode,
            input_noise_scale=0.0,
            latent_noise_scale=0.0,
            offload_device="cpu",
            enable_debug=False
        )
        
        final_image = ensure_standard_image(_unwrap(result))
        
        # 5. 自动保存与预览逻辑
        results = list()
        if show_preview:
            is_connected = False
            try:
                if prompt is not None and unique_id is not None:
                    _prompt = _unwrap(prompt)
                    _uid = str(_unwrap(unique_id))
                    if _prompt and _uid in _prompt:
                        for other_node_id, other_node_info in _prompt.items():
                            inputs = other_node_info.get("inputs", {})
                            for input_name, input_value in inputs.items():
                                if isinstance(input_value, list) and len(input_value) == 2:
                                    if str(input_value[0]) == _uid:
                                        is_connected = True
                                        break
                            if is_connected: break
            except: pass

            try:
                # 如果没有外接节点，保存到 output 目录；如果有外接，保存到 temp 目录用于预览
                if not is_connected:
                    output_dir = folder_paths.get_output_directory()
                    filename_prefix = "☯️无极放大"
                    type_str = "output"
                else:
                    output_dir = folder_paths.get_temp_directory()
                    filename_prefix = "wuji_preview"
                    type_str = "temp"

                full_output_folder, filename, counter, subfolder, filename_prefix = folder_paths.get_save_image_path(filename_prefix, output_dir, final_image.shape[2], final_image.shape[1])
                
                for batch_number in range(final_image.shape[0]):
                    i = 255. * final_image[batch_number].cpu().numpy()
                    img = Image.fromarray(np.clip(i, 0, 255).astype(np.uint8))
                    file = f"{filename}_{batch_number:05}_.png"
                    img.save(os.path.join(full_output_folder, file))
                    results.append({
                        "filename": file,
                        "subfolder": subfolder,
                        "type": type_str
                    })
                
                if not is_connected:
                    print(f"☯️ [无极工具箱] 放大完成，已自动保存至: {full_output_folder}")
            except Exception as e:
                print(f"⚠️ [无极工具箱] 保存预览图像失败: {e}")

        # ☯️ [输出优化] 返回统一的批次张量
        return {"ui": {"images": results}, "result": (final_image,)}

NODE_CLASS_MAPPINGS = {"WujiUpscaler": WujiUpscaler}
NODE_DISPLAY_NAME_MAPPINGS = {"WujiUpscaler": "☯️无极放大器"}
