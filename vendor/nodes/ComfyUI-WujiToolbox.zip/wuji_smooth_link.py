# -*- coding: utf-8 -*-
"""
☯️无极畅联
平滑连接器，支持任意类型连接
"""

class AnyType(str):
    """任意类型，用于接受任何输入"""
    def __ne__(self, __value: object) -> bool:
        return False
    def __eq__(self, __value: object) -> bool:
        return True

any_type = AnyType("*")


class WujiSmoothLink:
    """
    ☯️无极畅联
    独立运行的全局输入节点，支持无限无线连接
    """
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {},
            "optional": {
                "anything": (any_type, {}),
            }
        }

    RETURN_TYPES = ()
    FUNCTION = "process"
    CATEGORY = "☯️无极工具箱"
    OUTPUT_NODE = True
    DESCRIPTION = "☯️ 无极畅联 - 独立运行的全局输入节点，支持无限无线连接"

    def process(self, **kwargs):
        return ()
