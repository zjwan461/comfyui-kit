# -*- coding: utf-8 -*-
"""
ComfyUI-WujiToolbox 核心节点
直接调用官方API，确保与官方同步更新
"""

import os
import sys
import json
import torch
import importlib.util
import folder_paths
import comfy.sd
import comfy.sample
import comfy.samplers
import comfy.model_management
import comfy.controlnet
import comfy.clip_vision
from nodes import (
    CheckpointLoaderSimple, LoraLoader, VAELoader,
    KSamplerAdvanced, VAEDecode,
    LoadImage, ImageScale,
    CLIPTextEncode, CLIPSetLastLayer
)


def _load_kjnodes_module():
    """动态加载KJNodes的model_optimization_nodes模块"""
    try:
        # 尝试找到KJNodes路径
        kjnodes_path = None
        
        # 方法1: 从sys.path中查找
        for p in sys.path:
            if 'custom_nodes' in p:
                possible_path = os.path.join(p, 'ComfyUI-KJNodes')
                if os.path.exists(possible_path):
                    kjnodes_path = possible_path
                    break
        
        # 方法2: 从当前文件位置推导
        if not kjnodes_path:
            current_file = os.path.abspath(__file__)
            custom_nodes_dir = os.path.dirname(current_file)
            # 尝试上级目录中的ComfyUI-KJNodes
            parent_dir = os.path.dirname(custom_nodes_dir)
            possible_path = os.path.join(parent_dir, 'ComfyUI-KJNodes')
            if os.path.exists(possible_path):
                kjnodes_path = possible_path
        
        # 方法3: 尝试常见的ComfyUI路径结构
        if not kjnodes_path:
            possible_paths = [
                os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'ComfyUI-KJNodes'),
                os.path.join(os.path.expanduser('~'), 'ComfyUI', 'custom_nodes', 'ComfyUI-KJNodes'),
            ]
            for p in possible_paths:
                if os.path.exists(p):
                    kjnodes_path = p
                    break
        
        if not kjnodes_path or not os.path.exists(kjnodes_path):
            return None
        
        # 动态加载model_optimization_nodes模块
        module_path = os.path.join(kjnodes_path, 'nodes', 'model_optimization_nodes.py')
        if not os.path.exists(module_path):
            return None
        
        # 使用唯一的模块名避免冲突
        module_name = "wuji_kjnodes_model_opt"
        spec = importlib.util.spec_from_file_location(module_name, module_path)
        if not spec or not spec.loader:
            return None
            
        module = importlib.util.module_from_spec(spec)
        # 添加到sys.modules以便后续导入
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        return module
    except Exception as e:
        print(f"⚠️ [无极工具箱] 加载KJNodes模块失败: {e}")
        import traceback
        traceback.print_exc()
        return None


# 预加载KJNodes模块（在节点加载时执行）
_KJMODULE = _load_kjnodes_module()
if _KJMODULE:
    print("✅ [无极工具箱] KJNodes模块预加载成功")


class WujiLoader:
    """
    ☯️无极加载器 - 官方API直连版
    
    直接调用ComfyUI官方API加载模型：
    - UNet: 标准ComfyUI diffusion_models/unet加载
    - Checkpoint: 标准ComfyUI checkpoint加载
    
    其他模型类型（GGUF/Nunchaku等）请通过"外部模型"接口接入
    """
    
    # 类级别缓存
    _input_types_cache = None
    _cache_timestamp = 0
    _cache_duration = 30  # 缓存30秒
    
    @classmethod
    def INPUT_TYPES(cls):
        import time
        
        # 检查缓存是否有效
        current_time = time.time()
        if cls._input_types_cache is not None and (current_time - cls._cache_timestamp) < cls._cache_duration:
            return cls._input_types_cache
        
        # 获取各类模型列表
        checkpoints = folder_paths.get_filename_list("checkpoints")
        unet_files = []
        for folder in ["diffusion_models", "unet"]:
            try:
                unet_files += folder_paths.get_filename_list(folder)
            except:
                pass
        
        clip_files = folder_paths.get_filename_list("text_encoders")
        vae_files = folder_paths.get_filename_list("vae")
        vision_files = folder_paths.get_filename_list("clip_vision")
        controlnet_files = folder_paths.get_filename_list("controlnet")
        lora_files = folder_paths.get_filename_list("loras")
        
        cls._input_types_cache = {
            "required": {
                "unet模型": (["关闭"] + unet_files, {"default": "关闭"}),
                "checkpoint模型": (["关闭"] + checkpoints, {"default": "关闭"}),
                "clip模型1": (["关闭"] + clip_files, {"default": "关闭"}),
                "clip模型2": (["关闭"] + clip_files, {"default": "关闭"}),
                "clip类型": (["stable_diffusion", "stable_cascade", "sd3", "flux", "hunyuan_video", "wan", "qwen_image", "mochi", "ltxv", "cosmos", "lumina2", "hunyuan_image", "ovis"], {"default": "flux"}),
                "vae模型": (["关闭", "pixel_space"] + vae_files, {"default": "关闭"}),
                "视觉模型": (["关闭"] + vision_files, {"default": "关闭"}),
                "cn模型": (["关闭"] + controlnet_files, {"default": "关闭"}),
                "lora模型1": (["关闭"] + lora_files, {"default": "关闭"}),
                "lora权重1": ("FLOAT", {"default": 1.0, "min": -10.0, "max": 10.0, "step": 0.01}),
                "lora模型2": (["关闭"] + lora_files, {"default": "关闭"}),
                "lora权重2": ("FLOAT", {"default": 1.0, "min": -10.0, "max": 10.0, "step": 0.01}),
                "lora模型3": (["关闭"] + lora_files, {"default": "关闭"}),
                "lora权重3": ("FLOAT", {"default": 1.0, "min": -10.0, "max": 10.0, "step": 0.01}),
                "lora模型4": (["关闭"] + lora_files, {"default": "关闭"}),
                "lora权重4": ("FLOAT", {"default": 1.0, "min": -10.0, "max": 10.0, "step": 0.01}),
                "lora模型5": (["关闭"] + lora_files, {"default": "关闭"}),
                "lora权重5": ("FLOAT", {"default": 1.0, "min": -10.0, "max": 10.0, "step": 0.01}),
            },
            "optional": {
                "外部模型": ("MODEL",),
            }
        }
        cls._cache_timestamp = current_time
        return cls._input_types_cache
    
    RETURN_TYPES = ("MODEL", "CLIP", "VAE", "CLIP_VISION", "CONTROL_NET")
    RETURN_NAMES = ("模型", "CLIP", "VAE", "视觉模型", "ControlNet")
    FUNCTION = "load_models"
    CATEGORY = "☯️无极工具箱"
    
    def load_models(self, **kwargs):
        print("\n" + "="*50)
        print("☯️ [无极加载器] 开始加载模型...")
        print("="*50)
        
        model, clip, vae, clip_vision, control_net = None, None, None, None, None
        
        # 获取参数
        unet_name = kwargs.get("unet模型", "关闭")
        ckpt_name = kwargs.get("checkpoint模型", "关闭")
        external_model = kwargs.get("外部模型", None)
        
        # ===== 加载优先级：外部模型 > UNet > Checkpoint =====
        
        # 1. 外部模型输入（最高优先级，用于接入GGUF/Nunchaku等外部模型）
        if external_model is not None:
            print("☯️ [无极加载器] 使用外部接入的模型")
            model = external_model
            
        # 2. UNet模型加载（标准ComfyUI API）
        elif unet_name != "关闭":
            print(f"☯️ [无极加载器] 加载UNet模型: {unet_name}")
            try:
                unet_path = folder_paths.get_full_path("diffusion_models", unet_name)
                if not unet_path:
                    unet_path = folder_paths.get_full_path("unet", unet_name)
                
                if unet_path and os.path.exists(unet_path):
                    # 直接调用ComfyUI官方API
                    model = comfy.sd.load_diffusion_model(unet_path)
                    print(f"✅ [无极加载器] UNet模型加载成功")
                else:
                    print(f"❌ [无极加载器] 找不到UNet模型文件: {unet_name}")
            except Exception as e:
                print(f"❌ [无极加载器] UNet加载失败: {e}")
                import traceback
                traceback.print_exc()
        
        # 3. Checkpoint模型加载（标准ComfyUI API）
        elif ckpt_name != "关闭":
            print(f"☯️ [无极加载器] 加载Checkpoint模型: {ckpt_name}")
            try:
                ckpt_path = folder_paths.get_full_path("checkpoints", ckpt_name)
                if ckpt_path and os.path.exists(ckpt_path):
                    # 直接调用ComfyUI官方API
                    # 如果用户没有单独选择CLIP/VAE，则从checkpoint加载
                    load_clip = kwargs.get("clip模型1") == "关闭" and kwargs.get("clip模型2") == "关闭"
                    load_vae = kwargs.get("vae模型") == "关闭"
                    
                    out = comfy.sd.load_checkpoint_guess_config(
                        ckpt_path,
                        output_vae=load_vae,
                        output_clip=load_clip,
                        embedding_directory=folder_paths.get_folder_paths("embeddings")
                    )
                    model, clip, vae, _ = out
                    print(f"✅ [无极加载器] Checkpoint加载成功 (CLIP:{load_clip}, VAE:{load_vae})")
                else:
                    print(f"❌ [无极加载器] 找不到Checkpoint文件: {ckpt_name}")
            except Exception as e:
                print(f"❌ [无极加载器] Checkpoint加载失败: {e}")
                import traceback
                traceback.print_exc()
        
        else:
            print("⚠️ [无极加载器] 未选择任何主模型")
        
        # ===== 加载CLIP（如果上面没加载）=====
        if clip is None:
            clip = self._load_clip(kwargs)
        
        # ===== 加载VAE（如果上面没加载）=====
        if vae is None:
            vae = self._load_vae(kwargs)
        
        # ===== 加载视觉模型 =====
        clip_vision = self._load_vision(kwargs)
        
        # ===== 加载ControlNet =====
        control_net = self._load_controlnet(kwargs)
        
        # ===== 加载LoRA (5槽位) =====
        model, clip = self._load_loras(model, clip, kwargs)
        
        print("="*50)
        print("☯️ [无极加载器] 模型加载完成!")
        print(f"   模型: {'✅' if model else '❌'} | CLIP: {'✅' if clip else '❌'} | VAE: {'✅' if vae else '❌'}")
        print("="*50 + "\n")
        
        return (model, clip, vae, clip_vision, control_net)
    
    def _load_clip(self, kwargs):
        """加载CLIP模型 - 直接调用ComfyUI官方API"""
        c1 = kwargs.get("clip模型1", "关闭")
        c2 = kwargs.get("clip模型2", "关闭")
        
        if c1 == "关闭" and c2 == "关闭":
            return None
        
        try:
            c_names = []
            if c1 != "关闭":
                c_names.append(c1)
            if c2 != "关闭":
                c_names.append(c2)
            
            c_paths = []
            for name in c_names:
                p = folder_paths.get_full_path("text_encoders", name)
                if not p:
                    p = folder_paths.get_full_path("clip", name)
                if p:
                    c_paths.append(p)
            
            if not c_paths:
                return None
            
            print(f"☯️ [无极加载器] 加载CLIP: {c_names}")
            
            clip_type_str = kwargs.get("clip类型", "flux").upper()
            if clip_type_str == "FLUX2":
                clip_type_str = "FLUX"
            c_type = getattr(comfy.sd.CLIPType, clip_type_str, comfy.sd.CLIPType.FLUX)
            
            clip = comfy.sd.load_clip(
                ckpt_paths=c_paths,
                embedding_directory=folder_paths.get_folder_paths("embeddings"),
                clip_type=c_type
            )
            print(f"✅ [无极加载器] CLIP加载成功")
            return clip
            
        except Exception as e:
            print(f"❌ [无极加载器] CLIP加载失败: {e}")
            return None
    
    def _load_vae(self, kwargs):
        """加载VAE模型 - 直接调用ComfyUI官方API"""
        vae_name = kwargs.get("vae模型", "关闭")
        
        if vae_name == "关闭":
            return None
        
        try:
            if vae_name == "pixel_space":
                print("☯️ [无极加载器] 使用Pixel Space VAE")
                return comfy.sd.VAE(sd={"pixel_space_vae": torch.tensor(1.0)})
            
            print(f"☯️ [无极加载器] 加载VAE: {vae_name}")
            vae_path = folder_paths.get_full_path("vae", vae_name)
            
            if vae_path and os.path.exists(vae_path):
                vae_sd = comfy.utils.load_torch_file(vae_path)
                vae = comfy.sd.VAE(sd=vae_sd)
                print(f"✅ [无极加载器] VAE加载成功")
                return vae
            else:
                print(f"❌ [无极加载器] 找不到VAE文件: {vae_name}")
                return None
                
        except Exception as e:
            print(f"❌ [无极加载器] VAE加载失败: {e}")
            return None
    
    def _load_vision(self, kwargs):
        """加载视觉模型 - 直接调用ComfyUI官方API"""
        vision_name = kwargs.get("视觉模型", "关闭")
        
        if vision_name == "关闭":
            return None
        
        try:
            print(f"☯️ [无极加载器] 加载视觉模型: {vision_name}")
            vision_path = folder_paths.get_full_path("clip_vision", vision_name)
            
            if vision_path and os.path.exists(vision_path):
                clip_vision = comfy.clip_vision.load(vision_path)
                print(f"✅ [无极加载器] 视觉模型加载成功")
                return clip_vision
            else:
                print(f"❌ [无极加载器] 找不到视觉模型文件: {vision_name}")
                return None
                
        except Exception as e:
            print(f"❌ [无极加载器] 视觉模型加载失败: {e}")
            return None
    
    def _load_controlnet(self, kwargs):
        """加载ControlNet - 直接调用ComfyUI官方API"""
        cn_name = kwargs.get("cn模型", "关闭")
        
        if cn_name == "关闭":
            return None
        
        try:
            print(f"☯️ [无极加载器] 加载ControlNet: {cn_name}")
            cn_path = folder_paths.get_full_path("controlnet", cn_name)
            
            if cn_path and os.path.exists(cn_path):
                control_net = comfy.controlnet.load_controlnet(cn_path)
                print(f"✅ [无极加载器] ControlNet加载成功")
                return control_net
            else:
                print(f"❌ [无极加载器] 找不到ControlNet文件: {cn_name}")
                return None
                
        except Exception as e:
            print(f"❌ [无极加载器] ControlNet加载失败: {e}")
            return None
    
    def _load_loras(self, model, clip, kwargs):
        """加载LoRA模型 - 直接调用ComfyUI官方LoraLoader"""
        for i in range(1, 6):
            lora_name = kwargs.get(f"lora模型{i}", "关闭")
            lora_weight = kwargs.get(f"lora权重{i}", 1.0)
            
            if lora_name != "关闭":
                try:
                    print(f"☯️ [无极加载器] 加载LoRA {i}: {lora_name} (权重: {lora_weight})")
                    lora_loader = LoraLoader()
                    model, clip = lora_loader.load_lora(model, clip, lora_name, lora_weight, lora_weight)
                except Exception as e:
                    print(f"❌ [无极加载器] LoRA {i} 加载失败: {e}")
        
        return model, clip


class WujiOptimizer:
    """
    ☯️无极优化器 - 综合模型优化
    
    功能：
    - 精度优化（权重/计算精度）
    - 采样算法（Flux/SD3/AuraFlow等）
    - CFG优化（RescaleCFG, CFGZeroStar）
    - 注意力优化（SageAttention）
    - 编译优化（Torch.compile）
    """
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "模型": ("MODEL",),
                # 精度优化
                "权重精度": (["关闭", "fp4", "int4", "fp8_e4m3fn_fast", "fp8_e4m3fn", "fp8_e5m2", "fp16", "bf16"], {"default": "关闭"}),
                "计算精度": (["关闭", "fast", "bf16", "fp16", "fp32"], {"default": "fast"}),
                # 采样算法
                "采样算法": (["自动", "手动", "Flux", "Flux2", "SD3", "AuraFlow", "HunyuanVideo", "Wan", "LTXV", "Cosmos", "Lumina2", "QwenImage", "ZImage", "Ovis"], {"default": "自动"}),
                "采样算法值": ("FLOAT", {"default": 3.0, "min": 0.0, "max": 100.0, "step": 0.01}),
                # 编译优化
                "SageAttention": ("BOOLEAN", {"default": False}),
                "Torch编译": ("BOOLEAN", {"default": False}),
                # CFG优化
                "RescaleCFG": ("BOOLEAN", {"default": False}),
                "CFGZeroStar": ("BOOLEAN", {"default": False}),
                "CFGNorm": ("BOOLEAN", {"default": False}),
                "CFGNorm强度": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 100.0, "step": 0.01}),
            }
        }
    
    RETURN_TYPES = ("MODEL",)
    RETURN_NAMES = ("模型",)
    FUNCTION = "optimize"
    CATEGORY = "☯️无极工具箱"
    
    def optimize(self, 模型, 权重精度, 计算精度, 采样算法, 采样算法值, SageAttention, Torch编译, RescaleCFG, CFGZeroStar, CFGNorm, CFGNorm强度):
        
        # 简化日志输出，只在开始时打印一行
        print(f"☯️ [无极优化器] 开始优化...")
        
        if 模型 is None:
            print("❌ [无极优化器] 错误: 模型为None")
            return (None,)
        
        model = 模型.clone()
        applied_count = 0
        
        # ===== 1. 精度优化 =====
        if 权重精度 != "关闭" or 计算精度 != "关闭":
            try:
                model = self._apply_precision(model, 权重精度, 计算精度)
                applied_count += 1
            except Exception as e:
                print(f"⚠️ [无极优化器] 精度优化失败: {e}")
        
        # ===== 2. 采样算法 =====
        if 采样算法 == "手动":
            try:
                model = self._apply_sampling_manual(model, 采样算法值)
                applied_count += 1
            except Exception as e:
                print(f"⚠️ [无极优化器] 手动采样算法失败: {e}")
        elif 采样算法 != "自动":
            try:
                model = self._apply_sampling(model, 采样算法)
                applied_count += 1
            except Exception as e:
                print(f"⚠️ [无极优化器] 采样算法失败: {e}")
        
        # ===== 3. SageAttention =====
        if SageAttention:
            try:
                model = self._apply_sage_attention(model)
                applied_count += 1
            except Exception as e:
                print(f"⚠️ [无极优化器] SageAttention失败: {e}")
        
        # ===== 4. Torch编译 =====
        if Torch编译:
            try:
                model = self._apply_torch_compile(model)
                applied_count += 1
            except Exception as e:
                print(f"⚠️ [无极优化器] Torch编译失败: {e}")
        
        # ===== 5. RescaleCFG =====
        if RescaleCFG:
            try:
                model = self._apply_rescale_cfg(model)
                applied_count += 1
            except Exception as e:
                print(f"⚠️ [无极优化器] RescaleCFG失败: {e}")
        
        # ===== 6. CFGZeroStar =====
        if CFGZeroStar:
            try:
                model = self._apply_cfg_zero_star(model)
                applied_count += 1
            except Exception as e:
                print(f"⚠️ [无极优化器] CFGZeroStar失败: {e}")
        
        # ===== 7. CFGNorm =====
        if CFGNorm:
            try:
                model = self._apply_cfg_norm(model, CFGNorm强度)
                applied_count += 1
            except Exception as e:
                print(f"⚠️ [无极优化器] CFGNorm失败: {e}")
        
        print(f"✅ [无极优化器] 完成 ({applied_count}项)")
        
        return (model,)
    
    def _apply_precision(self, model, weight_dtype, compute_dtype):
        """应用精度优化 - 支持FP4/INT4/fast模式"""
        import comfy.model_management
        
        model_config = model.model.model_config
        
        # 解析权重精度
        if weight_dtype == "fp4":
            # FP4/NVFP4需要Blackwell架构(计算能力10.0+)
            if comfy.model_management.supports_nvfp4_compute():
                unet_dtype = torch.float8_e4m3fn  # 使用FP8作为基础，配合quant_config实现FP4
                # 设置FP4量化配置
                model_config.quant_config = {"mixed_ops": True, "weight_bits": 4, "format": "nvfp4"}
                print(f"   启用FP4量化 (NVFP4)")
            else:
                print(f"   ⚠️ 当前设备不支持FP4，回退到FP8")
                unet_dtype = torch.float8_e4m3fn
        elif weight_dtype == "int4":
            # INT4量化配置
            model_config.quant_config = {"mixed_ops": True, "weight_bits": 4, "format": "int4"}
            unet_dtype = torch.float8_e4m3fn  # 使用FP8作为计算精度
            print(f"   启用INT4量化")
        elif weight_dtype == "fp8_e4m3fn_fast":
            # FP8 Fast模式：启用FP8矩阵乘法优化
            unet_dtype = torch.float8_e4m3fn
            # 启用FP8优化标志
            if not hasattr(model_config, 'optimizations'):
                model_config.optimizations = {}
            model_config.optimizations["fp8"] = True
            # 设置FP8优化选项，让model_options也能传递这个设置
            if hasattr(model, 'model_options'):
                model.model_options["fp8_optimizations"] = True
            print(f"   启用FP8 E4M3FN Fast模式 (FP8矩阵乘法)")
            # 检查设备是否支持FP8计算
            if comfy.model_management.supports_fp8_compute():
                print(f"   ✅ 设备支持FP8计算")
            else:
                print(f"   ⚠️ 设备不支持FP8计算，将使用回退模式")
        elif weight_dtype == "fp8_e4m3fn":
            unet_dtype = torch.float8_e4m3fn
        elif weight_dtype == "fp8_e5m2":
            unet_dtype = torch.float8_e5m2
        elif weight_dtype == "fp16":
            unet_dtype = torch.float16
        elif weight_dtype == "bf16":
            unet_dtype = torch.bfloat16
        else:  # 关闭
            unet_dtype = None
        
        # 解析计算精度
        if compute_dtype == "fast":
            # Fast模式：启用FP16累加和其他优化
            manual_cast = torch.float16
            # 启用fast模式优化
            self._enable_fast_mode(model, model_config)
        elif compute_dtype == "fp16":
            manual_cast = torch.float16
        elif compute_dtype == "bf16":
            manual_cast = torch.bfloat16
        elif compute_dtype == "fp32":
            manual_cast = torch.float32
        else:  # 关闭
            manual_cast = None
        
        if unet_dtype is not None or manual_cast is not None:
            if unet_dtype is None:
                unet_dtype = model_config.unet_dtype
            if manual_cast is None:
                manual_cast = model_config.manual_cast_dtype
            
            model_config.set_inference_dtype(unet_dtype, manual_cast)
            print(f"✅ 精度: {unet_dtype}, 计算: {manual_cast}")
        else:
            print(f"ℹ️ 使用默认精度")
        
        return model
    
    def _enable_fast_mode(self, model, model_config):
        """启用Fast模式优化 - FP16累加、FP8矩阵乘法等"""
        try:
            import comfy.model_management
            import comfy.ops
            from comfy.cli_args import args, PerformanceFeature
            
            # 启用FP16累加
            if comfy.model_management.is_nvidia() or comfy.model_management.is_amd():
                torch.backends.cuda.matmul.allow_fp16_accumulation = True
                print(f"   启用FP16累加 (FP16 Accumulation)")
            
            # 启用FP8矩阵乘法
            if hasattr(model_config, 'optimizations'):
                model_config.optimizations["fp8"] = True
                print(f"   启用FP8矩阵乘法 (FP8 Matrix Multiplication)")
            
            # 启用CublasOps (如果可用且权重为FP16)
            if hasattr(model_config, 'custom_operations'):
                print(f"   启用Cublas优化 (CublasOps)")
            
            # 启用AutoTune
            if torch.cuda.is_available() and torch.backends.cudnn.is_available():
                torch.backends.cudnn.benchmark = True
                print(f"   启用CuDNN AutoTune")
            
            print(f"✅ [无极优化器] Fast模式优化已启用")
        except Exception as e:
            print(f"   ⚠️ Fast模式部分优化失败: {e}")
    
    def _apply_sampling_manual(self, model, shift_value):
        """应用手动采样算法 - 使用自定义shift值"""
        import comfy.model_sampling
        
        m = model.clone()
        
        # 使用通用的Flow模型采样，应用自定义shift值
        model_sampling = comfy.model_sampling.ModelSamplingDiscreteFlow(m.model.model_config)
        model_sampling.set_parameters(shift=shift_value)
        m.add_object_patch("model_sampling", model_sampling)
        print(f"✅ [无极优化器] 手动采样算法已应用 (shift={shift_value})")
        
        return m
    
    def _apply_sampling(self, model, sampling_mode):
        """应用采样算法"""
        import comfy.model_sampling
        
        m = model.clone()
        
        if sampling_mode == "Flux":
            # Flux默认参数
            max_shift = 1.15
            base_shift = 0.5
            width = 1024
            height = 1024
            
            x1 = 256
            x2 = 4096
            mm = (max_shift - base_shift) / (x2 - x1)
            b = base_shift - mm * x1
            calculated_shift = (width * height / (8 * 8 * 2 * 2)) * mm + b
            
            sampling_base = comfy.model_sampling.ModelSamplingFlux
            sampling_type = comfy.model_sampling.CONST
            
            class ModelSamplingAdvanced(sampling_base, sampling_type):
                pass
            
            model_sampling = ModelSamplingAdvanced(model.model.model_config)
            model_sampling.set_parameters(shift=calculated_shift)
            m.add_object_patch("model_sampling", model_sampling)
            print(f"✅ [无极优化器] Flux采样配置已应用")
            
        elif sampling_mode == "SD3":
            model_sampling = comfy.model_sampling.ModelSamplingDiscreteFlow(model.model.model_config)
            model_sampling.set_parameters(shift=1.0)
            m.add_object_patch("model_sampling", model_sampling)
            print(f"✅ [无极优化器] SD3采样配置已应用")
            
        elif sampling_mode == "AuraFlow":
            model_sampling = comfy.model_sampling.ModelSamplingDiscreteFlow(model.model.model_config)
            model_sampling.set_parameters(shift=1.73, multiplier=1.0)
            m.add_object_patch("model_sampling", model_sampling)
            print(f"✅ [无极优化器] AuraFlow采样配置已应用")
            
        elif sampling_mode == "HunyuanVideo":
            # HunyuanVideo使用shift=3.0
            model_sampling = comfy.model_sampling.ModelSamplingDiscreteFlow(model.model.model_config)
            model_sampling.set_parameters(shift=3.0)
            m.add_object_patch("model_sampling", model_sampling)
            print(f"✅ [无极优化器] HunyuanVideo采样配置已应用 (shift=3.0)")
            
        elif sampling_mode == "Wan":
            # Wan使用shift=5.0（WanVideoWrapper vitb_unipc默认）
            model_sampling = comfy.model_sampling.ModelSamplingDiscreteFlow(model.model.model_config)
            model_sampling.set_parameters(shift=5.0)
            m.add_object_patch("model_sampling", model_sampling)
            print(f"✅ [无极优化器] Wan采样配置已应用 (shift=5.0)")
            
        elif sampling_mode == "LTXV":
            # LTXV使用类似Flux的配置，max_shift=2.05, base_shift=0.95
            max_shift = 2.05
            base_shift = 0.95
            tokens = 4096  # 默认token数
            
            x1 = 1024
            x2 = 4096
            mm = (max_shift - base_shift) / (x2 - x1)
            b = base_shift - mm * x1
            shift = tokens * mm + b
            
            sampling_base = comfy.model_sampling.ModelSamplingFlux
            sampling_type = comfy.model_sampling.CONST
            
            class ModelSamplingAdvanced(sampling_base, sampling_type):
                pass
            
            model_sampling = ModelSamplingAdvanced(model.model.model_config)
            model_sampling.set_parameters(shift=shift)
            m.add_object_patch("model_sampling", model_sampling)
            print(f"✅ [无极优化器] LTXV采样配置已应用 (shift={shift:.2f})")
            
        elif sampling_mode == "Cosmos":
            model_sampling = comfy.model_sampling.ModelSamplingCosmosRFlow(model.model.model_config)
            m.add_object_patch("model_sampling", model_sampling)
            print(f"✅ [无极优化器] Cosmos采样配置已应用")
            
        elif sampling_mode == "Lumina2":
            model_sampling = comfy.model_sampling.ModelSamplingDiscreteEDM(model.model.model_config)
            m.add_object_patch("model_sampling", model_sampling)
            print(f"✅ [无极优化器] Lumina2采样配置已应用")
            
        elif sampling_mode == "Flux2":
            # Flux2使用与Flux相同的配置
            max_shift = 1.15
            base_shift = 0.5
            width = 1024
            height = 1024
            
            x1 = 256
            x2 = 4096
            mm = (max_shift - base_shift) / (x2 - x1)
            b = base_shift - mm * x1
            calculated_shift = (width * height / (8 * 8 * 2 * 2)) * mm + b
            
            sampling_base = comfy.model_sampling.ModelSamplingFlux
            sampling_type = comfy.model_sampling.CONST
            
            class ModelSamplingAdvanced(sampling_base, sampling_type):
                pass
            
            model_sampling = ModelSamplingAdvanced(model.model.model_config)
            model_sampling.set_parameters(shift=calculated_shift)
            m.add_object_patch("model_sampling", model_sampling)
            print(f"✅ [无极优化器] Flux2采样配置已应用")
            
        elif sampling_mode == "QwenImage":
            # QwenImage使用SD3类似的Flow采样，shift默认3.0
            model_sampling = comfy.model_sampling.ModelSamplingDiscreteFlow(model.model.model_config)
            model_sampling.set_parameters(shift=3.0)
            m.add_object_patch("model_sampling", model_sampling)
            print(f"✅ [无极优化器] QwenImage采样配置已应用 (shift=3.0)")
            
        elif sampling_mode == "ZImage":
            # ZImage使用SD3类似的Flow采样，shift默认3.0
            model_sampling = comfy.model_sampling.ModelSamplingDiscreteFlow(model.model.model_config)
            model_sampling.set_parameters(shift=3.0)
            m.add_object_patch("model_sampling", model_sampling)
            print(f"✅ [无极优化器] ZImage采样配置已应用 (shift=3.0)")
            
        elif sampling_mode == "Ovis":
            # Ovis使用SD3类似的Flow采样，shift默认3.0
            model_sampling = comfy.model_sampling.ModelSamplingDiscreteFlow(model.model.model_config)
            model_sampling.set_parameters(shift=3.0)
            m.add_object_patch("model_sampling", model_sampling)
            print(f"✅ [无极优化器] Ovis采样配置已应用 (shift=3.0)")
        
        return m
    
    def _apply_rescale_cfg(self, model):
        """应用RescaleCFG - ComfyUI官方实现"""
        m = model.clone()
        
        def rescale_cfg(args):
            cond = args["cond"]
            uncond = args["uncond"]
            cond_scale = args["cond_scale"]
            sigma = args["sigma"]
            sigma = sigma.view(sigma.shape[:1] + (1,) * (cond.ndim - 1))
            x_orig = args["input"]
            
            # rescale cfg has to be done on v-pred model output
            x = x_orig / (sigma * sigma + 1.0)
            cond = ((x - (x_orig - cond)) * (sigma ** 2 + 1.0) ** 0.5) / (sigma)
            uncond = ((x - (x_orig - uncond)) * (sigma ** 2 + 1.0) ** 0.5) / (sigma)
            
            # rescalecfg
            x_cfg = uncond + cond_scale * (cond - uncond)
            ro_pos = torch.std(cond, dim=(1,2,3), keepdim=True)
            ro_cfg = torch.std(x_cfg, dim=(1,2,3), keepdim=True)
            
            x_rescaled = x_cfg * (ro_pos / (ro_cfg + 1e-8))
            x_final = 0.7 * x_rescaled + (1 - 0.7) * x_cfg
            
            return x_orig - (x - x_final) * sigma
        
        m.set_model_sampler_cfg_function(rescale_cfg)
        print(f"✅ [无极优化器] RescaleCFG已应用")
        return m
    
    def _apply_cfg_zero_star(self, model):
        """应用CFGZeroStar - KJNodes实现"""
        try:
            # 使用预加载的KJNodes模块
            global _KJMODULE
            if _KJMODULE is None:
                print(f"⚠️ [无极优化器] KJNodes模块未加载，跳过CFGZeroStar")
                return model
            
            cfg_node = _KJMODULE.CFGZeroStarAndInit()
            model = cfg_node.patch(model, True, 0)[0]
            print(f"✅ [无极优化器] CFGZeroStar已应用")
            return model
        except Exception as e:
            print(f"⚠️ [无极优化器] CFGZeroStar应用失败: {e}")
            return model
    
    def _apply_cfg_norm(self, model, strength):
        """应用CFGNorm - ComfyUI官方实现"""
        m = model.clone()
        
        def cfg_norm(args):
            cond_p = args['cond_denoised']
            pred_text_ = args["denoised"]
            
            norm_full_cond = torch.norm(cond_p, dim=1, keepdim=True)
            norm_pred_text = torch.norm(pred_text_, dim=1, keepdim=True)
            scale = (norm_full_cond / (norm_pred_text + 1e-8)).clamp(min=0.0, max=1.0)
            return pred_text_ * scale * strength
        
        m.set_model_sampler_post_cfg_function(cfg_norm)
        print(f"✅ [无极优化器] CFGNorm已应用 (强度: {strength})")
        return m
    
    def _apply_sage_attention(self, model):
        """应用SageAttention - KJNodes实现"""
        try:
            # 使用预加载的KJNodes模块
            global _KJMODULE
            if _KJMODULE is None:
                print(f"⚠️ [无极优化器] KJNodes模块未加载，跳过SageAttention")
                return model
            
            sage_node = _KJMODULE.PathchSageAttentionKJ()
            model = sage_node.patch(model, "auto")[0]
            print(f"✅ [无极优化器] SageAttention已应用")
            return model
        except Exception as e:
            print(f"⚠️ [无极优化器] SageAttention应用失败: {e}")
            return model
    
    def _apply_torch_compile(self, model):
        """应用Torch编译优化"""
        try:
            import torch
            
            # 检测PyTorch版本
            version = torch.__version__.split('+')[0]
            version_parts = version.split('.')
            major = int(version_parts[0])
            minor = int(version_parts[1]) if len(version_parts) > 1 else 0
            patch = int(version_parts[2]) if len(version_parts) > 2 else 0
            
            # PyTorch 2.5+在Windows上torch.compile与Triton有兼容性问题，自动跳过
            # 版本号比较：2.5.0 及以上跳过
            version_tuple = (major, minor, patch)
            if version_tuple >= (2, 5, 0):
                print(f"⚠️ [无极优化器] PyTorch {version} 的torch.compile与当前环境不兼容，已自动跳过")
                return model
            
            m = model.clone()
            diffusion_model = m.get_model_object("diffusion_model")
            
            # 应用torch.compile
            compiled_model = torch.compile(
                diffusion_model,
                mode="reduce-overhead",
                backend="inductor"
            )
            
            m.add_object_patch("diffusion_model", compiled_model)
            print(f"✅ Torch编译已应用")
            return m
        except Exception as e:
            print(f"⚠️ Torch编译失败: {e}")
            return model


class WujiSampler:
    """
    ☯️无极采样器 - 直接调用官方KSamplerAdvanced + VAEDecode
    """
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "模型": ("MODEL",),
                "添加噪波": (["enable", "disable"], ),
                "种子": ("INT", {"default": 0, "min": 0, "max": 0xffffffffffffffff, "control_after_generate": True}),
                "步数": ("INT", {"default": 8, "min": 1, "max": 10000}),
                "CFG": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 100.0, "step": 0.1, "round": 0.01}),
                "采样器": (comfy.samplers.SAMPLER_NAMES,),
                "调度器": (comfy.samplers.SCHEDULER_NAMES,),
                "正向条件": ("CONDITIONING",),
                "负向条件": ("CONDITIONING",),
                "潜空间图像": ("LATENT",),
                "开始步数": ("INT", {"default": 0, "min": 0, "max": 10000}),
                "结束步数": ("INT", {"default": 10000, "min": 0, "max": 10000}),
                "返回剩余噪波": (["disable", "enable"], ),
                "VAE": ("VAE",),
            }
        }
    
    RETURN_TYPES = ("LATENT", "IMAGE")
    RETURN_NAMES = ("潜空间", "图像")
    FUNCTION = "sample"
    CATEGORY = "☯️无极工具箱"
    
    # 类级别缓存，避免重复创建实例
    _sampler_instance = None
    _decoder_instance = None
    
    def sample(self, 模型, 添加噪波, 种子, 步数, CFG, 采样器, 调度器, 
               正向条件, 负向条件, 潜空间图像, 开始步数, 结束步数, 返回剩余噪波, VAE):
        
        print("☯️ [无极采样器] 采样中...")
        
        # 1. 使用官方KSamplerAdvanced进行采样（复用实例）
        if self._sampler_instance is None:
            self._sampler_instance = KSamplerAdvanced()
        
        latent_result = self._sampler_instance.sample(
            模型, 添加噪波, 种子, 步数, CFG, 采样器, 调度器,
            正向条件, 负向条件, 潜空间图像, 开始步数, 结束步数, 返回剩余噪波
        )
        
        # KSamplerAdvanced 返回的是 tuple，需要取第一个元素（latent dict）
        if isinstance(latent_result, tuple):
            latent = latent_result[0]
        else:
            latent = latent_result
        
        # 2. 使用官方VAEDecode解码图像（复用实例）
        if self._decoder_instance is None:
            self._decoder_instance = VAEDecode()
        
        image_result = self._decoder_instance.decode(VAE, latent)
        
        # VAEDecode 返回的也是 tuple，需要取第一个元素（image tensor）
        if isinstance(image_result, tuple):
            image = image_result[0]
        else:
            image = image_result
        
        print("✅ [无极采样器] 完成")
        
        return (latent, image)


class WujiImageLoader:
    """
    ☯️无极图像加载器 - 百万像素比例缩放 + BEN2抠图
    直接串联官方节点，保持数据格式不变
    """

    @classmethod
    def INPUT_TYPES(cls):
        input_dir = folder_paths.get_input_directory()
        files = []
        if os.path.exists(input_dir):
            files = [f for f in os.listdir(input_dir) if os.path.isfile(os.path.join(input_dir, f))]
        if not files:
            files = ["请上传图像"]

        return {
            "required": {
                "图像": (sorted(files), {"image_upload": True}),
                "百万像素": ("FLOAT", {"default": 1.0, "min": 0.25, "max": 16.0, "step": 0.25, "display": "number"}),
                "BEN2抠图": ("BOOLEAN", {"default": False}),
            },
            "optional": {
                "细化前景": ("BOOLEAN", {"default": False}),
                "背景": (["透明", "白色", "黑色"], {"default": "透明"}),
            }
        }

    RETURN_TYPES = ("IMAGE", "MASK")
    RETURN_NAMES = ("图像", "遮罩")
    FUNCTION = "load_image"
    CATEGORY = "☯️无极工具箱"

    def load_image(self, 图像, 百万像素, BEN2抠图, 细化前景=False, 背景="透明"):
        import math

        print("\n" + "="*50)
        print("☯️ [无极图像加载器] 加载图像...")
        print("="*50)

        # 1. 使用官方LoadImage加载图像
        loader = LoadImage()
        img, mask = loader.load_image(图像)

        # 2. 计算目标尺寸（保持原图比例）
        orig_h = img.shape[1]
        orig_w = img.shape[2]
        orig_ratio = orig_w / orig_h

        target_pixels = 百万像素 * 1000000
        target_h = math.sqrt(target_pixels / orig_ratio)
        target_w = target_h * orig_ratio

        target_w = int(math.ceil(target_w / 8.0) * 8)
        target_h = int(math.ceil(target_h / 8.0) * 8)

        print(f"[无极图像加载器] 原图尺寸: {orig_w}x{orig_h}")
        print(f"[无极图像加载器] 目标像素: {百万像素}MP")
        print(f"[无极图像加载器] 缩放后尺寸: {target_w}x{target_h}")

        # 3. 使用官方ImageScale进行缩放
        scaler = ImageScale()
        img = scaler.upscale(img, "lanczos", target_w, target_h, "center")[0]  # 返回的是元组，取第一个元素

        # 同步缩放mask（ImageScale只处理图像，不处理mask）
        if mask is not None and mask.shape[1] != target_h and mask.shape[2] != target_w:
            import torch.nn.functional as F
            # mask是 (B, H, W)，需要变成 (B, 1, H, W) 进行interpolate
            mask_resized = F.interpolate(
                mask.unsqueeze(1),  # (B, 1, H, W)
                size=(target_h, target_w),
                mode='bilinear',
                align_corners=False
            ).squeeze(1)  # (B, H, W)
            mask = mask_resized

        # 4. BEN2抠图处理
        if BEN2抠图:
            print("[无极图像加载器] 启用BEN2抠图...")
            try:
                # 直接使用ComfyUI的NODE_CLASS_MAPPINGS来获取节点
                # 这样可以避免相对导入问题
                import nodes
                
                # 查找imageRemBg节点
                rembg_node_class = None
                for node_id, node_class in nodes.NODE_CLASS_MAPPINGS.items():
                    if node_id == "easy removeBackground" or (hasattr(node_class, '__name__') and node_class.__name__ == "imageRemBg"):
                        rembg_node_class = node_class
                        break
                
                if rembg_node_class is None:
                    raise ImportError("未找到ComfyUI-Easy-Use的easy removeBackground节点，请确保已安装该插件")

                # 参数映射
                bg_map = {"透明": "none", "白色": "white", "黑色": "black"}
                bg_param = bg_map.get(背景, "none")

                # 调用抠图节点
                rembg_node = rembg_node_class()
                result = rembg_node.remove(
                    rem_mode="BEN2",
                    images=img,
                    image_output="Hide",
                    save_prefix="ComfyUI",
                    add_background=bg_param,
                    refine_foreground=细化前景
                )

                # 获取结果
                if isinstance(result, dict) and "result" in result:
                    img, mask = result["result"]
                else:
                    img, mask = result

                print("✅ [无极图像加载器] BEN2抠图完成")

            except Exception as e:
                print(f"⚠️ [无极图像加载器] BEN2抠图失败: {e}")
                import traceback
                traceback.print_exc()

        print("✅ [无极图像加载器] 图像加载完成!")
        print("="*50 + "\n")
        
        return (img, mask)


class WujiEditor:
    """
    ☯️无极编辑器 - 直接调用官方CLIPTextEncode + 风格选择器
    """
    
    @classmethod
    def INPUT_TYPES(cls):
        # 加载风格预设
        styles = {}
        styles_file = os.path.join(os.path.dirname(__file__), "styles.json")
        if os.path.exists(styles_file):
            try:
                with open(styles_file, 'r', encoding='utf-8') as f:
                    styles = json.load(f)
            except:
                pass
        
        # 构建风格选项
        style_options = {}
        for category, items in styles.items():
            style_list = list(items.keys())
            if "关闭" not in style_list:
                style_list = ["关闭"] + style_list
            style_options[category] = style_list
        
        return {
            "required": {
                "CLIP": ("CLIP",),
                "宽度": ("INT", {"default": 512, "min": 64, "max": 16384, "step": 8}),
                "高度": ("INT", {"default": 512, "min": 64, "max": 16384, "step": 8}),
                "正向提示词": ("STRING", {"multiline": True, "default": "", "placeholder": "正向提示词..."}),
                "负向提示词": ("STRING", {"multiline": True, "default": "", "placeholder": "负向提示词..."}),
                "流派": (style_options.get("流派", ["关闭"]), {"default": "关闭"}),
                "媒介": (style_options.get("媒介", ["关闭"]), {"default": "关闭"}),
                "摄影": (style_options.get("摄影", ["关闭"]), {"default": "关闭"}),
                "动漫": (style_options.get("动漫", ["关闭"]), {"default": "关闭"}),
                "游戏": (style_options.get("游戏", ["关闭"]), {"default": "关闭"}),
                "负向预设": (style_options.get("负向", ["关闭"]), {"default": "关闭"}),
            }
        }

    RETURN_TYPES = ("CONDITIONING", "CONDITIONING", "LATENT")
    RETURN_NAMES = ("正向条件", "负向条件", "空Latent")
    FUNCTION = "encode"
    CATEGORY = "☯️无极工具箱"

    def encode(self, CLIP, 正向提示词, 负向提示词, 流派, 媒介, 摄影, 动漫, 游戏, 负向预设, 宽度, 高度):
        print("\n" + "="*50)
        print("☯️ [无极编辑器] 处理提示词...")
        print("="*50)
        
        # 加载风格预设
        styles = {}
        styles_file = os.path.join(os.path.dirname(__file__), "styles.json")
        if os.path.exists(styles_file):
            try:
                with open(styles_file, 'r', encoding='utf-8') as f:
                    styles = json.load(f)
            except:
                pass
        
        # 组合正向提示词
        positive_parts = []
        if 正向提示词:
            positive_parts.append(正向提示词)
            
        for category, selected in [("流派", 流派), ("媒介", 媒介), 
                                   ("摄影", 摄影), ("动漫", 动漫), ("游戏", 游戏)]:
            if selected != "关闭" and category in styles:
                style_text = styles[category].get(selected, "")
                if style_text:
                    positive_parts.append(style_text)
        
        final_positive = ", ".join(positive_parts) if positive_parts else "masterpiece, best quality"
        
        # 组合负向提示词
        negative_parts = []
        if 负向提示词:
            negative_parts.append(负向提示词)
        
        if 负向预设 != "关闭" and "负向" in styles:
            neg_text = styles["负向"].get(负向预设, "")
            if neg_text:
                negative_parts.append(neg_text)
        
        final_negative = ", ".join(negative_parts)
        
        print(f"[无极编辑器] 正向: {final_positive[:100]}...")
        print(f"[无极编辑器] 负向: {final_negative[:100]}...")
        
        # 使用官方CLIPTextEncode编码
        encoder = CLIPTextEncode()
        positive_cond = encoder.encode(CLIP, final_positive)
        negative_cond = encoder.encode(CLIP, final_negative)

        # 生成空Latent（直接创建，避免模型加载）
        import torch
        latent = torch.zeros([1, 4, 高度 // 8, 宽度 // 8])
        empty_latent = {"samples": latent, "downscale_ratio_spacial": 8}

        print("✅ [无极编辑器] 编码完成!")
        print("="*50 + "\n")

        return (positive_cond[0], negative_cond[0], empty_latent)



