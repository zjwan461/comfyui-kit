# -*- coding: utf-8 -*-
"""
☯️无极清理器
显存和内存清理工具
"""
import gc
import torch
import comfy.model_management


class AnyType(str):
    """任意类型"""
    def __ne__(self, __value: object) -> bool:
        return False
    def __eq__(self, __value: object) -> bool:
        return True

any_type = AnyType("*")


class WujiCleaner:
    """
    ☯️无极清理器
    清理显存和内存
    """
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "清理模式": (["基础清理", "极限清理"], {"default": "基础清理"}),
            },
            "optional": {
                "任意连接": (any_type, {}),
            },
        }

    RETURN_TYPES = (any_type,)
    RETURN_NAMES = ("任意连接",)
    FUNCTION = "clean_system"
    CATEGORY = "☯️无极工具箱"
    OUTPUT_NODE = True

    def clean_system(self, **kwargs):
        清理模式 = kwargs.get("清理模式", "基础清理")
        任意连接 = kwargs.get("任意连接")

        print("\n" + "="*50)
        print(f"☯️ [无极清理器] {清理模式}中...")
        print("="*50)

        with torch.inference_mode():
            if 清理模式 == "基础清理":
                # 基础清理：只清理垃圾回收
                gc.collect()
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                print("[无极清理器] 基础清理完成")
                return (任意连接,)

            # 极限清理：卸载所有模型并清理
            try:
                comfy.model_management.unload_all_models()
                gc.collect()
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                    torch.cuda.ipc_collect()
                print("[无极清理器] 极限清理完成")
            except Exception as e:
                print(f"[无极清理器] 清理出错: {e}")

            return (任意连接,)
