# -*- coding: utf-8 -*-
"""
☯️无极风格选择器
直接读取styles.json，不依赖其他模块
"""
import os
import json
import time

# 全局缓存
_STYLES_CACHE = None
_CACHE_TIMESTAMP = 0
_CACHE_DURATION = 60  # 缓存60秒

def load_wuji_styles():
    """加载风格预设 - 带缓存机制"""
    global _STYLES_CACHE, _CACHE_TIMESTAMP
    
    current_time = time.time()
    
    # 检查缓存是否有效
    if _STYLES_CACHE is not None and (current_time - _CACHE_TIMESTAMP) < _CACHE_DURATION:
        return _STYLES_CACHE
    
    # 重新加载
    styles_file = os.path.join(os.path.dirname(__file__), "styles.json")
    if os.path.exists(styles_file):
        try:
            with open(styles_file, 'r', encoding='utf-8') as f:
                _STYLES_CACHE = json.load(f)
                _CACHE_TIMESTAMP = current_time
                return _STYLES_CACHE
        except:
            pass
    
    _STYLES_CACHE = {}
    return {}


class WujiStyleSelector:
    """
    ☯️无极风格选择器
    独立的风格选择节点
    """
    
    @classmethod
    def INPUT_TYPES(cls):
        styles_data = load_wuji_styles()
        
        style_options = {}
        for category, styles in styles_data.items():
            if category != "负向":
                style_list = list(styles.keys())
                if "关闭" not in style_list:
                    style_list = ["关闭"] + style_list
                style_options[category] = style_list
        
        return {
            "required": {
                "正面提示词": ("STRING", {
                    "default": "", 
                    "multiline": True,
                    "placeholder": "手动输入正面提示词..."
                }),
            },
            "optional": {
                "流派": (style_options.get("流派", ["关闭"]), {"default": "写实风格"}),
                "媒介": (style_options.get("媒介", ["关闭"]), {"default": "关闭"}),
                "摄影": (style_options.get("摄影", ["关闭"]), {"default": "关闭"}),
                "动漫": (style_options.get("动漫", ["关闭"]), {"default": "关闭"}),
                "游戏": (style_options.get("游戏", ["关闭"]), {"default": "关闭"}),
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("正面文本",)
    FUNCTION = "process"
    CATEGORY = "☯️无极工具箱"
    
    def process(self, **kwargs):
        print("\n" + "="*50)
        print("☯️ [无极风格选择器] 处理中...")
        print("="*50)

        正面提示词 = kwargs.get("正面提示词", "")
        styles_data = load_wuji_styles()
            
        positive_parts = []
        if 正面提示词 and 正面提示词.strip():
            positive_parts.append(正面提示词.strip())
            
        positive_categories = ["流派", "媒介", "摄影", "动漫", "游戏"]
        for category in positive_categories:
            selected = kwargs.get(category, "关闭")
            if selected and selected != "关闭":
                if category in styles_data:
                    style_prompt = styles_data[category].get(selected, "")
                    if style_prompt and style_prompt.strip():
                        positive_parts.append(style_prompt.strip())
                        
        return (", ".join(positive_parts) if positive_parts else "",)


class WujiEditor:
    """
    ☯️无极风格编辑器
    带CLIP编码的风格编辑器 - 移除文本输出接口
    """
    
    @classmethod
    def INPUT_TYPES(cls):
        styles_data = load_wuji_styles()
        
        style_options = {}
        for category, styles in styles_data.items():
            style_list = list(styles.keys())
            if "关闭" not in style_list:
                style_list = ["关闭"] + style_list
            style_options[category] = style_list
        
        return {
            "required": {
                "CLIP": ("CLIP",),
                "正面提示词": ("STRING", {
                    "default": "", 
                    "multiline": True,
                    "placeholder": "手动输入正面提示词..."
                }),
                "负面提示词": ("STRING", {
                    "default": "", 
                    "multiline": True,
                    "placeholder": "手动输入负面提示词..."
                }),
            },
            "optional": {
                "流派": (style_options.get("流派", ["关闭"]), {"default": "写实风格"}),
                "媒介": (style_options.get("媒介", ["关闭"]), {"default": "关闭"}),
                "摄影": (style_options.get("摄影", ["关闭"]), {"default": "关闭"}),
                "动漫": (style_options.get("动漫", ["关闭"]), {"default": "关闭"}),
                "游戏": (style_options.get("游戏", ["关闭"]), {"default": "关闭"}),
                "负向预设": (style_options.get("负向", ["关闭"]), {"default": "关闭"}),
            }
        }
    
    RETURN_TYPES = ("CONDITIONING", "CONDITIONING")
    RETURN_NAMES = ("正面条件", "负面条件")
    FUNCTION = "process"
    CATEGORY = "☯️无极工具箱"
    
    def process(self, CLIP, 正面提示词, 负面提示词, **kwargs):
        print("\n" + "="*50)
        print("☯️ [无极风格编辑器] 处理中...")
        print("="*50)

        styles_data = load_wuji_styles()
        
        # 组合正向提示词
        positive_parts = []
        if 正面提示词 and 正面提示词.strip():
            positive_parts.append(正面提示词.strip())
            
        positive_categories = ["流派", "媒介", "摄影", "动漫", "游戏"]
        for category in positive_categories:
            selected = kwargs.get(category, "关闭")
            if selected and selected != "关闭":
                if category in styles_data:
                    style_prompt = styles_data[category].get(selected, "")
                    if style_prompt and style_prompt.strip():
                        positive_parts.append(style_prompt.strip())
        
        final_positive = ", ".join(positive_parts) if positive_parts else "masterpiece, best quality"
        
        # 组合负向提示词
        negative_parts = []
        if 负面提示词 and 负面提示词.strip():
            negative_parts.append(负面提示词.strip())
        
        selected_neg = kwargs.get("负向预设", "关闭")
        if selected_neg and selected_neg != "关闭":
            if "负向" in styles_data:
                neg_preset = styles_data["负向"].get(selected_neg, "")
                if neg_preset:
                    negative_parts.append(neg_preset)
        
        final_negative = ", ".join(negative_parts)
        
        print(f"[无极风格编辑器] 正向: {final_positive[:100]}...")
        print(f"[无极风格编辑器] 负向: {final_negative[:100]}...")
        
        # 使用官方CLIPTextEncode
        from nodes import CLIPTextEncode
        encoder = CLIPTextEncode()
        positive_cond = encoder.encode(CLIP, final_positive)
        negative_cond = encoder.encode(CLIP, final_negative)
        
        print("[无极风格编辑器] 编码完成!")
        print("="*50)
        
        return (positive_cond[0], negative_cond[0])
