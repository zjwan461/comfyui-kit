# -*- coding: utf-8 -*-
"""
ComfyUI-WujiToolbox
 无极工具箱 - 基础版
直接调用官方API，确保与官方同步更新
"""

import os
import sys

print("\n" + "="*50)
print(" [无极工具箱] 开始加载...")
print("="*50)

NODE_CLASS_MAPPINGS = {}
NODE_DISPLAY_NAME_MAPPINGS = {}

# 核心节点
try:
    from .nodes import WujiLoader, WujiOptimizer, WujiSampler, WujiImageLoader, WujiEditor
    NODE_CLASS_MAPPINGS["WujiLoader"] = WujiLoader
    NODE_CLASS_MAPPINGS["WujiOptimizer"] = WujiOptimizer
    NODE_CLASS_MAPPINGS["WujiSampler"] = WujiSampler
    NODE_CLASS_MAPPINGS["WujiImageLoader"] = WujiImageLoader
    NODE_CLASS_MAPPINGS["WujiEditor"] = WujiEditor
    NODE_DISPLAY_NAME_MAPPINGS["WujiLoader"] = "☯️无极加载器"
    NODE_DISPLAY_NAME_MAPPINGS["WujiOptimizer"] = "☯️无极优化器"
    NODE_DISPLAY_NAME_MAPPINGS["WujiSampler"] = "☯️无极采样器"
    NODE_DISPLAY_NAME_MAPPINGS["WujiImageLoader"] = "☯️无极图像加载器"
    NODE_DISPLAY_NAME_MAPPINGS["WujiEditor"] = "☯️无极编辑器"
    print(" 核心5节点加载成功")
except Exception as e:
    print(f" 核心节点加载失败: {e}")
    import traceback
    traceback.print_exc()

# 风格选择器
try:
    from .wuji_style_selector import WujiStyleSelector, WujiEditor as WujiStyleEditor
    NODE_CLASS_MAPPINGS["WujiStyleSelector"] = WujiStyleSelector
    NODE_CLASS_MAPPINGS["WujiStyleEditor"] = WujiStyleEditor
    NODE_DISPLAY_NAME_MAPPINGS["WujiStyleSelector"] = "☯️无极风格选择器"
    NODE_DISPLAY_NAME_MAPPINGS["WujiStyleEditor"] = "☯️无极风格编辑器"
    print(" 风格选择器加载成功")
except Exception as e:
    print(f" 风格选择器加载失败: {e}")

# 无极畅联
try:
    from .wuji_smooth_link import WujiSmoothLink
    NODE_CLASS_MAPPINGS["WujiSmoothLink"] = WujiSmoothLink
    NODE_DISPLAY_NAME_MAPPINGS["WujiSmoothLink"] = "☯️无极畅联"
    print(" 畅联加载成功")
except Exception as e:
    print(f"⚠ 畅联加载失败: {e}")

# 清理器
try:
    from .wuji_cleaner import WujiCleaner
    NODE_CLASS_MAPPINGS["WujiCleaner"] = WujiCleaner
    NODE_DISPLAY_NAME_MAPPINGS["WujiCleaner"] = "☯️无极清理器"
    print(" 清理器加载成功")
except Exception as e:
    print(f"⚠ 清理器加载失败: {e}")

# LLM润词器 - 从子模块导入
try:
    from .wuji_llm_prompt_expander.wuji_llm_prompt_expander_node import WujiLLMPromptExpander
    NODE_CLASS_MAPPINGS["WujiLLMPromptExpander"] = WujiLLMPromptExpander
    NODE_DISPLAY_NAME_MAPPINGS["WujiLLMPromptExpander"] = "☯️无极LLM润词器"
    print(" LLM润词器加载成功")
except Exception as e:
    print(f" LLM润词器加载失败: {e}")

# 放大器 - 从子模块导入
try:
    from .wuji_upscaler.wuji_upscaler_node import WujiUpscaler
    NODE_CLASS_MAPPINGS["WujiUpscaler"] = WujiUpscaler
    NODE_DISPLAY_NAME_MAPPINGS["WujiUpscaler"] = "☯️无极放大器"
    print(" 放大器加载成功")
except Exception as e:
    print(f" 放大器加载失败: {e}")

print("="*50)
print(f" [无极工具箱] 加载完成 - 共 {len(NODE_CLASS_MAPPINGS)} 个节点")
print("="*50 + "\n")

__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS"]
