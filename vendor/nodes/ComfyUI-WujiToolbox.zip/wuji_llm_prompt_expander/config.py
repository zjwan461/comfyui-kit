import os
import json

# 配置文件路径：移至 .settings 隐藏目录以防止触发 ComfyUI 热重载
_BASE_DIR = os.path.dirname(os.path.dirname(__file__))
_SETTINGS_DIR = os.path.join(_BASE_DIR, '.settings')
if not os.path.exists(_SETTINGS_DIR):
    try: os.makedirs(_SETTINGS_DIR)
    except: pass

CONFIG_FILE_PATH = os.path.join(_SETTINGS_DIR, 'prompt_expander_config.json')

# 默认配置
DEFAULT_CONFIG = {
    "api_keys": {
        "zhipu": "",
        "gemini": "",
        "openai": ""
    },
    "default_provider": "gemini",
    "default_model": "gemini-3-flash",
    "default_language": "中文",
    "default_temperature": 0.7,
    "default_max_tokens": 2048
}

class ConfigManager:
    """配置管理器"""
    
    def __init__(self):
        self.config = self.load_config()
    
    def load_config(self):
        """加载配置"""
        if os.path.exists(CONFIG_FILE_PATH):
            try:
                with open(CONFIG_FILE_PATH, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    # 合并默认配置
                    merged_config = DEFAULT_CONFIG.copy()
                    merged_config.update(config)
                    return merged_config
            except Exception as e:
                print(f"☯️ [无极工具箱] 警告：无法加载提示词扩展配置文件: {e}")
                return DEFAULT_CONFIG
        else:
            # 创建默认配置文件
            self.save_config(DEFAULT_CONFIG)
            return DEFAULT_CONFIG
    
    def save_config(self, config):
        """保存配置"""
        try:
            with open(CONFIG_FILE_PATH, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"☯️ [无极工具箱] 警告：无法保存提示词扩展配置文件: {e}")
    
    def get_api_key(self, provider):
        """获取API密钥"""
        # 优先从环境变量获取
        env_var = f"{provider.upper()}_API_KEY"
        if env_var in os.environ:
            return os.environ[env_var]
        
        # 从配置文件获取
        return self.config.get("api_keys", {}).get(provider, "")
    
    def update_api_key(self, provider, api_key):
        """更新API密钥"""
        if "api_keys" not in self.config:
            self.config["api_keys"] = {}
        self.config["api_keys"][provider] = api_key
        self.save_config(self.config)
    
    def get(self, key, default=None):
        """获取配置项"""
        return self.config.get(key, default)
    
    def set(self, key, value):
        """设置配置项"""
        self.config[key] = value
        self.save_config(self.config)

# 全局配置管理器实例
config_manager = ConfigManager()
