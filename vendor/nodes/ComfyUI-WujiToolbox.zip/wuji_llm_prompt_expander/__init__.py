"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
☯️ 无极LLM润词器
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

描述:
   - 支持本地 Qwen3 (4b, 8b) 提示词扩写
   - 支持在线 GLM4.6v-flash 提示词扩写
   - 支持在线 Gemini3-flash 提示词扩写
   - 支持在线 GPT 系列提示词扩写
   - 支持多模态输入（图像、视频）
   - 集成本地模型量化与极速模式优化

作者: AI-无极
版本: v1.1.0

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

# 导入节点类
from .wuji_llm_prompt_expander_node import WujiLLMPromptExpander

# 节点注册映射
NODE_CLASS_MAPPINGS = {
    "WujiLLMPromptExpander": WujiLLMPromptExpander
}

# 节点显示名称映射
NODE_DISPLAY_NAME_MAPPINGS = {
    "WujiLLMPromptExpander": "☯️无极LLM润词器"
}

# 导出变量
__all__ = [
    "NODE_CLASS_MAPPINGS",
    "NODE_DISPLAY_NAME_MAPPINGS"
]
