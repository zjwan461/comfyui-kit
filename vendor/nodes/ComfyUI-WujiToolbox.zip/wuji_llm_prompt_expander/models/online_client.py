import os
import json
import base64
import aiohttp
import asyncio
import numpy as np
import cv2

# 配置文件路径
CONFIG_FILE_PATH = os.path.join(os.path.dirname(__file__), '../config.json')

# API提供商映射
API_PROVIDER_MAP = {
    "gemini": {
        "base_url": "https://generativelanguage.googleapis.com",
        "env_var": "GEMINI_API_KEY"
    },
    "T8": {
        "base_url": "https://ai.t8star.cn",
        "env_var": "T8_API_KEY"
    },
    "zhipu": {
        "base_url": "https://open.bigmodel.cn/api/paas/v4",
        "env_var": "ZHIPU_API_KEY"
    }
}

# 模型类型映射
MODEL_TYPE_MAP = {
    "gemini-3-flash-preview-nothinking": "gemini",
    "glm-4.6v-flash": "zhipu",
    "gpt-5.2-2025-12-11": "openai"
}

def get_api_key(provider: str, api_key_override: str = "") -> str:
    """获取API密钥，优先级：节点输入 > 环境变量 > 配置文件"""
    if api_key_override and api_key_override.strip():
        return api_key_override.strip()
    
    env_var = API_PROVIDER_MAP.get(provider, {}).get("env_var", "")
    if env_var:
        key = os.environ.get(env_var)
        if key: return key.strip()
    
    if os.path.exists(CONFIG_FILE_PATH):
        try:
            with open(CONFIG_FILE_PATH, 'r', encoding='utf-8') as f:
                config = json.load(f)
            return config.get('api_keys', {}).get(provider, "").strip()
        except: pass
    return ""

def encode_image_tensor(image_tensor) -> str:
    """将ComfyUI tensor转换为base64 PNG (使用OpenCV)"""
    img_np = image_tensor.cpu().numpy() if hasattr(image_tensor, 'cpu') else np.array(image_tensor)
    if img_np.max() <= 1.0:
        img_np = (img_np * 255).astype(np.uint8)
    
    # RGB to BGR for OpenCV
    if img_np.shape[-1] == 3:
        img_np = cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR)
    elif img_np.shape[-1] == 4:
        img_np = cv2.cvtColor(img_np, cv2.COLOR_RGBA2BGRA)
        
    _, buffer = cv2.imencode('.png', img_np)
    return base64.b64encode(buffer).decode('utf-8')

class OnlineModelClient:
    """统一在线模型客户端"""
    
    def __init__(self, api_key: str, provider: str):
        self.api_key = api_key
        self.provider = provider
        self.base_url = API_PROVIDER_MAP.get(provider, {}).get("base_url", "")
        self.session = None
        # 优化超时设置，根据模型类型设置不同超时
        self.timeout = aiohttp.ClientTimeout(
            total=60,  # 总超时时间
            connect=10,  # 连接超时
            sock_read=40,  # 读取超时
            sock_connect=10  # socket连接超时
        )
        
        # 加载提供商配置
        config = {}
        if os.path.exists(CONFIG_FILE_PATH):
            try:
                with open(CONFIG_FILE_PATH, 'r', encoding='utf-8') as f:
                    config = json.load(f)
            except Exception as e:
                print(f"[无极工具箱] 警告：无法读取配置文件: {e}")
        
        # 更新base_url
        if 'api_providers' in config and provider in config['api_providers']:
            provider_config = config['api_providers'][provider]
            self.base_url = provider_config.get('base_url', self.base_url)
        
        # 优化连接池配置
        self.connector = aiohttp.TCPConnector(
            ssl=False,  # 使用ssl=False替代verify_ssl=False，避免互斥参数错误
            family=2,  # IPv4
            limit=10,  # 最大并发连接数
            limit_per_host=5,  # 每个主机的最大并发连接数
            keepalive_timeout=30,  # 连接保持活跃的时间
            force_close=False  # 请求完成后不立即关闭连接，保持连接复用
        )
    
    async def __aenter__(self):
        # 默认尝试使用系统代理，如果失败则在具体请求时处理
        self.session = aiohttp.ClientSession(
            trust_env=True, 
            connector=self.connector,
            raise_for_status=False,
            timeout=self.timeout
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    def _create_session(self, use_proxy=True):
        """创建一个新的 session，可选是否信任环境代理"""
        # 如果不使用代理，创建一个全新的 connector 以避免任何共享状态
        connector = self.connector
        if not use_proxy:
            connector = aiohttp.TCPConnector(ssl=False, family=2)
            
        return aiohttp.ClientSession(
            trust_env=use_proxy,
            connector=connector,
            raise_for_status=False,
            timeout=self.timeout
        )
    
    def _get_endpoint(self, model: str, model_type: str) -> str:
        """获取API端点URL"""
        if self.provider == "T8":
            # 如果base_url以v1结尾，直接拼接
            if self.base_url.rstrip('/').endswith('v1'):
                return f"{self.base_url.rstrip('/')}/chat/completions"
            # 否则添加v1
            else:
                return f"{self.base_url.rstrip('/')}/v1/chat/completions"
            
        if model_type == "gemini":
            # Gemini API端点
            if self.base_url.rstrip('/').endswith(('v1', 'v1beta', 'v1alpha')):
                return f"{self.base_url.rstrip('/')}/models/{model}:generateContent"
            else:
                return f"{self.base_url.rstrip('/')}/v1beta/models/{model}:generateContent"
        elif model_type == "zhipu":
            # 智谱GLM API端点
            return f"{self.base_url.rstrip('/')}/chat/completions"
        elif model_type == "openai":
            # OpenAI GPT API端点
            return f"{self.base_url.rstrip('/')}/chat/completions"
        else:
            raise ValueError(f"不支持的模型类型: {model_type}")
    
    async def generate_content(
        self,
        model: str,
        contents: list,
        temperature: float = 0.7,
        top_p: float = 0.9,
        max_tokens: int = 2048,
        random_seed: int = 0
    ) -> str:
        """生成内容
        
        Args:
            model: 模型名称
            contents: 内容列表
            temperature: 温度参数
            top_p: top_p参数
            max_tokens: 最大生成令牌数
            
        Returns:
            生成的文本
        """
        if not self.session:
            self.session = self._create_session(use_proxy=True)
        
        # 确定模型类型
        model_type = MODEL_TYPE_MAP.get(model, "gemini")
        url = self._get_endpoint(model, model_type)
        
        # 针对 Zhipu 等 API 限制 seed 范围
        # ComfyUI 的 seed 往往非常大 (64位)，会导致 API 报 400 错误
        # Zhipu AI 要求 seed 为 [1, 2147483647]
        safe_seed = (random_seed % 2147483646) + 1
        
        # 封装请求逻辑以便重试（带代理/不带代理）
        async def do_request(session):
            # T8 提供商强制使用 OpenAI 格式
            if self.provider == "T8":
                target_model_type = "openai"
                target_url = self._get_endpoint(model, target_model_type)
                
                # T8 需要 Authorization 头
                auth_header = self.api_key
                if not auth_header.startswith("Bearer "):
                    auth_header = f"Bearer {auth_header}"
                    
                headers = {
                    "Content-Type": "application/json",
                    "Authorization": auth_header
                }
                
                # 构造消息
                messages = []
                for content in contents:
                    role = content.get("role", "user")
                    parts = content.get("parts", [])
                    
                    # OpenAI GPT格式
                    message_content = ""
                    for part in parts:
                        if 'text' in part:
                            message_content += part['text']
                        elif 'inline_data' in part:
                            # 简单的图像处理
                            message_content += f"\n![image](data:{part['inline_data']['mime_type']};base64,{part['inline_data']['data']})\n"
                    messages.append({
                        "role": role,
                        "content": message_content
                    })
                
                payload = {
                    "model": model,
                    "messages": messages,
                    "temperature": temperature,
                    "top_p": top_p,
                    "max_tokens": max_tokens,
                    "seed": safe_seed,
                    "stream": False
                }
                
                async with session.post(target_url, json=payload, headers=headers) as response:
                    if response.status != 200:
                        error_text = await response.text()
                        raise Exception(f"T8 API错误 {response.status}: {error_text}")
                    result = await response.json()
                    return result['choices'][0]['message']['content'] if 'choices' in result and result['choices'] else ""

            elif model_type == "gemini":
                # Gemini API请求格式
                payload = {
                    "contents": contents,
                    "generationConfig": {
                        "temperature": temperature,
                        "topP": top_p,
                        "maxOutputTokens": max_tokens,
                        "seed": safe_seed
                    }
                }
                headers = {
                    "Content-Type": "application/json",
                    "x-goog-api-key": self.api_key
                }
                
                async with session.post(url, json=payload, headers=headers) as response:
                    if response.status != 200:
                        error_text = await response.text()
                        raise Exception(f"Gemini API错误 {response.status}: {error_text}")
                    result = await response.json()
                    if 'candidates' in result and result['candidates']:
                        candidate = result['candidates'][0]
                        if 'content' in candidate and 'parts' in candidate['content']:
                            return "".join([part['text'] for part in candidate['content']['parts'] if 'text' in part])
                    return ""
            
            elif model_type in ["zhipu", "openai"]:
                # 智谱GLM和OpenAI GPT请求格式
                messages = []
                for content in contents:
                    role = content.get("role", "user")
                    parts = content.get("parts", [])
                    
                    if model_type == "zhipu":
                        message_content = []
                        for part in parts:
                            if 'text' in part:
                                message_content.append({"type": "text", "text": part['text']})
                            elif 'inline_data' in part:
                                message_content.append({"type": "image_url", "image_url": {"url": f"data:{part['inline_data']['mime_type']};base64,{part['inline_data']['data']}"}})
                        messages.append({"role": role, "content": message_content})
                    else:
                        message_content = ""
                        for part in parts:
                            if 'text' in part: message_content += part['text']
                            elif 'inline_data' in part: message_content += f"\n![image](data:{part['inline_data']['mime_type']};base64,{part['inline_data']['data']})\n"
                        messages.append({"role": role, "content": message_content})
                
                payload = {
                    "model": model,
                    "messages": messages,
                    "temperature": temperature,
                    "top_p": top_p,
                    "max_tokens": max_tokens,
                    "seed": safe_seed
                }
                headers = {
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {self.api_key}"
                }
                
                async with session.post(url, json=payload, headers=headers) as response:
                    if response.status == 429:
                        raise Exception("Rate limit reached (429)")
                    if response.status != 200:
                        error_text = await response.text()
                        raise Exception(f"{model_type} API错误 {response.status}: {error_text}")
                    result = await response.json()
                    return result['choices'][0]['message']['content'] if 'choices' in result and result['choices'] else ""
            
            return ""

        try:
            # 第一轮尝试：使用系统代理
            return await do_request(self.session)
        except Exception as e:
            err_str = str(e)
            # 扩展错误检测：如果包含 127.0.0.1:7890，或者明确的代理/连接错误
            is_proxy_error = any(x in err_str for x in ["127.0.0.1:7890", "proxy", "Proxy", "Cannot connect to host", "Connection refused"])
            
            if is_proxy_error:
                print(f"[无极工具箱] 检测到可能的代理故障或拒绝连接 ({err_str})，正在尝试强制直连重试...")
                
                # 备份并清除所有可能的代理环境变量
                proxy_vars = ['HTTP_PROXY', 'HTTPS_PROXY', 'http_proxy', 'https_proxy', 'ALL_PROXY', 'all_proxy', 'no_proxy', 'NO_PROXY']
                old_env = {var: os.environ.get(var) for var in proxy_vars}
                for var in proxy_vars:
                    if var in os.environ:
                        del os.environ[var]
                
                # 设置 NO_PROXY 确保 aiohttp 内部也看到直连需求
                os.environ['NO_PROXY'] = '*'
                
                try:
                    # 创建完全隔离的直连 session
                    # 使用全新的 connector，并显式禁用 trust_env
                    async with aiohttp.ClientSession(
                        trust_env=False, 
                        connector=aiohttp.TCPConnector(ssl=False, family=2),
                        timeout=self.timeout
                    ) as no_proxy_session:
                        return await do_request(no_proxy_session)
                except Exception as e2:
                    print(f"[无极工具箱] 强制直连依然失败: {e2}")
                    raise e2
                finally:
                    # 恢复环境变量
                    for var, val in old_env.items():
                        if val is not None:
                            os.environ[var] = val
                        elif var in os.environ:
                            del os.environ[var]
            else:
                raise e

def run_async(coro):
    """安全地运行异步协程，解决 ComfyUI 环境下的事件循环冲突"""
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        # 如果当前线程没有事件循环，创建一个新的
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    if loop.is_running():
        # 如果循环正在运行（ComfyUI 内部通常如此），使用 nest_asyncio 允许嵌套运行
        try:
            import nest_asyncio
            nest_asyncio.apply()
        except ImportError:
            raise RuntimeError("[无极工具箱] 检测到事件循环正在运行，但未安装 nest-asyncio。请在终端运行: pip install nest-asyncio 以修复此问题。")
        
    return loop.run_until_complete(coro)
