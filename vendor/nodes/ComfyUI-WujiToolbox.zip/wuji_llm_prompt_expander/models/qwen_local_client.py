import torch
import time
import json
import random
import platform
import psutil
import numpy as np
import cv2
from packaging import version
from PIL import Image
from enum import Enum
from pathlib import Path
import folder_paths
import gc

try:
    import transformers
    from transformers import AutoModelForImageTextToText, AutoProcessor, AutoTokenizer, BitsAndBytesConfig
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False

# 尝试导入 SageAttention
SAGE_ATTENTION_AVAILABLE = False
try:
    import sageattention
    SAGE_ATTENTION_AVAILABLE = True
except ImportError:
    pass

try:
    from huggingface_hub import snapshot_download as hf_snapshot_download
    HF_HUB_AVAILABLE = True
except ImportError:
    HF_HUB_AVAILABLE = False

# 尝试导入 ModelScope，如果不存在则使用 HuggingFace
try:
    from modelscope.hub.snapshot_download import snapshot_download as ms_snapshot_download
    MODELSCOPE_AVAILABLE = True
except ImportError:
    ms_snapshot_download = None
    MODELSCOPE_AVAILABLE = False
    # print("[Qwen3VL] ⚠️ ModelScope 未安装，ModelScope 模型将无法下载。请运行: pip install modelscope") # 降低日志噪音

# 获取当前文件所在目录的父目录 (wuji_llm_prompt_expander)
NODE_DIR = Path(__file__).parent.parent
CONFIG_PATH = NODE_DIR / "config_qwen.json"
MODEL_CONFIGS = {}

def load_model_configs():
    """加载模型配置文件"""
    global MODEL_CONFIGS
    try:
        with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
            MODEL_CONFIGS = json.load(f)
    except FileNotFoundError:
        print(f"错误: 配置文件未找到 {CONFIG_PATH}")
        MODEL_CONFIGS = {}
    except json.JSONDecodeError:
        print(f"错误: 配置文件解析失败")
        MODEL_CONFIGS = {}

if not MODEL_CONFIGS:
    load_model_configs()

class Quantization(str, Enum):
    """量化选项枚举"""
    Q4_BIT = "4-bit (节省显存)"
    Q8_BIT = "8-bit (平衡)"
    NONE = "None (FP16)"
    
    @classmethod
    def get_values(cls):
        return [item.value for item in cls]

def get_model_info(model_name: str) -> dict:
    """获取模型信息"""
    return MODEL_CONFIGS.get(model_name, {})

def get_device_info() -> dict:
    """获取设备信息"""
    gpu_info = {}
    if torch.cuda.is_available():
        props = torch.cuda.get_device_properties(0)
        total_mem = props.total_memory / 1024**3
        gpu_info = {
            "available": True,
            "total_memory": total_mem,
            "free_memory": total_mem - (torch.cuda.memory_allocated(0) / 1024**3)
        }
    else:
        gpu_info = {"available": False, "total_memory": 0, "free_memory": 0}

    sys_mem = psutil.virtual_memory()
    sys_mem_info = {
        "total": sys_mem.total / 1024**3,
        "available": sys_mem.available / 1024**3
    }

    device_info = {
        "gpu": gpu_info,
        "system_memory": sys_mem_info,
        "device_type": "cpu",
        "recommended_device": "cpu",
        "memory_sufficient": True,
        "warning_message": ""
    }

    if platform.system() == "Darwin" and platform.processor() == "arm":
        device_info.update({
            "device_type": "apple_silicon",
            "recommended_device": "mps"
        })
        if sys_mem_info["total"] < 16:
            device_info.update({
                "memory_sufficient": False,
                "warning_message": "Apple Silicon 内存小于 16GB，性能可能受影响"
            })
    elif gpu_info["available"]:
        device_info.update({
            "device_type": "nvidia_gpu",
            "recommended_device": "cuda"
        })
        if gpu_info["total_memory"] < 8:
            device_info.update({
                "memory_sufficient": False,
                "warning_message": "GPU 显存小于 8GB，性能可能下降"
            })
    
    return device_info

def check_memory_requirements(model_name: str, quantization: str, device_info: dict) -> str:
    """检查内存需求并自动调整量化级别"""
    model_info = get_model_info(model_name)
    vram_req = model_info.get("vram_requirement", {})
    
    quant_map = {
        Quantization.Q4_BIT: vram_req.get("4bit", 0),
        Quantization.Q8_BIT: vram_req.get("8bit", 0),
        Quantization.NONE: vram_req.get("full", 0)
    }
    
    base_memory = quant_map.get(quantization, 0)
    device = device_info["recommended_device"]
    use_cpu_mps = device in ["cpu", "mps"]
    
    required_mem = base_memory * (1.5 if use_cpu_mps else 1.0)
    available_mem = device_info["system_memory"]["available"] if use_cpu_mps else device_info["gpu"]["free_memory"]
    mem_type = "系统内存" if use_cpu_mps else "GPU显存"

    if required_mem * 1.2 > available_mem:
        if quantization == Quantization.NONE:
            return Quantization.Q8_BIT
        if quantization == Quantization.Q8_BIT:
            return Quantization.Q4_BIT
    
    return quantization

def check_flash_attention() -> bool:
    """检查是否支持 Flash Attention 2"""
    try:
        import flash_attn
        if torch.cuda.is_available():
            major, _ = torch.cuda.get_device_capability()
            return major >= 8
    except ImportError:
        return False
    return False

class ImageProcessor:
    """图像处理器"""
    def to_pil(self, image_tensor: torch.Tensor) -> Image.Image:
        """将 ComfyUI 图像张量转换为 PIL Image (用于 Qwen 处理器)"""
        if image_tensor.dim() == 4:
            image_tensor = image_tensor[0]
        img_np = (image_tensor.cpu().numpy() * 255).astype(np.uint8)
        return Image.fromarray(img_np)

class ModelDownloader:
    """模型下载器
    
    模型存储路径：优先使用插件目录下的 models 文件夹，以支持随插件移动。
    同时兼容 ComfyUI/models/prompt_generator/ 目录。
    """
    def __init__(self, configs):
        self.configs = configs
        # 获取插件根目录 (ComfyUI-WujiToolbox/wuji_llm_prompt_expander)
        self.plugin_dir = Path(__file__).parent.parent
        
        # 1. 插件内部模型目录 (真正相对路径，支持整体复制)
        self.local_models_dir = self.plugin_dir / "models"
        
        # 2. ComfyUI 标准模型目录 (作为备选/兼容)
        try:
            self.comfy_models_dir = Path(folder_paths.models_dir) / "prompt_generator"
        except:
            self.comfy_models_dir = self.local_models_dir
            
        # 默认下载路径：为了实现用户要求的“随插件移动”，优先存放在插件内部
        self.models_dir = self.local_models_dir
        self.models_dir.mkdir(parents=True, exist_ok=True)

    def ensure_model_available(self, model_name):
        """确保模型可用，如果不存在则下载"""
        model_info = self.configs.get(model_name)
        if not model_info:
            raise ValueError(f"模型 '{model_name}' 未在配置中找到")

        repo_id = model_info['repo_id']
        source = model_info.get('source', 'huggingface')
        model_folder_name = repo_id.split('/')[-1]
        
        # 检查两个可能的路径
        paths_to_check = [
            self.local_models_dir / model_folder_name,
            self.comfy_models_dir / model_folder_name
        ]
        
        for model_path in paths_to_check:
            # 检查模型是否已完整下载（检查关键文件是否存在）
            config_file = model_path / "config.json"
            model_file = model_path / "model.safetensors"
            model_index = model_path / "model.safetensors.index.json"
            
            if model_path.exists() and config_file.exists():
                if model_file.exists() or model_index.exists():
                    return str(model_path)
        
        # 如果都不存在，则下载到默认路径 (local_models_dir)
        model_path = self.local_models_dir / model_folder_name
        
        # 检查 ModelScope 模型是否需要安装依赖
        if source == 'modelscope':
            if not MODELSCOPE_AVAILABLE:
                raise RuntimeError(
                    f"模型 '{model_name}' 来自 ModelScope，但 ModelScope 库未安装。\n"
                    f"请运行以下命令安装：\n"
                    f"pip install modelscope\n"
                    f"或者使用 HuggingFace 镜像站手动下载模型到: {model_path}"
                )
            snapshot_download_func = ms_snapshot_download
            download_kwargs = {
                "model_id": repo_id,
                "cache_dir": str(model_path.parent),
                "local_dir": str(model_path),
            }
        else:
            if not HF_HUB_AVAILABLE:
                raise RuntimeError(
                    f"模型 '{model_name}' 来自 HuggingFace，但 huggingface_hub 库未安装。\n"
                    f"请运行: pip install huggingface_hub"
                )
            snapshot_download_func = hf_snapshot_download
            download_kwargs = {
                "repo_id": repo_id,
                "local_dir": str(model_path),
                "local_dir_use_symlinks": False,
                "ignore_patterns": ["*.md", "*.txt", ".gitattributes"],
                "resume_download": True,
                "max_workers": 4
            }
        
        print(f"📥 正在从 {source.upper()} 下载模型 '{model_name}' 到 {model_path}...")
        
        # 创建模型目录
        model_path.mkdir(parents=True, exist_ok=True)
        
        # 添加重试机制
        max_retries = 3
        for attempt in range(max_retries):
            try:
                downloaded_path = snapshot_download_func(**download_kwargs)
                print(f"✅ 模型 '{model_name}' 下载完成！")
                return str(model_path)
            except Exception as e:
                if attempt < max_retries - 1:
                    print(f"⚠️ 下载失败（尝试 {attempt + 1}/{max_retries}）: {str(e)}")
                    print(f"⏳ 等待 5 秒后重试...")
                    time.sleep(5)
                else:
                    raise RuntimeError(f"模型下载失败: {str(e)}")

class QwenLocalClient:
    """Qwen3-VL 本地客户端"""
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(QwenLocalClient, cls).__new__(cls)
            cls._instance.initialized = False
        return cls._instance

    def __init__(self):
        if self.initialized:
            return
            
        self.model = None
        self.processor = None
        self.tokenizer = None
        self.current_model_name = None
        self.current_quantization = None
        self.current_device = None
        self.device_info = get_device_info()
        self.downloader = ModelDownloader(MODEL_CONFIGS)
        self.image_processor = ImageProcessor()
        self.initialized = True

    def clear_model_resources(self):
        """清理模型资源"""
        if self.model is not None:
            del self.model, self.processor, self.tokenizer
            self.model = self.processor = self.tokenizer = None
            self.current_model_name = self.current_quantization = self.current_device = None
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    def load_model(self, model_name: str, quantization_str: str, device: str = "auto"):
        """加载模型"""
        effective_device = self.device_info["recommended_device"] if device == "auto" else device
        
        # 如果模型已加载且配置相同，则跳过
        if (self.model is not None and 
            self.current_model_name == model_name and 
            self.current_quantization == quantization_str and 
            self.current_device == effective_device):
            return

        self.clear_model_resources()
        model_info = get_model_info(model_name)
        model_path = self.downloader.ensure_model_available(model_name)
        adjusted_quantization = check_memory_requirements(model_name, quantization_str, self.device_info)
        
        quant_config, load_dtype = None, torch.float16
        
        # 仅对非预量化模型应用量化配置
        if not get_model_info(model_name).get("quantized", False):
            if adjusted_quantization == Quantization.Q4_BIT:
                quant_config = BitsAndBytesConfig(
                    load_in_4bit=True,
                    bnb_4bit_compute_dtype=torch.float16,
                    bnb_4bit_quant_type="nf4",
                    bnb_4bit_use_double_quant=True
                )
                load_dtype = None
            elif adjusted_quantization == Quantization.Q8_BIT:
                quant_config = BitsAndBytesConfig(load_in_8bit=True)
                load_dtype = None

        device_map = "auto"
        if effective_device == "cuda" and torch.cuda.is_available():
            device_map = {"": 0}

        # 构建模型加载参数 (针对 30/40/50 系优化)
        attn_impl = "sdpa"
        if check_flash_attention():
            attn_impl = "flash_attention_2"
        
        load_kwargs = {
            "device_map": device_map,
            "torch_dtype": load_dtype,
            "attn_implementation": attn_impl,
            "use_safetensors": True,
            "trust_remote_code": True
        }
        
        if quant_config:
            load_kwargs["quantization_config"] = quant_config

        # 加载模型、处理器和分词器
        self.model = AutoModelForImageTextToText.from_pretrained(model_path, **load_kwargs).eval()
        
        # 如果支持 SageAttention 且可用，尝试进行优化
        if SAGE_ATTENTION_AVAILABLE and effective_device == "cuda":
            try:
                from sageattention import extend_and_patch
                extend_and_patch(self.model)
            except: pass

        self.processor = AutoProcessor.from_pretrained(model_path, trust_remote_code=True)
        self.tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
        
        self.current_model_name = model_name
        self.current_quantization = quantization_str
        self.current_device = effective_device

    @torch.no_grad()
    def generate(
        self,
        model_name: str,
        quantization: str,
        system_role: str,
        user_input: str,
        images: list,
        video,
        temperature: float,
        top_p: float,
        max_tokens: int,
        seed: int,
        device: str = "auto",
        keep_loaded: bool = False,
        turbo_mode: bool = False
    ) -> str:
        """生成内容"""
        
        # 设置随机种子
        if seed != -1:
            torch.manual_seed(seed)
            random.seed(seed)
        
        # 检查 transformers 版本
        if TRANSFORMERS_AVAILABLE:
            if version.parse(transformers.__version__) < version.parse("4.57.0"):
                raise RuntimeError(f"transformers 版本过低: 当前版本 {transformers.__version__}, 需要 >= 4.57.0")
        else:
            raise RuntimeError("transformers 库未安装，无法运行本地模型")

        self.load_model(model_name, quantization, device)
        effective_device = self.current_device
        
        # 构建对话消息
        conversation = []
        
        # 添加系统角色
        if system_role:
            conversation.append({
                "role": "system",
                "content": [{"type": "text", "text": system_role}]
            })
            
        # 构建用户消息
        user_content = []
        
        # 添加图像
        for img in images:
            if img is not None:
                # 如果是batch tensor，取第一张（目前逻辑）
                if isinstance(img, torch.Tensor):
                    if img.dim() == 4:
                        for i in range(img.shape[0]):
                             user_content.append({
                                "type": "image",
                                "image": self.image_processor.to_pil(img[i])
                            })
                    else:
                        user_content.append({
                            "type": "image",
                            "image": self.image_processor.to_pil(img)
                        })
                else:
                     user_content.append({
                        "type": "image",
                        "image": img
                    })

        # 添加视频
        if video is not None:
            # 假设 video 是 [B, H, W, C] tensor
            video_frames = [
                Image.fromarray((frame.cpu().numpy() * 255).astype(np.uint8))
                for frame in video
            ]
            
            # 简单采样16帧
            target_frames = 16
            if len(video_frames) > target_frames:
                indices = np.linspace(0, len(video_frames) - 1, target_frames, dtype=int)
                sampled_frames = [video_frames[i] for i in indices]
            else:
                sampled_frames = video_frames

            # 确保至少有2帧
            if sampled_frames and len(sampled_frames) == 1:
                sampled_frames.append(sampled_frames[0])
                
            if sampled_frames:
                user_content.append({
                    "type": "video",
                    "video": sampled_frames
                })

        # 添加文本
        user_content.append({
            "type": "text",
            "text": user_input
        })
        
        conversation.append({
            "role": "user",
            "content": user_content
        })

        # 应用聊天模板
        text_prompt = self.processor.apply_chat_template(
            conversation,
            tokenize=False,
            add_generation_prompt=True
        )
            
        # 提取图像和视频用于处理器
        pil_images = []
        video_frames_list = []
        
        for msg in conversation:
            if msg['role'] == 'user':
                for item in msg['content']:
                    if item['type'] == 'image':
                        pil_images.append(item['image'])
                    elif item['type'] == 'video':
                        video_frames_list.extend(item['video'])
        
        videos_arg = [video_frames_list] if video_frames_list else None
        
        # 处理输入
        # 加速模式下限制图像像素以减少显存占用和计算时间
        process_kwargs = {
            "text": text_prompt,
            "images": pil_images if pil_images else None,
            "videos": videos_arg,
            "return_tensors": "pt"
        }
        
        # Qwen2-VL 支持动态分辨率，这里进行限制
        if turbo_mode:
            # 加速模式：更低的分辨率
            process_kwargs["min_pixels"] = 256 * 256
            process_kwargs["max_pixels"] = 768 * 768
        else:
            # 标准模式：平衡
            process_kwargs["min_pixels"] = 256 * 256
            process_kwargs["max_pixels"] = 1024 * 1024

        inputs = self.processor(**process_kwargs)
        
        # 将输入移到设备
        # 即使模型是量化的，input tensors 也应该放到 GPU 上
        # 对于 bitsandbytes 量化，self.model.device 可能是 'cuda:0'
        # 如果是 auto device map，可能需要检查第一个参数的设备
        target_device = effective_device
        if hasattr(self.model, "device") and self.model.device.type != 'meta':
             target_device = self.model.device
        
        # 尝试获取模型参数的设备作为回退
        if target_device == 'cpu' and torch.cuda.is_available():
             try:
                 param_device = next(self.model.parameters()).device
                 if param_device.type != 'meta':
                     target_device = param_device
             except:
                 pass

        model_inputs = {
            k: v.to(target_device)
            for k, v in inputs.items()
            if torch.is_tensor(v)
        }

        # 设置停止标记
        stop_tokens = [self.tokenizer.eos_token_id]
        if hasattr(self.tokenizer, 'eot_id'):
            stop_tokens.append(self.tokenizer.eot_id)

        # 生成参数
        gen_kwargs = {
            "max_new_tokens": max_tokens,
            "repetition_penalty": 1.2, # 默认值
            "do_sample": True,
            "temperature": temperature,
            "top_p": top_p,
            "eos_token_id": stop_tokens,
            "pad_token_id": self.tokenizer.pad_token_id
        }
        
        # 生成文本
        outputs = self.model.generate(**model_inputs, **gen_kwargs)
        input_ids_len = model_inputs["input_ids"].shape[1]
        text = self.tokenizer.decode(
            outputs[0, input_ids_len:],
            skip_special_tokens=True
        )
        
        if not keep_loaded:
            self.clear_model_resources()
            
        return text.strip()
