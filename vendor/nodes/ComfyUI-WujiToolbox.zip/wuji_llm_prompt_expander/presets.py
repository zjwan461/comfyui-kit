# 预设指令集管理
import os
import json
import base64

# --- 加密处理模块 ---
class WujiCipher:
    @staticmethod
    def encrypt(data_str):
        """简单的异或+Base64加密，用于保护预设指令集"""
        key = "WUJI_PROMPT_SECRET_2025"
        # 转换为字节
        data_bytes = data_str.encode('utf-8')
        key_bytes = key.encode('utf-8')
        # 异或处理
        encrypted_bytes = bytearray()
        for i in range(len(data_bytes)):
            encrypted_bytes.append(data_bytes[i] ^ key_bytes[i % len(key_bytes)])
        # 转为Base64
        return base64.b64encode(encrypted_bytes).decode('utf-8')

    @staticmethod
    def decrypt(encrypted_str):
        """解密处理"""
        key = "WUJI_PROMPT_SECRET_2025"
        try:
            # Base64解码
            encrypted_bytes = base64.b64decode(encrypted_str)
            key_bytes = key.encode('utf-8')
            # 异或还原
            decrypted_bytes = bytearray()
            for i in range(len(encrypted_bytes)):
                decrypted_bytes.append(encrypted_bytes[i] ^ key_bytes[i % len(key_bytes)])
            return decrypted_bytes.decode('utf-8')
        except Exception:
            return None

try:
    import openpyxl
    OPENPYXL_SUPPORT = True
except ImportError:
    OPENPYXL_SUPPORT = False

# 更新文件名配置 - 直接使用插件根目录
UPDATE_FILENAME = "update_presets"
# 插件根目录
PLUGIN_DIR = os.path.dirname(__file__)
# 预设保存文件路径：移至 .settings 隐藏目录
_BASE_DIR = os.path.dirname(os.path.dirname(__file__))
_SETTINGS_DIR = os.path.join(_BASE_DIR, '.settings')
if not os.path.exists(_SETTINGS_DIR):
    try: os.makedirs(_SETTINGS_DIR)
    except: pass
PRESETS_FILE = os.path.join(_SETTINGS_DIR, "prompt_expander_presets.json")

# 默认预设指令集 - 包含"通用预设"和"自定义"
DEFAULT_PRESETS = {
    "通用预设": """你是一个顶级的AI绘画提示词专家。请根据提供的输入（手动输入提示词、图像/视频参考描述）扩写出高质量、细节丰富的英文提示词。

核心处理原则：
1. 视觉特征继承（族裔与审美保持）：
   - 你必须精准识别并保留参考图中人物的【族裔特征】（如：中国人/东亚人、发色、瞳色、面部轮廓）。
   - 严禁将参考图中的中国人自动转化为欧美人或其他族裔，除非手动提示词明确要求修改人种。
   - 保持参考图中的整体【艺术风格】与【审美调性】。

2. 冲突处理（绝对优先权）：
   - 如果“手动输入提示词”与“图像/视频参考内容”在【地点/场景】、【动作/姿态】、【服装/道具】等方面出现冲突，必须 100% 以“手动输入提示词”为准。
   - 彻底重构：严禁在扩写中混合冲突信息。若手动要求“教室”，则必须完全舍弃图像中的“街头/商铺”元素，但仍需保留图中人物的“中国人”长相特征。

3. 逻辑延展：
   - 基于手动输入的场景，自动补全合理的细节（如教室里的黑板、课桌、环境光影等）。

输出要求：
1. 纯净输出：仅输出扩写后的英文提示词。严禁包含任何解释或开场白。
2. 极致细节：包含构图、光影、材质、族裔细节描述（如 "beautiful Chinese girl", "East Asian features"）。
3. 语言：一律输出高质量的英文提示词。""",
    "自定义": ""
}

# 加载预设指令集
PRESET_INSTRUCTIONS = DEFAULT_PRESETS.copy()

# 尝试从文件加载预设
if os.path.exists(PRESETS_FILE):
    try:
        with open(PRESETS_FILE, 'r', encoding='utf-8') as f:
            content = f.read()
            
        # 尝试作为加密内容解密
        decrypted_content = WujiCipher.decrypt(content)
        if decrypted_content:
            saved_presets = json.loads(decrypted_content)
        else:
            # 如果解密失败，尝试作为普通JSON读取（兼容旧版或未加密版）
            saved_presets = json.loads(content)
            
        # 合并保存的预设，保留"通用预设"和"自定义"
        saved_presets["通用预设"] = DEFAULT_PRESETS["通用预设"]
        saved_presets["自定义"] = ""
        PRESET_INSTRUCTIONS.update(saved_presets)
        # ☯️ 无极工具箱：静默加载预设，不再打印敏感路径和加密状态
    except Exception:
        # ☯️ 无极工具箱：静默处理加载失败
        pass

class PresetManager:
    """预设指令集管理器"""
    
    @staticmethod
    def get_preset_list():
        """获取预设列表"""
        return list(PRESET_INSTRUCTIONS.keys())
    
    @staticmethod
    def get_preset_instruction(preset_name):
        """获取预设指令"""
        return PRESET_INSTRUCTIONS.get(preset_name, "")
    
    @staticmethod
    def add_preset(name, instruction):
        """添加预设指令"""
        PRESET_INSTRUCTIONS[name] = instruction
    
    @staticmethod
    def remove_preset(name):
        """移除预设指令"""
        if name != "自定义" and name in PRESET_INSTRUCTIONS:
            del PRESET_INSTRUCTIONS[name]
    
    @staticmethod
    def update_preset(name, instruction):
        """更新预设指令"""
        if name in PRESET_INSTRUCTIONS:
            PRESET_INSTRUCTIONS[name] = instruction
    
    @staticmethod
    def read_presets_from_xlsx(file_path):
        """从xlsx表格读取预设指令集"""
        if not OPENPYXL_SUPPORT:
            print(f"[无极工具箱] 警告：无法读取xlsx文件 {file_path}，请安装openpyxl库")
            return {}
        
        try:
            # 加载工作簿
            wb = openpyxl.load_workbook(file_path)
            ws = wb.active
            
            presets = {}
            # 遍历行，从第二行开始（第一行是表头）
            for row in ws.iter_rows(min_row=2, values_only=True):
                if len(row) >= 3:
                    # 获取标题和内容（忽略序列号）
                    title = row[1]
                    content = row[2]
                    
                    # 检查标题和内容是否有效
                    if title and content:
                        title = str(title).strip()
                        content = str(content).strip()
                        if title and content:
                            presets[title] = content
            
            return presets
        except Exception as e:
            print(f"[无极工具箱] 读取xlsx文件 {file_path} 失败: {e}")
            return {}
    
    @staticmethod
    def update_presets():
        """更新预设指令集：从update_presets.xlsx读取，完全替换旧预设"""
        print(f"[无极工具箱] 开始更新预设指令集...")
        
        # 直接使用插件根目录，不使用123文件夹
        update_file = os.path.join(PLUGIN_DIR, f"{UPDATE_FILENAME}.xlsx")
        if not os.path.exists(update_file):
            print(f"[无极工具箱] 未找到更新文件 {update_file}")
            print(f"[无极工具箱] 请复制update_presets_template.xlsx并重命名为update_presets.xlsx")
            return False
        
        print(f"[无极工具箱] 找到更新文件: {update_file}")
        
        # 读取xlsx文件生成预设
        presets = PresetManager.read_presets_from_xlsx(update_file)
        if not presets:
            print(f"[无极工具箱] 从更新文件中未读取到有效预设")
            return False
        
        # 备份原有预设
        original_presets = PRESET_INSTRUCTIONS.copy()
        
        try:
            # 清除除"自定义"外的所有预设
            for key in list(PRESET_INSTRUCTIONS.keys()):
                if key != "自定义":
                    del PRESET_INSTRUCTIONS[key]
            
            # 添加新预设
            PRESET_INSTRUCTIONS.update(presets)
            print(f"[无极工具箱] 成功更新 {len(presets)} 个预设指令集")
            
            # 保存预设到文件，持久化更新
            PresetManager.save_presets_to_json(PRESETS_FILE)
            return True
        except Exception as e:
            # 恢复原有预设
            PRESET_INSTRUCTIONS.clear()
            PRESET_INSTRUCTIONS.update(original_presets)
            print(f"[无极工具箱] 更新预设失败，已恢复原有预设: {e}")
            return False
    
    @staticmethod
    def load_presets_from_json(file_path):
        """从json文件加载预设指令集"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                presets = json.load(f)
            return presets
        except Exception as e:
            print(f"[无极工具箱] 读取json文件 {file_path} 失败: {e}")
            return {}
    
    @staticmethod
    def save_presets_to_json(file_path):
        """将预设指令集保存到json文件，并进行加密处理"""
        try:
            # 排除"自定义"预设
            presets_to_save = {k: v for k, v in PRESET_INSTRUCTIONS.items() if k != "自定义"}
            json_str = json.dumps(presets_to_save, ensure_ascii=False, indent=2)
            
            # 执行加密
            encrypted_content = WujiCipher.encrypt(json_str)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(encrypted_content)
            print(f"[无极工具箱] 成功保存预设并加密到 {file_path}")
            return True
        except Exception as e:
            print(f"[无极工具箱] 保存加密预设到 {file_path} 失败: {e}")
            return False
