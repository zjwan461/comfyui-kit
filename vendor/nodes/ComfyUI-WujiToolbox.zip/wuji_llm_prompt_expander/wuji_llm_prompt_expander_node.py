import os
import json
import torch
import gc
import time
import random
from typing import Tuple
import comfy.model_management

# 导入本地模块
from .config import ConfigManager
from .presets import PresetManager, PRESET_INSTRUCTIONS
from .models.online_client import OnlineModelClient, get_api_key, encode_image_tensor, run_async
from .models.qwen_local_client import QwenLocalClient, Quantization
from ..common.wuji_optimizations import cleanup_memory, WUJI_CTX

# 配置管理器实例
config_manager = ConfigManager()

# 加载本地模型配置
NODE_DIR = os.path.dirname(os.path.abspath(__file__))
try:
    with open(os.path.join(NODE_DIR, "config_qwen.json"), "r", encoding="utf-8") as f:
        qwen_config = json.load(f)
    LOCAL_MODELS = [k for k in qwen_config.keys() if not k.startswith("_")]
except Exception:
    LOCAL_MODELS = []

ONLINE_MODELS = ["glm-4.6v-flash", "gemini-3-flash-preview-nothinking", "gpt-5.2-2025-12-11"]
ALL_MODELS = ONLINE_MODELS + LOCAL_MODELS
DEFAULT_MODEL = "glm-4.6v-flash"

class WujiLLMPromptExpander:
    """
    ☯️ 无极LLM润词器
    
    整合在线API和本地大模型的极速提示词工具
    """
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "提示词": ("STRING", {"multiline": True, "default": ""}),
                "模型选择": (ALL_MODELS, {"default": DEFAULT_MODEL}),
                "API_Key": ("STRING", {"default": "", "placeholder": "仅在线模型需要"}),
                "扩写预设": (list(PRESET_INSTRUCTIONS.keys()), {"default": "通用预设"}),
                "自定义指令": ("STRING", {"multiline": True, "default": "请将以下提示词扩写为详细、富有细节的描述，适合用于AI绘画生成高质量图像。"}),
                "生成温度": ("FLOAT", {"default": 0.7, "min": 0.0, "max": 2.0, "step": 0.01}),
                "最大长度": ("INT", {"default": 2048, "min": 1, "max": 32768}),
            },
            "optional": {
                "图像1": ("IMAGE",),
                "图像2": ("IMAGE",),
                "图像3": ("IMAGE",),
                "图像4": ("IMAGE",),
                "视频": ("IMAGE",),
                "常驻显存": ("BOOLEAN", {"default": False, "label_on": "开启", "label_off": "关闭"}),
                "Key领取说明": ("STRING", {"default": "------------------------------------------\n🔑 API Key 领取地址：\n\n1. 智谱 AI (GLM-4V/Flash):\nhttps://bigmodel.cn/usercenter/proj-mgmt/apikeys\n\n2. T8 平台 (GPT/Gemini):\nhttps://ai.t8star.cn/token\n------------------------------------------", "multiline": True, "readonly": True}),
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("扩写提示词",)
    FUNCTION = "process"
    CATEGORY = "☯️无极工具箱"
    
    def __init__(self):
        self.local_client = QwenLocalClient()

    async def generate_with_online_model(self, model, provider, api_key, system_role, user_input, images, video, temperature, max_tokens, random_seed):
        actual_model = model.replace("-T8", "")
        parts = []
        
        for img_tensor in images:
            if img_tensor is not None:
                for i in range(img_tensor.shape[0]):
                    parts.append({"inline_data": {"mime_type": "image/png", "data": encode_image_tensor(img_tensor[i])}})
        
        if video is not None:
            batch_size = video.shape[0]
            step = max(1, batch_size // 10)
            for i in range(0, batch_size, step):
                parts.append({"inline_data": {"mime_type": "image/png", "data": encode_image_tensor(video[i])}})
        
        parts.append({"text": user_input})
        contents = []
        if system_role.strip(): contents.append({"role": "system", "parts": [{"text": system_role}]})
        contents.append({"role": "user", "parts": parts})
        
        async with OnlineModelClient(api_key, provider) as client:
            return await client.generate_content(model=actual_model, contents=contents, temperature=temperature, top_p=0.9, max_tokens=max_tokens, random_seed=random_seed)
    
    def process(self, **kwargs):
        # 标记 LLM 进入活跃状态，通知采样器可能需要释放显存
        WUJI_CTX.llm_active = True
        
        print("\n" + "="*50)
        print("☯️  [无极工具箱] - 正在使用无极提示词扩展处理...")
        print("="*50)

        # 移除显示用的说明，避免干扰后续逻辑
        kwargs.pop("Key领取说明", None)
        
        original_prompt = kwargs.get("提示词", "")
        model = kwargs.get("模型选择", DEFAULT_MODEL)
        api_key_input = kwargs.get("API_Key", "")
        preset = kwargs.get("扩写预设", "通用预设")
        instruction = kwargs.get("自定义指令", "") if preset == "自定义" else PRESET_INSTRUCTIONS.get(preset, "")
        
        # 默认使用 4bit 量化以平衡显存和速度
        local_quantization = kwargs.get("量化等级", Quantization.Q4_BIT)
        turbo_mode = True # 极速模式默认开启并隐藏
        keep_local_model = kwargs.get("常驻显存", False)
        temperature = kwargs.get("生成温度", 0.7)
        max_tokens = kwargs.get("最大长度", 2048)
        
        images = [kwargs.get(f"图像{i}") for i in range(1, 5) if kwargs.get(f"图像{i}") is not None]
        video = kwargs.get("视频")
        
        # 随机种子处理：如果输入中没有，则使用随机数
        seed = kwargs.get("随机种子", random.randint(0, 0xffffffffffffffff))
        
        user_input = f"### 手动输入提示词 (最高优先级):\n{original_prompt}\n\n"
        if images or video:
            user_input += "### 图像/视频参考内容 (仅作参考，若与上方手动输入冲突，请务必忽略此部分的相关描述):\n"
            # 后续逻辑保持不变
        
        try:
            with torch.inference_mode():
                if model in LOCAL_MODELS:
                    response = self.local_client.generate(
                        model_name=model, quantization=local_quantization, system_role=instruction, 
                        user_input=user_input, images=images, video=video, temperature=temperature, 
                        top_p=0.9, max_tokens=max_tokens, seed=seed, keep_loaded=keep_local_model, turbo_mode=turbo_mode
                    )
                else:
                    # 确定 API 提供商
                    # 根据用户反馈：Gemini 和 GPT 都是走 T8 的，智谱走 zhipu
                    if "gemini" in model or "gpt" in model:
                        provider = "T8"
                    else:
                        provider = "zhipu"
                        
                    api_key = get_api_key(provider, api_key_input)
                    if not api_key: return (f"❌ 错误：未配置 {provider} 的 API Key",)
                    
                    response = run_async(self.generate_with_online_model(
                        model, provider, api_key, instruction, user_input, images, video, temperature, max_tokens, seed
                    ))
                return (response,)
            
        except Exception as e:
            return (f"❌ 运行错误：{str(e)}",)
        finally:
            # 标记 LLM 结束活跃状态
            WUJI_CTX.llm_active = False
            
            # 无论成功与否，如果关闭了常驻显存，都必须强制清理
            if model in LOCAL_MODELS and not keep_local_model:
                print(f"🧹 [无极工具箱] 释放本地模型资源: {model}")
                self.local_client.clear_model_resources()
                cleanup_memory(force=True)
            elif model not in LOCAL_MODELS:
                # 在线模型也顺便清理下零碎显存
                cleanup_memory(force=True)
