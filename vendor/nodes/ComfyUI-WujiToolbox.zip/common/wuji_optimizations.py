# -*- coding: utf-8 -*-
"""
☯️ 无极工具箱 - 优化模块（完整版）
为放大器和润词器提供完整兼容性支持
"""
import torch
import gc
import os
import json
import platform
import ctypes

# --- Windows API 预获取 ---
if platform.system() == "Windows":
    try:
        kernel32 = ctypes.windll.kernel32
        psapi = ctypes.windll.psapi
        current_process_handle = kernel32.GetCurrentProcess()
    except:
        current_process_handle = None
else:
    current_process_handle = None

# --- 全局状态管理 ---
class WujiContext:
    _instance = None
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(WujiContext, cls).__new__(cls)
            cls._instance.llm_active = False
            cls._instance.sampler_running = False
            cls._instance.last_model = None
            cls._instance.last_clip = None
            cls._instance.last_vae = None
            cls._instance.style_cache = {}
        return cls._instance

WUJI_CTX = WujiContext()

def load_wuji_styles():
    """加载风格预设"""
    if not WUJI_CTX.style_cache:
        styles_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), "styles.json")
        if os.path.exists(styles_file):
            try:
                with open(styles_file, 'r', encoding='utf-8') as f:
                    WUJI_CTX.style_cache = json.load(f)
            except:
                pass
    return WUJI_CTX.style_cache

def cleanup_memory(force=False):
    """清理内存"""
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        if force:
            # 极限清理：清除所有已分配但未使用的显存
            if platform.system() == "Windows" and current_process_handle:
                try:
                    # 尝试减少工作集大小 (Windows 专用优化)
                    kernel32.SetProcessWorkingSetSize(current_process_handle, -1, -1)
                except:
                    pass

def ensure_standard_image(image):
    """确保图像格式标准"""
    if image is None:
        return None
    
    # 处理 numpy 数组
    if hasattr(image, 'shape'):
        import numpy as np
        if len(image.shape) == 3:
            # 添加 batch 维度
            image = image[np.newaxis, ...]
        return image
    
    return image

def wuji_cache_and_fallback(cache_key):
    """缓存装饰器"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                print(f"⚠️ [无极工具箱] 节点执行异常 ({cache_key}): {e}")
                raise e
        return wrapper
    return decorator

# 兼容性导出
__all__ = [
    'WUJI_CTX',
    'load_wuji_styles',
    'cleanup_memory',
    'ensure_standard_image',
    'wuji_cache_and_fallback'
]
