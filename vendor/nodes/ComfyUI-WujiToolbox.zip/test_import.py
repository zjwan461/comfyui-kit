
import sys
import os
import traceback

# Add the parent directory to sys.path so we can import ComfyUI-WujiToolbox
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

try:
    print("Attempting to import WujiIDPhotoGenerator...")
    from wuji_id_photo.wuji_id_photo_node import WujiIDPhotoGenerator
    print("Import successful!")
    print("Testing INPUT_TYPES...")
    types = WujiIDPhotoGenerator.INPUT_TYPES()
    print("INPUT_TYPES success!")
except Exception as e:
    print("Import failed!")
    traceback.print_exc()
