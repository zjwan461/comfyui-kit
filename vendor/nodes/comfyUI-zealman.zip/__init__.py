# -*- coding: utf-8 -*-
"""Zealman 插件：LLM 提示词助手与 MiniMax H3 工具节点。"""

from .h3_media_browser import ZealmanH3PickReferenceMedia
from .h3_model_loader import ZealmanH3ModelLoader
from .h3_memory import ZealmanH3ApplyUniBlockSwap
from .h3_ref_images import ZealmanH3LoadImageToRefImages, ZealmanH3ReferenceMedia
from .image_picker import register_routes
from .nodes import ZealmanLLMGenerate, ZealmanLLMModelLoader, ZealmanLLMUnload

register_routes()

WEB_DIRECTORY = "./web"

_NODE_DISPLAY = "H3 Reference Media → MiniMax"

NODE_CLASS_MAPPINGS = {
    "ZealmanLLM_ModelLoader": ZealmanLLMModelLoader,
    "ZealmanLLM_Generate": ZealmanLLMGenerate,
    "ZealmanLLM_Unload": ZealmanLLMUnload,
    "ZealmanH3LoadImageToRefImages": ZealmanH3LoadImageToRefImages,
    "ZealmanH3ReferenceMedia": ZealmanH3ReferenceMedia,
    "ZealmanH3PickReferenceMedia": ZealmanH3PickReferenceMedia,
    "ZealmanH3ModelLoader": ZealmanH3ModelLoader,
    "ZealmanH3ApplyUniBlockSwap": ZealmanH3ApplyUniBlockSwap,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "ZealmanLLM_ModelLoader": "Zealman LLM 模型加载器",
    "ZealmanLLM_Generate": "Zealman LLM",
    "ZealmanLLM_Unload": "Zealman LLM 卸载模型",
    "ZealmanH3LoadImageToRefImages": _NODE_DISPLAY,
    "ZealmanH3ReferenceMedia": _NODE_DISPLAY,
    "ZealmanH3PickReferenceMedia": "ZealmanH3素材选择",
    "ZealmanH3ModelLoader": "ZealmanH3模型加载",
    "ZealmanH3ApplyUniBlockSwap": "Zealman H3 UniBlockSwap（条件后）",
}

__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS", "WEB_DIRECTORY"]
