# -*- coding: utf-8 -*-
"""Pick MiniMax H3 reference media from input/output.

Limits: up to 9 images, 3 videos and 3 audios. The combined count is not capped.
Each video or audio clip can be shorter than 1 second. After trim, a clip
and its type total must stay within 15 seconds. Audio cannot be the only input.
"""

from __future__ import annotations

import json
import math
import os

import torch

from .h3_ref_images import (
    MINIMAX_H3_DEFAULT_FPS,
    MINIMAX_H3_DEFAULT_TRIM_SECONDS,
    MINIMAX_H3_MAX_REFERENCE_AUDIOS,
    MINIMAX_H3_MAX_REFERENCE_IMAGES,
    MINIMAX_H3_MAX_REFERENCE_VIDEOS,
    _clamp_trim_seconds,
    _no_reference_media_message,
    _process_audio_input,
    _resample_video_frames,
)
from .image_picker import resolve_image
from .media_resize import resize_tensor_to_long_edge

_LIMITS = {
    "image": MINIMAX_H3_MAX_REFERENCE_IMAGES,
    "video": MINIMAX_H3_MAX_REFERENCE_VIDEOS,
    "audio": MINIMAX_H3_MAX_REFERENCE_AUDIOS,
}
_MAX_CLIP_SECONDS = 15.0
_DURATION_SLACK = 0.05
_VIDEO_EXT = {".mp4", ".webm", ".mov", ".mkv", ".avi", ".m4v"}
_AUDIO_EXT = {".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aac"}
_NODE_PREFIX = "[ZealmanH3PickReferenceMedia]"
_H3_FPS = 24
_IMAGE_SIDE_BUCKETS = (512, 768, 1024, 1280, 1536, 2048, 4096)
_VIDEO_SIDE_BUCKETS = (256, 512, 768, 1024)
_IMAGE_MAX_SIDES = ["auto", *[str(side) for side in _IMAGE_SIDE_BUCKETS]]
_VIDEO_MAX_SIDES = ["auto", *[str(side) for side in _VIDEO_SIDE_BUCKETS]]
_TRIM_UNLIMITED = "不限制"
_TRIM_SECONDS = ["auto", *[str(second) for second in range(1, 16)], _TRIM_UNLIMITED]


def h3_length_from_seconds(seconds: float) -> int:
    """官方 MiniMax H3：24fps 取整，再向上对齐到 17n+5（与 align_frame_count 相同）。"""
    from comfy_extras.nodes_minimax_h3 import align_frame_count

    raw = max(5, math.floor(float(seconds) * _H3_FPS + 0.5))
    return int(align_frame_count(raw))


def h3_resolution(aspect_ratio: str, megapixels: float, multiple: int) -> tuple[int, int]:
    """与官方 Resolution Selector 相同，倍率默认 32。"""
    from comfy_extras.nodes_resolution import ASPECT_RATIOS

    pair = None
    for key, value in ASPECT_RATIOS.items():
        label = getattr(key, "value", str(key))
        if key == aspect_ratio or label == aspect_ratio or str(key) == aspect_ratio:
            pair = value
            break
    if pair is None:
        raise ValueError(f"{_NODE_PREFIX} 未知宽高比：{aspect_ratio}")
    w_ratio, h_ratio = pair
    multiple = max(1, int(multiple))
    total_pixels = float(megapixels) * 1024 * 1024
    scale = math.sqrt(total_pixels / (w_ratio * h_ratio))
    width = round(w_ratio * scale / multiple) * multiple
    height = round(h_ratio * scale / multiple) * multiple
    return int(width), int(height)


def _aspect_options() -> list[str]:
    from comfy_extras.nodes_resolution import ASPECT_RATIOS

    return [getattr(key, "value", str(key)) for key in ASPECT_RATIOS]


def _slot_key(kind: str, index: int) -> str:
    return f"ref_{kind}_{index}"


def merge_slot_filenames(serialized: str, slots: dict) -> str:
    """API 里的 ref_image_0 等文件名覆盖 media_files 里的同槽。output: 前缀表示 output 目录。"""
    try:
        records = json.loads(serialized or "[]")
    except json.JSONDecodeError:
        records = []
    if not isinstance(records, list):
        records = []
    for kind, count in _LIMITS.items():
        for index in range(count):
            key = _slot_key(kind, index)
            if key not in slots:
                continue
            ordinal = index + 1
            records = [
                item for item in records
                if not (isinstance(item, dict) and item.get("media_type") == kind and item.get("ordinal") == ordinal)
            ]
            raw = str(slots.get(key) or "").strip()
            if not raw:
                continue
            storage = "input"
            if raw.startswith("output:"):
                storage = "output"
                raw = raw[7:]
            parts = [part for part in raw.split("/") if part and part != "."]
            if not parts:
                continue
            filename = parts[-1]
            records.append({
                "media_type": kind,
                "ordinal": ordinal,
                "filename": filename,
                "subfolder": "/".join(parts[:-1]),
                "storage": storage,
            })
    return json.dumps(records, ensure_ascii=False)


def parse_media_records(serialized: str) -> list[dict]:
    try:
        records = json.loads(serialized or "[]")
    except json.JSONDecodeError as exc:
        raise ValueError(f"{_NODE_PREFIX} media_files 不是合法 JSON。") from exc
    if not isinstance(records, list):
        raise ValueError(f"{_NODE_PREFIX} media_files 必须是数组。")
    seen = set()
    parsed = []
    for record in records:
        if not isinstance(record, dict):
            raise ValueError(f"{_NODE_PREFIX} 素材记录格式不对。")
        kind = record.get("media_type")
        ordinal = record.get("ordinal")
        if kind not in _LIMITS or not isinstance(ordinal, int) or not 1 <= ordinal <= _LIMITS[kind]:
            raise ValueError(f"{_NODE_PREFIX} 素材槽位无效。")
        if (kind, ordinal) in seen:
            raise ValueError(f"{_NODE_PREFIX} 素材槽位重复：{kind} {ordinal}。")
        seen.add((kind, ordinal))
        storage = record.get("storage", "input")
        if storage not in ("input", "output"):
            raise ValueError(f"{_NODE_PREFIX} 只能从 input 或 output 选择。")
        filename = os.path.basename(str(record.get("filename") or ""))
        ext = os.path.splitext(filename)[1].lower()
        if kind == "video" and ext not in _VIDEO_EXT:
            raise ValueError(f"{_NODE_PREFIX} 不是视频文件：{filename}")
        if kind == "audio" and ext not in _AUDIO_EXT:
            raise ValueError(f"{_NODE_PREFIX} 不是音频文件：{filename}")
        path = resolve_image(storage, str(record.get("subfolder") or ""), filename)
        parsed.append({
            "media_type": kind,
            "ordinal": ordinal,
            "path": path,
            "mtime_ns": os.stat(path).st_mtime_ns,
            "size": os.stat(path).st_size,
        })
    parsed.sort(key=lambda item: (list(_LIMITS).index(item["media_type"]), item["ordinal"]))
    return parsed


def media_limit_error(records: list[dict]) -> str | None:
    """Return a Chinese error when picked media breaks MiniMax H3 reference limits."""
    kinds = {item.get("media_type") for item in records}
    if "audio" in kinds and "image" not in kinds and "video" not in kinds:
        return "音频不能单独使用，需要同时提供图像或视频。"
    labels = {"video": "视频", "audio": "音频"}
    for kind, label in labels.items():
        chosen = [item for item in records if item.get("media_type") == kind]
        for item in chosen:
            duration = item.get("duration")
            ordinal = item.get("ordinal")
            if not isinstance(duration, (int, float)) or duration <= 0:
                return f"读不到{label}{ordinal}的时长。"
            duration = float(duration)
            trim = item.get("trim_seconds")
            if trim is None:
                continue
            effective = min(duration, float(trim))
            if effective > _MAX_CLIP_SECONDS + _DURATION_SLACK:
                return f"{label}{ordinal}不能超过 15 秒，这段是 {effective:.1f} 秒。"
    return None


def media_duration_warning(records: list[dict]) -> str | None:
    """Over-long totals are reported, then still output at the chosen trim."""
    labels = {"video": "视频", "audio": "音频"}
    notes = []
    for kind, label in labels.items():
        chosen = [item for item in records if item.get("media_type") == kind]
        total = 0.0
        trim_value = None
        counted = 0
        for item in chosen:
            duration = item.get("duration")
            if not isinstance(duration, (int, float)) or float(duration) <= 0:
                continue
            trim = item.get("trim_seconds")
            if trim is None:
                effective = float(duration)
            elif isinstance(trim, (int, float)):
                trim_value = float(trim)
                effective = min(float(duration), trim_value)
            else:
                effective = float(duration)
            total += effective
            counted += 1
        if counted and total > _MAX_CLIP_SECONDS + _DURATION_SLACK:
            if any(item.get("trim_seconds") is None for item in chosen):
                setting = "不限制"
            elif trim_value is None:
                setting = "自动长度"
            else:
                setting = f"{trim_value:g}秒"
            notes.append(f"{label}合计 {total:.0f}秒，超过 15秒，可能报错，仍按{setting}输出")
    if not notes:
        return None
    return "；".join(notes)


def _probe_duration(kind: str, path: str) -> float:
    if kind == "audio":
        import av

        with av.open(path) as container:
            if container.duration:
                return float(container.duration / av.time_base)
            stream = next((item for item in container.streams if item.type == "audio"), None)
            if stream is not None and stream.duration and stream.time_base:
                return float(stream.duration * stream.time_base)
        audio = _load_audio(path)
        sample_rate = int(audio["sample_rate"])
        frames = int(audio["waveform"].shape[-1])
        if sample_rate <= 0 or frames <= 0:
            raise ValueError(f"{_NODE_PREFIX} 读不到音频时长：{os.path.basename(path)}")
        return frames / sample_rate

    from comfy_api.latest import InputImpl

    duration = float(InputImpl.VideoFromFile(path).get_duration())
    if duration <= 0:
        raise ValueError(f"{_NODE_PREFIX} 读不到视频时长：{os.path.basename(path)}")
    return duration


def nearest_side_bucket(long_edge: int, buckets: tuple[int, ...]) -> int:
    """Pick the tier closest to the source long edge. Ties stay on the smaller tier."""
    edge = max(1, int(long_edge))
    return min(buckets, key=lambda bucket: (abs(int(bucket) - edge), int(bucket)))


def resolve_side_choice(choice, long_edge: int, buckets: tuple[int, ...]) -> int:
    """auto snaps each file to the nearest edge tier. A fixed tier is used as-is."""
    text = str(choice or "auto").strip().lower()
    if text == "auto":
        return nearest_side_bucket(long_edge, buckets)
    try:
        value = int(float(text))
    except (TypeError, ValueError):
        return nearest_side_bucket(long_edge, buckets)
    if value in buckets:
        return value
    return nearest_side_bucket(value, buckets)


def _tensor_long_edge(tensor: torch.Tensor) -> int:
    if tensor.ndim == 3:
        height, width = int(tensor.shape[0]), int(tensor.shape[1])
    elif tensor.ndim == 4:
        height, width = int(tensor.shape[1]), int(tensor.shape[2])
    else:
        raise ValueError(f"{_NODE_PREFIX} 素材尺寸无效：{tuple(tensor.shape)}")
    return max(1, height, width)


def auto_trim_cap(durations: list[float], limit: float = _MAX_CLIP_SECONDS) -> float:
    """Keep original lengths when the total fits. Otherwise cap only the long clips."""
    values = [float(item) for item in durations if isinstance(item, (int, float)) and float(item) > 0]
    if not values:
        return float(limit)
    if sum(min(value, limit) for value in values) <= limit + _DURATION_SLACK:
        return float(limit)
    low = 0.0
    high = float(limit)
    for _ in range(60):
        mid = (low + high) / 2.0
        if sum(min(value, mid) for value in values) <= limit:
            low = mid
        else:
            high = mid
    return low


def resolve_trim_seconds(choice, durations: list[float]) -> float | None:
    """auto 先看总时长。1–15 按所选秒数裁。不限制时返回 None，调用方不裁切。"""
    text = str(choice or "auto").strip()
    lowered = text.lower()
    if lowered in {_TRIM_UNLIMITED, "unlimited", "none", "off"}:
        return None
    if lowered == "auto":
        return auto_trim_cap(durations)
    try:
        seconds = int(round(float(text)))
    except (TypeError, ValueError):
        return auto_trim_cap(durations)
    return float(min(15, max(1, seconds)))


def _reject_if_over_limit(records: list[dict], video_trim, audio_trim) -> dict[str, float | None]:
    measured = []
    for record in records:
        item = dict(record)
        kind = item["media_type"]
        if kind in ("video", "audio"):
            try:
                item["duration"] = _probe_duration(kind, item["path"])
            except Exception as exc:
                label = "视频" if kind == "video" else "音频"
                raise RuntimeError(
                    f"{_NODE_PREFIX} 读不到{label}{item['ordinal']}的时长：{exc}"
                ) from exc
        measured.append(item)
    targets = {}
    for kind, choice in (("video", video_trim), ("audio", audio_trim)):
        durations = [item["duration"] for item in measured if item["media_type"] == kind]
        targets[kind] = resolve_trim_seconds(choice, durations)
    for item in measured:
        kind = item["media_type"]
        if kind in targets:
            item["trim_seconds"] = targets[kind]
    error = media_limit_error(measured)
    if error:
        raise RuntimeError(f"{_NODE_PREFIX} {error}")
    warning = media_duration_warning(measured)
    if warning:
        print(f"{_NODE_PREFIX} {warning}", flush=True)
    return targets


def _load_image(path: str) -> torch.Tensor:
    import numpy as np
    from PIL import Image

    with Image.open(path) as img:
        rgb = img.convert("RGB")
        array = np.asarray(rgb, dtype=np.float32) / 255.0
    return torch.from_numpy(array).unsqueeze(0)


def _load_audio(path: str) -> dict:
    from comfy_extras.nodes_audio import load

    waveform, sample_rate = load(path)
    if waveform.ndim == 2:
        waveform = waveform.unsqueeze(0)
    return {"waveform": waveform, "sample_rate": int(sample_rate)}


def _load_video(path: str, trim_seconds: float | None):
    from comfy_api.latest import InputImpl

    # duration 为 0 时读取整段，不按秒数截断
    duration = 0.0 if trim_seconds is None else float(trim_seconds)
    clip = InputImpl.VideoFromFile(path, duration=duration)
    components = clip.get_components()
    frames = components.images
    if not isinstance(frames, torch.Tensor) or frames.ndim != 4 or frames.shape[0] <= 0:
        raise ValueError(f"{_NODE_PREFIX} 视频没有可用画面：{os.path.basename(path)}")
    frames = frames[..., :3]
    source_fps = float(components.frame_rate) if components.frame_rate else 24.0
    audio = components.audio if isinstance(components.audio, dict) else None
    return frames, max(1.0, source_fps), audio


def _h3_output_names():
    names = [f"ref_image_{index}" for index in range(MINIMAX_H3_MAX_REFERENCE_IMAGES)]
    names += [f"ref_video_{index}" for index in range(MINIMAX_H3_MAX_REFERENCE_VIDEOS)]
    names += [f"ref_video_audio_{index}" for index in range(MINIMAX_H3_MAX_REFERENCE_VIDEOS)]
    names += [f"ref_audio_{index}" for index in range(MINIMAX_H3_MAX_REFERENCE_AUDIOS)]
    return tuple(names)


class ZealmanH3PickReferenceMedia:
    """Pick files and expose one socket per MiniMax H3 reference input."""

    DESCRIPTION = "从 input / output 选择参考素材。规则在标题上的问号里。"
    SEARCH_ALIASES = [
        "H3 media picker",
        "9图3视频3音频",
        "ZealmanH3素材选择",
    ]

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "fps": (
                    "FLOAT",
                    {
                        "default": MINIMAX_H3_DEFAULT_FPS,
                        "min": 1.0,
                        "max": 60.0,
                        "step": 1.0,
                        "tooltip": "参考视频输出帧率。MiniMax H3 期望 24 fps。",
                    },
                ),
                "video_trim_seconds": (
                    _TRIM_SECONDS,
                    {"default": "auto", "tooltip": "auto 先看总时长。没超过 15 秒不裁，超过了只裁长的。也可选 1–15 秒。不限制按原长输出，不裁切。"},
                ),
                "audio_trim_seconds": (
                    _TRIM_SECONDS,
                    {"default": "auto", "tooltip": "auto 先看总时长。没超过 15 秒不裁，超过了只裁长的。也可选 1–15 秒。不限制按原长输出，不裁切。"},
                ),
                "image_max_side": (
                    _IMAGE_MAX_SIDES,
                    {"default": "auto", "tooltip": "长边档位。auto 按每张图的长边就近对齐，最高 4096。"},
                ),
                "video_max_side": (
                    _VIDEO_MAX_SIDES,
                    {"default": "auto", "tooltip": "长边档位。auto 按每段视频的长边就近对齐，最高 1024。"},
                ),
                "prompt": ("STRING", {"default": "", "multiline": True, "tooltip": "接到 MiniMax H3 的 prompt。"}),
                "seconds": (
                    "INT",
                    {
                        "default": 5,
                        "min": 1,
                        "max": 150,
                        "step": 1,
                        "tooltip": "秒数，每次步进 1 秒，整数。输出 length 为官方帧数：24fps 取整后向上对齐到 17n+5。最后再输出这个整数秒。",
                    },
                ),
                "aspect_ratio": (
                    _aspect_options(),
                    {"default": "1:1 (Square)", "tooltip": "与官方 Resolution Selector 相同的宽高比。"},
                ),
                "megapixels": (
                    "FLOAT",
                    {
                        "default": 1.0,
                        "min": 0.1,
                        "max": 16.0,
                        "step": 0.1,
                        "tooltip": "目标百万像素。1.0 在正方形时约为 1024×1024。",
                    },
                ),
                "multiple": (
                    "INT",
                    {
                        "default": 32,
                        "min": 8,
                        "max": 128,
                        "step": 4,
                        "tooltip": "宽高对齐到该倍数。MiniMax H3 用 32。",
                    },
                ),
            },
            "optional": {
                **{
                    _slot_key(kind, index): ("STRING", {"default": ""})
                    for kind, count in _LIMITS.items()
                    for index in range(count)
                },
                "media_files": ("STRING", {"default": "[]", "multiline": True}),
            },
        }

    RETURN_TYPES = (
        *(["IMAGE"] * MINIMAX_H3_MAX_REFERENCE_IMAGES),
        *(["IMAGE"] * MINIMAX_H3_MAX_REFERENCE_VIDEOS),
        *(["AUDIO"] * MINIMAX_H3_MAX_REFERENCE_VIDEOS),
        *(["AUDIO"] * MINIMAX_H3_MAX_REFERENCE_AUDIOS),
        "STRING",
        "INT",
        "INT",
        "INT",
        "INT",
    )
    RETURN_NAMES = _h3_output_names() + ("prompt", "width", "height", "length", "seconds")
    FUNCTION = "pack_picked_media"
    CATEGORY = "Zealman/H3"

    @classmethod
    def IS_CHANGED(cls, media_files="[]", **kwargs):
        try:
            records = parse_media_records(merge_slot_filenames(media_files, kwargs))
        except Exception as exc:
            return str(exc)
        return tuple((item["path"], item["mtime_ns"], item["size"]) for item in records)

    def pack_picked_media(
        self,
        media_files: str = "[]",
        fps: float = MINIMAX_H3_DEFAULT_FPS,
        video_trim_seconds: float = MINIMAX_H3_DEFAULT_TRIM_SECONDS,
        audio_trim_seconds: float = MINIMAX_H3_DEFAULT_TRIM_SECONDS,
        image_max_side: str = "auto",
        video_max_side: str = "auto",
        prompt: str = "",
        seconds: int = 5,
        aspect_ratio: str = "1:1 (Square)",
        megapixels: float = 1.0,
        multiple: int = 32,
        **slots,
    ):
        records = parse_media_records(merge_slot_filenames(media_files, slots))
        if not records:
            raise RuntimeError(_no_reference_media_message())
        trim_targets = _reject_if_over_limit(records, video_trim_seconds, audio_trim_seconds)

        video_trim_seconds = trim_targets["video"]
        audio_trim_seconds = trim_targets["audio"]
        target_fps = max(1.0, float(fps))

        images = [None] * MINIMAX_H3_MAX_REFERENCE_IMAGES
        videos = [None] * MINIMAX_H3_MAX_REFERENCE_VIDEOS
        video_audios = [None] * MINIMAX_H3_MAX_REFERENCE_VIDEOS
        audios = [None] * MINIMAX_H3_MAX_REFERENCE_AUDIOS
        for record in records:
            kind = record["media_type"]
            slot = record["ordinal"] - 1
            path = record["path"]
            label = f"ref_{kind}_{slot}" if kind != "image" else f"ref_image_{slot}"
            try:
                if kind == "image":
                    image = _load_image(path)
                    side = resolve_side_choice(image_max_side, _tensor_long_edge(image), _IMAGE_SIDE_BUCKETS)
                    images[slot] = resize_tensor_to_long_edge(image, side)
                elif kind == "video":
                    frames, source_fps, soundtrack = _load_video(path, video_trim_seconds)
                    frames = _resample_video_frames(frames, source_fps, target_fps, video_trim_seconds)
                    side = resolve_side_choice(video_max_side, _tensor_long_edge(frames), _VIDEO_SIDE_BUCKETS)
                    videos[slot] = resize_tensor_to_long_edge(frames, side)
                    if soundtrack is not None:
                        video_audios[slot] = _process_audio_input(soundtrack, video_trim_seconds)
                else:
                    audios[slot] = _process_audio_input(_load_audio(path), audio_trim_seconds)
            except Exception as exc:
                raise RuntimeError(f"{_NODE_PREFIX} 处理 {label} 失败：{exc}") from exc

        width, height = h3_resolution(aspect_ratio, megapixels, multiple)
        seconds = max(1, min(150, int(round(float(seconds)))))
        length = h3_length_from_seconds(seconds)
        return (*images, *videos, *video_audios, *audios, str(prompt or ""), width, height, length, seconds)
