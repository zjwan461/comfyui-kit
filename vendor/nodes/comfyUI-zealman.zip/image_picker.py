# -*- coding: utf-8 -*-
"""列出 Input / Output 里的图像，供全局选图窗口使用。"""

from __future__ import annotations

import hashlib
import os
import shutil
import threading
import time

import folder_paths

_LIST_TTL = 30.0
_THUMB_DIR = "/tmp/zealman-image-picker-thumbs"
_THUMB_EDGE = 256
_list_lock = threading.Lock()
_list_cache: dict[str, tuple[float, list[dict]]] = {}


def _base_dir(folder: str) -> str:
    if folder == "input":
        return folder_paths.get_input_directory()
    if folder == "output":
        return folder_paths.get_output_directory()
    raise ValueError(folder)


_KIND_EXT = {
    "image": None,
    "video": {".mp4", ".webm", ".mov", ".mkv", ".avi", ".m4v"},
    "audio": {".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aac"},
}


def list_images(folder: str, kind: str = "image") -> list[dict]:
    if kind not in _KIND_EXT:
        raise ValueError(kind)
    base = _base_dir(folder)
    if not base or not os.path.isdir(base):
        return []

    items: list[dict] = []
    allowed = _KIND_EXT[kind]
    for root, dirs, filenames in os.walk(base):
        dirs[:] = sorted(name for name in dirs if not name.startswith("."))
        rel_root = os.path.relpath(root, base)
        subfolder = "" if rel_root in (".", "") else rel_root.replace(os.sep, "/")
        visible = [name for name in filenames if not name.startswith(".")]
        if kind == "image":
            names = folder_paths.filter_files_content_types(visible, ["image"])
        else:
            names = [name for name in visible if os.path.splitext(name)[1].lower() in allowed]
        for name in names:
            rel = name if not subfolder else f"{subfolder}/{name}"
            path = os.path.join(root, name)
            try:
                mtime = os.path.getmtime(path)
            except OSError:
                mtime = 0
            value = rel if folder == "input" else f"{rel} [output]"
            items.append({
                "name": name,
                "subfolder": subfolder,
                "value": value,
                "mtime": mtime,
            })
    items.sort(key=lambda item: item["mtime"], reverse=True)
    return items


def get_images(folder: str, refresh: bool = False, kind: str = "image") -> list[dict]:
    key = f"{folder}:{kind}"
    now = time.monotonic()
    if not refresh:
        with _list_lock:
            hit = _list_cache.get(key)
            if hit and now - hit[0] < _LIST_TTL:
                return hit[1]
    items = list_images(folder, kind)
    with _list_lock:
        _list_cache[key] = (time.monotonic(), items)
    return items


def resolve_image(folder: str, subfolder: str, name: str) -> str:
    base = os.path.realpath(_base_dir(folder))
    filename = os.path.basename(name or "")
    if not filename or filename.startswith("."):
        raise ValueError("invalid name")
    parts = []
    for part in (subfolder or "").replace("\\", "/").split("/"):
        if not part or part == ".":
            continue
        if part == ".." or part.startswith("."):
            raise ValueError("invalid subfolder")
        parts.append(part)
    path = os.path.realpath(os.path.join(base, *parts, filename))
    if os.path.commonpath((path, base)) != base or not os.path.isfile(path):
        raise ValueError("not found")
    return path


def _first_video_frame(path: str):
    import av

    with av.open(path) as container:
        stream = next((item for item in container.streams if item.type == "video"), None)
        if stream is None:
            raise ValueError("no video stream")
        for frame in container.decode(stream):
            return frame.to_image().convert("RGB")
    raise ValueError("no frame")


def thumbnail_file(path: str) -> str:
    stat = os.stat(path)
    key = hashlib.sha1(f"{path}|{stat.st_mtime_ns}|{stat.st_size}".encode()).hexdigest()
    folder = os.path.join(_THUMB_DIR, key[:2])
    os.makedirs(folder, exist_ok=True)
    dest = os.path.join(folder, f"{key}.webp")
    if os.path.isfile(dest) and os.path.getsize(dest) > 0:
        return dest
    from PIL import Image

    ext = os.path.splitext(path)[1].lower()
    if ext in _KIND_EXT["video"]:
        img = _first_video_frame(path)
        img.thumbnail((_THUMB_EDGE, _THUMB_EDGE))
        tmp = f"{dest}.tmp"
        img.save(tmp, format="WEBP", quality=68, method=4)
        os.replace(tmp, dest)
        return dest

    with Image.open(path) as img:
        if img.mode not in ("RGB", "L"):
            img = img.convert("RGB")
        img.thumbnail((_THUMB_EDGE, _THUMB_EDGE))
        tmp = f"{dest}.tmp"
        img.save(tmp, format="WEBP", quality=68, method=4)
    os.replace(tmp, dest)
    return dest


_PLACEHOLDERS = {
    "image": "zealman-blank-image.png",
    "video": "zealman-blank-video.mp4",
    "audio": "zealman-blank-audio.mp3",
}


def placeholder_source(name: str) -> str:
    return os.path.join(os.path.dirname(__file__), "assets", "placeholders", name)


def ensure_placeholder(kind: str) -> str:
    name = _PLACEHOLDERS.get(kind)
    if not name:
        raise ValueError("invalid kind")
    src = placeholder_source(name)
    if not os.path.isfile(src) or os.path.getsize(src) <= 0:
        raise FileNotFoundError(name)
    dest_dir = folder_paths.get_input_directory()
    os.makedirs(dest_dir, exist_ok=True)
    dest = os.path.join(dest_dir, name)
    if not os.path.isfile(dest) or os.path.getsize(dest) <= 0:
        shutil.copyfile(src, dest)
        with _list_lock:
            _list_cache.pop(f"input:{kind}", None)
    return name


def ensure_builtin_placeholders() -> None:
    for kind in _PLACEHOLDERS:
        try:
            ensure_placeholder(kind)
        except Exception as exc:
            print(f"[zealman] 内置占位未恢复 {kind}: {exc}")


def register_routes() -> None:
    ensure_builtin_placeholders()
    import asyncio

    from aiohttp import web
    from server import PromptServer

    @PromptServer.instance.routes.get("/zealman/image-picker/{folder}")
    async def zealman_image_picker(request):
        folder = request.match_info["folder"]
        if folder not in ("input", "output"):
            return web.json_response({"error": "invalid folder"}, status=400)
        refresh = request.rel_url.query.get("refresh") == "1"
        kind = request.rel_url.query.get("kind", "image")
        if kind not in ("image", "video", "audio"):
            return web.json_response({"error": "invalid kind"}, status=400)
        loop = asyncio.get_running_loop()
        items = await loop.run_in_executor(None, get_images, folder, refresh, kind)
        return web.json_response(items, headers={"Cache-Control": "private, max-age=15"})

    @PromptServer.instance.routes.get("/zealman/image-thumb/{folder}")
    async def zealman_image_thumb(request):
        folder = request.match_info["folder"]
        if folder not in ("input", "output"):
            return web.json_response({"error": "invalid folder"}, status=400)
        try:
            path = resolve_image(
                folder,
                request.rel_url.query.get("subfolder", ""),
                request.rel_url.query.get("name", ""),
            )
        except (ValueError, OSError):
            return web.Response(status=404)
        loop = asyncio.get_running_loop()
        try:
            dest = await loop.run_in_executor(None, thumbnail_file, path)
        except Exception:
            return web.Response(status=404)
        return web.FileResponse(
            dest,
            headers={"Cache-Control": "private, max-age=86400", "Content-Type": "image/webp"},
        )

    @PromptServer.instance.routes.post("/zealman/placeholder/{kind}")
    async def zealman_placeholder(request):
        kind = request.match_info["kind"]
        if kind not in _PLACEHOLDERS:
            return web.json_response({"error": "invalid kind"}, status=400)
        loop = asyncio.get_running_loop()
        try:
            name = await loop.run_in_executor(None, ensure_placeholder, kind)
        except Exception as exc:
            return web.json_response({"error": str(exc)}, status=404)
        return web.json_response({"name": name, "subfolder": "", "type": "input", "kind": kind})
