"""Pack ComfyUI IMAGE / AUDIO inputs into MiniMax H3 reference bundles."""

from __future__ import annotations

import torch

from .media_resize import clamp_max_side, resize_tensor_hwc

MINIMAX_H3_DEFAULT_IMAGE_MAX_SIDE = 2048
MINIMAX_H3_DEFAULT_VIDEO_MAX_SIDE = 1024

MINIMAX_H3_REFERENCE_IMAGES_TYPE = "DENO_MINIMAX_H3_REFERENCE_IMAGES"
MINIMAX_H3_REFERENCE_VIDEO_AUDIOS_TYPE = "DENO_MINIMAX_H3_REFERENCE_VIDEO_AUDIOS"
MINIMAX_H3_REFERENCE_AUDIOS_TYPE = "DENO_MINIMAX_H3_REFERENCE_AUDIOS"

MINIMAX_H3_MAX_REFERENCE_IMAGES = 9
MINIMAX_H3_MAX_REFERENCE_VIDEOS = 3
MINIMAX_H3_MAX_REFERENCE_AUDIOS = 3

MINIMAX_H3_DEFAULT_FPS = 24.0
MINIMAX_H3_DEFAULT_TRIM_SECONDS = 10.0
MINIMAX_H3_MAX_TRIM_SECONDS = 15.0
MINIMAX_H3_MIN_VIDEO_FRAMES = 5

_NODE_PREFIX = "[ZealmanH3ReferenceMedia]"


def _no_reference_media_message() -> str:
    return (
        f"{_NODE_PREFIX} No reference media connected. "
        "Connect at least one IMAGE (image_1 … image_9), video frame batch "
        "(video_1 … video_3 as IMAGE from VHS/GetVideoComponents), "
        "or AUDIO (audio_1 … audio_3)."
    )


def _too_many_reference_images_message(count: int) -> str:
    return (
        f"{_NODE_PREFIX} MiniMax H3 supports at most "
        f"{MINIMAX_H3_MAX_REFERENCE_IMAGES} reference images, but {count} were provided."
    )


def _too_many_reference_videos_message(count: int) -> str:
    return (
        f"{_NODE_PREFIX} MiniMax H3 supports at most "
        f"{MINIMAX_H3_MAX_REFERENCE_VIDEOS} reference videos, but {count} were provided."
    )


def _too_many_reference_audios_message(count: int) -> str:
    return (
        f"{_NODE_PREFIX} MiniMax H3 supports at most "
        f"{MINIMAX_H3_MAX_REFERENCE_AUDIOS} standalone reference audios, but {count} were provided."
    )


def _clamp_trim_seconds(value: float) -> float:
    return max(0.1, min(float(value), MINIMAX_H3_MAX_TRIM_SECONDS))


def _scale_image_tensor(image: torch.Tensor, max_side: int) -> torch.Tensor:
    return resize_tensor_hwc(image, clamp_max_side(max_side))


def _scale_video_frames(frames: torch.Tensor, max_side: int) -> torch.Tensor:
    return resize_tensor_hwc(frames, clamp_max_side(max_side))


def _split_image_tensor(image: torch.Tensor) -> list[torch.Tensor]:
    if not isinstance(image, torch.Tensor):
        raise TypeError(f"{_NODE_PREFIX} Expected an IMAGE tensor, got {type(image).__name__}.")
    if image.ndim != 4:
        raise ValueError(
            f"{_NODE_PREFIX} IMAGE tensor must have shape [B, H, W, C], but received {tuple(image.shape)}."
        )

    batch, height, width, channels = image.shape
    if batch <= 0 or height <= 0 or width <= 0 or channels < 3:
        raise ValueError(
            f"{_NODE_PREFIX} IMAGE tensor must have shape [B>0, H>0, W>0, C>=3], "
            f"but received {tuple(image.shape)}."
        )

    rgb = image[..., :3]
    return [rgb[index : index + 1] for index in range(batch)]


def _collect_reference_images(**image_slots: torch.Tensor | None) -> list[torch.Tensor]:
    images: list[torch.Tensor] = []
    for slot_name in sorted(image_slots.keys(), key=lambda name: int(name.split("_", 1)[1])):
        image = image_slots[slot_name]
        if image is None:
            continue
        images.extend(_split_image_tensor(image))

    if len(images) > MINIMAX_H3_MAX_REFERENCE_IMAGES:
        raise RuntimeError(_too_many_reference_images_message(len(images)))

    return images


def _collect_named_slots(prefix: str, max_count: int, **slots):
    collected = []
    for index in range(1, max_count + 1):
        value = slots.get(f"{prefix}_{index}")
        if value is not None:
            collected.append(value)
    return collected


def _trim_audio_dict(audio: dict, start_seconds: float, duration_seconds: float) -> dict:
    waveform = audio["waveform"]
    sample_rate = int(audio["sample_rate"])
    if not isinstance(waveform, torch.Tensor):
        raise TypeError(f"{_NODE_PREFIX} AUDIO waveform must be a torch.Tensor.")

    audio_length = waveform.shape[-1]
    if audio_length <= 0:
        return {"waveform": waveform, "sample_rate": sample_rate}

    start_frame = int(round(start_seconds * sample_rate))
    end_frame = start_frame + int(round(duration_seconds * sample_rate))
    start_frame = max(0, min(start_frame, audio_length))
    end_frame = max(start_frame, min(end_frame, audio_length))

    if start_frame >= end_frame:
        raise ValueError(
            f"{_NODE_PREFIX} Audio trim produced an empty clip "
            f"(start={start_seconds}s, duration={duration_seconds}s)."
        )

    return {"waveform": waveform[..., start_frame:end_frame], "sample_rate": sample_rate}


def _resample_video_frames(images: torch.Tensor, source_fps: float, target_fps: float, trim_seconds: float | None) -> torch.Tensor:
    if images.ndim != 4:
        raise ValueError(
            f"{_NODE_PREFIX} Video frames must have shape [N, H, W, C], but received {tuple(images.shape)}."
        )

    frame_count = images.shape[0]
    if frame_count <= 0:
        raise ValueError(f"{_NODE_PREFIX} Video has no decodable frames.")

    source_fps = max(1.0, float(source_fps))
    target_fps = max(1.0, float(target_fps))
    if trim_seconds is None:
        if abs(source_fps - target_fps) < 0.01:
            return images
        target_count = max(1, int(round(frame_count * target_fps / source_fps)))
        if target_count == frame_count:
            return images
        indices = torch.linspace(0, frame_count - 1, target_count).round().long()
        return images[indices]

    trim_seconds = _clamp_trim_seconds(trim_seconds)
    target_count = max(MINIMAX_H3_MIN_VIDEO_FRAMES, int(round(target_fps * trim_seconds)))

    if frame_count == target_count:
        return images

    if frame_count > target_count:
        indices = torch.linspace(0, frame_count - 1, target_count).round().long()
        return images[indices]

    if frame_count >= MINIMAX_H3_MIN_VIDEO_FRAMES:
        return images

    indices = torch.linspace(0, frame_count - 1, MINIMAX_H3_MIN_VIDEO_FRAMES).round().long()
    return images[indices]


def _process_video_frames_input(
    frames: torch.Tensor,
    fps: float,
    trim_seconds: float,
) -> torch.Tensor:
    """IMAGE 帧 batch（与 MiniMaxH3ReferenceToVideo.ref_video 相同）。"""
    if frames is None:
        raise TypeError(f"{_NODE_PREFIX} Expected an IMAGE frame batch for video_N.")
    if not isinstance(frames, torch.Tensor):
        frames = torch.from_numpy(frames)
    if frames.ndim != 4:
        raise ValueError(
            f"{_NODE_PREFIX} Video frame batch must have shape [N, H, W, C], "
            f"but received {tuple(frames.shape)}."
        )
    if frames.shape[0] <= 0:
        raise ValueError(f"{_NODE_PREFIX} Video frame batch is empty.")

    source_fps = max(1.0, float(fps))
    return _resample_video_frames(frames, source_fps, source_fps, trim_seconds)


def _process_audio_input(audio, trim_seconds: float | None) -> dict:
    if audio is None:
        raise TypeError(f"{_NODE_PREFIX} Expected an AUDIO input.")
    if not isinstance(audio, dict) or "waveform" not in audio or "sample_rate" not in audio:
        raise TypeError(f"{_NODE_PREFIX} AUDIO input must be a ComfyUI audio dict.")
    if trim_seconds is None:
        waveform = audio["waveform"]
        if not isinstance(waveform, torch.Tensor):
            raise TypeError(f"{_NODE_PREFIX} AUDIO waveform must be a torch.Tensor.")
        if waveform.ndim == 2:
            waveform = waveform.unsqueeze(0)
        return {"waveform": waveform, "sample_rate": int(audio["sample_rate"])}
    return _trim_audio_dict(audio, 0.0, _clamp_trim_seconds(trim_seconds))


def _collect_reference_videos(
    fps: float,
    video_trim_seconds: float,
    video_max_side: int,
    **kwargs,
) -> list[torch.Tensor]:
    video_frames: list[torch.Tensor] = []

    for index in range(1, MINIMAX_H3_MAX_REFERENCE_VIDEOS + 1):
        frame_batch = kwargs.get(f"video_{index}")
        if frame_batch is None:
            continue
        try:
            frames = _process_video_frames_input(frame_batch, fps, video_trim_seconds)
            video_frames.append(_scale_video_frames(frames, video_max_side))
        except Exception as exc:
            raise RuntimeError(f"{_NODE_PREFIX} Failed to process video_{index}: {exc}") from exc

    if len(video_frames) > MINIMAX_H3_MAX_REFERENCE_VIDEOS:
        raise RuntimeError(_too_many_reference_videos_message(len(video_frames)))

    return video_frames


class ZealmanH3LoadImageToRefImages:
    """Pack ComfyUI reference media into MiniMax H3-compatible bundles."""

    DESCRIPTION = (
        "Pack up to 9 images, 3 reference video frame batches (IMAGE), and 3 audios into "
        "ordered MiniMax H3 reference bundles. "
        "video_1…video_3 accept IMAGE frame batches only (same as MiniMax ref_video); "
        "ref_videos output is an IMAGE list of those frame batches. "
        "Images use image_max_side; each video frame uses video_max_side. "
        "Videos are trimmed (default 10s, max 15s), resampled to the chosen fps (default 24). "
        "Output types match MiniMax H3 Reference to Video and H3 Vision Analyzer wired inputs."
    )
    SEARCH_ALIASES = [
        "H3 Reference Media",
        "H3 ref media",
        "MiniMax reference media",
        "H3 Load Image ref_images",
        "Zealman H3 reference",
    ]

    @classmethod
    def INPUT_TYPES(cls):
        optional = {
            **{
                f"image_{index}": ("IMAGE",)
                for index in range(1, MINIMAX_H3_MAX_REFERENCE_IMAGES + 1)
            },
            **{
                f"video_{index}": (
                    "IMAGE",
                    {
                        "tooltip": (
                            f"参考视频 {index} 的帧序列（IMAGE batch [N,H,W,C]，"
                            "如 VHS/GetVideoComponents；与 MiniMax ref_video 相同）。"
                        ),
                    },
                )
                for index in range(1, MINIMAX_H3_MAX_REFERENCE_VIDEOS + 1)
            },
            **{
                f"audio_{index}": ("AUDIO",)
                for index in range(1, MINIMAX_H3_MAX_REFERENCE_AUDIOS + 1)
            },
        }
        return {
            "required": {
                "fps": (
                    "FLOAT",
                    {
                        "default": MINIMAX_H3_DEFAULT_FPS,
                        "min": 1.0,
                        "max": 60.0,
                        "step": 1.0,
                        "tooltip": "Output frame rate for reference videos (MiniMax H3 expects 24 fps).",
                    },
                ),
                "video_trim_seconds": (
                    "FLOAT",
                    {
                        "default": MINIMAX_H3_DEFAULT_TRIM_SECONDS,
                        "min": 0.2,
                        "max": MINIMAX_H3_MAX_TRIM_SECONDS,
                        "step": 0.5,
                        "tooltip": "Trim each reference video to this duration in seconds (max 15).",
                    },
                ),
                "audio_trim_seconds": (
                    "FLOAT",
                    {
                        "default": MINIMAX_H3_DEFAULT_TRIM_SECONDS,
                        "min": 0.1,
                        "max": MINIMAX_H3_MAX_TRIM_SECONDS,
                        "step": 0.5,
                        "tooltip": "Trim standalone reference audios to this duration in seconds (max 15).",
                    },
                ),
                "image_max_side": (
                    "INT",
                    {
                        "default": MINIMAX_H3_DEFAULT_IMAGE_MAX_SIDE,
                        "min": 32,
                        "max": 16384,
                        "step": 32,
                        "tooltip": "参考图长边上限：超过则缩小，不超过则仅 32 对齐居中裁切。",
                    },
                ),
                "video_max_side": (
                    "INT",
                    {
                        "default": MINIMAX_H3_DEFAULT_VIDEO_MAX_SIDE,
                        "min": 32,
                        "max": 16384,
                        "step": 32,
                        "tooltip": "参考视频每一帧的长边上限（规则同 image_max_side）。",
                    },
                ),
            },
            "optional": optional,
        }

    RETURN_TYPES = (
        MINIMAX_H3_REFERENCE_IMAGES_TYPE,
        "IMAGE",
        "IMAGE",
        MINIMAX_H3_REFERENCE_VIDEO_AUDIOS_TYPE,
        MINIMAX_H3_REFERENCE_AUDIOS_TYPE,
    )
    RETURN_NAMES = ("ref_images", "image_list", "ref_videos", "ref_video_audios", "ref_audios")
    OUTPUT_IS_LIST = (False, True, True, False, False)
    FUNCTION = "pack_reference_media"
    CATEGORY = "Zealman/H3"

    def pack_reference_media(
        self,
        fps: float = MINIMAX_H3_DEFAULT_FPS,
        video_trim_seconds: float = MINIMAX_H3_DEFAULT_TRIM_SECONDS,
        audio_trim_seconds: float = MINIMAX_H3_DEFAULT_TRIM_SECONDS,
        image_max_side: int = MINIMAX_H3_DEFAULT_IMAGE_MAX_SIDE,
        video_max_side: int = MINIMAX_H3_DEFAULT_VIDEO_MAX_SIDE,
        **kwargs,
    ):
        image_max_side = clamp_max_side(image_max_side)
        video_max_side = clamp_max_side(video_max_side)
        image_slots = {
            key: value for key, value in kwargs.items() if key.startswith("image_")
        }
        audio_inputs = _collect_named_slots("audio", MINIMAX_H3_MAX_REFERENCE_AUDIOS, **kwargs)

        images = _collect_reference_images(**image_slots)
        images = [_scale_image_tensor(image, image_max_side) for image in images]

        video_trim_seconds = _clamp_trim_seconds(video_trim_seconds)
        audio_trim_seconds = _clamp_trim_seconds(audio_trim_seconds)

        video_frames = _collect_reference_videos(
            fps,
            video_trim_seconds,
            video_max_side,
            **kwargs,
        )

        if not images and not video_frames and not audio_inputs:
            raise RuntimeError(_no_reference_media_message())
        if len(audio_inputs) > MINIMAX_H3_MAX_REFERENCE_AUDIOS:
            raise RuntimeError(_too_many_reference_audios_message(len(audio_inputs)))

        standalone_audios: list[dict] = []
        for index, audio in enumerate(audio_inputs, start=1):
            try:
                standalone_audios.append(_process_audio_input(audio, audio_trim_seconds))
            except Exception as exc:
                raise RuntimeError(f"{_NODE_PREFIX} Failed to process audio_{index}: {exc}") from exc

        video_audios = tuple(None for _ in video_frames)

        return (
            tuple(images),
            images,
            video_frames,
            video_audios,
            tuple(standalone_audios),
        )


ZealmanH3ReferenceMedia = ZealmanH3LoadImageToRefImages
