# -*- coding: utf-8 -*-
"""Zealman 插件目录名（含重命名前的旧名）。"""

from __future__ import annotations

import os

# 新目录优先；旧目录为兼容桩，供 Promptor / 历史路径解析。
ZEALMAN_PLUGIN_DIR_NAMES = ("comfyUI-zealman", "comfyUI-zealman-llm")


def iter_zealman_plugin_dirs(custom_nodes: list[str] | None = None) -> list[str]:
    if not custom_nodes:
        try:
            import folder_paths

            custom_nodes = folder_paths.get_folder_paths("custom_nodes")
        except Exception:
            custom_nodes = ["/root/ComfyUI/custom_nodes"]
    found: list[str] = []
    for base in custom_nodes:
        for name in ZEALMAN_PLUGIN_DIR_NAMES:
            path = os.path.join(base, name)
            if os.path.isdir(path):
                found.append(path)
    # 去重且保持 ZEALMAN_PLUGIN_DIR_NAMES 顺序
    ordered: list[str] = []
    seen: set[str] = set()
    for name in ZEALMAN_PLUGIN_DIR_NAMES:
        for path in found:
            if os.path.basename(path) == name and path not in seen:
                ordered.append(path)
                seen.add(path)
    return ordered


def resolve_zealman_plugin_file(filename: str, custom_nodes: list[str] | None = None) -> str | None:
    for plugin_dir in iter_zealman_plugin_dirs(custom_nodes):
        path = os.path.join(plugin_dir, filename)
        if os.path.isfile(path):
            return path
    return None
