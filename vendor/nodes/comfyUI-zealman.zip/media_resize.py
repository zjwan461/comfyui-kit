# -*- coding: utf-8 -*-
"""Reference / vision media: long-edge scale + center crop to multiples of 32."""

from __future__ import annotations

import base64
import io
import math

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

ALIGN = 32
DEFAULT_MAX_SIDE = 1024
JPEG_QUALITY = 90


def clamp_max_side(value: int) -> int:
    return max(ALIGN, int(value or DEFAULT_MAX_SIDE))


def align_down(value: int, align: int = ALIGN) -> int:
    size = max(align, int(value))
    return max(align, (size // align) * align)


def resize_pil_max_side_align32(pil: Image.Image, max_side: int) -> Image.Image:
    """Scale by long edge, then center-crop to 32-aligned width/height."""
    max_side = clamp_max_side(max_side)
    width, height = pil.size
    if width <= 0 or height <= 0:
        return pil

    long_edge = max(width, height)
    if long_edge > max_side:
        scale = max_side / float(long_edge)
        new_w = max(1, int(round(width * scale)))
        new_h = max(1, int(round(height * scale)))
        pil = pil.resize((new_w, new_h), resample=Image.BICUBIC)
        width, height = pil.size

    target_w = align_down(width)
    target_h = align_down(height)
    if target_w == width and target_h == height:
        return pil

    left = max(0, (width - target_w) // 2)
    top = max(0, (height - target_h) // 2)
    return pil.crop((left, top, left + target_w, top + target_h))


def pil_to_jpeg_b64(pil: Image.Image, quality: int = JPEG_QUALITY) -> str:
    if pil.mode in ("RGBA", "LA") or "transparency" in pil.info:
        rgba = pil.convert("RGBA")
        background = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
        background.alpha_composite(rgba)
        pil = background.convert("RGB")
    elif pil.mode not in ("RGB", "L"):
        pil = pil.convert("RGB")
    buf = io.BytesIO()
    pil.save(buf, format="JPEG", quality=quality, optimize=True, progressive=True)
    return base64.b64encode(buf.getvalue()).decode("utf-8")


def b64_jpeg_resize_max_side(b64: str, max_side: int) -> str:
    text = (b64 or "").strip()
    if not text or max_side <= 0:
        return text
    if text.startswith("data:"):
        comma = text.find(",")
        payload = text[comma + 1 :] if comma >= 0 else text
    else:
        payload = text
    try:
        raw = base64.b64decode(payload, validate=False)
        pil = Image.open(io.BytesIO(raw))
        pil = resize_pil_max_side_align32(pil, max_side)
        return pil_to_jpeg_b64(pil)
    except Exception:
        return text


def b64_to_data_url_resized(b64: str, max_side: int) -> str:
    text = (b64 or "").strip()
    if not text:
        return ""
    if text.startswith("data:"):
        comma = text.find(",")
        prefix = text[: comma + 1] if comma >= 0 else "data:image/jpeg;base64,"
        payload = text[comma + 1 :] if comma >= 0 else text
        resized = b64_jpeg_resize_max_side(payload, max_side)
        return f"{prefix}{resized}" if resized else ""
    resized = b64_jpeg_resize_max_side(text, max_side)
    if not resized:
        return ""
    return f"data:image/jpeg;base64,{resized}"


def round_up_to_multiple(number: int, multiple: int = ALIGN) -> int:
    size = max(1, int(number))
    step = max(1, int(multiple))
    remainder = size % step
    if remainder == 0:
        return size
    return ((size + step - 1) // step) * step


def total_kilo_pixel_size(width: int, height: int, kilo_pixels: int, multiple: int = ALIGN) -> tuple[int, int]:
    """Match LayerStyle total_pixel(kilo pixel): area is kilo_pixels * 1000, aspect stays original."""
    if width <= 0 or height <= 0:
        raise ValueError(f"Invalid image size {width}x{height}")
    ratio = float(width) / float(height)
    target_width = math.sqrt(ratio * float(kilo_pixels) * 1000.0)
    target_height = target_width / ratio
    return (
        round_up_to_multiple(int(target_width), multiple),
        round_up_to_multiple(int(target_height), multiple),
    )


def fit_crop_lanczos(image: Image.Image, target_width: int, target_height: int) -> Image.Image:
    """Center-crop to the target aspect, then Lanczos-resize. Same fit=crop path as LayerStyle."""
    rgb = image.convert("RGB")
    orig_width, orig_height = rgb.size
    if orig_width <= 0 or orig_height <= 0:
        return rgb
    if orig_width / orig_height > target_width / target_height:
        fit_width = max(1, int(orig_height * target_width / target_height))
        left = max(0, (orig_width - fit_width) // 2)
        rgb = rgb.crop((left, 0, left + fit_width, orig_height))
    else:
        fit_height = max(1, int(orig_width * target_height / target_width))
        top = max(0, (orig_height - fit_height) // 2)
        rgb = rgb.crop((0, top, orig_width, top + fit_height))
    return rgb.resize((target_width, target_height), resample=Image.LANCZOS)


def resize_tensor_total_kilo_pixels(tensor: torch.Tensor, kilo_pixels: int, multiple: int = ALIGN) -> torch.Tensor:
    """Resize [N,H,W,C] or [H,W,C] by total kilo pixels, original aspect, crop, Lanczos, round up to 32."""
    kilo_pixels = max(1, int(kilo_pixels or 0))
    squeeze = False
    if tensor.ndim == 3:
        tensor = tensor.unsqueeze(0)
        squeeze = True
    if tensor.ndim != 4:
        raise ValueError(f"Expected [N,H,W,C] or [H,W,C], got {tuple(tensor.shape)}")
    _, height, width, channels = tensor.shape
    if height <= 0 or width <= 0 or channels <= 0:
        return tensor.squeeze(0) if squeeze else tensor
    target_width, target_height = total_kilo_pixel_size(width, height, kilo_pixels, multiple)
    frames = tensor.detach().cpu().float()
    if frames.max().item() > 1.5:
        frames = frames / 255.0
    frames = frames.clamp(0, 1)
    converted = []
    for frame in frames:
        array = (frame[..., :3].numpy() * 255.0).round().astype("uint8")
        image = fit_crop_lanczos(Image.fromarray(array, mode="RGB"), target_width, target_height)
        converted.append(torch.from_numpy(np.asarray(image, dtype=np.float32) / 255.0))
    out = torch.stack(converted, dim=0)
    return out.squeeze(0) if squeeze else out


def resize_tensor_to_long_edge(tensor: torch.Tensor, target_side: int, multiple: int = ALIGN) -> torch.Tensor:
    """Scale [N,H,W,C] or [H,W,C] so the long edge equals the target, then center-crop to a multiple of 32."""
    step = max(1, int(multiple))
    target_side = align_down(max(step, int(target_side or DEFAULT_MAX_SIDE)), step)
    squeeze = False
    if tensor.ndim == 3:
        tensor = tensor.unsqueeze(0)
        squeeze = True
    if tensor.ndim != 4:
        raise ValueError(f"Expected [N,H,W,C] or [H,W,C], got {tuple(tensor.shape)}")

    _, height, width, _ = tensor.shape
    if height <= 0 or width <= 0:
        return tensor.squeeze(0) if squeeze else tensor

    if int(height) >= int(width):
        new_h = target_side
        new_w = max(1, int(round(float(width) * target_side / float(height))))
    else:
        new_w = target_side
        new_h = max(1, int(round(float(height) * target_side / float(width))))

    out = tensor
    if new_h != int(height) or new_w != int(width):
        chw = out.permute(0, 3, 1, 2).float()
        chw = F.interpolate(chw, size=(new_h, new_w), mode="bicubic", align_corners=False)
        out = chw.permute(0, 2, 3, 1).clamp(0, 1)
        height, width = new_h, new_w

    target_h = align_down(height, step)
    target_w = align_down(width, step)
    if target_h < height or target_w < width:
        top = max(0, (height - target_h) // 2)
        left = max(0, (width - target_w) // 2)
        out = out[:, top : top + target_h, left : left + target_w, :]

    return out.squeeze(0) if squeeze else out


def resize_tensor_hwc(tensor: torch.Tensor, max_side: int) -> torch.Tensor:
    """Resize [N,H,W,C] or [H,W,C] tensors: long-edge scale + 32-aligned center crop."""
    max_side = clamp_max_side(max_side)
    squeeze = False
    if tensor.ndim == 3:
        tensor = tensor.unsqueeze(0)
        squeeze = True
    if tensor.ndim != 4:
        raise ValueError(f"Expected [N,H,W,C] or [H,W,C], got {tuple(tensor.shape)}")

    _, height, width, _ = tensor.shape
    if height <= 0 or width <= 0:
        return tensor.squeeze(0) if squeeze else tensor

    long_edge = max(height, width)
    if long_edge > max_side:
        scale = max_side / float(long_edge)
        new_h = max(1, int(round(height * scale)))
        new_w = max(1, int(round(width * scale)))
    else:
        new_h, new_w = height, width

    target_h = align_down(new_h)
    target_w = align_down(new_w)

    out = tensor
    if new_h != height or new_w != width:
        chw = out.permute(0, 3, 1, 2)
        chw = F.interpolate(chw, size=(new_h, new_w), mode="bicubic", align_corners=False)
        out = chw.permute(0, 2, 3, 1)
        height, width = new_h, new_w

    if target_h < height or target_w < width:
        top = max(0, (height - target_h) // 2)
        left = max(0, (width - target_w) // 2)
        out = out[:, top : top + target_h, left : left + target_w, :]

    return out.squeeze(0) if squeeze else out
