# -*- coding: utf-8 -*-
"""供 ComfyUI-MiniMax-H3-Promptor 调用的本地 Zealman LLM 推理桥接。"""

from __future__ import annotations

import os
import sys
import inspect
from typing import Any


def _load_media_resize():
    """
    Promptor 用 spec_from_file_location 单独加载本文件，没有 parent package，
    相对导入会报 attempted relative import with no known parent package。
    优先复用 ComfyUI 已加载的 media_resize，否则按文件路径加载。
    """
    import importlib.util

    suffixes = tuple(
        os.path.join(name, "media_resize.py").replace("\\", "/")
        for name in ("comfyUI-zealman", "comfyUI-zealman-llm")
    )
    for mod in list(sys.modules.values()):
        if mod is None:
            continue
        mod_file = (getattr(mod, "__file__", "") or "").replace("\\", "/")
        if not any(mod_file.endswith(suffix) for suffix in suffixes):
            continue
        fn = getattr(mod, "b64_to_data_url_resized", None)
        clamp = getattr(mod, "clamp_max_side", None)
        if callable(fn) and callable(clamp):
            return fn, clamp

    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, "media_resize.py")
    cached_name = "comfyui_zealman_llm_media_resize"
    cached = sys.modules.get(cached_name)
    if cached is not None and callable(getattr(cached, "b64_to_data_url_resized", None)):
        return cached.b64_to_data_url_resized, cached.clamp_max_side

    spec = importlib.util.spec_from_file_location(cached_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"无法加载 media_resize：{path}")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[cached_name] = mod
    spec.loader.exec_module(mod)
    return mod.b64_to_data_url_resized, mod.clamp_max_side


b64_to_data_url_resized, clamp_max_side = _load_media_resize()

_BRIDGE_VERSION = "2026-09-09-fix1"
_ZEALMAN_PLUGIN_DIR_NAMES = ("comfyUI-zealman", "comfyUI-zealman-llm")


def _bridge_log(msg: str) -> None:
    print(f"[comfyUI-zealman] h3_bridge({_BRIDGE_VERSION}): {msg}", flush=True)


def _zealman_nodes_module():
    """
    必须使用 ComfyUI 已加载的 Zealman nodes 模块（comfyUI-zealman 或旧目录）。
    禁止再 spec 加载第二份 nodes.py（会产生独立的 ZealmanLLMStorage → 重复占 VRAM / 推理异常）。
    本文件常被 Promptor 用 spec_from_file_location 单独加载，禁止相对导入。
    """
    for name in _ZEALMAN_PLUGIN_DIR_NAMES:
        for key in (f"{name}.nodes", name):
            mod = sys.modules.get(key)
            if mod is not None and _is_zealman_nodes_module(mod):
                return mod
        suffix = f".{name}.nodes"
        for key, mod in list(sys.modules.items()):
            if mod is None:
                continue
            if str(key).endswith(suffix) and _is_zealman_nodes_module(mod):
                return mod

    for mod in list(sys.modules.values()):
        if mod is None:
            continue
        if _is_zealman_nodes_module(mod):
            return mod

    dirs = ", ".join(_ZEALMAN_PLUGIN_DIR_NAMES)
    raise RuntimeError(
        f"Zealman 插件尚未被 ComfyUI 加载（已查找：{dirs}）。请确认插件存在并重启 ComfyUI。"
    )


def _is_zealman_nodes_module(mod) -> bool:
    """排除 torch.ops 等假阳性（hasattr 会惰性创建 OpNamespace）。

    SeedVR 等插件会把 xformers._C_flashattention 换成 FailingStub，
    __getattr__ 抛的是 ImportError 不是 AttributeError。
    getattr(mod, name, None) 挡不住，全量扫 sys.modules 时会误报
    `_C_flashattention unavailable`。
    """
    try:
        mod_file = (getattr(mod, "__file__", "") or "").replace("\\", "/")
        if mod_file.endswith(os.path.join("comfyUI-zealman", "nodes.py")):
            return True
        if mod_file.endswith(os.path.join("comfyUI-zealman-llm", "nodes.py")):
            return True
        name = getattr(mod, "__name__", "") or ""
        name_norm = name.replace("\\", "/")
        if name.endswith(".nodes") and (
            "comfyUI-zealman" in name_norm or "comfyUI-zealman-llm" in name_norm
        ):
            return True
        storage = getattr(mod, "ZealmanLLMStorage", None)
        chat_fn = getattr(mod, "_chat_completion", None)
        return (
            inspect.isclass(storage)
            and callable(chat_fn)
            and getattr(storage, "ensure_capacity", None) is not None
        )
    except Exception:
        return False


def _resolve_model(zealman_model, ZealmanLLMStorage):
    """优先使用 ZealmanLLMStorage 中的最新实例（ensure_capacity 重载后连线对象可能过期）。"""
    storage = getattr(ZealmanLLMStorage, "model", None)
    if storage is not None and getattr(storage, "llm", None) is not None:
        if zealman_model is not None and zealman_model is not storage:
            sync = getattr(ZealmanLLMStorage, "sync_model_ref", None)
            if callable(sync):
                sync(zealman_model, storage)
        return storage

    if (
        zealman_model is not None
        and hasattr(zealman_model, "llm")
        and hasattr(zealman_model, "settings")
        and getattr(zealman_model, "llm", None) is not None
    ):
        ZealmanLLMStorage.model = zealman_model
        return zealman_model
    return ZealmanLLMStorage.resolve(zealman_model)


def _build_messages(
    *,
    system_prompt: str,
    user_message: str,
    base64_images: list[Any] | None,
    max_side: int = 1024,
) -> tuple[list[dict], str, str, int]:
    system_text = (system_prompt or "").strip()
    prompt_text = (user_message or "").strip()
    image_urls: list[str] = []
    side = clamp_max_side(max_side)

    if base64_images and len(base64_images) > 0:
        if isinstance(base64_images[0], dict):
            text_parts: list[str] = []
            for item in base64_images:
                if not isinstance(item, dict):
                    continue
                if "text" in item and str(item.get("text") or "").strip():
                    text_parts.append(str(item["text"]).strip())
                elif "image" in item:
                    url = b64_to_data_url_resized(str(item["image"]), side)
                    if url:
                        image_urls.append(url)
            if text_parts:
                prompt_text = "\n\n".join(text_parts)
        else:
            for item in base64_images:
                url = b64_to_data_url_resized(str(item), side)
                if url:
                    image_urls.append(url)
            if not prompt_text:
                prompt_text = "Analyze the attached image(s)."

    if not prompt_text and not image_urls:
        raise ValueError("Zealman LLM：提示词与图片不能同时为空。")

    messages: list[dict] = []
    if system_text:
        messages.append({"role": "system", "content": system_text})

    if image_urls:
        user_content: list[dict] = [{"type": "text", "text": prompt_text}]
        for url in image_urls:
            user_content.append({"type": "image_url", "image_url": {"url": url}})
        messages.append({"role": "user", "content": user_content})
    else:
        messages.append({"role": "user", "content": prompt_text})

    return messages, prompt_text, system_text, len(image_urls)


def prepare_zealman_vision_capacity(
    zealman_model,
    *,
    n_images: int,
    max_side: int = 1024,
    system_prompt: str = "",
    max_tokens: int = 4096,
) -> tuple[int, str | None]:
    """Vision Analyzer 分析前按峰值图片数预扩容 Zealman 上下文。"""
    if zealman_model is None:
        return 0, None

    n_images = max(0, int(n_images))
    if n_images <= 0:
        return 0, None

    try:
        zn = _zealman_nodes_module()
        ZealmanLLMStorage = zn.ZealmanLLMStorage
        _estimate_needed_ctx = zn._estimate_needed_ctx
        _snap_ctx = zn._snap_ctx

        model = _resolve_model(zealman_model, ZealmanLLMStorage)
        if not getattr(model, "llm", None):
            return 0, "Zealman LLM 模型对象无效，请重新运行「Zealman LLM 模型加载器」。"

        if model.chat_handler is None:
            return 0, "当前 Zealman LLM 未加载 mmproj，无法看图。请在加载器中选择视觉投影。"

        system_text = (system_prompt or "").strip()
        side = clamp_max_side(max_side)
        suggested_ctx = _snap_ctx(
            _estimate_needed_ctx(
                n_images,
                int(side),
                system_text,
                max_tokens=int(max_tokens),
            )
        )
        current_ctx = int((model.settings or {}).get("n_ctx", 0) or 0)

        model = ZealmanLLMStorage.ensure_capacity(
            model,
            n_images=n_images,
            max_side=int(side),
            prompt_text="Vision analysis",
            system_text=system_text,
            max_tokens=int(max_tokens),
        )
        target_ctx = int((model.settings or {}).get("n_ctx", suggested_ctx) or suggested_ctx)
        _bridge_log(
            f"vision ctx {current_ctx} -> {target_ctx} "
            f"(peak {n_images} images, max_side={side}, suggested={suggested_ctx})"
        )
        return target_ctx, None
    except Exception as exc:
        return 0, f"Zealman LLM 视觉上下文预扩容失败：{exc}"


def zealman_chat(
    zealman_model,
    *,
    system_prompt: str = "",
    user_message: str = "",
    base64_images: list[Any] | None = None,
    max_side: int = 1024,
    temperature: float = 0.7,
    max_tokens: int = 4096,
    top_p: float = 0.9,
    top_k: int = 20,
    seed: int = 0,
) -> tuple[str, str | None]:
    """使用已加载的 Zealman LLM 完成一次 chat。返回 (content, error)。"""
    if zealman_model is None:
        return "", "未连接 zealman模型。请先运行「Zealman LLM 模型加载器」并连线。"

    import comfy.model_management as mm

    side = clamp_max_side(max_side)

    try:
        zn = _zealman_nodes_module()
        _bridge_log(f"nodes={getattr(zn, '__file__', None)}")
        ZealmanLLMStorage = zn.ZealmanLLMStorage
        _apply_qwen38_sampling = zn._apply_qwen38_sampling
        _chat_completion = zn._chat_completion
        if not callable(_chat_completion):
            return "", f"Zealman bridge 内部错误：_chat_completion 不可调用 ({type(_chat_completion)!r})"
        _is_vision_capacity_error = zn._is_vision_capacity_error
        _normalize_seed = zn._normalize_seed
        _reset_llm = zn._reset_llm
        _strip_think = zn._strip_think
        _vision_capacity_error = zn._vision_capacity_error

        try:
            model = _resolve_model(zealman_model, ZealmanLLMStorage)
        except Exception as exc:
            return "", f"Zealman LLM 模型无效：{exc}"

        if not getattr(model, "llm", None):
            return "", "Zealman LLM 模型对象无效，请重新运行「Zealman LLM 模型加载器」。"

        try:
            messages, prompt_text, system_text, n_images = _build_messages(
                system_prompt=system_prompt,
                user_message=user_message,
                base64_images=base64_images,
                max_side=side,
            )
        except Exception as exc:
            return "", str(exc)

        if n_images > 0 and model.chat_handler is None:
            return "", "当前 Zealman LLM 未加载 mmproj，无法看图。请在加载器中选择视觉投影。"

        llm_handler = getattr(model.llm, "chat_handler", None)
        if n_images > 0 and llm_handler is None:
            return (
                "",
                "Zealman LLM 视觉 handler 未就绪（llm.chat_handler 为空）。"
                "请确认已选择 mmproj 并重启 ComfyUI 后重试。",
            )

        try:
            model = ZealmanLLMStorage.ensure_capacity(
                model,
                n_images=n_images,
                max_side=int(side),
                prompt_text=prompt_text,
                system_text=system_text,
                max_tokens=int(max_tokens),
            )
        except Exception as exc:
            return "", f"Zealman LLM 上下文扩容失败：{exc}"

        temperature, sampled_top_p, sampled_top_k = _apply_qwen38_sampling(
            model.settings or {},
            float(temperature),
            float(top_p),
            int(top_k),
        )
        params = {
            "max_tokens": int(max_tokens),
            "temperature": temperature,
            "top_p": sampled_top_p,
            "top_k": sampled_top_k,
            "seed": _normalize_seed(seed),
            "stream": False,
            "stop": ["</s>"],
        }

        if mm.processing_interrupted():
            raise mm.InterruptProcessingException()

        _reset_llm(model.llm)
        try:
            out = _chat_completion(model.llm, messages=messages, params=params)
        except mm.InterruptProcessingException:
            raise
        except Exception as exc:
            err_text = str(exc)
            if _is_vision_capacity_error(exc):
                n_ctx = int((model.settings or {}).get("n_ctx", 32768) or 32768)
                try:
                    ZealmanLLMStorage.unload()
                except Exception:
                    pass
                err = _vision_capacity_error(
                    n_images=n_images,
                    max_side=int(side),
                    n_ctx=n_ctx,
                    max_tokens=int(max_tokens),
                )
                return "", str(err)
            if "flashattention" in err_text.lower() or "_c_flashattention" in err_text.lower():
                return (
                    "",
                    "Zealman LLM 推理失败：Flash Attention 不可用。"
                    "请确认未重复加载模型；若仍失败，可在加载器改用较小上下文或重启 ComfyUI 后再试。"
                    f" 原始错误：{err_text}",
                )
            return "", f"Zealman LLM 推理失败：{err_text}"

        try:
            text = out["choices"][0]["message"]["content"]
        except Exception:
            text = str(out)

        text = _strip_think(str(text or "")).lstrip().removeprefix(": ").strip()
        if not text:
            return "", "Zealman LLM 返回空内容。"
        return text, None
    except mm.InterruptProcessingException:
        raise
    except Exception as exc:
        return "", f"Zealman bridge 异常：{exc}"
