# -*- coding: utf-8 -*-
"""MiniMax H3 显存与 UniBlockSwap 工具节点（Zealman 通用版，不依赖南风内部节点）。"""

from __future__ import annotations


class ZealmanH3ApplyUniBlockSwap:
    """条件编码完成后再安装 UniBlockSwap，避免采样前卸载 CLIP/VAE 时条件链尚未结束。

    与原生 ``UniBlockSwap`` 行为一致，但 ``conditioning_dependency`` 仅用于建立执行依赖，
    不参与数值计算。适用于 U23 等离散节点 H3 工作流。
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": ("MODEL",),
                "conditioning_dependency": ("CONDITIONING",),
                "num_blocks": (
                    "INT",
                    {
                        "default": 1,
                        "min": -1,
                        "max": 49,
                        "step": 1,
                        "tooltip": "从末尾换入 GPU 的 block 数；-1=全部，0=关闭（与 UniBlockSwap 一致）",
                    },
                ),
            },
        }

    RETURN_TYPES = ("MODEL",)
    RETURN_NAMES = ("model",)
    FUNCTION = "apply"
    CATEGORY = "Zealman/H3 Memory"

    def apply(self, model, conditioning_dependency, num_blocks=1):
        del conditioning_dependency  # 仅作执行屏障，保证条件编码先于 Swap
        if int(num_blocks) == 0:
            return (model,)
        try:
            import importlib

            module = importlib.import_module("ComfyUI_UniBlockSwap.uniblockswap_node")
        except Exception as exc:
            raise RuntimeError(
                "已启用 Zealman H3 UniBlockSwap，但未找到 ComfyUI_UniBlockSwap 插件；"
                "请确认 custom_nodes/ComfyUI_UniBlockSwap 已安装并重启 ComfyUI。"
            ) from exc
        return module.UniBlockSwap().apply_swap(model, int(num_blocks))
