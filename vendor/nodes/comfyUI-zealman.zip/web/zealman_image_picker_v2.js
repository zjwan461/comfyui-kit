import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";

const STYLE_ID = "zealman-image-picker-style";
const PAGE_SIZE = 240;

function imageWidgetNames(nodeData) {
    const names = [];
    const groups = [nodeData?.input?.required, nodeData?.input?.optional];
    for (const group of groups) {
        if (!group) continue;
        for (const [name, spec] of Object.entries(group)) {
            if (!Array.isArray(spec)) continue;
            const options = spec.find((item) => item && typeof item === "object" && !Array.isArray(item));
            if (!options) continue;
            if (spec[0] === "IMAGEUPLOAD" || options.imageInputName) continue;
            if (options.video_upload || options.audio_upload || options.mesh_upload) continue;
            if (options.image_upload || options.animated_image_upload) names.push(name);
        }
    }
    return names;
}

function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
.zealman-image-picker {
  position: fixed;
  inset: 0;
  z-index: 100000;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.62);
  color: #f4f4f5;
  font-family: inherit;
}
.zealman-image-picker-panel {
  width: min(920px, calc(100vw - 32px));
  height: min(720px, calc(100vh - 32px));
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 16px;
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 16px;
  background: #18181b;
  box-shadow: 0 24px 80px rgba(0, 0, 0, 0.45);
}
.zealman-image-picker-head, .zealman-image-picker-tools {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.zealman-image-picker-head h2 {
  margin: 0;
  font-size: 16px;
  font-weight: 700;
}
.zealman-image-picker-head button, .zealman-image-picker-more {
  border: 1px solid rgba(255, 255, 255, 0.16);
  border-radius: 999px;
  background: transparent;
  color: inherit;
  padding: 6px 12px;
  cursor: pointer;
}
.zealman-image-picker-tools input {
  flex: 1;
  border: 1px solid rgba(255, 255, 255, 0.16);
  border-radius: 10px;
  background: #09090b;
  color: inherit;
  padding: 8px 10px;
}
.zealman-image-picker-grid {
  flex: 1;
  overflow: auto;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 10px;
  align-content: start;
}
.zealman-image-picker-card {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 6px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 12px;
  background: #09090b;
  color: inherit;
  text-align: left;
  cursor: pointer;
}
.zealman-image-picker-card img {
  width: 100%;
  height: 110px;
  object-fit: cover;
  border-radius: 8px;
  background: #27272a;
}
.zealman-image-picker-card span {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 12px;
}
.zealman-image-picker-status {
  margin: 0;
  color: #a1a1aa;
  font-size: 13px;
}
`;
    document.head.appendChild(style);
}

function viewUrl(item, folder) {
    const params = new URLSearchParams({
        filename: item.name,
        type: folder,
        subfolder: item.subfolder || "",
    });
    return api.apiURL(`/view?${params.toString()}`);
}

function applyImage(node, widget, value) {
    const values = widget.options?.values;
    if (Array.isArray(values) && !values.includes(value)) values.push(value);
    widget.value = value;
    widget.callback?.(value);
    node.setDirtyCanvas?.(true, true);
}

let closeActive = null;

function closeDialog() {
    const close = closeActive;
    closeActive = null;
    close?.();
}

async function openPicker(node, widget, folder) {
    ensureStyle();
    closeDialog();
    const root = document.createElement("div");
    root.className = "zealman-image-picker";
    root.innerHTML = `
      <div class="zealman-image-picker-panel" role="dialog" aria-modal="true" aria-label="${folder}">
        <div class="zealman-image-picker-head">
          <h2>${folder}</h2>
          <button type="button" data-close>关闭</button>
        </div>
        <div class="zealman-image-picker-tools">
          <input type="search" placeholder="搜索文件名" />
        </div>
        <p class="zealman-image-picker-status">正在读取</p>
        <div class="zealman-image-picker-grid"></div>
      </div>
    `;
    const panel = root.querySelector(".zealman-image-picker-panel");
    const status = root.querySelector(".zealman-image-picker-status");
    const grid = root.querySelector(".zealman-image-picker-grid");
    const search = root.querySelector("input");
    root.addEventListener("pointerdown", (event) => {
        if (event.target === root) closeDialog();
    });
    panel.addEventListener("pointerdown", (event) => event.stopPropagation());
    root.querySelector("[data-close]").addEventListener("click", closeDialog);
    const onKey = (event) => {
        if (event.key === "Escape") closeDialog();
    };
    document.addEventListener("keydown", onKey);
    closeActive = () => {
        document.removeEventListener("keydown", onKey);
        root.remove();
    };
    document.body.appendChild(root);
    search.focus();

    let files = [];
    try {
        const response = await api.fetchApi(`/zealman/image-picker/${folder}`);
        if (!response.ok) throw new Error(String(response.status));
        files = await response.json();
    } catch (error) {
        status.textContent = "读取失败";
        return;
    }

    const render = (limit) => {
        const query = search.value.trim().toLowerCase();
        const matched = files.filter((item) => {
            const text = `${item.subfolder}/${item.name}`.toLowerCase();
            return !query || text.includes(query);
        });
        grid.replaceChildren();
        if (!matched.length) {
            status.textContent = "这个目录里没有图像";
            return;
        }
        const shown = matched.slice(0, limit);
        status.textContent = matched.length > shown.length
            ? `显示 ${shown.length} / ${matched.length}`
            : `${matched.length} 张`;
        for (const item of shown) {
            const card = document.createElement("button");
            card.type = "button";
            card.className = "zealman-image-picker-card";
            card.title = item.value;
            const image = document.createElement("img");
            image.alt = "";
            image.loading = "lazy";
            image.src = viewUrl(item, folder);
            const label = document.createElement("span");
            label.textContent = item.subfolder ? `${item.subfolder}/${item.name}` : item.name;
            card.append(image, label);
            card.addEventListener("click", () => {
                applyImage(node, widget, item.value);
                closeDialog();
            });
            grid.appendChild(card);
        }
        if (matched.length > shown.length) {
            const more = document.createElement("button");
            more.type = "button";
            more.className = "zealman-image-picker-more";
            more.textContent = "继续显示";
            more.addEventListener("click", () => render(limit + PAGE_SIZE));
            grid.appendChild(more);
        }
    };
    search.addEventListener("input", () => render(PAGE_SIZE));
    render(PAGE_SIZE);
}

function isPickerButton(widget) {
    if (widget?.type !== "button") return false;
    if (widget.options?.zealmanPicker) return true;
    return widget.serialize === false && /^(input|output)(#\d+)?$/.test(widget.name || "");
}

function removePickerButtons(node) {
    const widgets = node.widgets || [];
    for (const widget of widgets.filter(isPickerButton)) {
        if (typeof node.removeWidget === "function") node.removeWidget(widget);
        else {
            const index = widgets.indexOf(widget);
            if (index >= 0) widgets.splice(index, 1);
        }
    }
}

function attachPickers(node, names) {
    removePickerButtons(node);
    node.__zealmanImagePicker = true;
    const widgets = node.widgets || [];
    const targets = [];
    for (const name of names) {
        const widget = widgets.find((item) => item?.name === name && item.type !== "button");
        if (widget && !targets.includes(widget)) targets.push(widget);
    }
    if (!targets.length) return;
    for (let index = targets.length - 1; index >= 0; index -= 1) {
        const widget = targets[index];
        let at = widgets.indexOf(widget);
        const next = widgets[at + 1];
        if (next?.type === "button" && next.options?.canvasOnly) at += 1;
        const suffix = targets.length > 1 ? `:${widget.name}` : "";
        const options = { serialize: false, zealmanPicker: true };
        node.addWidget("button", `input${suffix}`, null, () => openPicker(node, widget, "input"), options);
        node.addWidget("button", `output${suffix}`, null, () => openPicker(node, widget, "output"), options);
        const pair = widgets.splice(widgets.length - 2, 2);
        for (const button of pair) {
            button.serialize = false;
            button.options.zealmanPicker = true;
        }
        widgets.splice(at + 1, 0, ...pair);
    }
    if (typeof node.computeSize === "function" && typeof node.setSize === "function") {
        const size = node.computeSize();
        node.setSize([
            Math.max(node.size?.[0] || 0, size[0]),
            Math.max(node.size?.[1] || 0, size[1]),
        ]);
    }
}

app.registerExtension({
    name: "comfyUI-zealman.imagePicker",
    beforeRegisterNodeDef(nodeType, nodeData) {
        const names = imageWidgetNames(nodeData);
        if (!names.length) return;
        const created = nodeType.prototype.onNodeCreated;
        nodeType.prototype.onNodeCreated = function () {
            const result = created?.apply(this, arguments);
            attachPickers(this, names);
            return result;
        };
    },
});
