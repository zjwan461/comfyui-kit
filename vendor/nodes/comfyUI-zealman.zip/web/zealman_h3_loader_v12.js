import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";

const NODE = "ZealmanH3ModelLoader";
let loadingApiJson = null;

function hookLoadApiJson() {
    if (app._zh3ApiHooked || typeof app.loadApiJson !== "function") return;
    const original = app.loadApiJson;
    app._zh3ApiHooked = true;
    app.loadApiJson = async function loadApiJson(apiData) {
        const previous = loadingApiJson;
        loadingApiJson = apiData;
        try {
            return await original.apply(this, arguments);
        } finally {
            loadingApiJson = previous;
        }
    };
}

function rowsFromApiInputs(inputs) {
    if (!inputs || typeof inputs !== "object") return [];
    return Object.keys(inputs)
        .filter((key) => /^lora_\d+$/.test(key))
        .sort((left, right) => Number(left.slice(5)) - Number(right.slice(5)))
        .flatMap((key) => {
            const value = inputs[key];
            if (!value || typeof value !== "object" || Array.isArray(value)) return [];
            if (typeof value.lora !== "string") return [];
            return [{
                on: value.on !== false,
                lora: value.lora || "none",
                strength: roundStrength(value.strength),
            }];
        });
}

function apiNodeFor(snapshot, node) {
    if (!snapshot || node?.id == null) return null;
    const direct = snapshot[node.id] ?? snapshot[String(node.id)];
    if (direct?.class_type === NODE) return direct;
    const matches = Object.values(snapshot).filter((item) => item?.class_type === NODE);
    if (matches.length === 1) return matches[0];
    return matches.find((item) => item?._meta?.title && item._meta.title === node.title) || null;
}
const LABELS = {
    unet_name: "模型",
    clip_name: "文本编码器",
    video_vae: "视频VAE",
    audio_vae: "音频VAE",
    attention: "注意力",
};

function widgetHeight() {
    return LiteGraph.NODE_WIDGET_HEIGHT || 20;
}

function hideWidget(node, name) {
    const widget = node.widgets?.find((item) => item.name === name);
    if (!widget) return null;
    widget.hidden = true;
    widget.computeSize = () => [0, -4];
    widget.computedHeight = 0;
    widget.options = widget.options || {};
    widget.options.hidden = true;
    if (name === "lora_stack") widget.options.serialize = false;
    return widget;
}

function readStack(widget) {
    try {
        const value = JSON.parse(widget?.value || "[]");
        return Array.isArray(value) ? value.map((row) => ({
            on: row?.on !== false,
            lora: row?.lora || "none",
            strength: Number.isFinite(Number(row?.strength)) ? Number(row.strength) : 1,
        })) : [];
    } catch {
        return [];
    }
}

function roundStrength(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) return 1;
    return Math.round(Math.min(10, Math.max(-10, number)) * 100) / 100;
}

function fitText(ctx, text, maxWidth) {
    const value = String(text || "");
    if (ctx.measureText(value).width <= maxWidth) return value;
    let end = value.length;
    while (end > 1 && ctx.measureText(`${value.slice(0, end)}…`).width > maxWidth) end -= 1;
    return `${value.slice(0, end)}…`;
}

function drawToggle(ctx, posX, posY, height, on) {
    const toggleRadius = height * 0.36;
    const toggleWidth = height * 1.5;
    ctx.save();
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(posX + 4, posY + 4, toggleWidth - 8, height - 8, height * 0.5);
    else ctx.rect(posX + 4, posY + 4, toggleWidth - 8, height - 8);
    ctx.globalAlpha = (app.canvas?.editor_alpha || 1) * 0.25;
    ctx.fillStyle = "rgba(255,255,255,0.45)";
    ctx.fill();
    ctx.globalAlpha = app.canvas?.editor_alpha || 1;
    ctx.fillStyle = on ? "#89B" : "#888";
    ctx.beginPath();
    ctx.arc(on ? posX + height : posX + height * 0.5, posY + height * 0.5, toggleRadius, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    return [posX, toggleWidth];
}

function drawStrength(ctx, rightX, posY, height, value) {
    const arrowWidth = 9;
    const arrowHeight = 10;
    const gap = 3;
    const numberWidth = 32;
    const midY = posY + height / 2;
    let posX = rightX - arrowWidth - gap - numberWidth - gap - arrowWidth;
    ctx.save();
    ctx.fillStyle = LiteGraph.WIDGET_TEXT_COLOR || "#ddd";
    ctx.beginPath();
    ctx.moveTo(posX, midY);
    ctx.lineTo(posX + arrowWidth, midY + arrowHeight / 2);
    ctx.lineTo(posX + arrowWidth, midY - arrowHeight / 2);
    ctx.closePath();
    ctx.fill();
    const left = [posX, arrowWidth];
    posX += arrowWidth + gap;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(fitText(ctx, Number(value).toFixed(2), numberWidth), posX + numberWidth / 2, midY);
    const text = [posX, numberWidth];
    posX += numberWidth + gap;
    ctx.beginPath();
    ctx.moveTo(posX, midY - arrowHeight / 2);
    ctx.lineTo(posX + arrowWidth, midY);
    ctx.lineTo(posX, midY + arrowHeight / 2);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
    return { left, text, right: [posX, arrowWidth] };
}

function install(node) {
    if (node._zh3LoraInstalled) return;
    const stack = hideWidget(node, "lora_stack");
    if (!stack) return;
    function lockDefaults() {
        for (const name of ["weight_dtype", "clip_device"]) {
            const widget = hideWidget(node, name);
            if (widget) widget.value = "default";
        }
    }
    lockDefaults();
    node._zh3LoraInstalled = true;
    for (const widget of node.widgets || []) {
        if (LABELS[widget.name]) {
            widget.label = LABELS[widget.name];
            widget.options = widget.options || {};
            widget.options.label = LABELS[widget.name];
        }
    }
    let files = ["none"];
    let rows = readStack(stack);

    function write() {
        stack.value = JSON.stringify(rows);
        node.graph?.setDirtyCanvas(true, true);
    }

    function chooseLora(event, current, onChoose) {
        const values = files.includes(current) || !current ? files : [current, ...files];
        new LiteGraph.ContextMenu(values, {
            event,
            title: "Choose a lora",
            scale: Math.max(1, app.canvas?.ds?.scale || 1),
            className: "dark",
            callback: onChoose,
        });
    }

    function drawRow(ctx, row, width, y) {
        const height = widgetHeight();
        const margin = 15;
        const inner = margin * 0.33;
        ctx.save();
        ctx.fillStyle = LiteGraph.WIDGET_BGCOLOR || "#222";
        ctx.strokeStyle = LiteGraph.WIDGET_OUTLINE_COLOR || "#666";
        ctx.beginPath();
        if (ctx.roundRect) ctx.roundRect(margin, y, width - margin * 2, height, height * 0.5);
        else ctx.rect(margin, y, width - margin * 2, height);
        ctx.fill();
        ctx.stroke();
        const toggle = drawToggle(ctx, margin, y, height, row.on);
        if (!row.on) ctx.globalAlpha = (app.canvas?.editor_alpha || 1) * 0.4;
        const strengthRight = width - margin - inner - inner;
        const strength = drawStrength(ctx, strengthRight, y, height, row.strength);
        const nameX = toggle[0] + toggle[1] + inner;
        const nameWidth = Math.max(12, strength.left[0] - inner - nameX);
        ctx.fillStyle = LiteGraph.WIDGET_TEXT_COLOR || "#ddd";
        ctx.font = `${LiteGraph.NODE_SUBTEXT_SIZE || 12}px sans-serif`;
        ctx.textAlign = "left";
        ctx.textBaseline = "middle";
        const label = row.lora && row.lora !== "none" ? row.lora : "none";
        ctx.fillText(fitText(ctx, label, nameWidth), nameX, y + height * 0.5);
        ctx.restore();
        return {
            toggle,
            nameX,
            nameWidth,
            strength,
            y,
            height,
        };
    }

    function addRowWidget(row, index) {
        const widget = node.addCustomWidget({
            name: `lora_${index + 1}`,
            type: "custom",
            value: row,
            y: 0,
            serialize: false,
            options: { serialize: true },
            serializeValue() {
                return {
                    on: row.on !== false,
                    lora: row.lora || "none",
                    strength: roundStrength(row.strength),
                };
            },
            computeSize(width) {
                return [width, widgetHeight()];
            },
            draw(ctx, owner, width, y) {
                const nodeWidth = owner?.renderingSize?.[0] || owner?.size?.[0] || width;
                widget._zones = drawRow(ctx, row, nodeWidth, y);
                if (widget.width != null) widget.width = undefined;
            },
            mouse(event, pos) {
                return handleRow(widget, row, event, pos, true, write);
            },
        });
        widget.serialize = false;
        widget.options = widget.options || {};
        widget.options.serialize = true;
        return widget;
    }

    function handleRow(widget, row, event, pos, canDelete, commit) {
        const zones = widget._zones;
        const type = event?.type || "";
        if (!zones || (type !== "pointerdown" && type !== "mousedown")) return false;
        const x = pos[0];
        const y = pos[1];
        if (y < zones.y || y > zones.y + zones.height) return false;
        if (event.button === 2) {
            if (!canDelete) return true;
            event.preventDefault?.();
            rows.splice(rows.indexOf(row), 1);
            commit();
            rebuild();
            return true;
        }
        if (x >= zones.toggle[0] && x <= zones.toggle[0] + zones.toggle[1]) {
            row.on = !row.on;
            commit();
            node.setDirtyCanvas(true, true);
            return true;
        }
        if (x < zones.strength.left[0]) {
            chooseLora(event, row.lora, (value) => {
                if (typeof value === "string") row.lora = value;
                commit();
                node.setDirtyCanvas(true, true);
            });
            return true;
        }
        const text = zones.strength.text;
        if (x >= text[0] && x <= text[0] + text[1] && app.canvas?.prompt) {
            app.canvas.prompt("Value", Number(row.strength).toFixed(2), (value) => {
                row.strength = roundStrength(value);
                commit();
                node.setDirtyCanvas(true, true);
            }, event);
            return true;
        }
        const direction = x < text[0] ? -1 : 1;
        row.strength = roundStrength(row.strength + direction * 0.05);
        commit();
        node.setDirtyCanvas(true, true);
        return true;
    }

    const button = node.addWidget("button", "＋ 添加 LoRA", "", () => {
        rows.push({ on: true, lora: "none", strength: 1 });
        write();
        rebuild();
    });
    button.serialize = false;
    button.options = button.options || {};
    button.options.serialize = false;

    function rebuild() {
        node.widgets = (node.widgets || []).filter((item) => !/^lora_\d+$/.test(String(item.name || "")));
        const created = rows.map((row, index) => addRowWidget(row, index));
        for (const widget of created) {
            const at = node.widgets.indexOf(widget);
            if (at >= 0) node.widgets.splice(at, 1);
        }
        const buttonIndex = node.widgets.indexOf(button);
        node.widgets.splice(buttonIndex < 0 ? node.widgets.length : buttonIndex, 0, ...created);
        const size = node.computeSize();
        node.setSize([Math.max(node.size?.[0] || 0, 460), size[1]]);
        node.setDirtyCanvas(true, true);
    }

    node._zh3LoraRead = () => {
        hideWidget(node, "lora_stack");
        lockDefaults();
        rows = readStack(stack);
        rebuild();
    };
    const previous = node.onConfigure;
    node.onConfigure = function onConfigure() {
        previous?.apply(this, arguments);
        node._zh3LoraRead();
    };
    rebuild();
    const apiSnapshot = loadingApiJson;
    if (apiSnapshot) {
        setTimeout(() => {
            const imported = rowsFromApiInputs(apiNodeFor(apiSnapshot, node)?.inputs);
            if (!imported.length) return;
            rows = imported;
            write();
            rebuild();
        }, 32);
    }
    api.fetchApi("/models/loras")
        .then((response) => response.json())
        .then((listed) => {
            files = ["none", ...(Array.isArray(listed) ? listed : [])];
            node.setDirtyCanvas(true, true);
        })
        .catch(() => {});
}

hookLoadApiJson();

app.registerExtension({
    name: "comfyUI-zealman.h3Loader",
    async beforeRegisterNodeDef(nodeType, nodeData) {
        if (nodeData.name !== NODE) return;
        const created = nodeType.prototype.onNodeCreated;
        nodeType.prototype.onNodeCreated = function onNodeCreated() {
            const result = created?.apply(this, arguments);
            install(this);
            return result;
        };
    },
});
