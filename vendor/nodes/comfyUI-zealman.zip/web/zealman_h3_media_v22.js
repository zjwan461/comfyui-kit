// 素材面板已改到 zealman_h3_media_v23.js，这个文件不再注册。
