import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";

const STYLE_ID = "zealman-image-picker-style";
const BATCH_SIZE = 40;
const LIST_TTL = 30000;
const listCache = new Map();

function imageWidgetNames(nodeData) {
    const names = [];
    const groups = [nodeData?.input?.required, nodeData?.input?.optional];
    for (const group of groups) {
        if (!group) continue;
        for (const [name, spec] of Object.entries(group)) {
            if (!Array.isArray(spec)) continue;
            const options = spec.find((item) => item && typeof item === "object" && !Array.isArray(item));
            if (!options) continue;
            if (spec[0] === "IMAGEUPLOAD" || options.imageInputName) continue;
            if (options.video_upload || options.audio_upload || options.mesh_upload) continue;
            if (options.image_upload || options.animated_image_upload) names.push(name);
        }
    }
    return names;
}

function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
.zealman-image-picker {
  position: fixed;
  inset: 0;
  z-index: 100000;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.62);
  color: #f4f4f5;
  font-family: inherit;
}
.zealman-image-picker-panel {
  width: min(920px, calc(100vw - 32px));
  height: min(720px, calc(100vh - 32px));
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 16px;
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 16px;
  background: #18181b;
  box-shadow: 0 24px 80px rgba(0, 0, 0, 0.45);
}
.zealman-image-picker-head, .zealman-image-picker-tools {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.zealman-image-picker-head h2 {
  margin: 0;
  font-size: 16px;
  font-weight: 700;
}
.zealman-image-picker-head button {
  border: 1px solid rgba(255, 255, 255, 0.16);
  border-radius: 999px;
  background: transparent;
  color: inherit;
  padding: 6px 12px;
  cursor: pointer;
}
.zealman-image-picker-head div {
  display: flex;
  gap: 8px;
}
.zealman-image-picker-tools input {
  flex: 1;
  border: 1px solid rgba(255, 255, 255, 0.16);
  border-radius: 10px;
  background: #09090b;
  color: inherit;
  padding: 8px 10px;
}
.zealman-image-picker-grid {
  flex: 1;
  overflow: auto;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 10px;
  align-content: start;
}
.zealman-image-picker-card {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 6px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 12px;
  background: #09090b;
  color: inherit;
  text-align: left;
  cursor: pointer;
}
.zealman-image-picker-card img {
  width: 100%;
  height: 110px;
  object-fit: cover;
  border-radius: 8px;
  background: #27272a;
}
.zealman-image-picker-card span {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 12px;
}
.zealman-image-picker-placeholders {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}
.zealman-image-picker-placeholders button {
  border: 1px solid rgba(255, 255, 255, 0.16);
  border-radius: 999px;
  background: transparent;
  color: inherit;
  padding: 6px 12px;
  cursor: pointer;
}
.zealman-image-picker-status {
  margin: 0;
  color: #a1a1aa;
  font-size: 13px;
}
.zealman-image-picker-tabs {
  display: flex;
  gap: 8px;
}
.zealman-image-picker-tabs button {
  border: 1px solid rgba(255, 255, 255, 0.16);
  border-radius: 999px;
  background: transparent;
  color: inherit;
  padding: 6px 14px;
  cursor: pointer;
}
.zealman-image-picker-tabs button.is-active {
  background: #3f3f46;
}
.zealman-image-picker-panel.is-drop {
  outline: 2px solid #38bdf8;
}
`;
    document.head.appendChild(style);
}

function thumbUrl(item, folder) {
    const params = new URLSearchParams({
        name: item.name,
        subfolder: item.subfolder || "",
        mtime: String(Math.floor(item.mtime || 0)),
    });
    return api.apiURL(`/zealman/image-thumb/${folder}?${params.toString()}`);
}

async function loadFiles(folder, force, kind = "image") {
    const cacheKey = `${folder}:${kind}`;
    const cached = listCache.get(cacheKey);
    if (!force && cached && Date.now() - cached.at < LIST_TTL) return cached.files;
    const params = new URLSearchParams();
    if (force) params.set("refresh", "1");
    if (kind && kind !== "image") params.set("kind", kind);
    const query = params.toString() ? `?${params}` : "";
    const response = await api.fetchApi(`/zealman/image-picker/${folder}${query}`);
    if (!response.ok) throw new Error(String(response.status));
    const files = await response.json();
    listCache.set(cacheKey, { at: Date.now(), files });
    return files;
}

function applyImage(node, widget, value) {
    const values = widget.options?.values;
    if (Array.isArray(values) && !values.includes(value)) values.push(value);
    widget.value = value;
    widget.callback?.(value);
    node.setDirtyCanvas?.(true, true);
}

let closeActive = null;

function closeDialog() {
    const close = closeActive;
    closeActive = null;
    close?.();
}

async function openPicker(node, widget, folder) {
    ensureStyle();
    closeDialog();
    const root = document.createElement("div");
    root.className = "zealman-image-picker";
    root.innerHTML = `
      <div class="zealman-image-picker-panel" role="dialog" aria-modal="true" aria-label="${folder}">
        <div class="zealman-image-picker-head">
          <h2>${folder}</h2>
          <div>
            <button type="button" data-refresh>刷新</button>
            <button type="button" data-close>关闭</button>
          </div>
        </div>
        <div class="zealman-image-picker-tools">
          <input type="search" placeholder="搜索文件名" />
        </div>
        <p class="zealman-image-picker-status">正在读取</p>
        <div class="zealman-image-picker-grid"></div>
      </div>
    `;
    const panel = root.querySelector(".zealman-image-picker-panel");
    const status = root.querySelector(".zealman-image-picker-status");
    const grid = root.querySelector(".zealman-image-picker-grid");
    const search = root.querySelector("input");
    root.addEventListener("pointerdown", (event) => {
        if (event.target === root) closeDialog();
    });
    panel.addEventListener("pointerdown", (event) => event.stopPropagation());
    root.querySelector("[data-close]").addEventListener("click", closeDialog);
    const onKey = (event) => {
        if (event.key === "Escape") closeDialog();
    };
    document.addEventListener("keydown", onKey);
    closeActive = () => {
        document.removeEventListener("keydown", onKey);
        root.remove();
    };
    document.body.appendChild(root);
    search.focus();

    const observer = new IntersectionObserver((entries) => {
        for (const entry of entries) {
            if (!entry.isIntersecting) continue;
            const image = entry.target;
            const src = image.dataset.src;
            if (!src || image.getAttribute("src")) continue;
            image.src = src;
            observer.unobserve(image);
        }
    }, { root: grid, rootMargin: "240px" });
    const previousClose = closeActive;
    closeActive = () => {
        observer.disconnect();
        previousClose?.();
    };

    let files = [];
    let matched = [];
    let shown = 0;
    let searchTimer = 0;

    const updateStatus = () => {
        if (!matched.length) {
            status.textContent = "这个目录里没有图像";
            return;
        }
        status.textContent = shown < matched.length
            ? `显示 ${shown} / ${matched.length}`
            : `${matched.length} 张`;
    };

    const appendBatch = () => {
        const next = matched.slice(shown, shown + BATCH_SIZE);
        for (const item of next) {
            const card = document.createElement("button");
            card.type = "button";
            card.className = "zealman-image-picker-card";
            card.title = item.value;
            const image = document.createElement("img");
            image.alt = "";
            image.decoding = "async";
            image.dataset.src = thumbUrl(item, folder);
            observer.observe(image);
            const label = document.createElement("span");
            label.textContent = item.subfolder ? `${item.subfolder}/${item.name}` : item.name;
            card.append(image, label);
            card.addEventListener("click", () => {
                applyImage(node, widget, item.value);
                closeDialog();
            });
            grid.appendChild(card);
        }
        shown += next.length;
        updateStatus();
        if (shown < matched.length && grid.scrollHeight <= grid.clientHeight + 48 && shown < BATCH_SIZE * 6) {
            appendBatch();
        }
    };

    const resetGrid = () => {
        const query = search.value.trim().toLowerCase();
        matched = files.filter((item) => {
            if (!query) return true;
            return `${item.subfolder}/${item.name}`.toLowerCase().includes(query);
        });
        shown = 0;
        grid.replaceChildren();
        appendBatch();
    };

    const fill = async (force) => {
        const cached = !force && listCache.get(`${folder}:image`);
        if (!cached) status.textContent = "正在读取";
        try {
            files = await loadFiles(folder, force);
        } catch (error) {
            if (!files.length) status.textContent = "读取失败";
            return;
        }
        if (!root.isConnected) return;
        resetGrid();
    };

    grid.addEventListener("scroll", () => {
        if (shown >= matched.length) return;
        if (grid.scrollTop + grid.clientHeight >= grid.scrollHeight - 320) appendBatch();
    });
    search.addEventListener("input", () => {
        window.clearTimeout(searchTimer);
        searchTimer = window.setTimeout(resetGrid, 150);
    });
    root.querySelector("[data-refresh]").addEventListener("click", () => { void fill(true); });
    void fill(false);
}

const KIND_LABEL = { image: "图像", video: "视频", audio: "音频" };

export function forgetMediaList(folder = "input", kind) {
    if (kind) listCache.delete(`${folder}:${kind}`);
    else {
        for (const item of Object.keys(KIND_LABEL)) listCache.delete(`${folder}:${item}`);
    }
}

export function openMediaBrowser({ kind: initialKind = "image", onSelect, onFiles }) {
    ensureStyle();
    closeDialog();
    let folder = "input";
    let kind = KIND_LABEL[initialKind] ? initialKind : "image";
    const root = document.createElement("div");
    root.className = "zealman-image-picker";
    root.innerHTML = `
      <div class="zealman-image-picker-panel" role="dialog" aria-modal="true">
        <div class="zealman-image-picker-head">
          <h2>选择素材</h2>
          <div>
            <button type="button" data-folder="input">input</button>
            <button type="button" data-folder="output">output</button>
            <button type="button" data-refresh>刷新</button>
            <button type="button" data-close>关闭</button>
          </div>
        </div>
        <div class="zealman-image-picker-tabs">
          <button type="button" data-kind="image">图像</button>
          <button type="button" data-kind="video">视频</button>
          <button type="button" data-kind="audio">音频</button>
        </div>
        <div class="zealman-image-picker-tools">
          <input type="search" placeholder="搜索文件名，或把文件拖进窗口" />
        </div>
        <p class="zealman-image-picker-status">正在读取</p>
        <div class="zealman-image-picker-grid"></div>
        <div class="zealman-image-picker-placeholders">
          <button type="button" data-placeholder="image">图像占位</button>
          <button type="button" data-placeholder="video">视频占位</button>
          <button type="button" data-placeholder="audio">音频占位</button>
        </div>
      </div>
    `;
    const panel = root.querySelector(".zealman-image-picker-panel");
    const status = root.querySelector(".zealman-image-picker-status");
    const grid = root.querySelector(".zealman-image-picker-grid");
    const search = root.querySelector("input");
    const folderButtons = [...root.querySelectorAll("[data-folder]")];
    const kindButtons = [...root.querySelectorAll("[data-kind]")];
    const markFolder = () => {
        for (const button of folderButtons) {
            button.style.background = button.dataset.folder === folder ? "#3f3f46" : "transparent";
        }
        for (const button of kindButtons) {
            button.classList.toggle("is-active", button.dataset.kind === kind);
        }
    };
    root.addEventListener("pointerdown", (event) => {
        if (event.target === root) closeDialog();
    });
    panel.addEventListener("pointerdown", (event) => event.stopPropagation());
    root.querySelector("[data-close]").addEventListener("click", closeDialog);
    const onKey = (event) => {
        if (event.key === "Escape") closeDialog();
    };
    document.addEventListener("keydown", onKey);
    const observer = new IntersectionObserver((entries) => {
        for (const entry of entries) {
            if (!entry.isIntersecting) continue;
            const image = entry.target;
            const src = image.dataset.src;
            if (!src || image.getAttribute("src")) continue;
            image.src = src;
            observer.unobserve(image);
        }
    }, { root: grid, rootMargin: "240px" });
    closeActive = () => {
        observer.disconnect();
        document.removeEventListener("keydown", onKey);
        root.remove();
    };
    document.body.appendChild(root);
    search.focus();

    let files = [];
    let matched = [];
    let shown = 0;
    let searchTimer = 0;
    const emptyText = () => (kind === "audio" ? "这个目录里没有音频" : kind === "video" ? "这个目录里没有视频" : "这个目录里没有图像");
    const unitOf = () => (kind === "image" ? "张" : "段");

    const updateStatus = () => {
        if (!matched.length) {
            status.textContent = emptyText();
            return;
        }
        status.textContent = shown < matched.length
            ? `显示 ${shown} / ${matched.length}`
            : `${matched.length} ${unitOf()}`;
    };
    const appendBatch = () => {
        const next = matched.slice(shown, shown + BATCH_SIZE);
        for (const item of next) {
            const card = document.createElement("button");
            card.type = "button";
            card.className = "zealman-image-picker-card";
            card.title = item.value;
            if (kind === "audio") {
                const mark = document.createElement("div");
                mark.textContent = "音频";
                mark.style.cssText = "height:110px;display:flex;align-items:center;justify-content:center;border-radius:8px;background:#27272a;font-weight:700";
                card.appendChild(mark);
            } else {
                const image = document.createElement("img");
                image.alt = "";
                image.decoding = "async";
                image.dataset.src = thumbUrl(item, folder);
                observer.observe(image);
                card.appendChild(image);
            }
            const label = document.createElement("span");
            label.textContent = item.subfolder ? `${item.subfolder}/${item.name}` : item.name;
            card.appendChild(label);
            card.addEventListener("click", () => {
                onSelect?.({
                    filename: item.name,
                    subfolder: item.subfolder || "",
                    storage: folder,
                    media_type: kind,
                });
                closeDialog();
            });
            grid.appendChild(card);
        }
        shown += next.length;
        updateStatus();
        if (shown < matched.length && grid.scrollHeight <= grid.clientHeight + 48 && shown < BATCH_SIZE * 6) {
            appendBatch();
        }
    };
    const resetGrid = () => {
        const query = search.value.trim().toLowerCase();
        matched = files.filter((item) => !query || `${item.subfolder}/${item.name}`.toLowerCase().includes(query));
        shown = 0;
        grid.replaceChildren();
        appendBatch();
    };
    const fill = async (force) => {
        markFolder();
        if (force || !listCache.get(`${folder}:${kind}`)) status.textContent = "正在读取";
        try {
            files = await loadFiles(folder, force, kind);
        } catch {
            if (!files.length) status.textContent = "读取失败";
            return;
        }
        if (!root.isConnected) return;
        resetGrid();
    };
    grid.addEventListener("scroll", () => {
        if (shown >= matched.length) return;
        if (grid.scrollTop + grid.clientHeight >= grid.scrollHeight - 320) appendBatch();
    });
    search.addEventListener("input", () => {
        window.clearTimeout(searchTimer);
        searchTimer = window.setTimeout(resetGrid, 150);
    });
    for (const button of folderButtons) {
        button.addEventListener("click", () => {
            if (folder === button.dataset.folder) return;
            folder = button.dataset.folder;
            void fill(false);
        });
    }
    for (const button of kindButtons) {
        button.addEventListener("click", () => {
            if (kind === button.dataset.kind) return;
            kind = button.dataset.kind;
            search.value = "";
            void fill(false);
        });
    }
    panel.addEventListener("dragover", (event) => {
        if (!event.dataTransfer?.types?.includes("Files")) return;
        event.preventDefault();
        panel.classList.add("is-drop");
    });
    panel.addEventListener("dragleave", (event) => {
        if (!panel.contains(event.relatedTarget)) panel.classList.remove("is-drop");
    });
    panel.addEventListener("drop", (event) => {
        const dropped = [...(event.dataTransfer?.files || [])];
        if (!dropped.length) return;
        event.preventDefault();
        event.stopPropagation();
        panel.classList.remove("is-drop");
        if (onFiles) {
            onFiles(dropped);
            closeDialog();
        }
    });
    root.querySelector("[data-refresh]").addEventListener("click", () => { void fill(true); });
    const pickPlaceholder = async (placeholderKind) => {
        status.textContent = "正在放入占位";
        try {
            const response = await api.fetchApi(`/zealman/placeholder/${placeholderKind}`, { method: "POST" });
            if (!response.ok) throw new Error(String(response.status));
            const item = await response.json();
            if (!item?.name) throw new Error("empty");
            forgetMediaList("input", placeholderKind);
            onSelect?.({
                filename: item.name,
                subfolder: item.subfolder || "",
                storage: "input",
                media_type: placeholderKind,
            });
            closeDialog();
        } catch {
            status.textContent = "占位素材不可用";
        }
    };
    for (const button of root.querySelectorAll("[data-placeholder]")) {
        button.addEventListener("click", () => { void pickPlaceholder(button.dataset.placeholder); });
    }
    void fill(false);
}

function isPickerButton(widget) {
    if (widget?.type !== "button") return false;
    if (widget.options?.zealmanPicker) return true;
    return widget.serialize === false && /^(input|output)(#\d+)?$/.test(widget.name || "");
}

function removePickerButtons(node) {
    const widgets = node.widgets || [];
    for (const widget of widgets.filter(isPickerButton)) {
        if (typeof node.removeWidget === "function") node.removeWidget(widget);
        else {
            const index = widgets.indexOf(widget);
            if (index >= 0) widgets.splice(index, 1);
        }
    }
}

function attachPickers(node, names) {
    removePickerButtons(node);
    node.__zealmanImagePicker = true;
    const widgets = node.widgets || [];
    const targets = [];
    for (const name of names) {
        const widget = widgets.find((item) => item?.name === name && item.type !== "button");
        if (widget && !targets.includes(widget)) targets.push(widget);
    }
    if (!targets.length) return;
    for (let index = targets.length - 1; index >= 0; index -= 1) {
        const widget = targets[index];
        let at = widgets.indexOf(widget);
        const next = widgets[at + 1];
        if (next?.type === "button" && next.options?.canvasOnly) at += 1;
        const suffix = targets.length > 1 ? `:${widget.name}` : "";
        const options = { serialize: false, zealmanPicker: true };
        node.addWidget("button", `input${suffix}`, null, () => openPicker(node, widget, "input"), options);
        node.addWidget("button", `output${suffix}`, null, () => openPicker(node, widget, "output"), options);
        const pair = widgets.splice(widgets.length - 2, 2);
        for (const button of pair) {
            button.serialize = false;
            button.options.zealmanPicker = true;
        }
        widgets.splice(at + 1, 0, ...pair);
    }
    if (typeof node.computeSize === "function" && typeof node.setSize === "function") {
        const size = node.computeSize();
        node.setSize([
            Math.max(node.size?.[0] || 0, size[0]),
            Math.max(node.size?.[1] || 0, size[1]),
        ]);
    }
}

app.registerExtension({
    name: "comfyUI-zealman.imagePicker",
    beforeRegisterNodeDef(nodeType, nodeData) {
        const names = imageWidgetNames(nodeData);
        if (!names.length) return;
        const created = nodeType.prototype.onNodeCreated;
        nodeType.prototype.onNodeCreated = function () {
            const result = created?.apply(this, arguments);
            attachPickers(this, names);
            return result;
        };
    },
});
