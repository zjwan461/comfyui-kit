import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";
import { forgetMediaList, openMediaBrowser } from "./zealman_image_picker_v3.js";

const LIMITS = { image: 9, video: 3, audio: 3 };
const MAX_SECONDS = 15;
const DURATION_SLACK = 0.05;
const TITLES = { image: "图像", video: "视频", audio: "音频" };
const EXTENSIONS = {
    image: [".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"],
    video: [".mp4", ".webm", ".mov", ".mkv", ".avi", ".m4v"],
    audio: [".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aac"],
};
const FILE_EXTS = new Set(Object.values(EXTENSIONS).flat());
const STYLE_ID = "zealman-h3-media-style-v34";
const NODE = "ZealmanH3PickReferenceMedia";
let loadingApiJson = null;

function hookLoadApiJson() {
    if (app._zh3MediaApiHooked || typeof app.loadApiJson !== "function") return;
    const original = app.loadApiJson;
    app._zh3MediaApiHooked = true;
    app.loadApiJson = async function loadApiJson(apiData) {
        const previous = loadingApiJson;
        loadingApiJson = apiData;
        try {
            return await original.apply(this, arguments);
        } finally {
            loadingApiJson = previous;
        }
    };
}

function apiNodeFor(snapshot, node) {
    if (!snapshot || node?.id == null) return null;
    const direct = snapshot[node.id] ?? snapshot[String(node.id)];
    if (direct?.class_type === NODE) return direct;
    const matches = Object.values(snapshot).filter((item) => item?.class_type === NODE);
    if (matches.length === 1) return matches[0];
    return matches.find((item) => item?._meta?.title && item._meta.title === node.title) || null;
}
const FIXED_WIDTH = 440;
const WIDGET_HEIGHT = 292;
const PROMPT_HEIGHT = 280;

function field(node, name) {
    return node.widgets?.find((widget) => widget.name === name);
}

function slotName(kind, index) {
    return `ref_${kind}_${index}`;
}

function encodeSlot(record) {
    const path = record.subfolder ? `${record.subfolder}/${record.filename}` : record.filename;
    return record.storage === "output" ? `output:${path}` : path;
}

function isFileSlot(raw) {
    const text = String(raw ?? "").trim();
    if (!text) return false;
    const path = text.startsWith("output:") ? text.slice("output:".length) : text;
    const ext = path.slice(path.lastIndexOf(".")).toLowerCase();
    return FILE_EXTS.has(ext);
}

function decodeSlot(kind, index, raw) {
    if (!isFileSlot(raw)) return null;
    let text = String(raw || "").trim();
    let storage = "input";
    if (text.startsWith("output:")) {
        storage = "output";
        text = text.slice("output:".length);
    }
    const parts = text.split("/").filter((part) => part && part !== ".");
    const filename = parts.pop();
    if (!filename) return null;
    return {
        media_type: kind,
        ordinal: index + 1,
        filename,
        subfolder: parts.join("/"),
        storage,
    };
}

function validRecord(record) {
    return Boolean(
        record
        && Object.hasOwn(LIMITS, record.media_type)
        && Number.isInteger(record.ordinal)
        && record.ordinal >= 1
        && record.ordinal <= LIMITS[record.media_type]
        && typeof record.filename === "string"
        && (record.storage === "input" || record.storage === "output")
    );
}

function readMediaFiles(node) {
    let value = [];
    try {
        value = JSON.parse(field(node, "media_files")?.value || "[]");
    } catch {
        value = [];
    }
    if (!Array.isArray(value)) return [];
    return value.filter(validRecord);
}

function readSlotRecords(node) {
    const records = [];
    let foundWidget = false;
    for (const [kind, count] of Object.entries(LIMITS)) {
        for (let index = 0; index < count; index += 1) {
            const widget = field(node, slotName(kind, index));
            if (!widget) continue;
            foundWidget = true;
            const record = decodeSlot(kind, index, widget.value);
            if (record) records.push(record);
        }
    }
    return foundWidget ? records : null;
}

function readRecords(node) {
    const fromFiles = readMediaFiles(node);
    if (fromFiles.length) return fromFiles;
    return readSlotRecords(node) || [];
}

function writeSlots(node, items) {
    for (const [kind, count] of Object.entries(LIMITS)) {
        for (let index = 0; index < count; index += 1) {
            const widget = field(node, slotName(kind, index));
            if (!widget) continue;
            const record = items.find((item) => item.media_type === kind && item.ordinal === index + 1);
            const value = record ? encodeSlot(record) : "";
            if (widget.value !== value) widget.value = value;
            widget.serializeValue = () => {
                const current = items.find((item) => item.media_type === kind && item.ordinal === index + 1);
                return current ? encodeSlot(current) : "";
            };
            hideWidget(node, widget.name);
        }
    }
}

function hideWidget(node, name) {
    const widget = field(node, name);
    if (!widget) return;
    widget.hidden = true;
    widget.type = "hidden";
    widget.computeSize = () => [0, -4];
    widget.computedHeight = 0;
    widget.options = widget.options || {};
    widget.options.hidden = true;
    widget.options.canvasOnly = true;
    if (widget.inputEl) widget.inputEl.style.display = "none";
    if (widget.element) widget.element.style.display = "none";
}

function viewUrl(record) {
    const params = new URLSearchParams({
        filename: record.filename,
        subfolder: record.subfolder || "",
        type: record.storage || "input",
    });
    return api.apiURL(`/view?${params.toString()}`);
}

function probeDuration(url, kind) {
    return new Promise((resolve, reject) => {
        const media = document.createElement(kind === "audio" ? "audio" : "video");
        const timer = window.setTimeout(() => {
            media.removeAttribute("src");
            media.load();
            reject(new Error(`读不到${TITLES[kind]}时长`));
        }, 8000);
        media.preload = "metadata";
        media.onloadedmetadata = () => {
            window.clearTimeout(timer);
            const duration = media.duration;
            media.removeAttribute("src");
            media.load();
            if (!Number.isFinite(duration) || duration <= 0) reject(new Error(`读不到${TITLES[kind]}时长`));
            else resolve(duration);
        };
        media.onerror = () => {
            window.clearTimeout(timer);
            reject(new Error(`读不到${TITLES[kind]}时长`));
        };
        media.src = url;
    });
}

async function probeFile(file, kind) {
    const url = URL.createObjectURL(file);
    try {
        return await probeDuration(url, kind);
    } finally {
        URL.revokeObjectURL(url);
    }
}

function autoTrimSeconds(durations) {
    const values = (Array.isArray(durations) ? durations : []).filter((value) => Number.isFinite(value) && value > 0);
    if (!values.length) return MAX_SECONDS;
    const within = values.reduce((sum, value) => sum + Math.min(value, MAX_SECONDS), 0);
    if (within <= MAX_SECONDS + DURATION_SLACK) return MAX_SECONDS;
    let low = 0;
    let high = MAX_SECONDS;
    for (let step = 0; step < 60; step += 1) {
        const mid = (low + high) / 2;
        const total = values.reduce((sum, value) => sum + Math.min(value, mid), 0);
        if (total <= MAX_SECONDS) low = mid;
        else high = mid;
    }
    return low;
}

function chosenTrim(node, kind, durations) {
    const widget = field(node, kind === "video" ? "video_trim_seconds" : "audio_trim_seconds");
    const value = String(widget?.value ?? "auto");
    if (value === "不限制") return Number.POSITIVE_INFINITY;
    if (value !== "auto") {
        const seconds = Number(value);
        if (Number.isFinite(seconds) && seconds > 0) return seconds;
    }
    return autoTrimSeconds(durations);
}

function effectiveDuration(source, trim) {
    if (!Number.isFinite(source)) return source;
    return source + DURATION_SLACK < trim ? source : trim;
}

function clipError(kind, duration) {
    if (!Number.isFinite(duration) || duration <= 0) return `读不到${TITLES[kind]}时长`;
    return "";
}

function placementError(node, list, kind, ordinal, duration) {
    const exists = list.some((item) => item.media_type === kind && item.ordinal === ordinal);
    if (kind !== "video" && kind !== "audio") return "";
    const pending = list.some((item) => (
        item.media_type === kind && item.ordinal !== ordinal && !Number.isFinite(item.duration)
    ));
    if (pending) return `正在确认已有${TITLES[kind]}时长，请稍后再放`;
    return clipError(kind, duration);
}

function formatSeconds(value) {
    const rounded = Math.round(Number(value) * 10) / 10;
    if (!Number.isFinite(rounded)) return "0";
    return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
}

function limitStatus(node, list) {
    const problems = [];
    const warnings = [];
    const over = new Set();
    const hasImage = list.some((item) => item.media_type === "image");
    const hasVideo = list.some((item) => item.media_type === "video");
    const hasAudio = list.some((item) => item.media_type === "audio");
    if (hasAudio && !hasImage && !hasVideo) problems.push("音频不能单独使用，需要同时加上图像或视频");
    for (const kind of ["video", "audio"]) {
        const group = list.filter((item) => item.media_type === kind);
        for (const item of group) {
            if (item.durationProbed && !Number.isFinite(item.duration)) {
                problems.push(`读不到${TITLES[kind]}${item.ordinal}的时长`);
                continue;
            }
            if (!Number.isFinite(item.duration)) continue;
            const error = clipError(kind, item.duration);
            if (error) problems.push(`${TITLES[kind]}${item.ordinal}：${error}`);
        }
        const known = group.filter((item) => Number.isFinite(item.duration));
        const trim = chosenTrim(node, kind, known.map((item) => Number(item.duration)));
        const total = known.reduce((sum, item) => sum + effectiveDuration(item.duration, trim), 0);
        if (known.length === group.length && group.length && total > MAX_SECONDS + DURATION_SLACK) {
            const mode = String(field(node, kind === "video" ? "video_trim_seconds" : "audio_trim_seconds")?.value ?? "auto");
            const setting = mode === "auto" ? "自动长度" : mode === "不限制" ? "不限制" : `${formatSeconds(trim)}秒`;
            warnings.push(`${TITLES[kind]}合计${formatSeconds(total)}秒，超过${MAX_SECONDS}秒，可能报错，仍按${setting}输出`);
            over.add(kind);
        }
    }
    if (problems.length) return { text: problems[0], error: true, over };
    const parts = [`合计 ${list.length} 个`];
    for (const kind of ["video", "audio"]) {
        const group = list.filter((item) => item.media_type === kind && Number.isFinite(item.duration));
        if (!group.length) continue;
        const trim = chosenTrim(node, kind, group.map((item) => Number(item.duration)));
        const total = group.reduce((sum, item) => sum + effectiveDuration(item.duration, trim), 0);
        parts.push(`${TITLES[kind]} ${formatSeconds(total)}秒`);
    }
    if (warnings.length) return { text: warnings.join(" · "), warn: true, over };
    return { text: parts.join(" · "), error: false, over };
}

function ensureStyle() {
    document.getElementById("zealman-h3-media-style")?.remove();
    document.getElementById("zealman-h3-media-style-v9")?.remove();
    document.getElementById("zealman-h3-media-style-v10")?.remove();
    document.getElementById("zealman-h3-media-style-v11")?.remove();
    document.getElementById("zealman-h3-media-style-v12")?.remove();
    document.getElementById("zealman-h3-media-style-v13")?.remove();
    document.getElementById("zealman-h3-media-style-v14")?.remove();
    document.getElementById("zealman-h3-media-style-v15")?.remove();
    document.getElementById("zealman-h3-media-style-v18")?.remove();
    document.getElementById("zealman-h3-media-style-v19")?.remove();
    document.getElementById("zealman-h3-media-style-v20")?.remove();
    document.getElementById("zealman-h3-media-style-v27")?.remove();
    document.getElementById("zealman-h3-media-style-v28")?.remove();
    document.getElementById("zealman-h3-media-style-v29")?.remove();
    document.getElementById("zealman-h3-media-style-v30")?.remove();
    document.getElementById("zealman-h3-media-style-v31")?.remove();
    document.getElementById("zealman-h3-media-style-v32")?.remove();
    document.getElementById("zealman-h3-media-style-v33")?.remove();
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
.zh3-media { box-sizing: border-box; width: 100%; height: auto; padding: 0 8px 4px; overflow: visible; color: #e7f8f5; font: 12px/1.3 system-ui, sans-serif; }
.zh3-board { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)) 2px minmax(0, 1fr) 2px minmax(0, 1fr); column-gap: 4px; align-items: start; width: 100%; }
.zh3-grid-section { display: flex; flex-direction: column; min-width: 0; margin: 0; }
.zh3-grid-section.is-image { grid-column: 1 / span 3; }
.zh3-grid-section.is-video { grid-column: 5; }
.zh3-grid-section.is-audio { grid-column: 7; }
.zh3-media h3 { margin: 0 0 4px; height: 16px; line-height: 16px; font-size: 11px; font-weight: 700; color: #9de9e0; white-space: nowrap; overflow: hidden; }
.zh3-grid { display: grid; gap: 4px; align-items: start; }
.zh3-grid.is-image { grid-template-columns: repeat(3, minmax(0, 1fr)); }
.zh3-grid.is-video, .zh3-grid.is-audio { grid-template-columns: minmax(0, 1fr); }
.zh3-slot { position: relative; width: 100%; aspect-ratio: 1 / 1; border: 1px solid rgba(91,220,207,.35); border-radius: 2px; background: rgba(2,22,21,.72); overflow: hidden; cursor: pointer; }
.zh3-slot:hover { border-color: rgba(126,246,234,.85); }
.zh3-slot.is-dragover { border-color: #72ecdf; background: rgba(10,87,82,.48); }
.zh3-msg { min-height: 16px; margin: 0 0 6px; color: #9de9e0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.zh3-msg.is-error { color: #fca5a5; }
.zh3-msg.is-warn { color: #fbbf24; }
.zh3-preview, .zh3-slot video, .zh3-slot .zh3-audio { position: absolute; inset: 0; width: 100%; height: 100%; max-width: none; max-height: none; }
.zh3-preview { background: #09090b center / cover no-repeat; }
.zh3-slot video { object-fit: cover; background: #09090b; }
.zh3-slot .zh3-audio { display: flex; align-items: center; justify-content: center; color: #e4c4a0; pointer-events: none; }
.zh3-slot .zh3-audio svg { width: 42%; height: 42%; }
.zh3-mask { position: absolute; inset: 0; z-index: 1; display: flex; align-items: center; justify-content: center; padding: 4px; color: #9dbbb8; font-size: 11px; font-weight: 650; text-align: center; pointer-events: none; }
.zh3-slot.has-media .zh3-mask { opacity: 0; color: #f4fffd; background: rgba(4,28,27,.62); }
.zh3-slot.has-media:hover .zh3-mask { opacity: 1; }
.zh3-clear { position: absolute; top: 2px; right: 2px; z-index: 2; width: 16px; height: 16px; padding: 0; border: 1px solid rgba(255,255,255,.28); border-radius: 2px; background: rgba(0,0,0,.62); color: #fff; line-height: 14px; cursor: pointer; opacity: 0; }
.zh3-slot:hover .zh3-clear { opacity: 1; }
.zh3-grid-section.is-video h3 { color: #e09de9; }
.zh3-grid-section.is-video .zh3-slot { border-color: rgba(160,92,219,.35); background: rgba(21,2,22,.72); }
.zh3-grid-section.is-video .zh3-slot:hover { border-color: rgba(190,126,246,.85); }
.zh3-grid-section.is-video .zh3-slot.is-dragover { border-color: #df72ec; background: rgba(82,10,87,.48); }
.zh3-grid-section.is-video .zh3-mask { color: #b89dbb; }
.zh3-grid-section.is-video .zh3-slot.has-media .zh3-mask { color: #f7f4ff; background: rgba(27,4,28,.62); }
.zh3-grid-section.is-audio h3 { color: #e4c4a0; }
.zh3-grid-section.is-audio .zh3-slot { border-color: rgba(219,160,92,.35); background: rgba(22,14,2,.72); }
.zh3-grid-section.is-audio .zh3-slot:hover { border-color: rgba(246,190,126,.85); }
.zh3-grid-section.is-audio .zh3-slot.is-dragover { border-color: #ebb474; background: rgba(87,51,10,.48); }
.zh3-grid-section.is-audio .zh3-mask { color: #bcac9a; }
.zh3-grid-section.is-audio .zh3-slot.has-media .zh3-mask { color: #fff8f0; background: rgba(28,18,4,.62); }
.zh3-grid-section.is-audio .zh3-audio { color: #e4c4a0; }
.zh3-slot.has-media { border-color: rgba(46,245,214,.95); }
.zh3-slot.has-media:hover { border-color: #b6fff4; }
.zh3-slot.is-disabled,
.zh3-grid-section.is-image .zh3-slot.is-disabled,
.zh3-grid-section.is-video .zh3-slot.is-disabled,
.zh3-grid-section.is-audio .zh3-slot.is-disabled {
  cursor: not-allowed;
  opacity: 0.34;
  filter: grayscale(1);
  border-color: #3f3f46 !important;
  background: #18181b !important;
  pointer-events: none;
}
.zh3-slot.is-disabled .zh3-mask { color: #71717a !important; background: rgba(24,24,27,.55); opacity: 1 !important; }
.zh3-grid-section.is-video .zh3-slot.has-media { border-color: rgba(198,96,255,.95); }
.zh3-grid-section.is-video .zh3-slot.has-media:hover { border-color: #e4c2ff; }
.zh3-grid-section.is-audio .zh3-slot.has-media { border-color: rgba(255,168,48,.95); }
.zh3-grid-section.is-audio .zh3-slot.has-media:hover { border-color: #ffd7a3; }
.zh3-slot.is-over,
.zh3-slot.is-over:hover,
.zh3-grid-section.is-video .zh3-slot.is-over,
.zh3-grid-section.is-video .zh3-slot.is-over:hover,
.zh3-grid-section.is-audio .zh3-slot.is-over,
.zh3-grid-section.is-audio .zh3-slot.is-over:hover {
  border-color: #ef4444 !important;
  box-shadow: inset 0 0 0 1px #ef4444;
}
`;
    document.head.appendChild(style);
}

function raisePrompt(node) {
    const prompt = field(node, "prompt");
    if (!prompt) return;
    prompt.options = prompt.options || {};
    prompt.options.getMinHeight = () => PROMPT_HEIGHT;
    prompt.options.getMaxHeight = () => PROMPT_HEIGHT;
    prompt.options.getHeight = () => PROMPT_HEIGHT;
    prompt.computedHeight = PROMPT_HEIGHT + 4;
}

function installGallery(node) {
    if (node._zh3MediaVersion >= 34) return;
    node._zh3Media?.dispose?.();
    node._zh3Media = null;
    if (Array.isArray(node.widgets)) {
        node.widgets = node.widgets.filter((widget) => widget?.name !== "zh3_media_gallery");
    }
    raisePrompt(node);
    ensureStyle();
    hideWidget(node, "media_files");
    const mediaFiles = field(node, "media_files");
    if (mediaFiles) {
        mediaFiles.serialize = false;
        mediaFiles.options = mediaFiles.options || {};
        mediaFiles.options.serialize = false;
    }
    for (const [kind, count] of Object.entries(LIMITS)) {
        for (let index = 0; index < count; index += 1) hideWidget(node, slotName(kind, index));
    }
    let items = readRecords(node);
    const root = document.createElement("div");
    root.className = "zh3-media";
    const message = document.createElement("div");
    message.className = "zh3-msg";
    root.addEventListener("pointerdown", (event) => event.stopPropagation());

    function sortItems() {
        items.sort((a, b) => (
            Object.keys(LIMITS).indexOf(a.media_type) - Object.keys(LIMITS).indexOf(b.media_type)
            || a.ordinal - b.ordinal
        ));
    }

    function commit() {
        sortItems();
        const widget = field(node, "media_files");
        if (widget) {
            widget.value = JSON.stringify(items.map(({ durationProbed, ...item }) => item));
        }
        writeSlots(node, items);
        node.graph?.setDirtyCanvas(true);
    }

    function replace(kind, ordinal, record) {
        const next = items.filter((item) => item.media_type !== kind || item.ordinal !== ordinal);
        items = next;
        if (record) items.push({ ...record, media_type: kind, ordinal });
        commit();
        render();
    }

    function fileKind(file) {
        const name = String(file?.name || "").toLowerCase();
        for (const [kind, extensions] of Object.entries(EXTENSIONS)) {
            if (extensions.some((ext) => name.endsWith(ext))) return kind;
        }
        return "";
    }

    function nextOrdinal(kind, start) {
        const used = new Set(items.filter((item) => item.media_type === kind).map((item) => item.ordinal));
        for (let ordinal = start; ordinal <= LIMITS[kind]; ordinal += 1) {
            if (!used.has(ordinal)) return ordinal;
        }
        for (let ordinal = 1; ordinal < start; ordinal += 1) {
            if (!used.has(ordinal)) return ordinal;
        }
        return start;
    }

    async function uploadFile(file) {
        const body = new FormData();
        body.append("image", file, file.name);
        body.append("type", "input");
        const response = await api.fetchApi("/upload/image", { method: "POST", body });
        if (!response.ok) throw new Error(`上传失败 ${response.status}`);
        const result = await response.json();
        if (!result?.name) throw new Error("上传没有返回文件名");
        return {
            filename: result.name,
            subfolder: result.subfolder || "",
            storage: result.type || "input",
        };
    }

    let uploading = false;
    async function assignDropped(files, preferredKind, preferredOrdinal) {
        if (uploading || !files?.length) return;
        uploading = true;
        message.textContent = "正在放入素材…";
        const rejected = [];
        let pinnedOrdinal = preferredOrdinal;
        try {
            for (const file of files) {
                const kind = fileKind(file);
                if (!kind) {
                    rejected.push(file.name);
                    continue;
                }
                let ordinal;
                if (pinnedOrdinal && kind === preferredKind) {
                    ordinal = pinnedOrdinal;
                    pinnedOrdinal = 0;
                } else {
                    ordinal = nextOrdinal(kind, kind === preferredKind ? preferredOrdinal : 1);
                }
                let duration = null;
                if (kind === "video" || kind === "audio") {
                    try {
                        duration = await probeFile(file, kind);
                    } catch (error) {
                        rejected.push(`${file.name}（${error.message || "读不到时长"}）`);
                        continue;
                    }
                }
                const reason = placementError(node, items, kind, ordinal, duration);
                if (reason) {
                    rejected.push(`${file.name}（${reason}）`);
                    continue;
                }
                const saved = await uploadFile(file);
                replace(kind, ordinal, { ...saved, duration, durationProbed: true });
                forgetMediaList("input", kind);
            }
            if (rejected.length) paintMessage(`没有放入：${rejected.join("、")}`, true);
        } catch (error) {
            message.textContent = error.message || "放入失败";
        } finally {
            uploading = false;
        }
    }

    function paintMessage(text, isError, isWarn) {
        message.textContent = text || "";
        message.title = text || "";
        message.classList.toggle("is-error", Boolean(isError) && !isWarn);
        message.classList.toggle("is-warn", Boolean(isWarn));
    }

    async function hydrateDurations() {
        const pending = items.filter((item) => (
            (item.media_type === "video" || item.media_type === "audio") && !item.durationProbed
        ));
        if (!pending.length) return;
        await Promise.all(pending.map(async (item) => {
            item.durationProbed = true;
            try {
                item.duration = await probeDuration(viewUrl(item), item.media_type);
            } catch {
                item.duration = Number.NaN;
            }
        }));
        commit();
        render();
    }

    function render() {
        root.querySelectorAll(".zh3-board").forEach((board) => board.remove());
        if (!message.isConnected) root.prepend(message);
        const status = limitStatus(node, items);
        paintMessage(status.text, status.error, status.warn);
        const board = document.createElement("div");
        board.className = "zh3-board";
        for (const [kind, count] of Object.entries(LIMITS)) {
            const section = document.createElement("section");
            section.className = `zh3-grid-section is-${kind}`;
            const heading = document.createElement("h3");
            const used = items.filter((item) => item.media_type === kind).length;
            heading.textContent = `${TITLES[kind]} ${used}/${count}`;
            const grid = document.createElement("div");
            grid.className = `zh3-grid is-${kind}`;
            for (let ordinal = 1; ordinal <= count; ordinal += 1) {
                const record = items.find((item) => item.media_type === kind && item.ordinal === ordinal);
                const cell = document.createElement("div");
                const overLimit = Boolean(record) && status.over?.has(kind);
                cell.className = `zh3-slot${record ? " has-media" : ""}${overLimit ? " is-over" : ""}`;
                cell.title = record ? record.filename : `选择${TITLES[kind]} ${ordinal}`;
                if (overLimit) {
                    cell.style.borderColor = "#ef4444";
                    cell.style.boxShadow = "inset 0 0 0 1px #ef4444";
                }
                if (record && kind === "image") {
                    const preview = document.createElement("div");
                    preview.className = "zh3-preview";
                    preview.style.backgroundImage = `url("${viewUrl(record)}")`;
                    cell.appendChild(preview);
                } else if (record && kind === "video") {
                    const video = document.createElement("video");
                    video.muted = true;
                    video.playsInline = true;
                    video.preload = "metadata";
                    video.src = viewUrl(record);
                    cell.appendChild(video);
                } else if (record) {
                    const mark = document.createElement("div");
                    mark.className = "zh3-audio";
                    mark.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 3v10.55A4 4 0 1 0 14 17V7h4V3h-6z"/></svg>`;
                    cell.appendChild(mark);
                }
                const mask = document.createElement("div");
                mask.className = "zh3-mask";
                mask.textContent = `＋ @${TITLES[kind]}${ordinal}`;
                cell.appendChild(mask);
                if (record) {
                    const clear = document.createElement("button");
                    clear.type = "button";
                    clear.className = "zh3-clear";
                    clear.textContent = "×";
                    clear.addEventListener("pointerdown", (event) => event.stopPropagation());
                    clear.addEventListener("click", (event) => {
                        event.stopPropagation();
                        replace(kind, ordinal, null);
                    });
                    cell.appendChild(clear);
                }
                const allowDrop = (event) => {
                    if (!event.dataTransfer?.types?.includes("Files")) return;
                    event.preventDefault();
                    event.stopPropagation();
                    cell.classList.add("is-dragover");
                };
                cell.addEventListener("dragover", allowDrop);
                cell.addEventListener("dragleave", () => cell.classList.remove("is-dragover"));
                cell.addEventListener("drop", (event) => {
                    const dropped = [...(event.dataTransfer?.files || [])];
                    if (!dropped.length) return;
                    event.preventDefault();
                    event.stopPropagation();
                    cell.classList.remove("is-dragover");
                    cell._suppressUntil = Date.now() + 400;
                    void assignDropped(dropped, kind, ordinal);
                });
                cell.addEventListener("click", () => {
                    if (Date.now() < (cell._suppressUntil || 0)) return;
                    openMediaBrowser({
                        kind,
                        onSelect: (picked) => {
                            const targetKind = picked.media_type || kind;
                            const targetOrdinal = targetKind === kind ? ordinal : nextOrdinal(targetKind, 1);
                            const place = (duration) => {
                                const reason = placementError(node, items, targetKind, targetOrdinal, duration);
                                if (reason) {
                                    paintMessage(reason, true);
                                    return;
                                }
                                replace(targetKind, targetOrdinal, {
                                    ...picked,
                                    duration,
                                    durationProbed: targetKind === "video" || targetKind === "audio",
                                });
                            };
                            if (targetKind !== "video" && targetKind !== "audio") {
                                place(null);
                                return;
                            }
                            paintMessage("正在读取时长…", false);
                            probeDuration(viewUrl(picked), targetKind).then(place).catch((error) => {
                                paintMessage(error.message || `读不到${TITLES[targetKind]}时长`, true);
                            });
                        },
                        onFiles: (dropped) => { void assignDropped(dropped, kind, ordinal); },
                    });
                });
                grid.appendChild(cell);
            }
            section.append(heading, grid);
            board.append(section);
        }
        root.append(board);
    }

    const enforceHostSize = () => {
        const host = root.parentElement;
        if (!host) return;
        const width = FIXED_WIDTH - 24;
        host.style.width = `${width}px`;
        host.style.minWidth = `${width}px`;
        host.style.maxWidth = `${width}px`;
        host.style.height = `${WIDGET_HEIGHT}px`;
        host.style.minHeight = `${WIDGET_HEIGHT}px`;
        host.style.maxHeight = `${WIDGET_HEIGHT}px`;
        host.style.overflow = "hidden";
        root.style.width = "100%";
        root.style.height = "100%";
        root.style.overflow = "hidden";
    };
    const dom = node.addDOMWidget("zh3_media_gallery", "zh3_media_gallery", root, {
        serialize: false,
        hideOnZoom: false,
        getMinHeight: () => WIDGET_HEIGHT,
        getMaxHeight: () => WIDGET_HEIGHT,
        getHeight: () => WIDGET_HEIGHT,
        onDraw: enforceHostSize,
        beforeResize: enforceHostSize,
        afterResize: enforceHostSize,
    });
    dom.serialize = false;
    dom.options = dom.options || {};
    dom.options.serialize = false;
    const promptWidget = field(node, "prompt");
    const promptIndex = node.widgets?.indexOf(promptWidget) ?? -1;
    const galleryIndex = node.widgets?.indexOf(dom) ?? -1;
    if (promptIndex >= 0 && galleryIndex > promptIndex) {
        node.widgets.splice(galleryIndex, 1);
        node.widgets.splice(promptIndex, 0, dom);
    }
    node._zh3MediaVersion = 34;
    node._zh3Media = {
        restore() {
            hideWidget(node, "media_files");
            for (const [kind, count] of Object.entries(LIMITS)) {
                for (let index = 0; index < count; index += 1) hideWidget(node, slotName(kind, index));
            }
            items = readRecords(node);
            sortItems();
            writeSlots(node, items);
            render();
            void hydrateDurations();
        },
        dispose() {
            root.remove();
        },
    };
    node._zh3Media.restore();
    let painting = false;
    const paintRecords = (records) => {
        if (painting) return;
        painting = true;
        try {
            items = records;
            commit();
            render();
        } finally {
            painting = false;
        }
    };
    for (const [kind, count] of Object.entries(LIMITS)) {
        for (let index = 0; index < count; index += 1) {
            const widget = field(node, slotName(kind, index));
            if (!widget || widget._zh3SlotHook) continue;
            widget._zh3SlotHook = true;
            const previous = widget.callback;
            widget.callback = function onSlotValue() {
                previous?.apply(this, arguments);
                if (painting) return;
                const records = readSlotRecords(node);
                if (records) paintRecords(records);
            };
        }
    }
    for (const name of ["video_trim_seconds", "audio_trim_seconds"]) {
        const widget = field(node, name);
        if (!widget || widget._zh3TrimHook) continue;
        widget._zh3TrimHook = true;
        const previous = widget.callback;
        widget.callback = function onTrimValue() {
            previous?.apply(this, arguments);
            render();
        };
    }
    const apiSnapshot = loadingApiJson;
    if (apiSnapshot) {
        setTimeout(() => {
            const imported = [];
            const inputs = apiNodeFor(apiSnapshot, node)?.inputs;
            if (inputs) {
                for (const [kind, count] of Object.entries(LIMITS)) {
                    for (let index = 0; index < count; index += 1) {
                        const record = decodeSlot(kind, index, inputs[slotName(kind, index)]);
                        if (record) imported.push(record);
                    }
                }
            }
            if (imported.length) paintRecords(imported);
        }, 32);
    }
    dom.computeSize = () => [FIXED_WIDTH - 24, WIDGET_HEIGHT];
    dom.computedHeight = WIDGET_HEIGHT;
    node.resizable = false;
    const previousCompute = node.computeSize?.bind(node);
    const natural = previousCompute?.() || [FIXED_WIDTH, WIDGET_HEIGHT];
    const fixedHeight = natural[1];
    let locking = false;
    const lockSize = () => {
        if (locking) return;
        locking = true;
        try {
            dom.computedHeight = WIDGET_HEIGHT;
            node.size[0] = FIXED_WIDTH;
            node.size[1] = fixedHeight;
            enforceHostSize();
            node.setDirtyCanvas?.(true, true);
        } finally {
            locking = false;
        }
    };
    node._zh3LockSize = lockSize;
    node.computeSize = () => [FIXED_WIDTH, fixedHeight];
    const originalResize = node.onResize;
    node.onResize = function onResize() {
        const value = originalResize?.apply(this, arguments);
        lockSize();
        return value;
    };
    lockSize();
}

function slotValueFromRecord(record) {
    if (!record?.filename) return "";
    const path = record.subfolder ? `${record.subfolder}/${record.filename}` : record.filename;
    return record.storage === "output" ? `output:${path}` : path;
}

function patchZh3ApiOutput(output) {
    if (!output || typeof output !== "object") return;
    for (const node of Object.values(output)) {
        if (node?.class_type !== NODE || !node.inputs) continue;
        let records = [];
        try {
            records = JSON.parse(node.inputs.media_files || "[]");
        } catch {
            records = [];
        }
        if (!Array.isArray(records)) records = [];
        for (const [kind, count] of Object.entries(LIMITS)) {
            for (let index = 0; index < count; index += 1) {
                const key = slotName(kind, index);
                const hit = records.find((item) => item?.media_type === kind && item?.ordinal === index + 1);
                const current = node.inputs[key];
                if (hit?.filename) node.inputs[key] = slotValueFromRecord(hit);
                else if (!isFileSlot(current)) delete node.inputs[key];
            }
        }
        delete node.inputs.media_files;
    }
}

const HELP_SIZE = 16;
const HELP_SECTIONS = [
    {
        title: "数量",
        lines: [
            "图像最多 9 张",
            "视频最多 3 段",
            "音频最多 3 段",
        ],
    },
    {
        title: "时长",
        lines: [
            "每段可以短于 1 秒，不超过 15 秒",
            "视频加起来不超过 15 秒",
            "音频加起来不超过 15 秒",
            "音频不能单独使用，需要同时有图像或视频",
        ],
    },
    {
        title: "裁切",
        lines: [
            "默认 auto，先看原长加起来有没有超过 15 秒",
            "没超过就不裁，例如 4 秒、5 秒、6 秒保持原样",
            "超过了只裁长的那段，短的保持原长",
            "也可以手动选 1 到 15 秒",
            "选不限制时不裁切，按原长输出",
            "手动长度或不限制加起来超过 15 秒时会提示可能报错，仍按这个长度输出",
        ],
    },
    {
        title: "尺寸",
        lines: [
            "默认 auto，按每份素材的长边就近对齐档位",
            "图像：512、768、1024、1280、1536、2048、4096",
            "长边是 10xx 时，按 1024 处理",
            "长边接近 2048 时，按 2048 处理",
            "视频最高 1024：256、512、768、1024",
            "选了固定档位时，这一类全部按这个长边缩放",
        ],
    },
];
let helpPopup = null;

function helpFrame(node) {
    return {
        x: (Number(node?.size?.[0]) || FIXED_WIDTH) - HELP_SIZE - 8,
        y: -24,
        size: HELP_SIZE,
    };
}

function helpHit(node, localPos) {
    if (!Array.isArray(localPos) || node?.flags?.collapsed) return false;
    const frame = helpFrame(node);
    return localPos[0] >= frame.x
        && localPos[0] <= frame.x + frame.size
        && localPos[1] >= frame.y
        && localPos[1] <= frame.y + frame.size;
}

function closeHelpPopup() {
    helpPopup?.remove();
    helpPopup = null;
}

function ensureHelpPopup() {
    if (helpPopup?.isConnected) {
        closeHelpPopup();
        return;
    }
    closeHelpPopup();
    const popup = document.createElement("div");
    popup.className = "zh3-help-popup";
    const head = document.createElement("div");
    head.className = "zh3-help-head";
    const title = document.createElement("strong");
    title.textContent = "MiniMax H3 素材规则";
    const close = document.createElement("button");
    close.type = "button";
    close.textContent = "×";
    close.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        closeHelpPopup();
    });
    head.append(title, close);
    const body = document.createElement("div");
    body.className = "zh3-help-body";
    for (const section of HELP_SECTIONS) {
        const block = document.createElement("section");
        block.className = "zh3-help-section";
        const heading = document.createElement("h4");
        heading.textContent = section.title;
        block.appendChild(heading);
        for (const line of section.lines) {
            const row = document.createElement("p");
            row.textContent = line;
            block.appendChild(row);
        }
        body.appendChild(block);
    }
    popup.append(head, body);
    popup.addEventListener("pointerdown", (event) => event.stopPropagation());
    document.body.appendChild(popup);
    helpPopup = popup;
}

function positionHelpPopup(node, ctx) {
    if (!helpPopup) return;
    const rect = app.canvas?.canvas?.getBoundingClientRect?.();
    const transform = ctx?.getTransform?.();
    let left = 24;
    let top = 24;
    if (rect && transform && ctx?.canvas) {
        const scaleX = rect.width / ctx.canvas.width;
        const scaleY = rect.height / ctx.canvas.height;
        const width = node?.size?.[0] || FIXED_WIDTH;
        left = rect.left + ((transform.e + ((width + 12) * transform.a)) * scaleX);
        top = rect.top + ((transform.f - (28 * transform.d)) * scaleY);
    }
    helpPopup.style.left = `${Math.min(Math.max(12, left), window.innerWidth - helpPopup.offsetWidth - 12)}px`;
    helpPopup.style.top = `${Math.max(12, Math.min(top, window.innerHeight - helpPopup.offsetHeight - 12))}px`;
}

function drawHelpButton(ctx, node) {
    if (node?.flags?.collapsed) return;
    const frame = helpFrame(node);
    const hovered = node.__zh3HelpHover === true;
    const centerX = frame.x + frame.size / 2;
    const centerY = frame.y + frame.size / 2;
    ctx.save();
    ctx.beginPath();
    ctx.arc(centerX, centerY, frame.size / 2 + (hovered ? 1 : 0), 0, Math.PI * 2);
    ctx.fillStyle = hovered ? "rgba(126, 34, 206, 0.98)" : "rgba(88, 28, 135, 0.96)";
    ctx.fill();
    ctx.lineWidth = hovered ? 2 : 1.2;
    ctx.strokeStyle = hovered ? "rgba(233, 213, 255, 1)" : "rgba(192, 132, 252, 0.9)";
    ctx.stroke();
    ctx.fillStyle = "#f5e8ff";
    ctx.font = hovered ? "900 12px sans-serif" : "bold 11px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("?", centerX, centerY + 0.2);
    ctx.restore();
}

function patchHelpButton(nodeType) {
    const originalDraw = nodeType.prototype.onDrawForeground;
    nodeType.prototype.onDrawForeground = function onDrawForeground(ctx) {
        const result = originalDraw?.apply(this, arguments);
        drawHelpButton(ctx, this);
        if (helpPopup && this.__zh3HelpOpen) positionHelpPopup(this, ctx);
        return result;
    };
    const originalMove = nodeType.prototype.onMouseMove;
    nodeType.prototype.onMouseMove = function onMouseMove(event, localPos) {
        const hit = helpHit(this, localPos);
        if (this.__zh3HelpHover !== hit) {
            this.__zh3HelpHover = hit;
            const canvasEl = app.canvas?.canvas;
            if (canvasEl?.style) canvasEl.style.cursor = hit ? "pointer" : "";
            app.graph?.setDirtyCanvas?.(true, false);
        }
        if (hit) return true;
        return originalMove?.apply(this, arguments);
    };
    const originalDown = nodeType.prototype.onMouseDown;
    nodeType.prototype.onMouseDown = function onMouseDown(event, localPos) {
        if (helpHit(this, localPos)) {
            event?.preventDefault?.();
            event?.stopPropagation?.();
            this.__zh3HelpOpen = !helpPopup;
            ensureHelpPopup();
            positionHelpPopup(this, app.canvas?.ctx);
            if (!helpPopup) this.__zh3HelpOpen = false;
            return true;
        }
        return originalDown?.apply(this, arguments);
    };
    const originalLeave = nodeType.prototype.onMouseLeave;
    nodeType.prototype.onMouseLeave = function onMouseLeave() {
        this.__zh3HelpHover = false;
        return originalLeave?.apply(this, arguments);
    };
    const originalRemoved = nodeType.prototype.onRemoved;
    nodeType.prototype.onRemoved = function onRemoved() {
        if (this.__zh3HelpOpen) closeHelpPopup();
        return originalRemoved?.apply(this, arguments);
    };
}

function isMediaNode(node) {
    if (!node) return false;
    return [node.comfyClass, node.type, node.title].some((name) => name === NODE || name === "ZealmanH3素材选择");
}

function nodeFromHeader(header) {
    const nodeEl = header.closest("[data-node-id]");
    const nodeId = nodeEl?.dataset?.nodeId;
    const graph = app.graph;
    const node = graph?.getNodeById?.(nodeId) || graph?.getNodeById?.(Number(nodeId))
        || graph?._nodes?.find((item) => String(item.id) === String(nodeId))
        || graph?.nodes?.find((item) => String(item.id) === String(nodeId));
    if (isMediaNode(node)) return node;
    const title = header.querySelector("[data-testid='node-title']")?.textContent || "";
    if (title.includes("ZealmanH3素材选择")) return node || { title };
    return null;
}

function injectDomHelpButton(header) {
    if (!nodeFromHeader(header)) return;
    if (header.querySelector(".zh3-help-button")) return;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "zh3-help-button";
    button.textContent = "?";
    button.setAttribute("aria-label", "素材规则");
    button.addEventListener("pointerdown", (event) => {
        event.preventDefault();
        event.stopPropagation();
    });
    button.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        ensureHelpPopup();
        if (!helpPopup) return;
        const rect = button.getBoundingClientRect();
        helpPopup.style.left = `${Math.min(rect.left, window.innerWidth - helpPopup.offsetWidth - 12)}px`;
        helpPopup.style.top = `${Math.min(rect.bottom + 8, window.innerHeight - helpPopup.offsetHeight - 12)}px`;
    });
    const titleRow = header.querySelector("[data-testid='node-title']");
    (titleRow || header.querySelector(":scope > div") || header).appendChild(button);
}

function installHelpButton() {
    if (installHelpButton.done) return;
    installHelpButton.done = true;
    const style = document.createElement("style");
    style.id = "zealman-h3-help-style-v34";
    style.textContent = `
.zh3-help-button { width: 18px; height: 18px; flex: 0 0 18px; display: inline-flex; align-items: center; justify-content: center; margin-left: 6px; border-radius: 999px; border: 1px solid #c084fc; background: #581c87; color: #f5e8ff; font: 800 12px/1 sans-serif; cursor: pointer; pointer-events: auto; position: relative; z-index: 5; }
.zh3-help-button:hover { background: #7e22ce; color: #fff; }
.zh3-help-popup { position: fixed; z-index: 10000; width: min(420px, calc(100vw - 24px)); padding: 14px 16px 12px; border-radius: 12px; border: 1px solid rgba(192,132,252,.55); background: rgba(36,16,58,.98); color: #f5e8ff; box-shadow: 0 16px 40px rgba(0,0,0,.35); font: 13px/1.55 system-ui, sans-serif; white-space: normal; }
.zh3-help-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 12px; }
.zh3-help-head strong { font-size: 14px; }
.zh3-help-head button { width: 22px; height: 22px; border: 0; border-radius: 6px; background: rgba(255,255,255,.08); color: #f5e8ff; cursor: pointer; }
.zh3-help-section { margin: 0 0 12px; }
.zh3-help-section:last-child { margin-bottom: 0; }
.zh3-help-section h4 { margin: 0 0 4px; font-size: 12px; font-weight: 800; letter-spacing: .04em; color: #e9d5ff; }
.zh3-help-section p { margin: 0; }
`;
    document.head.appendChild(style);
    const inject = () => document.querySelectorAll(".lg-node-header").forEach(injectDomHelpButton);
    inject();
    const observer = new MutationObserver(() => inject());
    observer.observe(document.body, { childList: true, subtree: true });
}

hookLoadApiJson();

app.registerExtension({
    name: "comfyUI-zealman.h3Media",
    setup() {
        installHelpButton();
        if (!app.graphToPrompt || app.graphToPrompt._zh3Patched) return;
        const original = app.graphToPrompt.bind(app);
        const wrapped = async function patchedGraphToPrompt(...args) {
            const result = await original(...args);
            patchZh3ApiOutput(result?.output);
            return result;
        };
        wrapped._zh3Patched = true;
        app.graphToPrompt = wrapped;
    },
    beforeRegisterNodeDef(nodeType, nodeData) {
        if (nodeData?.name !== NODE) return;
        patchHelpButton(nodeType);
        const created = nodeType.prototype.onNodeCreated;
        nodeType.prototype.onNodeCreated = function onNodeCreated() {
            const result = created?.apply(this, arguments);
            installGallery(this);
            return result;
        };
        const configured = nodeType.prototype.onConfigure;
        nodeType.prototype.onConfigure = function onConfigure() {
            const result = configured?.apply(this, arguments);
            raisePrompt(this);
            this._zh3Media?.restore();
            this._zh3LockSize?.();
            return result;
        };
    },
});
