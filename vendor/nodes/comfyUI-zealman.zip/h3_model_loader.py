# -*- coding: utf-8 -*-
"""MiniMax H3 模型加载：UNET、CLIP、视频 VAE、音频 VAE、注意力，以及可增减的 LoRA。"""

from __future__ import annotations

import json
import re

import folder_paths
import nodes

_MISSING = "未找到"
_NONE_LORA = "none"
_ATTENTION_PYTORCH = "pytorch attention"
_ATTENTION_KITCHEN = "comfy kitchen attention"


def _filenames(folder):
    try:
        names = folder_paths.get_filename_list(folder)
    except Exception:
        names = []
    return list(names) or [_MISSING]


def _prefer(names, preferred):
    return preferred if preferred in names else names[0]


def _parse_lora_stack(raw):
    if isinstance(raw, list):
        items = raw
    else:
        text = str(raw or "").strip() or "[]"
        try:
            items = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError("LoRA 列表不是有效的 JSON") from exc
    if not isinstance(items, list):
        raise ValueError("LoRA 列表格式不正确")
    rows = []
    for item in items:
        if not isinstance(item, dict) or item.get("on") is False:
            continue
        name = str(item.get("lora") or "").strip()
        if not name or name == _NONE_LORA:
            continue
        try:
            strength = float(item.get("strength", 1))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"LoRA 强度无效：{name}") from exc
        if strength == 0:
            continue
        rows.append((name, strength))
    return rows


def _attention_choices():
    modes = [_ATTENTION_PYTORCH]
    try:
        import comfy.ldm.modules.attention as attention_module

        if attention_module.COMFY_KITCHEN_INT8_ATTENTION_IS_AVAILABLE:
            modes.append(_ATTENTION_KITCHEN)
    except Exception:
        pass
    default = _ATTENTION_KITCHEN if _ATTENTION_KITCHEN in modes else _ATTENTION_PYTORCH
    return modes, default


def _lora_choices():
    try:
        names = folder_paths.get_filename_list("loras")
    except Exception:
        names = []
    return [_NONE_LORA, *names]


def _default_lora_stack():
    preferred = "minimax/minimax_h3_turbo_v4_step600_ema_pruned_comfyui.safetensors"
    if preferred not in _lora_choices():
        return "[]"
    return json.dumps([{"on": True, "lora": preferred, "strength": 1.0}], ensure_ascii=False)


def _apply_attention(model, attention):
    import comfy.ldm.modules.attention as attention_module

    mapped = {
        _ATTENTION_KITCHEN: "comfy_kitchen_int8",
        _ATTENTION_PYTORCH: "pytorch",
    }.get(attention, "pytorch")
    function = attention_module.get_attention_function(mapped, None)
    if function is None:
        function = attention_module.get_attention_function("pytorch")
    cloned = model.clone()
    cloned.model_options.setdefault("transformer_options", {})
    cloned.set_model_optimized_attention(function)
    return cloned


class _AnyType(str):
    def __ne__(self, other):
        return False


class _FlexibleOptional(dict):
    """Accept lora_1, lora_2, ... without listing them in INPUT_TYPES."""

    def __init__(self, data):
        super().__init__(data)
        self._data = data

    def __getitem__(self, key):
        if key in self._data:
            return self._data[key]
        return (_AnyType("*"),)

    def __contains__(self, key):
        return True


def _row_from_value(value):
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return None
        try:
            value = json.loads(text)
        except json.JSONDecodeError:
            return None
    if not isinstance(value, dict) or value.get("on") is False:
        return None
    name = str(value.get("lora") or "").strip()
    if not name or name == _NONE_LORA:
        return None
    try:
        strength = float(value.get("strength", 1))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"LoRA 强度无效：{name}") from exc
    if strength == 0:
        return None
    return name, strength


def _lora_rows(lora_stack, kwargs):
    numbered = [key for key in kwargs if re.fullmatch(r"lora_\d+", key)]
    if numbered:
        numbered.sort(key=lambda key: int(key.split("_", 1)[1]))
        return [row for key in numbered if (row := _row_from_value(kwargs.get(key)))]
    return _parse_lora_stack(lora_stack)


def _apply_lora(loader, model, name, strength):
    if not name or name == _NONE_LORA or float(strength) == 0:
        return model
    return loader.load_lora(model, None, name, float(strength), 0)[0]


class ZealmanH3ModelLoader:
    CATEGORY = "Zealman/H3"
    FUNCTION = "load"
    RETURN_TYPES = ("MODEL", "CLIP", "VAE", "VAE")
    RETURN_NAMES = ("model", "clip", "video_vae", "audio_vae")
    DESCRIPTION = (
        "加载 MiniMax H3 的 UNET、文本编码器、视频 VAE 和音频 VAE。"
        "模型输出顺序是 UNET、全部 LoRA，最后才是注意力后端。"
        "注意力使用系统的 pytorch attention 或 comfy kitchen attention。"
    )

    @classmethod
    def INPUT_TYPES(cls):
        attention_modes, attention_default = _attention_choices()
        unets = _filenames("diffusion_models")
        clips = _filenames("text_encoders")
        vaes = _filenames("vae")
        return {
            "required": {
                "unet_name": (unets, {
                    "default": _prefer(unets, "minimax/minimax_h3_fl2va_pruned_int8_convrot.safetensors"),
                    "tooltip": "扩散模型目录下的全部文件。",
                }),
                "weight_dtype": (["default", "fp8_e4m3fn", "fp8_e4m3fn_fast", "fp8_e5m2"], {"default": "default"}),
                "clip_name": (clips, {
                    "default": _prefer(clips, "qwen3vl_32b_minimax_h3_int8_convrot.safetensors"),
                    "tooltip": "文本编码器目录下的全部文件。",
                }),
                "clip_device": (["default", "cpu"], {"default": "default"}),
                "video_vae": (vaes, {
                    "default": _prefer(vaes, "minimax_h3_video_vae_fp16.safetensors"),
                    "tooltip": "VAE 目录下的全部文件。",
                }),
                "audio_vae": (vaes, {
                    "default": _prefer(vaes, "minimax_h3_audio_vae_fp32.safetensors"),
                    "tooltip": "VAE 目录下的全部文件。",
                }),
                "attention": (attention_modes, {"default": attention_default}),
            },
            "optional": _FlexibleOptional({
                "lora_stack": ("STRING", {"default": _default_lora_stack(), "multiline": True}),
            }),
        }

    @classmethod
    def IS_CHANGED(cls, **kwargs):
        return "|".join(f"{key}={kwargs.get(key, '')}" for key in sorted(kwargs))

    def load(self, unet_name, weight_dtype, clip_name, clip_device, video_vae, audio_vae, attention, lora_stack="[]", **kwargs):
        missing = [
            label for label, value in (
                ("模型", unet_name),
                ("文本编码器", clip_name),
                ("视频VAE", video_vae),
                ("音频VAE", audio_vae),
            ) if value == _MISSING
        ]
        if missing:
            raise ValueError("未找到 H3 文件：" + "、".join(missing))
        model = nodes.UNETLoader().load_unet(unet_name, "default")[0]
        clip = nodes.CLIPLoader().load_clip(clip_name, type="minimax", device=clip_device)[0]
        video = nodes.VAELoader().load_vae(video_vae)[0]
        audio = nodes.VAELoader().load_vae(audio_vae)[0]
        loader = nodes.LoraLoader()
        for name, strength in _lora_rows(lora_stack, kwargs):
            model = _apply_lora(loader, model, name, strength)
        model = _apply_attention(model, attention)
        return (model, clip, video, audio)
