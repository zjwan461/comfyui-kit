import { app } from "/scripts/app.js";

let presetData = {};
let presetsLoaded = false;

async function loadPresets() {
    try {
        const resp = await fetch("/whitejade/presets/curves?t=" + Date.now());
        presetData = await resp.json();
        console.log("[PSCurves] 预设加载成功:", Object.keys(presetData));
    } catch (e) {
        console.error("[PSCurves] 加载预设失败:", e);
        presetData = {};
    }
    presetsLoaded = true;
}

async function refreshPresetOptions(presetWidget) {
    console.log("[PSCurves] 开始刷新预设列表...");
    await loadPresets();
    const names = Object.keys(presetData);
    const values = ["重置", "【刷新列表】", "— 自定义 —", ...names];
    presetWidget.options.values = values;
    console.log("[PSCurves] 下拉框选项已更新:", values);
    // 强制重绘节点，让下拉框立即生效
    if (presetWidget.parent && presetWidget.parent.setDirtyCanvas) {
        presetWidget.parent.setDirtyCanvas(true, true);
    }
}

app.registerExtension({
    name: "WhiteJade.PSCurves.Editor",

    async beforeRegisterNodeDef(nodeType, nodeData, app) {
        if (nodeData.name !== "WJIPSCurves") return;
        await loadPresets();

        // 直接修改 nodeData 中的 preset 选项列表，确保前后端一致
        if (nodeData.input?.required?.preset) {
            const baseValues = [...nodeData.input.required.preset[0]];
            const fixedValues = ["重置", "【刷新列表】", "— 自定义 —", ...baseValues.filter(v => v !== "无" && v !== "【刷新列表】" && v !== "重置" && v !== "— 自定义 —")];
            if (!fixedValues.includes("无")) {
                fixedValues.push("无");
            }
            nodeData.input.required.preset[0] = fixedValues;
            nodeData.input.required.preset[1] = nodeData.input.required.preset[1] || {};
            nodeData.input.required.preset[1].default = "重置";
        }

        // 保存混合模式的原始中文选项值，防止被 ComfyUI 翻译系统篡改
        const originalBlendModes = nodeData.input?.required?.blend_mode
            ? [...nodeData.input.required.blend_mode[0]]
            : null;

        const orig_onNodeCreated = nodeType.prototype.onNodeCreated;
        nodeType.prototype.onNodeCreated = function() {
            orig_onNodeCreated?.apply(this, arguments);

            const MAX_ANCHORS = 16;
            const channels = ["rgb", "r", "g", "b"];
            const nodeRef = this;
            let isApplyingPreset = false;

            // 通道到参数前缀的映射
            const channelMap = {
                "全通道": [],
                "R": ["r"],
                "G": ["g"],
                "B": ["b"],
                "明度": ["rgb"]
            };

            // 中文标签映射
            const labelMap = {
                "channel": "通道",
                "preset": "预设",
                "intensity": "强度",
                "blend_mode": "混合模式",
                "mask_blur": "遮罩模糊"
            };

            channels.forEach(ch => {
                labelMap[`${ch}_count`] = `${ch.toUpperCase()} 锚点数量`;
                for (let i = 1; i <= MAX_ANCHORS; i++) {
                    labelMap[`${ch}_${i}_x`] = `${ch.toUpperCase()} 锚点${i} 水平位置`;
                    labelMap[`${ch}_${i}_y`] = `${ch.toUpperCase()} 锚点${i} 垂直位置`;
                }
            });

            if (this.widgets) {
                this.widgets.forEach(w => {
                    if (labelMap[w.name]) {
                        w.label = labelMap[w.name];
                    }
                });
            }

            // 应用预设参数到 widget
            const applyPresetParams = (params) => {
                if (!params) return;
                isApplyingPreset = true;
                Object.entries(params).forEach(([key, value]) => {
                    const w = this.widgets.find(w => w.name === key);
                    if (w) {
                        w.value = value;
                    }
                });
                isApplyingPreset = false;
                updateVisibility();
                this.setDirtyCanvas(true, true);
                if (app.graph) app.graph.change();
            };

            // 恢复所有参数为默认值
            const resetToDefaults = () => {
                isApplyingPreset = true;
                const defaults = {
                    "rgb": {"count": 1, "xs": [128], "ys": [128]},
                    "r":   {"count": 1, "xs": [128], "ys": [128]},
                    "g":   {"count": 1, "xs": [128], "ys": [128]},
                    "b":   {"count": 1, "xs": [128], "ys": [128]},
                };
                channels.forEach(ch => {
                    const d = defaults[ch];
                    const countW = this.widgets.find(w => w.name === `${ch}_count`);
                    if (countW) countW.value = d.count;
                    for (let i = 1; i <= MAX_ANCHORS; i++) {
                        const wx = this.widgets.find(w => w.name === `${ch}_${i}_x`);
                        const wy = this.widgets.find(w => w.name === `${ch}_${i}_y`);
                        if (wx) wx.value = d.xs[i - 1] || 128;
                        if (wy) wy.value = d.ys[i - 1] || 128;
                    }
                });
                isApplyingPreset = false;
                updateVisibility();
                this.setDirtyCanvas(true, true);
                if (app.graph) app.graph.change();
            };

            // 当用户手动修改任何参数时，标记为自定义
            const resetPreset = () => {
                if (isApplyingPreset) return;
                const presetWidget = this.widgets.find(w => w.name === "preset");
                if (presetWidget && presetWidget.value !== "— 自定义 —") {
                    presetWidget.value = "— 自定义 —";
                    this.setDirtyCanvas(true, true);
                    if (app.graph) app.graph.change();
                }
            };

            // 为所有锚点相关 widget 添加手动修改检测
            channels.forEach(prefix => {
                const countW = this.widgets.find(w => w.name === `${prefix}_count`);
                if (countW) {
                    const origCb = countW.callback;
                    countW.callback = function() {
                        if (origCb) origCb.apply(this, arguments);
                        resetPreset();
                    };
                }
                for (let i = 1; i <= MAX_ANCHORS; i++) {
                    ['x', 'y'].forEach(axis => {
                        const w = this.widgets.find(w => w.name === `${prefix}_${i}_${axis}`);
                        if (w) {
                            const origCb = w.callback;
                            w.callback = function() {
                                if (origCb) origCb.apply(this, arguments);
                                resetPreset();
                            };
                        }
                    });
                }
            });

            // 根据当前通道和锚点数量更新 widget 可见性与节点尺寸
            const updateVisibility = () => {
                const channelWidget = this.widgets.find(w => w.name === "channel");
                const currentChannel = channelWidget ? channelWidget.value : "全通道";
                const activePrefixes = channelMap[currentChannel] || [];
                const isFullChannel = currentChannel === "全通道";

                channels.forEach(ch => {
                    const countWidget = this.widgets.find(w => w.name === `${ch}_count`);
                    const count = countWidget ? (countWidget.value || 0) : 0;
                    const isActive = activePrefixes.includes(ch);

                    if (countWidget) {
                        countWidget.hidden = !isActive;
                    }

                    for (let i = 1; i <= MAX_ANCHORS; i++) {
                        const wx = this.widgets.find(w => w.name === `${ch}_${i}_x`);
                        const wy = this.widgets.find(w => w.name === `${ch}_${i}_y`);
                        const shouldShow = isActive && (i <= count);
                        if (wx) wx.hidden = !shouldShow;
                        if (wy) wy.hidden = !shouldShow;
                    }
                });

                // 全通道模式显示预设，其他模式隐藏
                const presetWidget = this.widgets.find(w => w.name === "preset");
                if (presetWidget) {
                    presetWidget.hidden = !isFullChannel;
                }

                if (this.computeSize) {
                    const sz = this.computeSize();
                    const newW = Math.max(320, sz[0]);
                    const newH = sz[1] + 4;
                    this.setSize([newW, newH]);
                }
                this.setDirtyCanvas(true, true);
            };

            // 监听 channel 变化
            const channelWidget = this.widgets.find(w => w.name === "channel");
            if (channelWidget) {
                const orig_callback = channelWidget.callback;
                channelWidget.callback = function() {
                    if (orig_callback) orig_callback.apply(this, arguments);
                    updateVisibility();
                };
            }

            // 监听各通道 count 变化
            channels.forEach(ch => {
                const countWidget = this.widgets.find(w => w.name === `${ch}_count`);
                if (countWidget) {
                    const orig_callback = countWidget.callback;
                    countWidget.callback = function() {
                        if (orig_callback) orig_callback.apply(this, arguments);
                        updateVisibility();
                    };
                }
            });

            // 监听预设变化
            const presetWidget = this.widgets.find(w => w.name === "preset");
            if (presetWidget) {
                const orig_preset_callback = presetWidget.callback;
                presetWidget.callback = async function() {
                    if (orig_preset_callback) orig_preset_callback.apply(this, arguments);
                    const val = presetWidget.value;
                    if (val === "【刷新列表】") {
                        await refreshPresetOptions(presetWidget);
                        presetWidget.value = "重置";
                        nodeRef.setDirtyCanvas(true, true);
                        return;
                    }
                    if (val === "重置" || val === "无") {
                        resetToDefaults();
                        nodeRef.setDirtyCanvas(true, true);
                        return;
                    }
                    if (val === "— 自定义 —") {
                        // 占位符，无操作
                        return;
                    }
                    if (presetData[val]) {
                        const data = presetData[val];
                        if (data.params) {
                            applyPresetParams(data.params);
                        }
                        nodeRef.setDirtyCanvas(true, true);
                        if (app.graph) app.graph.change();
                    }
                };
            }

            // 保护 blend_mode 的选项值不被 ComfyUI 翻译系统篡改
            if (originalBlendModes) {
                setTimeout(() => {
                    const blendWidget = this.widgets.find(w => w.name === "blend_mode");
                    if (blendWidget && blendWidget.options) {
                        blendWidget.options.values = [...originalBlendModes];
                        if (!originalBlendModes.includes(blendWidget.value)) {
                            blendWidget.value = originalBlendModes[0];
                        }
                        const frozenValues = [...originalBlendModes];
                        Object.defineProperty(blendWidget.options, 'values', {
                            get() { return frozenValues; },
                            set(v) { /* 忽略外部修改 */ }
                        });
                        this.setDirtyCanvas(true, true);
                    }
                }, 50);
            }

            // 初始更新
            updateVisibility();
        };
    }
});
