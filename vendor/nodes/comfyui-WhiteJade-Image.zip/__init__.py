"""
ComfyUI 高低频分离插件
Frequency Separation for ComfyUI

模拟 Photoshop 高低频分离技术
"""

import os
from .nodes import NODE_CLASS_MAPPINGS, NODE_DISPLAY_NAME_MAPPINGS

# 注册前端 JS 目录，使 ComfyUI 自动加载自定义组件
WEB_DIRECTORY = os.path.join(os.path.dirname(os.path.realpath(__file__)), "js")

# 注册自定义 API：实时扫描预设目录，不依赖静态缓存
try:
    import server
    from aiohttp import web
    import json as _json

    @server.PromptServer.instance.routes.get("/whitejade/presets/{category}")
    async def get_presets(request):
        category = request.match_info.get("category", "curves")
        plugin_dir = os.path.dirname(os.path.realpath(__file__))
        presets_dir = os.path.join(plugin_dir, "presets", category)
        presets = {}
        if os.path.exists(presets_dir):
            for f in sorted(os.listdir(presets_dir)):
                if f.endswith('.json'):
                    try:
                        with open(os.path.join(presets_dir, f), 'r', encoding='utf-8') as fh:
                            data = _json.load(fh)
                        if data.get("type") == "ps_curves":
                            presets[f[:-5]] = data
                    except Exception:
                        pass
        return web.json_response(presets)
except Exception:
    pass

__all__ = ['NODE_CLASS_MAPPINGS', 'NODE_DISPLAY_NAME_MAPPINGS', 'WEB_DIRECTORY']

# 版本信息
__version__ = "1.0.0"