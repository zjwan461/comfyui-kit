"""
LUA (Latent Upscale Adapter) ComfyUI 节点
论文: "One Small Step in Latent, One Giant Leap for Pixels"
仓库: https://github.com/vaskers5/LUA
"""

import os
import torch
import torch.nn.functional as F
from huggingface_hub import hf_hub_download

import comfy.model_management as mm

try:
    from ..utils.lua_swinir import SwinIRMultiHead
except ImportError:
    SwinIRMultiHead = None


HF_REPO_ID = "vaskers5/LUA-FLUX"
HF_FILENAME = "lua_flux.pth"

_FLUX_MODEL_CONFIG = dict(
    in_chans=16,
    img_size=32,
    window_size=16,
    img_range=1.0,
    depths=[6, 6, 6, 6, 6, 6],
    embed_dim=360,
    num_heads=[12, 12, 12, 12, 12, 12],
    mlp_ratio=2,
    resi_connection="1conv",
    primary_head="x4",
    head_num_feat=256,
    heads=[
        {"name": "x2", "scale": 2, "out_chans": 16},
        {"name": "x4", "scale": 4, "out_chans": 16, "primary": True},
    ],
)

# 模型缓存
_lua_model_cache = {}


def _load_lua_model(weights_path=None, device="cpu", dtype=torch.float32):
    """加载 LUA 模型（带缓存）"""
    cache_key = f"{weights_path}_{device}_{dtype}"
    if cache_key in _lua_model_cache:
        return _lua_model_cache[cache_key]

    if SwinIRMultiHead is None:
        raise RuntimeError(
            "LUA 模型架构未找到。请确保 lua_swinir.py 已放置在 utils/ 目录下。"
        )

    if weights_path is None or weights_path == "":
        # 优先检查插件目录下的 models/lua/
        plugin_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        local_path = os.path.join(plugin_dir, "models", "lua", HF_FILENAME)
        if os.path.exists(local_path):
            weights_path = local_path
        else:
            weights_path = hf_hub_download(repo_id=HF_REPO_ID, filename=HF_FILENAME)

    weights_path = str(weights_path)

    model = SwinIRMultiHead(**_FLUX_MODEL_CONFIG)
    ckpt = torch.load(weights_path, map_location="cpu", weights_only=True)
    key = "params_ema" if "params_ema" in ckpt else "params"
    model.load_state_dict(ckpt[key], strict=True)
    model.eval().to(device=device, dtype=dtype)

    n_params = sum(p.numel() for p in model.parameters()) / 1e6
    print(f"[LUA] 已加载 ({n_params:.1f}M 参数, heads: {list(model.heads.keys())})")

    _lua_model_cache[cache_key] = model
    return model


def _get_vae_params(vae):
    """从 ComfyUI VAE 对象获取 scaling_factor 和 shift_factor"""
    # 尝试多种路径
    try:
        scale_factor = vae.first_stage_model.config.scaling_factor
        shift_factor = getattr(vae.first_stage_model.config, "shift_factor", 0.0)
        return float(scale_factor), float(shift_factor)
    except Exception:
        pass

    try:
        scale_factor = vae.vae.config.scaling_factor
        shift_factor = getattr(vae.vae.config, "shift_factor", 0.0)
        return float(scale_factor), float(shift_factor)
    except Exception:
        pass

    try:
        scale_factor = vae.scale_factor
        shift_factor = getattr(vae, "shift_factor", 0.0)
        return float(scale_factor), float(shift_factor)
    except Exception:
        pass

    # FLUX 默认值
    return 0.3611, 0.1159


@torch.inference_mode()
def _upscale_latent(model, latent, head="x2"):
    """对单个 latent 进行 upscaling"""
    x = latent.to(dtype=torch.float32, device=next(model.parameters()).device)
    ws = model.window_size
    _, _, h, w = x.shape
    ph = (ws - h % ws) % ws
    pw = (ws - w % ws) % ws
    if ph or pw:
        x = F.pad(x, (0, pw, 0, ph), "reflect")
    sc = int(model.head_scales[head])
    out = model.forward_single_head(x, head)
    _, _, oh, ow = out.shape
    return out[:, :, : oh - ph * sc, : ow - pw * sc]


class LUAUpscaleNode:
    """LUA 潜空间超分辨率 - 在 VAE 解码前直接放大 latent"""

    CATEGORY = "WhiteJade/Latent"
    FUNCTION = "upscale"
    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("Latent",)

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "latent": ("LATENT",),
                "vae": ("VAE",),
                "放大倍数": (["x2", "x4"], {"default": "x2"}),
            },
            "optional": {
                "scaling_factor": ("FLOAT", {
                    "default": 0.3611,
                    "step": 0.0001,
                    "tooltip": "VAE scaling factor，FLUX 默认 0.3611"
                }),
                "shift_factor": ("FLOAT", {
                    "default": 0.1159,
                    "step": 0.0001,
                    "tooltip": "VAE shift factor，FLUX 默认 0.1159"
                }),
                "weights_path": ("STRING", {
                    "default": "",
                    "tooltip": "本地权重路径，留空自动从 HuggingFace 下载"
                }),
            }
        }

    def upscale(self, latent, vae, 放大倍数, scaling_factor=0.3611, shift_factor=0.1159, weights_path=""):
        samples = latent["samples"]

        # 自动检测 VAE 参数
        auto_scale, auto_shift = _get_vae_params(vae)
        if abs(scaling_factor - 0.3611) < 1e-6 and abs(shift_factor - 0.1159) < 1e-6:
            scaling_factor = auto_scale
            shift_factor = auto_shift

        device = mm.get_torch_device()

        # 反归一化：从模型空间转到 VAE 原始空间
        vae_lat = samples / scaling_factor + shift_factor

        # 加载模型
        model = _load_lua_model(
            weights_path=weights_path if weights_path else None,
            device=device,
            dtype=torch.float32,
        )

        # 逐 batch 处理
        result = []
        for i in range(vae_lat.shape[0]):
            up = _upscale_latent(model, vae_lat[i:i+1], head=放大倍数)
            result.append(up)

        upscaled = torch.cat(result, dim=0)

        # 重新归一化：转回模型空间
        upscaled = (upscaled - shift_factor) * scaling_factor

        return ({"samples": upscaled},)
