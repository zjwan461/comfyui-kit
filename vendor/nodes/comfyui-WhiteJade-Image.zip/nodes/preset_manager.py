import os
import json


def _get_presets_dir(category="default"):
    """获取预设存储目录"""
    plugin_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    presets_dir = os.path.join(plugin_dir, "presets", category)
    os.makedirs(presets_dir, exist_ok=True)
    return presets_dir


def _update_presets_cache(category="curves"):
    """扫描预设目录并更新前端缓存文件"""
    plugin_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    presets_dir = os.path.join(plugin_dir, "presets", category)
    presets = {}
    if os.path.exists(presets_dir):
        for f in sorted(os.listdir(presets_dir)):
            if f.endswith('.json'):
                try:
                    with open(os.path.join(presets_dir, f), 'r', encoding='utf-8') as fh:
                        data = json.load(fh)
                    if data.get("type") == "ps_curves":
                        presets[f[:-5]] = data
                except Exception:
                    pass
    js_path = os.path.join(plugin_dir, "js", f"presets_{category}.json")
    try:
        with open(js_path, 'w', encoding='utf-8') as f:
            json.dump(presets, f, ensure_ascii=False)
    except Exception as e:
        print(f"[SavePreset] 更新缓存失败: {e}")


class SavePresetNode:
    """通用预设保存节点——可扩展给其他节点使用"""
    OUTPUT_NODE = True

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "preset_data": ("STRING", {"forceInput": True}),
                "filename": ("STRING", {"default": "my_preset"}),
            },
            "optional": {
                "category": (["curves"], {"default": "curves"}),
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("saved_name",)
    FUNCTION = "save_preset"
    CATEGORY = "image/adjustment"

    def save_preset(self, preset_data, filename, category="curves"):
        presets_dir = _get_presets_dir(category)

        if not preset_data:
            print(f"[SavePreset] 保存失败: preset_data 为空（请确认已连接到 PS 曲线节点的 preset_data 输出）")
            return ("",)

        try:
            parsed = json.loads(preset_data)
        except json.JSONDecodeError as e:
            print(f"[SavePreset] 保存失败: preset_data 不是合法 JSON - {e}")
            return ("",)

        # 自动递增编号，避免覆盖已有文件
        base_name = filename
        filepath = os.path.join(presets_dir, f"{base_name}.json")
        counter = 1
        while os.path.exists(filepath):
            filepath = os.path.join(presets_dir, f"{base_name}_{counter}.json")
            counter += 1

        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(parsed, f, ensure_ascii=False, indent=2)
            actual_name = os.path.splitext(os.path.basename(filepath))[0]
            # 保存成功后立即更新前端缓存
            _update_presets_cache(category)
            print(f"[SavePreset] 已保存: {filepath} (类型: {parsed.get('type', 'unknown')})")
        except Exception as e:
            print(f"[SavePreset] 保存失败: {e}")
            return ("",)

        return (actual_name,)


# 节点导出
SavePreset = SavePresetNode
