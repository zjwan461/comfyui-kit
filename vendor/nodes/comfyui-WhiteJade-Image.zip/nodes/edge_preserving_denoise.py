"""
保边降噪节点 - 只去除细小噪点，保留边缘
基于改进的保边平滑算法（非局部均值 + 边缘感知）
"""

import torch
import torch.nn.functional as F


class EdgePreservingDenoiseNode:
    """
    保边降噪节点

    核心特性：
    1. 基于局部方差的自适应降噪 - 平坦区域强降噪，边缘区域弱降噪
    2. 多尺度分析 - 区分噪点和真实细节
    3. 边缘感知权重 - 沿边缘方向平滑，垂直边缘方向保护

    算法原理：
    - 计算局部方差，方差小的区域（平坦）认为是噪点，方差大的区域（边缘）保护
    - 使用引导滤波思想，以原图本身为引导图
    """

    CATEGORY = "image/frequency_separation"
    FUNCTION = "edge_preserving_denoise"
    RETURN_TYPES = ("IMAGE", "IMAGE", "IMAGE")
    RETURN_NAMES = ("降噪结果", "噪点层", "边缘权重")

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "图像": ("IMAGE",),
                "降噪强度": ("FLOAT", {
                    "default": 0.5,
                    "min": 0.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "tooltip": "整体降噪强度，0=无效果，1=最强"
                }),
                "细节保护": ("FLOAT", {
                    "default": 0.7,
                    "min": 0.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "tooltip": "保护图像细节的程度，越高越保留边缘"
                }),
            },
            "optional": {
                "噪点大小": ("FLOAT", {
                    "default": 0.02,
                    "min": 0.005,
                    "max": 0.1,
                    "step": 0.001,
                    "tooltip": "目标噪点的大小尺度，越小处理越细微的噪点"
                }),
                "边缘阈值": ("FLOAT", {
                    "default": 0.05,
                    "min": 0.01,
                    "max": 0.2,
                    "step": 0.01,
                    "tooltip": "边缘检测阈值，越低越敏感"
                }),
                "迭代次数": ("INT", {
                    "default": 2,
                    "min": 1,
                    "max": 5,
                    "step": 1,
                    "tooltip": "降噪迭代次数，越多越平滑但越慢"
                }),
                "通道分离": ("BOOLEAN", {
                    "default": False,
                    "tooltip": "是否对每个颜色通道独立处理（可去除色度噪点）"
                }),
                "色度降噪": ("FLOAT", {
                    "default": 0.0,
                    "min": 0.0,
                    "max": 1.0,
                    "step": 0.01,
                    "tooltip": "专门针对色度（颜色）噪点的降噪强度"
                }),
            }
        }

    def edge_preserving_denoise(self, 图像, 降噪强度, 细节保护,
                               噪点大小=0.02, 边缘阈值=0.05, 迭代次数=2,
                               通道分离=False, 色度降噪=0.0,
                               **kwargs):
        """保边降噪主流程"""

        # 1. 预处理 [B,H,W,C] -> [B,C,H,W]
        x = 图像.permute(0, 3, 1, 2)
        b, c, h, w = x.shape
        device = x.device

        # 2. 亮度/色度分离（如果启用色度降噪）
        if 色度降噪 > 0:
            luminance, chrominance = self._separate_luma_chroma(x)
        else:
            luminance = x
            chrominance = None

        # 3. 计算边缘权重图
        edge_weight = self._compute_edge_weight(luminance, 边缘阈值)

        # 4. 自适应降噪（核心算法）
        if 通道分离 and not 色度降噪 > 0:
            # 对每个通道独立处理
            denoised = torch.zeros_like(x)
            for ch in range(c):
                denoised[:, ch:ch+1] = self._adaptive_denoise(
                    x[:, ch:ch+1], edge_weight, 降噪强度, 细节保护, 
                    噪点大小, 迭代次数
                )
        else:
            # 对亮度通道降噪
            denoised_luma = self._adaptive_denoise(
                luminance, edge_weight, 降噪强度, 细节保护,
                噪点大小, 迭代次数
            )

            if 色度降噪 > 0 and chrominance is not None:
                # 对色度通道单独降噪（更激进）
                denoised_chroma = self._adaptive_denoise(
                    chrominance, edge_weight, 色度降噪, 0.3,
                    噪点大小 * 2, 迭代次数
                )
                denoised = self._combine_luma_chroma(denoised_luma, denoised_chroma)
            else:
                denoised = denoised_luma

        # 5. 提取噪点层
        noise_layer = x - denoised
        noise_layer = (noise_layer + 0.5).clamp(0, 1)  # 偏移到中性灰显示

        # 6. 输出格式化 [B,C,H,W] -> [B,H,W,C]
        result_out = denoised.permute(0, 2, 3, 1)
        noise_out = noise_layer.permute(0, 2, 3, 1)
        weight_out = edge_weight.permute(0, 2, 3, 1).repeat(1, 1, 1, 3)

        return (result_out, noise_out, weight_out)

    def _separate_luma_chroma(self, image):
        """分离亮度/色度通道"""
        # 使用Rec.601标准计算亮度
        r, g, b = image[:, 0:1], image[:, 1:2], image[:, 2:3]
        luminance = 0.299 * r + 0.587 * g + 0.114 * b

        # 色度 = 原图 - 亮度（保留颜色差异）
        chrominance = image - luminance

        return luminance, chrominance

    def _combine_luma_chroma(self, luminance, chrominance):
        """合并亮度/色度通道"""
        return luminance + chrominance

    def _compute_edge_weight(self, image, threshold):
        """
        计算边缘保护权重图

        权重越接近1表示越平坦（可以强降噪）
        权重越接近0表示越像边缘（需要保护）
        """
        # 计算局部梯度
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], 
                               dtype=torch.float32, device=image.device).view(1, 1, 3, 3)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], 
                               dtype=torch.float32, device=image.device).view(1, 1, 3, 3)

        # 对亮度通道计算梯度
        if image.shape[1] == 3:
            gray = image.mean(dim=1, keepdim=True)
        else:
            gray = image

        # 计算各方向梯度
        pad = 1
        gray_padded = F.pad(gray, (pad, pad, pad, pad), mode='reflect')

        grad_x = F.conv2d(gray_padded, sobel_x, groups=1)
        grad_y = F.conv2d(gray_padded, sobel_y, groups=1)

        # 梯度幅值
        gradient_magnitude = torch.sqrt(grad_x**2 + grad_y**2 + 1e-8)

        # 计算局部方差（平坦度）
        mean_local = F.avg_pool2d(gray, kernel_size=5, stride=1, padding=2)
        mean_sq_local = F.avg_pool2d(gray**2, kernel_size=5, stride=1, padding=2)
        variance = mean_sq_local - mean_local**2

        # 综合边缘强度 = 梯度 + 方差
        edge_strength = gradient_magnitude + variance * 2.0

        # 转换为权重（sigmoid平滑）
        # 边缘强度大 -> 权重小（保护）
        # 边缘强度小 -> 权重大（降噪）
        weight = 1.0 / (1.0 + torch.exp((edge_strength - threshold) * 20.0))

        return weight

    def _adaptive_denoise(self, image, edge_weight, strength, detail_protect, 
                          noise_scale, iterations):
        """
        自适应降噪核心

        原理：
        1. 小半径模糊去除高频噪点
        2. 根据边缘权重自适应混合原图和模糊图
        3. 迭代处理增强效果
        """
        result = image
        _, c, h, w = image.shape

        # 计算合适的模糊半径（基于噪点大小）
        kernel_size = max(3, int(min(h, w) * noise_scale))
        if kernel_size % 2 == 0:
            kernel_size += 1

        # 计算sigma（小sigma = 只影响高频）
        sigma = max(0.5, kernel_size / 8.0)

        for i in range(iterations):
            # 小半径高斯模糊（只影响细小颗粒）
            blurred = self._gaussian_blur(result, kernel_size, sigma)

            # 计算当前迭代强度（递减）
            iter_strength = strength * (1.0 - i * 0.15)

            # 自适应混合：
            # - 平坦区域（edge_weight ≈ 1）：更多使用模糊结果
            # - 边缘区域（edge_weight ≈ 0）：更多保留原图

            # 基础混合比例
            blend_ratio = iter_strength * edge_weight

            # 细节保护：增加边缘区域的保留
            protect_factor = (1.0 - edge_weight) * detail_protect
            blend_ratio = blend_ratio * (1.0 - protect_factor)

            # 混合
            result = result * (1.0 - blend_ratio) + blurred * blend_ratio

            # 逐步减小模糊半径（精细处理）
            kernel_size = max(3, kernel_size - 2)
            sigma = max(0.3, sigma * 0.8)

        return torch.clamp(result, 0, 1)

    def _gaussian_blur(self, image, kernel_size, sigma):
        """高斯模糊"""
        from ..utils.filters import apply_gaussian_blur
        return apply_gaussian_blur(image, kernel_size, sigma)


EdgePreservingDenoise = EdgePreservingDenoiseNode
