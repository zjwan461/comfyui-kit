"""
高低频混合节点 - 修复版（设备统一）
"""

import torch
import torch.nn.functional as F


class FrequencyMixerNode:
    """频率混合 - 修复设备问题"""

    CATEGORY = "image/frequency_separation"
    FUNCTION = "mix_frequency"
    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("合成结果",)

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "高频层混合模式": (["正常", "叠加", "柔光", "线性光", "亮光"], {
                    "default": "线性光",
                }),
                "低频层透明度": ("FLOAT", {
                    "default": 1.0,
                    "min": 0.0,
                    "max": 1.0,
                    "step": 0.01,
                }),
                "高频层透明度": ("FLOAT", {
                    "default": 1.0,
                    "min": 0.0,
                    "max": 1.0,
                    "step": 0.01,
                }),
            },
            "optional": {
                "低频层": ("IMAGE",),
                "高频层": ("IMAGE",),
                "原图": ("IMAGE",),
            }
        }

    def mix_frequency(self, 高频层混合模式, 低频层透明度, 高频层透明度,
                      低频层=None, 高频层=None, 原图=None):

        has_low = 低频层 is not None
        has_high = 高频层 is not None
        has_original = 原图 is not None

        if not (has_low or has_high or has_original):
            return (torch.full((1, 64, 64, 3), 0.5),)

        ref = 原图 if has_original else (低频层 if has_low else 高频层)
        b, h, w, c = ref.shape

        # 确定目标设备
        target_device = ref.device

        # 初始化
        if has_original:
            result = 原图.clone().to(target_device)
        else:
            result = torch.zeros_like(ref).to(target_device)

        # 混合低频层
        if has_low and 低频层透明度 > 0:
            low = self._match_size(低频层.to(target_device), h, w)
            if 低频层透明度 < 1.0:
                low = low * 低频层透明度
            result = self._blend_normal(result, low)

        # 混合高频层
        if has_high and 高频层透明度 > 0:
            high = self._match_size(高频层.to(target_device), h, w)
            if 高频层透明度 < 1.0:
                high = high * 高频层透明度
            result = self._blend(result, high, 高频层混合模式)

        return (torch.clamp(result, 0, 1),)

    def _match_size(self, tensor, h, w):
        if tensor.shape[1] == h and tensor.shape[2] == w:
            return tensor
        t = tensor.permute(0, 3, 1, 2)
        t = F.interpolate(t, (h, w), mode='bilinear', align_corners=False)
        return t.permute(0, 2, 3, 1)

    def _blend_normal(self, base, blend):
        if base.shape != blend.shape:
            blend = self._match_size(blend, base.shape[1], base.shape[2])
        return blend

    def _blend(self, base, blend, mode):
        if base.shape != blend.shape:
            blend = self._match_size(blend, base.shape[1], base.shape[2])

        b = base.permute(0, 3, 1, 2)
        bl = blend.permute(0, 3, 1, 2)

        if mode == "正常":
            result = bl
        elif mode == "叠加":
            mask = b < 0.5
            result = torch.where(mask, 2*b*bl, 1-2*(1-b)*(1-bl))
        elif mode == "柔光":
            mask = bl < 0.5
            result = torch.where(mask,
                               2*b*bl + b*b*(1-2*bl),
                               2*b*(1-bl) + torch.sqrt(b)*(2*bl-1))
        elif mode == "线性光":
            result = b + 2*(bl - 0.5)
        elif mode == "亮光":
            eps = 1e-7
            mask = bl < 0.5
            result = torch.where(mask,
                               1 - (1-b)/(2*bl + eps),
                               b/(2*(1-bl) + eps))
        else:
            result = bl

        return torch.clamp(result, 0, 1).permute(0, 2, 3, 1)


FrequencyMixer = FrequencyMixerNode