"""
高低频分离节点 - 模拟Photoshop应用图像功能
"""

import torch
from ..utils.filters import apply_gaussian_blur


class FrequencySeparationNode:
    """
    将图像分离为低频（色彩/光影）和高频（纹理细节）

    核心公式（PS"应用图像"模式）:
        高频 = (原图 - 低频) / 缩放 + 补偿值/255

    高频层以中性灰(0.5)为基准显示纹理细节
    """

    CATEGORY = "image/frequency_separation"
    FUNCTION = "separate_frequency"
    RETURN_TYPES = ("IMAGE", "IMAGE", "IMAGE")
    RETURN_NAMES = ("低频层", "高频层", "原图")

    # 固定算法参数（不暴露给用户）
    PS_SCALE = 2.0
    PS_OFFSET = 128.0

    def __init__(self):
        self.NEUTRAL_GRAY = 0.5

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "图像": ("IMAGE",),
                "模糊半径": ("INT", {
                    "default": 30,
                    "min": 3,
                    "max": 201,
                    "step": 2,
                    "tooltip": "模糊半径，越大分离得越彻底。建议: 磨皮30-50，细节分离10-20"
                }),
                "模糊强度": ("FLOAT", {
                    "default": 0.0,
                    "min": 0.0,
                    "max": 100.0,
                    "step": 0.1,
                    "tooltip": "高斯模糊强度，0为自动(半径/6)"
                }),
                "高频_去色": ("BOOLEAN", {
                    "default": False,
                    "tooltip": "将高频层转换为灰度，去除颜色信息"
                }),
            },
            "optional": {
                "启用低频调整": ("BOOLEAN", {"default": False}),
                "低频_亮度": ("FLOAT", {
                    "default": 0.0,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                }),
                "低频_对比度": ("FLOAT", {
                    "default": 1.0,
                    "min": 0.0,
                    "max": 3.0,
                    "step": 0.01,
                }),
                "低频_饱和度": ("FLOAT", {
                    "default": 1.0,
                    "min": 0.0,
                    "max": 3.0,
                    "step": 0.01,
                }),
                "启用高频调整": ("BOOLEAN", {"default": False}),
                "高频_强度": ("FLOAT", {
                    "default": 1.0,
                    "min": -2.0,
                    "max": 3.0,
                    "step": 0.01,
                    "tooltip": "高频纹理强度倍增"
                }),
            }
        }

    def separate_frequency(self, 图像, 模糊半径, 模糊强度, 高频_去色,
                          启用低频调整=False, 启用高频调整=False,
                          低频_亮度=0.0, 低频_对比度=1.0, 低频_饱和度=1.0,
                          高频_强度=1.0,
                          **kwargs):
        """主处理函数"""

        # 1. 预处理 [B,H,W,C] -> [B,C,H,W]
        x = self._prepare_input(图像)

        # 2. 计算模糊参数
        actual_radius, actual_sigma = self._calculate_blur_params(模糊半径, 模糊强度)

        # 3. 生成低频层
        low_freq = apply_gaussian_blur(x, actual_radius, actual_sigma)

        # 4. 低频调整
        if 启用低频调整:
            low_freq = self._adjust_low_frequency(
                low_freq, 低频_亮度, 低频_对比度, 低频_饱和度
            )

        # 5. 生成高频层（PS应用图像公式，使用固定参数）
        high_freq = self._calculate_high_frequency(x, low_freq)

        # 6. 高频调整（去色始终生效，不受启用高频调整开关控制）
        high_freq = self._adjust_high_frequency(
            high_freq, 高频_去色, 高频_强度 if 启用高频调整 else 1.0
        )

        # 7. 输出格式化 [B,C,H,W] -> [B,H,W,C]
        return self._format_output(low_freq, high_freq, 图像)

    def _prepare_input(self, image):
        """输入预处理: [B,H,W,C] -> [B,C,H,W]"""
        return image.permute(0, 3, 1, 2)

    def _calculate_blur_params(self, radius, strength):
        """计算模糊参数"""
        actual_radius = radius + 1 if radius % 2 == 0 else radius
        actual_sigma = strength if strength > 0 else actual_radius / 6.0
        return actual_radius, actual_sigma

    def _calculate_high_frequency(self, original, low_freq):
        """
        PS"应用图像"核心公式（固定参数）:
        高频 = (原图 - 低频) / 2.0 + 128/255
        """
        offset_norm = self.PS_OFFSET / 255.0
        diff = original - low_freq
        return (diff / self.PS_SCALE) + offset_norm

    def _adjust_low_frequency(self, low_freq, brightness, contrast, saturation):
        """低频层调整"""
        result = low_freq

        # 亮度对比度
        result = (result - 0.5) * contrast + 0.5 + brightness

        # 饱和度
        if saturation != 1.0:
            gray = result.mean(dim=1, keepdim=True)
            result = gray + (result - gray) * saturation

        return torch.clamp(result, 0, 1)

    def _adjust_high_frequency(self, high_freq, desaturate, intensity):
        """高频层调整"""
        result = high_freq

        # 去色（始终生效，不受启用高频调整开关控制）
        if desaturate:
            gray = result.mean(dim=1, keepdim=True)
            result = gray.expand(-1, 3, -1, -1)

        # 强度调整（仅在启用高频调整时生效）
        if intensity != 1.0:
            offset_norm = self.PS_OFFSET / 255.0
            result = offset_norm + (result - offset_norm) * intensity

        return torch.clamp(result, 0, 1)

    def _format_output(self, low_freq, high_freq, original):
        """输出格式化: [B,C,H,W] -> [B,H,W,C]"""
        low_out = low_freq.permute(0, 2, 3, 1)
        high_out = high_freq.permute(0, 2, 3, 1)
        return (low_out, high_out, original)


FrequencySeparation = FrequencySeparationNode