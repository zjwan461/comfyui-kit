"""
去灰节点 (Dehaze / Auto Levels)

PS 自动色阶原理：
- 找到每个通道的暗部锚点（最左侧有效像素）和亮部锚点（最右侧有效像素）
- 将暗部锚点映射到 0，亮部锚点映射到 1
- 中间调线性拉伸
- 可选仅亮度模式（保留色相）

参数说明：
- 暗部裁剪: 忽略最暗的 x% 像素，避免噪点干扰锚点检测
- 亮部裁剪: 忽略最亮的 x% 像素，避免高光溢出干扰
- 强度: 效果混合比例 0~1（0=原图，1=完全去灰）
- 仅亮度: 是否只调整亮度通道，保留色相
"""

import torch


class DehazeNode:
    """去灰节点 - PS 自动色阶风格"""

    CATEGORY = "image/color_correction"
    FUNCTION = "dehaze"
    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("去灰结果",)

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "图像": ("IMAGE",),
                "暗部裁剪": ("FLOAT", {
                    "default": 0.1,
                    "min": 0.0,
                    "max": 2.0,
                    "step": 0.01,
                    "display": "slider",
                    "tooltip": "忽略最暗的x%像素，避免噪点干扰锚点检测。建议0.05-0.5"
                }),
                "亮部裁剪": ("FLOAT", {
                    "default": 0.1,
                    "min": 0.0,
                    "max": 2.0,
                    "step": 0.01,
                    "display": "slider",
                    "tooltip": "忽略最亮的x%像素，避免高光溢出干扰。建议0.05-0.5"
                }),
                "强度": ("FLOAT", {
                    "default": 1.0,
                    "min": 0.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "tooltip": "去灰效果强度。0=原图，1=完全去灰"
                }),
            },
            "optional": {
                "仅亮度": ("BOOLEAN", {
                    "default": False,
                    "tooltip": "True=只调整明度，保留色相；False=独立调整RGB三通道"
                }),
            }
        }

    def dehaze(self, 图像, 暗部裁剪, 亮部裁剪, 强度, 仅亮度=False, **kwargs):
        """
        去灰主流程

        算法：
        1. 计算每个通道的直方图
        2. 根据裁剪百分比找到暗部锚点和亮部锚点
        3. 线性映射：output = (input - shadow) / (highlight - shadow)
        4. 与原图按强度混合
        """
        x = 图像
        b, h, w, c = x.shape
        device = x.device

        if not x.is_cuda:
            x = x.cuda()
            device = x.device

        # [B,H,W,C] -> [B,C,H,W]
        x = x.permute(0, 3, 1, 2)

        if 仅亮度:
            result = self._dehaze_luminance(x, 暗部裁剪, 亮部裁剪, 强度)
        else:
            result = self._dehaze_rgb(x, 暗部裁剪, 亮部裁剪, 强度)

        # [B,C,H,W] -> [B,H,W,C]
        result = result.permute(0, 2, 3, 1)

        return (torch.clamp(result, 0, 1),)

    def _dehaze_rgb(self, image, shadow_clip, highlight_clip, strength):
        """独立调整 RGB 三通道"""
        b, c, h, w = image.shape
        device = image.device

        # 展平为 [B, C, H*W]
        flat = image.view(b, c, -1)

        # 计算每个通道的锚点
        shadow = torch.zeros(b, c, device=device)
        highlight = torch.zeros(b, c, device=device)

        for i in range(b):
            for ch in range(c):
                sorted_vals, _ = torch.sort(flat[i, ch])
                n = sorted_vals.numel()

                # 暗部锚点：跳过最暗的 shadow_clip% 像素
                shadow_idx = int(n * shadow_clip / 100.0)
                shadow_idx = min(shadow_idx, n - 1)
                shadow[i, ch] = sorted_vals[shadow_idx]

                # 亮部锚点：跳过最亮的 highlight_clip% 像素
                highlight_idx = int(n * (1.0 - highlight_clip / 100.0))
                highlight_idx = max(highlight_idx, 0)
                highlight[i, ch] = sorted_vals[highlight_idx]

        # 扩展维度用于广播 [B, C, 1, 1]
        shadow = shadow.view(b, c, 1, 1)
        highlight = highlight.view(b, c, 1, 1)

        # 防止除零
        range_val = highlight - shadow
        range_val = torch.where(range_val < 1e-6, torch.ones_like(range_val), range_val)

        # 线性映射
        dehazed = (image - shadow) / range_val

        # 与原图按强度混合
        result = image * (1.0 - strength) + dehazed * strength

        return result

    def _dehaze_luminance(self, image, shadow_clip, highlight_clip, strength):
        """仅调整亮度通道，保留色相"""
        b, c, h, w = image.shape
        device = image.device

        # 计算亮度
        r, g, b_ch = image[:, 0], image[:, 1], image[:, 2]
        luminance = 0.299 * r + 0.587 * g + 0.114 * b_ch

        # 展平亮度 [B, H*W]
        lum_flat = luminance.view(b, -1)

        # 计算亮度锚点
        shadow = torch.zeros(b, device=device)
        highlight = torch.zeros(b, device=device)

        for i in range(b):
            sorted_vals, _ = torch.sort(lum_flat[i])
            n = sorted_vals.numel()

            shadow_idx = int(n * shadow_clip / 100.0)
            shadow_idx = min(shadow_idx, n - 1)
            shadow[i] = sorted_vals[shadow_idx]

            highlight_idx = int(n * (1.0 - highlight_clip / 100.0))
            highlight_idx = max(highlight_idx, 0)
            highlight[i] = sorted_vals[highlight_idx]

        # 扩展维度 [B, 1, 1]
        shadow = shadow.view(b, 1, 1)
        highlight = highlight.view(b, 1, 1)

        # 亮度范围
        range_val = highlight - shadow
        range_val = torch.where(range_val < 1e-6, torch.ones_like(range_val), range_val)

        # 亮度映射
        lum_dehazed = (luminance - shadow) / range_val

        # 计算缩放比例（保持色相）
        # 原亮度为 0 的地方保持 0，避免除零
        scale = torch.where(
            luminance > 1e-6,
            lum_dehazed / luminance,
            torch.ones_like(luminance)
        )

        # 应用缩放
        dehazed = image * scale.unsqueeze(1)  # [B, 1, H, W] 广播到 [B, 3, H, W]

        # 与原图按强度混合
        result = image * (1.0 - strength) + dehazed * strength

        return result


Dehaze = DehazeNode