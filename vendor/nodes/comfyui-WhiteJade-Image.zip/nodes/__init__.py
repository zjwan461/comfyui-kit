from .frequency_separation import FrequencySeparationNode, FrequencySeparation
from .frequency_mixer import FrequencyMixerNode, FrequencyMixer
from .portraiture import SkinSmoothingNode, Portraiture
from .edge_preserving_denoise import EdgePreservingDenoiseNode, EdgePreservingDenoise
from .latent_preset import LatentPresetNode, EmptyLatentPreset
from .histogram_node import HistogramNode, Histogram
from .ps_curves import PSCurvesNode, PSCurves
from .blend_modes import BlendModeNode, BlendMode
from .dehaze_node import DehazeNode, Dehaze
from .preset_manager import SavePresetNode, SavePreset
from .latent_tile import LatentTileBatchNode, LatentTileAssemblyNode
from .lua_upscale import LUAUpscaleNode


NODE_CLASS_MAPPINGS = {
    "WJIFrequencySeparation": FrequencySeparationNode,
    "WJIFrequencyMixer": FrequencyMixerNode,
    "WJISkinSmoothing": SkinSmoothingNode,
    "WJIEdgePreservingDenoise": EdgePreservingDenoiseNode,
    "WJILatentPreset": LatentPresetNode,
    "WJIHistogram": HistogramNode,
    "WJIPSCurves": PSCurvesNode,
    "WJIBlendMode": BlendModeNode,
    "WJIDehaze": DehazeNode,
    "WJISavePreset": SavePresetNode,
    "WJILatentTileBatch": LatentTileBatchNode,
    "WJILatentTileAssembly": LatentTileAssemblyNode,
    "WJILUAUpscale": LUAUpscaleNode,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "WJIFrequencySeparation": "🔍 频率分离 (Frequency Separation)",
    "WJIFrequencyMixer": "🎨 频率混合 (Frequency Mixer)",
    "WJISkinSmoothing": "✨ 肤色平滑 (Skin Smoothing)",
    "WJIEdgePreservingDenoise": "🛡️ 保边降噪 (Edge Preserving Denoise)",
    "WJILatentPreset": "📐 Latent预设 (Empty Latent Preset)",
    "WJIHistogram": "📊 直方图显示 (Histogram)",
    "WJIPSCurves": "🎨 曲线 (Curves)",
    "WJIBlendMode": "🎭 混合模式 (Blend Mode)",
    "WJIDehaze": "🌫️ 去灰 (Dehaze)",
    "WJISavePreset": "💾 保存预设 (Save Preset)",
    "WJILatentTileBatch": "🔲 Latent分块 (Latent Tile Batch)",
    "WJILatentTileAssembly": "🧩 Latent拼接 (Latent Tile Assembly)",
    "WJILUAUpscale": "🚀 LUA潜空间放大 (LUA Upscale)",
}

__all__ = ['NODE_CLASS_MAPPINGS', 'NODE_DISPLAY_NAME_MAPPINGS']
