"""
Latent预设节点 v4.0 - 取消批量大小上限
"""

import torch
import math


class LatentPresetNode:
    """
    Latent预设 - 文生图/视频工作流中的空Latent替代方案
    """

    CATEGORY = "latent"
    FUNCTION = "generate_latent"
    RETURN_TYPES = ("LATENT", "INT", "INT", "INT")
    RETURN_NAMES = ("Latent", "宽", "高", "总张数")

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "预设分辨率": (cls._get_preset_keys(), {
                    "default": "自定义",
                    "tooltip": "选择预设分辨率，括号内为比例和方向"
                }),
                "横竖对调": ("BOOLEAN", {
                    "default": False,
                    "tooltip": "开启后宽高对调，横图变竖图，竖图变横图，正图不变"
                }),
                "批量大小": ("INT", {
                    "default": 1,
                    "min": 1,
                    "max": 4096,
                    "step": 1,
                    "tooltip": "生成图片/帧数量，视频生成时可设为帧数"
                }),
            },
            "optional": {
                "自定义宽": ("INT", {
                    "default": 1024,
                    "min": 64,
                    "max": 8192,
                    "step": 8,
                    "tooltip": "仅在预设选择'自定义'时生效"
                }),
                "自定义高": ("INT", {
                    "default": 1024,
                    "min": 64,
                    "max": 8192,
                    "step": 8,
                    "tooltip": "仅在预设选择'自定义'时生效"
                }),
                "缩放倍数": (["8", "16", "32", "64"], {
                    "default": "8",
                    "tooltip": "边长缩放到该整倍数"
                }),
            }
        }

    @classmethod
    def _get_preset_keys(cls):
        """生成预设列表，自定义置顶"""
        presets = cls._build_presets()
        keys = ["自定义"]
        for k in presets.keys():
            if k != "自定义":
                keys.append(k)
        return keys

    @classmethod
    def _build_presets(cls):
        """构建预设字典"""
        raw_presets = [
            (512, 512),
            (512, 768),
            (768, 512),
            (512, 1024),
            (1024, 512),
            (1024, 1024),
            (832, 1216),
            (1216, 832),
            (768, 1344),
            (1344, 768),
            (896, 1152),
            (1152, 896),
            (768, 1360),
            (1360, 768),
            (1080, 1920),
            (1920, 1080),
            (640, 480),
            (480, 640),
            (1280, 720),
            (720, 1280),
            (2560, 1440),
            (3840, 2160),
            (1080, 1080),
            (1080, 1350),
            (1200, 630),
        ]

        presets = {"自定义": (1024, 1024)}

        for w, h in raw_presets:
            ratio_str, direction = cls._calc_ratio(w, h)
            key = f"{w} × {h} ({ratio_str}-{direction})"
            presets[key] = (w, h)

        return presets

    @staticmethod
    def _calc_ratio(w, h):
        """计算比例和方向"""
        if w == h:
            return "1:1", "正"

        g = math.gcd(w, h)
        rw, rh = w // g, h // g

        if rw > 20 or rh > 20:
            ratio = w / h
            if abs(ratio - 16/9) < 0.05:
                return "16:9", "横" if w > h else "竖"
            elif abs(ratio - 9/16) < 0.05:
                return "9:16", "竖"
            elif abs(ratio - 4/3) < 0.05:
                return "4:3", "横" if w > h else "竖"
            elif abs(ratio - 3/4) < 0.05:
                return "3:4", "竖"
            elif abs(ratio - 3/2) < 0.05:
                return "3:2", "横"
            elif abs(ratio - 2/3) < 0.05:
                return "2:3", "竖"
            elif abs(ratio - 2/1) < 0.05:
                return "2:1", "横"
            elif abs(ratio - 1/2) < 0.05:
                return "1:2", "竖"
            elif abs(ratio - 21/9) < 0.05 or abs(ratio - 7/3) < 0.05:
                return "21:9", "横"
            elif abs(ratio - 9/21) < 0.05:
                return "9:21", "竖"
            else:
                return f"{rw}:{rh}", "横" if w > h else "竖"

        direction = "横" if w > h else "竖"
        return f"{rw}:{rh}", direction

    def generate_latent(self, 预设分辨率, 横竖对调, 批量大小,
                       自定义宽=1024, 自定义高=1024, 缩放倍数="8",
                       **kwargs):
        """生成Latent张量"""

        presets = self._build_presets()

        if 预设分辨率 == "自定义":
            base_w, base_h = 自定义宽, 自定义高
        else:
            base_w, base_h = presets.get(预设分辨率, (1024, 1024))

        if 横竖对调:
            w, h = base_h, base_w
        else:
            w, h = base_w, base_h

        multiple = int(缩放倍数)
        w = (w // multiple) * multiple
        h = (h // multiple) * multiple
        w = max(multiple, w)
        h = max(multiple, h)

        latent = torch.zeros(批量大小, 4, h // 8, w // 8)

        return ({"samples": latent}, w, h, 批量大小)


EmptyLatentPreset = LatentPresetNode