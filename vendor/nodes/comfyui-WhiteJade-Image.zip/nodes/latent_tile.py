"""
Latent 分块与拼接节点
支持精确均分策略，无偏移覆盖
"""

import torch


def _solve_tile_size(total_latent, factor, target_overlap):
    """解整数方程 tile + (factor-1)*step = total_latent，找最接近目标 overlap 的解。
    
    返回: (tile_lat, step_lat, actual_overlap)
    """
    if factor == 1:
        return total_latent, total_latent, 0.0
    
    ideal_tile = total_latent / (1 + (factor - 1) * (1 - target_overlap))
    
    best_m = None
    best_k = None
    best_error = float('inf')
    best_tile_error = float('inf')
    
    # 约束: k > m  =>  total - (factor-1)*m > m  =>  total > factor*m  =>  m < total/factor
    max_m = (total_latent - 1) // factor
    if max_m < 1:
        max_m = 1
    
    for m in range(1, max_m + 1):
        k = total_latent - (factor - 1) * m
        if k <= m:
            continue
        actual_overlap = 1.0 - m / k
        error = abs(actual_overlap - target_overlap)
        tile_error = abs(k - ideal_tile)
        
        if error < best_error - 1e-9 or (abs(error - best_error) < 1e-9 and tile_error < best_tile_error):
            best_error = error
            best_tile_error = tile_error
            best_m = m
            best_k = k
    
    if best_m is None:
        # Fallback: 直接均分
        if total_latent % factor == 0:
            k = total_latent // factor
            m = k
            return k, m, 0.0
        else:
            # 向上取整 tile，再反推 step
            k = (total_latent + factor - 1) // factor
            m = max(1, (total_latent - k) // (factor - 1)) if factor > 1 else k
            k = total_latent - (factor - 1) * m
            if k <= m:
                k = m + 1
                m = (total_latent - k) // (factor - 1)
                if m < 1:
                    m = 1
                    k = total_latent - (factor - 1)
            actual_overlap = 1.0 - m / k if k > 0 else 0.0
            return k, m, actual_overlap
    
    return best_k, best_m, 1.0 - best_m / best_k


class LatentTileBatchNode:
    """将 Latent 精确均分为若干块，输出 batch latent。"""
    
    CATEGORY = "WhiteJade/Latent"
    FUNCTION = "tile_batch"
    RETURN_TYPES = ("LATENT", "LIST", "TUPLE", "TUPLE", "TUPLE")
    RETURN_NAMES = ("分块Latent", "位置信息", "原始尺寸", "网格尺寸", "单块尺寸")
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "latent": ("LATENT",),
                "横向块数": ("INT", {
                    "default": 2,
                    "min": 1,
                    "max": 10,
                    "step": 1,
                }),
                "纵向块数": ("INT", {
                    "default": 2,
                    "min": 1,
                    "max": 10,
                    "step": 1,
                }),
                "重叠率": ("FLOAT", {
                    "default": 0.1,
                    "min": 0.0,
                    "max": 0.95,
                    "step": 0.01,
                }),
            }
        }
    
    def tile_batch(self, latent, 横向块数, 纵向块数, 重叠率):
        samples = latent["samples"]
        if samples.shape[0] != 1:
            raise ValueError(f"LatentTileBatch 目前只支持 batch_size=1 的输入，当前为 {samples.shape[0]}")
        
        _, C, h_lat, w_lat = samples.shape
        h_px = h_lat * 8
        w_px = w_lat * 8
        
        # 求解 tile 尺寸
        tile_w_lat, step_w_lat, actual_overlap_w = _solve_tile_size(w_lat, 横向块数, 重叠率)
        tile_h_lat, step_h_lat, actual_overlap_h = _solve_tile_size(h_lat, 纵向块数, 重叠率)
        
        tile_w_px = tile_w_lat * 8
        tile_h_px = tile_h_lat * 8
        step_w_px = step_w_lat * 8
        step_h_px = step_h_lat * 8
        
        # 处理 noise_mask
        has_noise_mask = "noise_mask" in latent
        noise_masks = []
        if has_noise_mask:
            noise_mask = latent["noise_mask"]
            nm_h, nm_w = noise_mask.shape[-2], noise_mask.shape[-1]
            nm_is_latent = (nm_h == h_lat and nm_w == w_lat)
            # 如果 noise_mask 不是 latent 尺寸，统一插值到 latent 尺寸后再切片
            if not nm_is_latent:
                noise_mask = torch.nn.functional.interpolate(
                    noise_mask, size=(h_lat, w_lat), mode='bilinear', align_corners=False
                )
        else:
            noise_mask = None
        
        tiles = []
        positions = []
        
        for row in range(纵向块数):
            for col in range(横向块数):
                left_px = col * step_w_px
                upper_px = row * step_h_px
                right_px = left_px + tile_w_px
                lower_px = upper_px + tile_h_px
                
                left_lat = col * step_w_lat
                upper_lat = row * step_h_lat
                right_lat = left_lat + tile_w_lat
                lower_lat = upper_lat + tile_h_lat
                
                tile_sample = samples[:, :, upper_lat:lower_lat, left_lat:right_lat]
                tiles.append(tile_sample)
                positions.append((left_px, upper_px, right_px, lower_px))
                
                if has_noise_mask:
                    tile_nm = noise_mask[:, :, upper_lat:lower_lat, left_lat:right_lat]
                    noise_masks.append(tile_nm)
        
        batch_samples = torch.cat(tiles, dim=0)
        out_latent = {"samples": batch_samples}
        
        if has_noise_mask:
            out_latent["noise_mask"] = torch.cat(noise_masks, dim=0)
        
        return (
            out_latent,
            positions,
            (w_px, h_px),
            (横向块数, 纵向块数),
            (tile_w_px, tile_h_px),
        )


class LatentTileAssemblyNode:
    """将分块后的 batch latent 按坐标拼接还原。"""
    
    CATEGORY = "WhiteJade/Latent"
    FUNCTION = "assemble"
    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("完整Latent",)
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "分块Latent": ("LATENT",),
                "位置信息": ("LIST",),
                "原始尺寸": ("TUPLE",),
                "网格尺寸": ("TUPLE",),
                "混合宽度": ("INT", {
                    "default": 64,
                    "min": 0,
                    "max": 512,
                    "step": 8,
                }),
            }
        }
    
    @staticmethod
    def _blend_horizontal(left_img, right_img, blend, device, dtype, channels):
        """横向 feather blend。输入均为 [channels, H, W]"""
        mask = torch.linspace(1, 0, blend, device=device, dtype=dtype).view(1, 1, -1)
        mask = mask.expand(channels, left_img.shape[-2], blend)
        
        left_part = left_img[:, :, -blend:]
        right_part = right_img[:, :, :blend]
        blended = left_part * mask + right_part * (1.0 - mask)
        
        return torch.cat([
            left_img[:, :, :-blend],
            blended,
            right_img[:, :, blend:]
        ], dim=-1)
    
    @staticmethod
    def _blend_vertical(top_img, bottom_img, blend, device, dtype, channels):
        """纵向 feather blend。输入均为 [channels, H, W]"""
        mask = torch.linspace(1, 0, blend, device=device, dtype=dtype).view(1, -1, 1)
        mask = mask.expand(channels, blend, top_img.shape[-1])
        
        top_part = top_img[:, -blend:, :]
        bottom_part = bottom_img[:, :blend, :]
        blended = top_part * mask + bottom_part * (1.0 - mask)
        
        return torch.cat([
            top_img[:, :-blend, :],
            blended,
            bottom_img[:, blend:, :]
        ], dim=-2)
    
    def assemble(self, 分块Latent, 位置信息, 原始尺寸, 网格尺寸, 混合宽度):
        samples = 分块Latent["samples"]
        N, C, tile_h_lat, tile_w_lat = samples.shape
        num_cols, num_rows = 网格尺寸
        
        if N != num_cols * num_rows:
            raise ValueError(f"块数 {N} 与网格尺寸 {num_cols}x{num_rows}={num_cols*num_rows} 不匹配")
        
        orig_w_px, orig_h_px = 原始尺寸
        orig_w_lat = orig_w_px // 8
        orig_h_lat = orig_h_px // 8
        blend_lat = 混合宽度 // 8
        
        device = samples.device
        dtype = samples.dtype
        
        # --- 逐行横向拼接 ---
        row_images = []
        for row in range(num_rows):
            row_img = samples[row * num_cols]
            
            for col in range(1, num_cols):
                idx = row * num_cols + col
                tile = samples[idx]
                
                prev_right = 位置信息[idx - 1][2]
                curr_left = 位置信息[idx][0]
                overlap_px = prev_right - curr_left
                
                if overlap_px > 0 and blend_lat > 0:
                    overlap_lat = overlap_px // 8
                    # 总是用整个 overlap 区域做 feather，避免宽度计算出错
                    blend = overlap_lat
                    row_img = self._blend_horizontal(row_img, tile, blend, device, dtype, C)
                else:
                    row_img = torch.cat([row_img, tile], dim=-1)
            
            row_images.append(row_img)
        
        # --- 纵向拼接 ---
        final = row_images[0]
        for row in range(1, num_rows):
            row_tile = row_images[row]
            
            prev_lower = 位置信息[(row - 1) * num_cols][3]
            curr_upper = 位置信息[row * num_cols][1]
            overlap_px = prev_lower - curr_upper
            
            if overlap_px > 0 and blend_lat > 0:
                overlap_lat = overlap_px // 8
                blend = overlap_lat
                final = self._blend_vertical(final, row_tile, blend, device, dtype, C)
            else:
                final = torch.cat([final, row_tile], dim=-2)
        
        final = final.unsqueeze(0)
        out_latent = {"samples": final}
        
        # --- noise_mask 拼接 ---
        if "noise_mask" in 分块Latent:
            nm = 分块Latent["noise_mask"]
            nm_C = nm.shape[1]
            
            nm_row_images = []
            for row in range(num_rows):
                nm_row = nm[row * num_cols]
                for col in range(1, num_cols):
                    idx = row * num_cols + col
                    nm_tile = nm[idx]
                    prev_right = 位置信息[idx - 1][2]
                    curr_left = 位置信息[idx][0]
                    overlap_px = prev_right - curr_left
                    
                    if overlap_px > 0 and blend_lat > 0:
                        overlap_lat = overlap_px // 8
                        blend = overlap_lat
                        nm_row = self._blend_horizontal(nm_row, nm_tile, blend, device, dtype, nm_C)
                    else:
                        nm_row = torch.cat([nm_row, nm_tile], dim=-1)
                nm_row_images.append(nm_row)
            
            nm_final = nm_row_images[0]
            for row in range(1, num_rows):
                nm_row_tile = nm_row_images[row]
                prev_lower = 位置信息[(row - 1) * num_cols][3]
                curr_upper = 位置信息[row * num_cols][1]
                overlap_px = prev_lower - curr_upper
                
                if overlap_px > 0 and blend_lat > 0:
                    overlap_lat = overlap_px // 8
                    blend = overlap_lat
                    nm_final = self._blend_vertical(nm_final, nm_row_tile, blend, device, dtype, nm_C)
                else:
                    nm_final = torch.cat([nm_final, nm_row_tile], dim=-2)
            
            out_latent["noise_mask"] = nm_final.unsqueeze(0)
        
        return (out_latent,)
