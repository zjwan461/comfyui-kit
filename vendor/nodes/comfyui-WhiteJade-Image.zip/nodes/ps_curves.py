import torch
import numpy as np
import os
import json


def _get_presets_dir(category="curves"):
    """获取预设存储目录"""
    plugin_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    presets_dir = os.path.join(plugin_dir, "presets", category)
    os.makedirs(presets_dir, exist_ok=True)
    return presets_dir


def scan_presets(category="curves"):
    """扫描指定类别预设目录，返回可用预设名称列表"""
    presets_dir = _get_presets_dir(category)
    names = []
    if os.path.exists(presets_dir):
        for f in sorted(os.listdir(presets_dir)):
            if f.endswith('.json'):
                try:
                    with open(os.path.join(presets_dir, f), 'r', encoding='utf-8') as fh:
                        data = json.load(fh)
                    if data.get("type") == "ps_curves":
                        names.append(f[:-5])
                except Exception:
                    pass
    return names

class PSCurvesNode:
    """Photoshop 风格曲线调整节点"""

    MAX_ANCHORS = 16

    @classmethod
    def INPUT_TYPES(cls):
        required = {
            "image": ("IMAGE",),
            "channel": (["全通道", "R", "G", "B", "明度"], {"default": "全通道"}),
        }

        defaults = {
            "rgb": {"count": 1, "xs": [128], "ys": [128]},
            "r":   {"count": 1, "xs": [128], "ys": [128]},
            "g":   {"count": 1, "xs": [128], "ys": [128]},
            "b":   {"count": 1, "xs": [128], "ys": [128]},
        }

        for ch in ["rgb", "r", "g", "b"]:
            d = defaults[ch]
            required[f"{ch}_count"] = ("INT", {
                "default": d["count"], "min": 0, "max": cls.MAX_ANCHORS, "step": 1
            })
            for i in range(1, cls.MAX_ANCHORS + 1):
                required[f"{ch}_{i}_x"] = ("INT", {
                    "default": d["xs"][i - 1] if i <= len(d["xs"]) else 128,
                    "min": 0, "max": 255, "step": 1
                })
                required[f"{ch}_{i}_y"] = ("INT", {
                    "default": d["ys"][i - 1] if i <= len(d["ys"]) else 128,
                    "min": 0, "max": 255, "step": 1
                })

        preset_names = ["重置", "【刷新列表】", "— 自定义 —"] + scan_presets("curves")
        # 兼容旧工作流：旧值 "无" 仍然合法
        if "无" not in preset_names:
            preset_names.append("无")
        required["preset"] = (preset_names, {"default": "重置"})
        required["intensity"] = ("FLOAT", {"default": 1.0, "min": 0.0, "max": 2.0, "step": 0.01})

        return {
            "required": required,
            "optional": {
                "mask": ("MASK",),
                "preset_data": ("STRING", {"default": "", "forceInput": True}),
                "blend_mode": ([
                    "正常", "溶解", "变暗", "正片叠底", "颜色加深",
                    "线性加深", "深色", "变亮", "滤色", "颜色减淡",
                    "线性减淡（添加）", "浅色", "叠加", "柔光", "强光",
                    "亮光", "线性光", "点光", "实色混合", "差值",
                    "排除", "减去", "划分", "色相", "饱和度",
                    "颜色", "明度"
                ], {"default": "正常"}),
                "mask_blur": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 50.0, "step": 0.1}),
            }
        }

    RETURN_TYPES = ("IMAGE", "IMAGE", "STRING", "STRING")
    RETURN_NAMES = ("图像", "曲线图表", "直方图数据", "预设数据")
    FUNCTION = "apply_curves"
    CATEGORY = "image/adjustment"

    def apply_curves(self, image, channel, intensity,
                     mask=None, blend_mode="正常", mask_blur=0.0,
                     preset_data="", **kwargs):

        device = image.device

        # 如果外部输入了预设数据，解析并覆盖对应参数
        if preset_data and isinstance(preset_data, str):
            try:
                pd = json.loads(preset_data)
                if pd.get("type") == "ps_curves":
                    for k, v in pd.get("params", {}).items():
                        kwargs[k] = v
            except Exception:
                pass

        points_map = {
            "RGB": self._build_points(kwargs, "rgb"),
            "R": self._build_points(kwargs, "r"),
            "G": self._build_points(kwargs, "g"),
            "B": self._build_points(kwargs, "b")
        }

        luts = {}
        for ch, points in points_map.items():
            luts[ch] = self._generate_lut(points)

        result = image.clone()

        if channel == "全通道":
            # 先应用各单通道曲线 (R/G/B)
            for i, ch_name in enumerate(["R", "G", "B"]):
                lut = torch.tensor(luts[ch_name], dtype=torch.float32, device=device) / 255.0
                indices = (result[..., i] * 255).long().clamp(0, 255)
                result[..., i] = lut[indices]
            # 再应用 RGB Master 曲线到所有通道（与 PS 一致）
            master_lut = torch.tensor(luts["RGB"], dtype=torch.float32, device=device) / 255.0
            for i in range(3):
                indices = (result[..., i] * 255).long().clamp(0, 255)
                result[..., i] = master_lut[indices]
        elif channel == "明度":
            result = self._apply_luminosity_curve(result, luts["RGB"], device)
        else:
            ch_idx = {"R": 0, "G": 1, "B": 2}[channel]
            lut = torch.tensor(luts[channel], dtype=torch.float32, device=device) / 255.0
            indices = (result[..., ch_idx] * 255).long().clamp(0, 255)
            result[..., ch_idx] = lut[indices]

        if blend_mode != "正常":
            result = self._apply_blend_mode(image, result, blend_mode, mask, mask_blur)
        elif mask is not None:
            mask = self._process_mask(mask, mask_blur, device)
            result = image * (1 - mask) + result * mask

        if intensity != 1.0:
            result = image + (result - image) * intensity

        hist_data = self._compute_histogram(result)
        chart = self._generate_curve_chart(luts, channel, hist_data)

        # 导出当前所有曲线参数为预设数据
        curve_params = {}
        for prefix in ["rgb", "r", "g", "b"]:
            curve_params[f"{prefix}_count"] = kwargs.get(f"{prefix}_count", 0)
            for i in range(1, self.MAX_ANCHORS + 1):
                curve_params[f"{prefix}_{i}_x"] = kwargs.get(f"{prefix}_{i}_x", 128)
                curve_params[f"{prefix}_{i}_y"] = kwargs.get(f"{prefix}_{i}_y", 128)

        output_preset = json.dumps({
            "type": "ps_curves",
            "version": "1.0",
            "params": curve_params
        }, ensure_ascii=False)

        return (result.clamp(0, 1), chart, hist_data, output_preset)

    def _build_points(self, kwargs, prefix):
        count = kwargs.get(f"{prefix}_count", 0)
        # 默认两端固定锚点
        point_map = {0: 0, 255: 255}
        for i in range(1, count + 1):
            x = kwargs.get(f"{prefix}_{i}_x", 128)
            y = kwargs.get(f"{prefix}_{i}_y", 128)
            # 额外锚点覆盖同位置的固定端点，允许自由调整 Y 值
            point_map[x] = y
        # 按 X 坐标排序返回
        return [[x, y] for x, y in sorted(point_map.items())]

    def _generate_lut(self, points):
        if len(points) < 2:
            return list(range(256))

        x = [p[0] for p in points]
        y = [p[1] for p in points]

        if len(points) >= 3:
            try:
                from scipy.interpolate import PchipInterpolator
                cs = PchipInterpolator(x, y)
                lut = cs(np.arange(256))
            except Exception:
                lut = np.interp(np.arange(256), x, y)
        else:
            lut = np.interp(np.arange(256), x, y)

        return np.clip(lut, 0, 255).astype(np.float32).tolist()

    def _apply_luminosity_curve(self, image, lut, device):
        """对明度通道应用曲线，保持色调和饱和度不变"""
        lum = 0.2126 * image[..., 0] + 0.7152 * image[..., 1] + 0.0722 * image[..., 2]
        lut_tensor = torch.tensor(lut, dtype=torch.float32, device=device) / 255.0
        indices = (lum * 255).long().clamp(0, 255)
        new_lum = lut_tensor[indices]
        ratio = new_lum / (lum + 1e-6)
        ratio = ratio.unsqueeze(-1).expand_as(image)
        result = image * ratio
        return torch.clamp(result, 0, 1)

    def _apply_blend_mode(self, base, blend, mode, mask=None, mask_blur=0.0):
        device = base.device

        if mask is not None:
            mask = self._process_mask(mask, mask_blur, device)
        else:
            mask = torch.ones_like(base[..., :1])

        if mask.dim() == 2:
            mask = mask.unsqueeze(0).unsqueeze(-1)
        elif mask.dim() == 3:
            if mask.shape[-1] == 1:
                mask = mask.unsqueeze(0) if mask.shape[0] != base.shape[0] else mask
            else:
                mask = mask.unsqueeze(-1)

        mask = mask.to(device)

        # 用于深色/浅色的亮度比较
        lum_base = 0.299 * base[..., 0] + 0.587 * base[..., 1] + 0.114 * base[..., 2]
        lum_blend = 0.299 * blend[..., 0] + 0.587 * blend[..., 1] + 0.114 * blend[..., 2]

        if mode == "正常":
            result = blend
        elif mode == "溶解":
            h, w = base.shape[1], base.shape[2]
            yy = torch.arange(h, device=device).view(1, -1, 1, 1).float()
            xx = torch.arange(w, device=device).view(1, 1, -1, 1).float()
            noise = (((yy * 37.0 + xx * 73.0 + 13.0) % 256.0) / 255.0).expand_as(base)
            lum = blend.mean(dim=-1, keepdim=True).expand_as(base)
            result = torch.where(noise < lum, blend, base)
        elif mode == "变暗":
            result = torch.minimum(base, blend)
        elif mode == "正片叠底":
            result = base * blend
        elif mode == "颜色加深":
            result = 1 - (1 - base) / (blend + 1e-6)
        elif mode == "线性加深":
            result = base + blend - 1
        elif mode == "深色":
            mask_dark = (lum_base < lum_blend).unsqueeze(-1).expand_as(base)
            result = torch.where(mask_dark, base, blend)
        elif mode == "变亮":
            result = torch.maximum(base, blend)
        elif mode == "滤色":
            result = 1 - (1 - base) * (1 - blend)
        elif mode == "颜色减淡":
            result = base / (1 - blend + 1e-6)
        elif mode == "线性减淡（添加）":
            result = base + blend
        elif mode == "浅色":
            mask_light = (lum_base > lum_blend).unsqueeze(-1).expand_as(base)
            result = torch.where(mask_light, base, blend)
        elif mode == "叠加":
            mask_dark = base < 0.5
            result = torch.where(mask_dark, 2 * base * blend,
                                1 - 2 * (1 - base) * (1 - blend))
        elif mode == "柔光":
            mask_dark = blend < 0.5
            result = torch.where(mask_dark,
                                2 * base * blend + base ** 2 * (1 - 2 * blend),
                                2 * base * (1 - blend) + torch.sqrt(base.clamp(min=0)) * (2 * blend - 1))
        elif mode == "强光":
            mask_dark = blend < 0.5
            result = torch.where(mask_dark, 2 * base * blend,
                                1 - 2 * (1 - base) * (1 - blend))
        elif mode == "亮光":
            mask_dark = blend <= 0.5
            result = torch.where(mask_dark,
                                1 - (1 - base) / (2 * blend.clamp(min=1e-6)),
                                base / (1 - 2 * (blend - 0.5)).clamp(min=1e-6))
        elif mode == "线性光":
            result = base + 2 * blend - 1
        elif mode == "点光":
            mask_dark = blend <= 0.5
            result = torch.where(mask_dark,
                                torch.minimum(base, 2 * blend),
                                torch.maximum(base, 2 * blend - 1))
        elif mode == "实色混合":
            result = (base + blend >= 1).float()
        elif mode == "差值":
            result = torch.abs(base - blend)
        elif mode == "排除":
            result = base + blend - 2 * base * blend
        elif mode == "减去":
            result = base - blend
        elif mode == "划分":
            result = base / (blend + 1e-6)
        elif mode in ["色相", "饱和度", "颜色", "明度"]:
            result = self._hsl_blend_mode(base, blend, mode)
        else:
            result = blend

        result = base * (1 - mask) + result * mask
        return torch.clamp(result, 0, 1)

    def _process_mask(self, mask, blur, device):
        import torch.nn.functional as F

        if mask.dim() == 2:
            mask = mask.unsqueeze(0).unsqueeze(-1)
        elif mask.dim() == 3:
            mask = mask.unsqueeze(-1)

        mask = mask.to(device)

        if blur > 0:
            kernel_size = int(blur * 2) | 1
            if kernel_size < 3:
                kernel_size = 3
            mask = mask.permute(0, 3, 1, 2)
            mask = F.gaussian_blur(mask, kernel_size, sigma=blur)
            mask = mask.permute(0, 2, 3, 1)

        return mask

    def _hsl_blend_mode(self, base, blend, mode):
        base_hsl = self._rgb_to_hsl(base)
        blend_hsl = self._rgb_to_hsl(blend)

        if mode == "色相":
            result_hsl = torch.stack([blend_hsl[..., 0], base_hsl[..., 1], base_hsl[..., 2]], dim=-1)
        elif mode == "饱和度":
            result_hsl = torch.stack([base_hsl[..., 0], blend_hsl[..., 1], base_hsl[..., 2]], dim=-1)
        elif mode == "颜色":
            result_hsl = torch.stack([blend_hsl[..., 0], blend_hsl[..., 1], base_hsl[..., 2]], dim=-1)
        elif mode == "明度":
            result_hsl = torch.stack([base_hsl[..., 0], base_hsl[..., 1], blend_hsl[..., 2]], dim=-1)
        else:
            return blend

        return self._hsl_to_rgb(result_hsl)

    def _rgb_to_hsl(self, rgb):
        r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
        maxc = torch.max(torch.max(r, g), b)
        minc = torch.min(torch.min(r, g), b)
        l = (maxc + minc) / 2

        delta = maxc - minc
        s = torch.where(l > 0.5, delta / (2 - maxc - minc + 1e-6), delta / (maxc + minc + 1e-6))
        s = torch.where(delta == 0, torch.zeros_like(s), s)

        h = torch.zeros_like(r)
        h = torch.where(delta != 0, torch.where(maxc == r, ((g - b) / (delta + 1e-6)) % 6, h), h)
        h = torch.where(delta != 0, torch.where(maxc == g, ((b - r) / (delta + 1e-6)) + 2, h), h)
        h = torch.where(delta != 0, torch.where(maxc == b, ((r - g) / (delta + 1e-6)) + 4, h), h)
        h = h / 6

        return torch.stack([h, s, l], dim=-1)

    def _hsl_to_rgb(self, hsl):
        h, s, l = hsl[..., 0], hsl[..., 1], hsl[..., 2]

        def hue_to_rgb(p, q, t):
            t = t % 1.0
            return torch.where(t < 1/6, p + (q - p) * 6 * t,
                   torch.where(t < 1/2, q,
                   torch.where(t < 2/3, p + (q - p) * (2/3 - t) * 6, p)))

        q = torch.where(l < 0.5, l * (1 + s), l + s - l * s)
        p = 2 * l - q

        r = hue_to_rgb(p, q, h + 1/3)
        g = hue_to_rgb(p, q, h)
        b = hue_to_rgb(p, q, h - 1/3)

        rgb = torch.stack([r, g, b], dim=-1)
        gray = l.unsqueeze(-1).expand_as(rgb)
        rgb = torch.where(s.unsqueeze(-1) == 0, gray, rgb)

        return torch.clamp(rgb, 0, 1)

    def _generate_curve_chart(self, luts, active_channel, histogram_data=None):
        """生成曲线可视化图表"""
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        import json

        fig, ax = plt.subplots(figsize=(4, 4), dpi=64)
        ax.set_facecolor('#1a1a1a')
        fig.patch.set_facecolor('#1a1a1a')

        # 绘制直方图背景（颜色比对应曲线更浅更透明）
        if histogram_data:
            try:
                hist = json.loads(histogram_data)
            except:
                hist = {}

            hist_colors = {
                "RGB": (1.0, 1.0, 1.0, 0.10),
                "R": (1.0, 100/255, 100/255, 0.12),
                "G": (100/255, 1.0, 100/255, 0.12),
                "B": (100/255, 100/255, 1.0, 0.12)
            }

            x = np.arange(256)

            if active_channel == "全通道":
                for ch in ["R", "G", "B"]:
                    data = hist.get(ch, [])
                    if data and max(data) > 0:
                        heights = np.array(data) / max(data) * 255 * 0.75
                        ax.fill_between(x, 0, heights, color=hist_colors[ch])
            else:
                ch = "RGB" if active_channel == "明度" else active_channel
                data = hist.get(ch, [])
                if data and max(data) > 0:
                    heights = np.array(data) / max(data) * 255 * 0.75
                    ax.fill_between(x, 0, heights, color=hist_colors[ch])

        # 参考对角线
        ax.plot([0, 255], [0, 255], color='#666666', linestyle='--', alpha=0.5, linewidth=1)

        colors = {"R": "#ff4444", "G": "#44ff44", "B": "#4444ff"}

        if active_channel == "全通道":
            for ch in ["R", "G", "B"]:
                ax.plot(range(256), luts[ch], color=colors[ch],
                       linewidth=2.5, label=ch, alpha=0.9)
            ax.plot(range(256), luts["RGB"], color="#ffffff",
                   linewidth=2.5, label="RGB", alpha=0.9)
        else:
            lut_key = "RGB" if active_channel == "明度" else active_channel
            ax.plot(range(256), luts[lut_key], color=colors.get(lut_key, "#ffffff"),
                   linewidth=2.5, label=active_channel, alpha=0.9)

        ax.set_xlim(0, 255)
        ax.set_ylim(0, 255)
        ax.set_xlabel("输入", color='white')
        ax.set_ylabel("输出", color='white')
        ax.set_xticks([0, 51, 102, 153, 204, 255])
        ax.set_yticks([0, 51, 102, 153, 204, 255])
        ax.tick_params(colors='white')
        ax.legend(facecolor='#333', edgecolor='#555', labelcolor='white')
        ax.grid(True, alpha=0.2, color='#444')

        for spine in ax.spines.values():
            spine.set_color('#555')

        fig.canvas.draw()

        canvas = fig.canvas
        if hasattr(canvas, 'buffer_rgba'):
            buf = np.frombuffer(canvas.buffer_rgba(), dtype=np.uint8)
            buf = buf.reshape(canvas.get_width_height()[::-1] + (4,))
            buf = buf[..., :3]
        elif hasattr(canvas, 'tostring_rgb'):
            buf = np.frombuffer(canvas.tostring_rgb(), dtype=np.uint8)
            buf = buf.reshape(canvas.get_width_height()[::-1] + (3,))
        elif hasattr(canvas, 'tostring_argb'):
            buf = np.frombuffer(canvas.tostring_argb(), dtype=np.uint8)
            buf = buf.reshape(canvas.get_width_height()[::-1] + (4,))
            buf = buf[..., 1:]
        else:
            from PIL import Image
            import io
            buf = io.BytesIO()
            fig.savefig(buf, format='png', facecolor='#1a1a1a', dpi=64)
            buf.seek(0)
            img = Image.open(buf).convert('RGB')
            buf = np.array(img)

        plt.close(fig)

        chart = torch.from_numpy(buf.astype(np.float32) / 255.0).unsqueeze(0)
        return chart

    def _compute_histogram(self, image):
        import json

        img = (image[0].cpu().numpy() * 255).astype(np.uint8)

        hist_data = {}
        channels = ["R", "G", "B"]

        for i, ch in enumerate(channels):
            hist, _ = np.histogram(img[..., i], bins=256, range=(0, 256))
            max_val = hist.max()
            if max_val > 0:
                hist = (hist / max_val * 100).astype(int)
            hist_data[ch] = hist.tolist()

        gray = img.mean(axis=-1).astype(np.uint8)
        hist_gray, _ = np.histogram(gray, bins=256, range=(0, 256))
        max_gray = hist_gray.max()
        if max_gray > 0:
            hist_gray = (hist_gray / max_gray * 100).astype(int)
        hist_data["RGB"] = hist_gray.tolist()

        return json.dumps(hist_data)


PSCurves = PSCurvesNode
