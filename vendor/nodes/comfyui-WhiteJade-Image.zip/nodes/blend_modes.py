import torch
import torch.nn.functional as F

class BlendModeNode:
    """Photoshop 混合模式节点"""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "base_image": ("IMAGE",),
                "blend_image": ("IMAGE",),
                "blend_mode": ([
                    "normal", "multiply", "screen", "overlay", 
                    "soft_light", "hard_light", "vivid_light", "linear_light",
                    "pin_light", "hard_mix", "color_dodge", 
                    "color_burn", "darken", "lighten", 
                    "difference", "exclusion", "subtract", "divide",
                    "hue", "saturation", "color", "luminosity"
                ], {"default": "normal"}),
                "opacity": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 1.0, "step": 0.01}),
            },
            "optional": {
                "mask": ("MASK",),
                "mask_blur": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 50.0, "step": 0.1}),
                "fill": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 1.0, "step": 0.01}),
            }
        }

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("image",)
    FUNCTION = "apply_blend"
    CATEGORY = "image/adjustment"

    def apply_blend(self, base_image, blend_image, blend_mode, opacity, 
                    mask=None, mask_blur=0.0, fill=1.0):

        device = base_image.device

        if base_image.shape != blend_image.shape:
            blend_image = F.interpolate(
                blend_image.permute(0, 3, 1, 2),
                size=(base_image.shape[1], base_image.shape[2]),
                mode='bilinear',
                align_corners=False
            ).permute(0, 2, 3, 1)

        if mask is not None:
            mask = self._process_mask(mask, mask_blur, device, base_image.shape)
        else:
            mask = torch.ones_like(base_image[..., :1])

        if fill < 1.0:
            blend_image = base_image + (blend_image - base_image) * fill

        result = self._blend(base_image, blend_image, blend_mode)
        result = base_image + (result - base_image) * mask * opacity

        return (torch.clamp(result, 0, 1),)

    def _process_mask(self, mask, blur, device, target_shape):
        if mask.dim() == 2:
            mask = mask.unsqueeze(0).unsqueeze(-1)
        elif mask.dim() == 3:
            mask = mask.unsqueeze(-1)

        if mask.shape[1:3] != target_shape[1:3]:
            mask = F.interpolate(
                mask.permute(0, 3, 1, 2),
                size=(target_shape[1], target_shape[2]),
                mode='bilinear',
                align_corners=False
            ).permute(0, 2, 3, 1)

        mask = mask.to(device)

        if blur > 0:
            kernel_size = int(blur * 2) | 1
            if kernel_size < 3:
                kernel_size = 3
            mask = mask.permute(0, 3, 1, 2)
            mask = F.gaussian_blur(mask, kernel_size, sigma=blur)
            mask = mask.permute(0, 2, 3, 1)

        return mask

    def _blend(self, base, blend, mode):
        if mode == "normal":
            return blend
        elif mode == "multiply":
            return base * blend
        elif mode == "screen":
            return 1 - (1 - base) * (1 - blend)
        elif mode == "overlay":
            mask_dark = base < 0.5
            return torch.where(mask_dark, 
                              2 * base * blend,
                              1 - 2 * (1 - base) * (1 - blend))
        elif mode == "soft_light":
            mask_dark = blend < 0.5
            dark = 2 * base * blend + base ** 2 * (1 - 2 * blend)
            light = 2 * base * (1 - blend) + torch.sqrt(base.clamp(min=1e-6)) * (2 * blend - 1)
            return torch.where(mask_dark, dark, light)
        elif mode == "hard_light":
            mask_dark = blend < 0.5
            return torch.where(mask_dark,
                              2 * base * blend,
                              1 - 2 * (1 - base) * (1 - blend))
        elif mode == "vivid_light":
            mask_dark = blend < 0.5
            burn = 1 - (1 - base) / (2 * blend + 1e-6)
            dodge = base / (2 * (1 - blend) + 1e-6)
            return torch.where(mask_dark, burn, dodge)
        elif mode == "linear_light":
            return base + 2 * blend - 1
        elif mode == "pin_light":
            mask_dark = blend < 0.5
            dark = torch.minimum(base, 2 * blend)
            light = torch.maximum(base, 2 * blend - 1)
            return torch.where(mask_dark, dark, light)
        elif mode == "hard_mix":
            return (base + blend >= 1.0).float()
        elif mode == "color_dodge":
            return base / (1 - blend + 1e-6)
        elif mode == "color_burn":
            return 1 - (1 - base) / (blend + 1e-6)
        elif mode == "darken":
            return torch.minimum(base, blend)
        elif mode == "lighten":
            return torch.maximum(base, blend)
        elif mode == "difference":
            return torch.abs(base - blend)
        elif mode == "exclusion":
            return base + blend - 2 * base * blend
        elif mode == "subtract":
            return base - blend
        elif mode == "divide":
            return base / (blend + 1e-6)
        elif mode in ["hue", "saturation", "color", "luminosity"]:
            return self._hsl_blend(base, blend, mode)
        return blend

    def _hsl_blend(self, base, blend, mode):
        base_hsl = self._rgb_to_hsl(base)
        blend_hsl = self._rgb_to_hsl(blend)

        if mode == "hue":
            result = torch.stack([blend_hsl[..., 0], base_hsl[..., 1], base_hsl[..., 2]], dim=-1)
        elif mode == "saturation":
            result = torch.stack([base_hsl[..., 0], blend_hsl[..., 1], base_hsl[..., 2]], dim=-1)
        elif mode == "color":
            result = torch.stack([blend_hsl[..., 0], blend_hsl[..., 1], base_hsl[..., 2]], dim=-1)
        elif mode == "luminosity":
            result = torch.stack([base_hsl[..., 0], base_hsl[..., 1], blend_hsl[..., 2]], dim=-1)
        else:
            return blend

        return self._hsl_to_rgb(result)

    def _rgb_to_hsl(self, rgb):
        r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
        maxc = torch.max(torch.max(r, g), b)
        minc = torch.min(torch.min(r, g), b)
        l = (maxc + minc) / 2

        delta = maxc - minc
        s = torch.where(l > 0.5, 
                       delta / (2 - maxc - minc + 1e-6), 
                       delta / (maxc + minc + 1e-6))
        s = torch.where(delta == 0, torch.zeros_like(s), s)

        h = torch.zeros_like(r)
        h = torch.where(delta != 0, 
                       torch.where(maxc == r, ((g - b) / (delta + 1e-6)) % 6, h), h)
        h = torch.where(delta != 0, 
                       torch.where(maxc == g, ((b - r) / (delta + 1e-6)) + 2, h), h)
        h = torch.where(delta != 0, 
                       torch.where(maxc == b, ((r - g) / (delta + 1e-6)) + 4, h), h)
        h = h / 6

        return torch.stack([h, s, l], dim=-1)

    def _hsl_to_rgb(self, hsl):
        h, s, l = hsl[..., 0], hsl[..., 1], hsl[..., 2]

        def hue_to_rgb(p, q, t):
            t = t % 1.0
            return torch.where(t < 1/6, p + (q - p) * 6 * t,
                   torch.where(t < 1/2, q,
                   torch.where(t < 2/3, p + (q - p) * (2/3 - t) * 6, p)))

        q = torch.where(l < 0.5, l * (1 + s), l + s - l * s)
        p = 2 * l - q

        r = hue_to_rgb(p, q, h + 1/3)
        g = hue_to_rgb(p, q, h)
        b = hue_to_rgb(p, q, h - 1/3)

        rgb = torch.stack([r, g, b], dim=-1)
        gray = l.unsqueeze(-1).expand_as(rgb)
        rgb = torch.where(s.unsqueeze(-1) == 0, gray, rgb)

        return torch.clamp(rgb, 0, 1)


BlendMode = BlendModeNode
