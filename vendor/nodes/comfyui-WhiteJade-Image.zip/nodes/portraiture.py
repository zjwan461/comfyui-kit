"""
肤色平滑节点 - v7.0

按用户要求精简：
1. 节点名称改为"肤色平滑"
2. 去除原图输入端口
3. 去除肤色保护功能
4. 磨皮蒙版 → 平滑蒙版
5. 磨皮强度 → 平滑强度，默认0.3
6. 处理模式默认多次精细
7. 清晰度补偿默认0.2
8. 饱和度补偿默认0.1
"""

import torch
import torch.nn.functional as F


class SkinSmoothingNode:
    """
    肤色平滑 - 精简版
    """

    CATEGORY = "image/frequency_separation"
    FUNCTION = "skin_smoothing"
    RETURN_TYPES = ("IMAGE", "IMAGE", "IMAGE", "IMAGE")
    RETURN_NAMES = ("平滑低频", "平滑蒙版", "暗部保护", "亮部保护")

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "低频层": ("IMAGE",),
                "平滑强度": ("FLOAT", {
                    "default": 0.3,
                    "min": 0.0,
                    "max": 2.0,
                    "step": 0.01,
                    "display": "slider",
                    "tooltip": "低频层平滑强度，建议0.2-0.6"
                }),
            },
            "optional": {
                "边缘保护": ("FLOAT", {
                    "default": 0.85,
                    "min": 0.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "tooltip": "保护五官轮廓，越高越保留边缘"
                }),
                "明暗保护": ("BOOLEAN", {
                    "default": True,
                    "tooltip": "保护暗部（眼眉/鼻影）和亮部（高光）细节"
                }),
                "暗部保护强度": ("FLOAT", {
                    "default": 0.5,
                    "min": 0.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "tooltip": "暗部区域原图混合比例"
                }),
                "亮部保护强度": ("FLOAT", {
                    "default": 0.4,
                    "min": 0.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "tooltip": "亮部区域原图混合比例"
                }),
                "处理模式": (["单次快速", "多次精细"], {
                    "default": "多次精细",
                    "tooltip": "单次=速度快，多次=效果更好但慢"
                }),
                "大图优化": ("BOOLEAN", {
                    "default": True,
                    "tooltip": "启用FFT频域滤波，适合单反大图"
                }),
                "清晰度补偿": ("FLOAT", {
                    "default": 0.2,
                    "min": -1.0,
                    "max": 1.0,
                    "step": 0.01,
                    "display": "slider",
                    "tooltip": "Camera Raw风格清晰度，正值增强局部对比"
                }),
                "饱和度补偿": ("FLOAT", {
                    "default": 0.1,
                    "min": -0.5,
                    "max": 0.5,
                    "step": 0.01,
                    "display": "slider",
                    "tooltip": "磨皮后肤色可能发灰，适当提升饱和度"
                }),
            }
        }

    def skin_smoothing(self, 低频层, 平滑强度,
                      边缘保护=0.85,
                      明暗保护=True,
                      暗部保护强度=0.5, 亮部保护强度=0.4,
                      处理模式="多次精细", 大图优化=True,
                      清晰度补偿=0.2, 饱和度补偿=0.1,
                      **kwargs):
        """主处理函数"""

        if 平滑强度 <= 0 and 清晰度补偿 == 0 and 饱和度补偿 == 0:
            mask = torch.zeros_like(低频层[:, :, :, 0:1])
            empty = torch.zeros_like(低频层)
            return (低频层, mask.repeat(1, 1, 1, 3), empty, empty)

        # 预处理 [B,H,W,C] -> [B,C,H,W]
        x = 低频层.permute(0, 3, 1, 2)
        b, c, h, w = x.shape
        device = x.device

        if not x.is_cuda:
            x = x.cuda()
            device = x.device

        # 1. 保边平滑
        iterations = 2 if 处理模式 == "多次精细" else 1

        if 平滑强度 > 0:
            if 大图优化:
                smoothed = self._fft_edge_preserving_smooth(x, 平滑强度, 边缘保护, iterations)
            else:
                smoothed = self._spatial_edge_preserving_smooth(x, 平滑强度, 边缘保护, iterations)
        else:
            smoothed = x.clone()

        # 2. 明暗关系保护
        dark_restore = None
        bright_restore = None
        if 明暗保护 and 平滑强度 > 0:
            smoothed, dark_restore, bright_restore = self._tonal_protection(
                x, smoothed,
                暗部保护强度, 亮部保护强度
            )

        # 3. 清晰度补偿
        if abs(清晰度补偿) > 0.01:
            smoothed = self._clarity_adjust(smoothed, 清晰度补偿)

        # 4. 饱和度补偿
        if abs(饱和度补偿) > 0.01:
            smoothed = self._saturation_adjust(smoothed, 饱和度补偿)

        # 5. 计算平滑蒙版
        if 平滑强度 > 0:
            blend_mask = torch.abs(smoothed - x).mean(dim=1, keepdim=True)
            blend_mask = (blend_mask / (blend_mask.max() + 1e-8)).clamp(0, 1)
        else:
            blend_mask = torch.zeros_like(x[:, 0:1, :, :])

        # 6. 输出格式化
        smoothed_out = smoothed.permute(0, 2, 3, 1)
        mask_out = blend_mask.permute(0, 2, 3, 1).repeat(1, 1, 1, 3)

        dark_out = dark_restore.permute(0, 2, 3, 1).repeat(1, 1, 1, 3) if dark_restore is not None else torch.zeros_like(smoothed_out)
        bright_out = bright_restore.permute(0, 2, 3, 1).repeat(1, 1, 1, 3) if bright_restore is not None else torch.zeros_like(smoothed_out)

        return (smoothed_out, mask_out, dark_out, bright_out)

    def _fft_edge_preserving_smooth(self, image, strength, edge_protect, iterations=1):
        """FFT频域保边平滑"""
        result = image

        for i in range(iterations):
            iter_strength = strength * (1.0 - i * 0.25)
            if iter_strength <= 0:
                break

            b, c, h, w = result.shape
            blur_radius = max(15, min(h, w) // (20 + i * 8))

            mean_local = self._fft_lowpass_multi_channel(result, blur_radius)
            mean_sq = self._fft_lowpass_multi_channel(result ** 2, blur_radius)
            variance = mean_sq - mean_local ** 2
            edge_strength = variance / (variance.max() + 1e-8)

            base_weight = (1.0 - edge_strength) * iter_strength
            protect = edge_protect * edge_strength
            smooth_weight = base_weight * (1.0 - protect)
            max_weight = min(iter_strength * 0.9, 1.0)
            smooth_weight = smooth_weight.clamp(0, max_weight)

            result = result * (1.0 - smooth_weight) + mean_local * smooth_weight
            result = torch.clamp(result, 0, 1)

        return result

    def _fft_lowpass_multi_channel(self, image, radius):
        """多通道FFT低通滤波"""
        b, c, h, w = image.shape
        img_flat = image.view(b * c, 1, h, w)

        fft_img = torch.fft.fft2(img_flat)
        fft_img = torch.fft.fftshift(fft_img, dim=(-2, -1))

        y = torch.arange(h, device=image.device, dtype=torch.float32)
        x_axis = torch.arange(w, device=image.device, dtype=torch.float32)
        yy, xx = torch.meshgrid(y, x_axis, indexing="ij")
        cy, cx = h // 2, w // 2

        distance = torch.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)
        cutoff = max(1.0, min(h, w) / (radius * 2.0))
        mask = torch.exp(-(distance ** 2) / (2 * cutoff ** 2))
        mask = mask.view(1, 1, h, w)

        fft_filtered = fft_img * mask
        fft_filtered = torch.fft.ifftshift(fft_filtered, dim=(-2, -1))
        filtered = torch.fft.ifft2(fft_filtered).real

        return filtered.view(b, c, h, w)

    def _spatial_edge_preserving_smooth(self, image, strength, edge_protect, iterations=1):
        """空域保边平滑"""
        result = image
        _, c, h, w = image.shape

        for i in range(iterations):
            iter_strength = strength * (1.0 - i * 0.25)
            if iter_strength <= 0:
                break

            base_window = max(5, min(h, w) // (15 + i * 5))
            if base_window % 2 == 0:
                base_window += 1
            padding = base_window // 2

            padded = F.pad(result, (padding, padding, padding, padding), mode="reflect")
            mean_local = F.avg_pool2d(padded, kernel_size=base_window, stride=1)
            mean_sq = F.avg_pool2d(padded ** 2, kernel_size=base_window, stride=1)
            variance = mean_sq - mean_local ** 2
            edge_strength = variance / (variance.max() + 1e-8)

            base_weight = (1.0 - edge_strength) * iter_strength
            protect = edge_protect * edge_strength
            smooth_weight = base_weight * (1.0 - protect)
            max_weight = min(iter_strength * 0.9, 1.0)
            smooth_weight = smooth_weight.clamp(0, max_weight)

            result = result * (1.0 - smooth_weight) + mean_local * smooth_weight
            result = torch.clamp(result, 0, 1)

        return result

    def _tonal_protection(self, original, smoothed, dark_strength, bright_strength):
        """明暗关系保护 - 主动区域保护"""
        lum_orig = original.mean(dim=1, keepdim=True)

        b = lum_orig.size(0)
        lum_flat = lum_orig.view(b, -1)
        median_val = torch.median(lum_flat, dim=1)[0].view(b, 1, 1, 1)

        dark_degree = torch.clamp((median_val - lum_orig) / (median_val + 1e-6), 0, 1)
        dark_mask = dark_degree * dark_strength

        bright_degree = torch.clamp((lum_orig - median_val) / (1.0 - median_val + 1e-6), 0, 1)
        bright_mask = bright_degree * bright_strength

        after_dark = smoothed * (1.0 - dark_mask) + original * dark_mask
        after_dark = torch.clamp(after_dark, 0, 1)

        after_bright = after_dark * (1.0 - bright_mask) + original * bright_mask
        after_bright = torch.clamp(after_bright, 0, 1)

        return after_bright, dark_mask, bright_mask

    def _clarity_adjust(self, image, amount):
        """清晰度补偿"""
        if abs(amount) < 0.01:
            return image

        b, c, h, w = image.shape
        blur_r = max(3, min(h, w) // 100)
        if blur_r % 2 == 0:
            blur_r += 1

        blurred = self._fft_lowpass_multi_channel(image, blur_r)
        detail = image - blurred
        detail_enhanced = torch.tanh(detail * (1.0 + amount * 3.0))

        result = blurred + detail_enhanced
        return torch.clamp(result, 0, 1)

    def _saturation_adjust(self, image, amount):
        """饱和度补偿"""
        if abs(amount) < 0.01:
            return image

        r, g, b = image[:, 0:1], image[:, 1:2], image[:, 2:3]
        gray = 0.299*r + 0.587*g + 0.114*b

        saturation_factor = 1.0 + amount
        result = gray + (image - gray) * saturation_factor

        return torch.clamp(result, 0, 1)


Portraiture = SkinSmoothingNode