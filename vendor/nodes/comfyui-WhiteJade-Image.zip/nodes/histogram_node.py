"""
直方图显示节点 v6.0 - 多通道独立输出

取消前端通道选择，固定输出 RGB+亮度预览
增加独立输出端口：明度、红、绿、蓝、RGB
"""

import torch


class HistogramNode:
    """
    直方图显示 - 多通道独立输出

    输出端口：
    - 直方图: RGB+亮度叠加预览图
    - 统计信息: 文本统计
    - 明度: 亮度通道直方图图像
    - 红通道: R通道直方图图像
    - 绿通道: G通道直方图图像
    - 蓝通道: B通道直方图图像
    - RGB: RGB三通道叠加直方图图像
    """

    CATEGORY = "image/analysis"
    FUNCTION = "show_histogram"
    RETURN_TYPES = ("IMAGE", "STRING", "IMAGE", "IMAGE", "IMAGE", "IMAGE", "IMAGE")
    RETURN_NAMES = ("直方图", "统计信息", "明度", "红通道", "绿通道", "蓝通道", "RGB")
    OUTPUT_NODE = True

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "图像": ("IMAGE",),
            },
            "optional": {
                "显示网格": ("BOOLEAN", {
                    "default": True,
                    "tooltip": "显示参考网格线"
                }),
            }
        }

    def show_histogram(self, 图像, 显示网格=True, **kwargs):
        """生成直方图数据和图像"""

        x = 图像
        b, h, w, c = x.shape
        device = x.device

        if not x.is_cuda:
            x = x.cuda()
            device = x.device

        # 计算各通道直方图
        bins = 256

        r = x[:, :, :, 0].flatten(start_dim=1)
        g = x[:, :, :, 1].flatten(start_dim=1)
        b_ch = x[:, :, :, 2].flatten(start_dim=1)
        lum = (0.299*r + 0.587*g + 0.114*b_ch)

        hist_r = self._compute_hist(r, bins, device)
        hist_g = self._compute_hist(g, bins, device)
        hist_b = self._compute_hist(b_ch, bins, device)
        hist_lum = self._compute_hist(lum, bins, device)

        # 归一化
        hist_r = hist_r / (hist_r.max(dim=1, keepdim=True)[0] + 1e-8)
        hist_g = hist_g / (hist_g.max(dim=1, keepdim=True)[0] + 1e-8)
        hist_b = hist_b / (hist_b.max(dim=1, keepdim=True)[0] + 1e-8)
        hist_lum = hist_lum / (hist_lum.max(dim=1, keepdim=True)[0] + 1e-8)

        stats = self._compute_stats(x, lum)

        # 颜色配置
        color_r = torch.tensor([1.0, 0.2, 0.2], device=device)
        color_g = torch.tensor([0.2, 1.0, 0.2], device=device)
        color_b = torch.tensor([0.2, 0.4, 1.0], device=device)
        color_lum = torch.tensor([0.9, 0.9, 0.9], device=device)

        # 生成各通道独立直方图图像
        img_lum = self._draw_histogram([hist_lum], [color_lum], 显示网格, device)
        img_r = self._draw_histogram([hist_r], [color_r], 显示网格, device)
        img_g = self._draw_histogram([hist_g], [color_g], 显示网格, device)
        img_b = self._draw_histogram([hist_b], [color_b], 显示网格, device)
        img_rgb = self._draw_histogram(
            [hist_r, hist_g, hist_b], 
            [color_r, color_g, color_b], 
            显示网格, device
        )

        # 生成 RGB+亮度 叠加预览图（主输出）
        img_main = self._draw_histogram(
            [hist_r, hist_g, hist_b, hist_lum],
            [color_r, color_g, color_b, color_lum],
            显示网格, device
        )

        # 准备前端显示数据（取第一个批次的数据）
        ui_data = {
            "r": hist_r[0].cpu().numpy().tolist(),
            "g": hist_g[0].cpu().numpy().tolist(),
            "b": hist_b[0].cpu().numpy().tolist(),
            "lum": hist_lum[0].cpu().numpy().tolist(),
            "channelMode": "RGB+亮度",
            "showGrid": 显示网格,
            "stats": stats,
        }

        return {
            "ui": {"histogram_data": ui_data},
            "result": (img_main, stats, img_lum, img_r, img_g, img_b, img_rgb),
        }

    def _compute_hist(self, values, bins, device):
        """计算直方图 [B, bins]"""
        b = values.size(0)
        hist = torch.zeros(b, bins, device=device)
        values_int = (values * 255).long().clamp(0, 255)

        for i in range(b):
            for j in range(bins):
                hist[i, j] = (values_int[i] == j).float().sum()

        return hist

    def _draw_histogram(self, channels_to_draw, colors, show_grid, device):
        """绘制直方图图像 [B, 256, 512, 3]"""
        b = channels_to_draw[0].size(0)
        hist_h = 256
        hist_w = 512

        result = torch.zeros(b, hist_h, hist_w, 3, device=device)

        for hist, color in zip(channels_to_draw, colors):
            for i in range(b):
                for x_pos in range(hist_w):
                    bin_idx = int(x_pos / hist_w * 255)
                    bin_idx = min(bin_idx, 255)
                    height = int(hist[i, bin_idx].item() * hist_h)
                    height = min(height, hist_h)

                    if height > 0:
                        y_start = hist_h - height
                        y_end = hist_h
                        alpha = 0.7 if len(channels_to_draw) > 1 else 0.9
                        result[i, y_start:y_end, x_pos, :] = \
                            result[i, y_start:y_end, x_pos, :] * (1 - alpha) + color * alpha

        if show_grid:
            grid_color = torch.tensor([0.25, 0.25, 0.25], device=device)
            for pct in [0.25, 0.5, 0.75]:
                x_line = int(pct * hist_w)
                result[:, :, x_line, :] = grid_color
                y_line = int(pct * hist_h)
                result[:, y_line, :, :] = grid_color

        return result

    def _compute_stats(self, image, lum):
        """计算统计信息"""
        b = image.size(0)
        stats_list = []

        for i in range(b):
            lum_i = lum[i]

            mean_lum = lum_i.mean().item()
            median_lum = lum_i.median().item()
            std_lum = lum_i.std().item()
            min_lum = lum_i.min().item()
            max_lum = lum_i.max().item()

            dark_pct = (lum_i < 0.35).float().mean().item() * 100
            bright_pct = (lum_i > 0.65).float().mean().item() * 100
            contrast = max_lum - min_lum

            stats = (
                f"批次{i+1}: "
                f"平均亮度={mean_lum:.3f}, "
                f"中位数={median_lum:.3f}, "
                f"标准差={std_lum:.3f}, "
                f"范围=[{min_lum:.3f}-{max_lum:.3f}], "
                f"对比度={contrast:.3f}, "
                f"暗部(<0.35)={dark_pct:.1f}%, "
                f"亮部(>0.65)={bright_pct:.1f}%"
            )
            stats_list.append(stats)

        return "\n".join(stats_list)


Histogram = HistogramNode