"""
核心滤波算法 - 纯PyTorch实现，无外部依赖
"""

import torch
import torch.nn.functional as F


def create_gaussian_kernel(kernel_size, sigma, channels, device):
    """
    创建2D高斯核

    Args:
        kernel_size: 核大小（奇数）
        sigma: 标准差
        channels: 通道数
        device: 计算设备

    Returns:
        kernel: [channels, 1, kernel_size, kernel_size]
    """
    # 确保奇数
    size = kernel_size + 1 if kernel_size % 2 == 0 else kernel_size

    # 1D高斯分布
    x = torch.arange(size, dtype=torch.float32, device=device) - size // 2
    gaussian_1d = torch.exp(-x.pow(2) / (2 * sigma ** 2))
    gaussian_1d = gaussian_1d / gaussian_1d.sum()

    # 2D高斯核（外积）
    gaussian_2d = gaussian_1d.unsqueeze(0) * gaussian_1d.unsqueeze(1)

    # 扩展到多通道
    kernel = gaussian_2d.unsqueeze(0).unsqueeze(0).repeat(channels, 1, 1, 1)

    return kernel


def apply_gaussian_blur(image, kernel_size, sigma):
    """
    应用高斯模糊

    Args:
        image: [B, C, H, W] 或 [C, H, W]，值范围[0, 1]
        kernel_size: 模糊核大小
        sigma: 标准差

    Returns:
        模糊后的图像，维度与输入相同
    """
    # 处理输入维度
    squeeze_batch = False

    if image.dim() == 3:  # [C, H, W]
        image = image.unsqueeze(0)
        squeeze_batch = True

    batch, channels, height, width = image.shape
    device = image.device

    # 创建核
    kernel = create_gaussian_kernel(kernel_size, sigma, channels, device)

    # 反射填充
    padding = kernel_size // 2
    image_padded = F.pad(image, (padding, padding, padding, padding), mode='reflect')

    # 分组卷积（每通道独立）
    blurred = F.conv2d(image_padded, kernel, groups=channels)

    # 恢复维度
    if squeeze_batch:
        blurred = blurred.squeeze(0)

    return blurred


def frequency_separation(image, kernel_size=30, sigma=None):
    """
    基础高低频分离

    Args:
        image: [B, C, H, W] tensor
        kernel_size: 模糊核大小
        sigma: 标准差，None则自动计算(kernel_size/6)

    Returns:
        low_freq: 低频层
        high_freq: 高频层（有正有负，未加中性灰偏移）
    """
    if sigma is None:
        sigma = kernel_size / 6.0

    low_freq = apply_gaussian_blur(image, kernel_size, sigma)
    high_freq = image - low_freq  # 纯差值，无偏移

    return low_freq, high_freq