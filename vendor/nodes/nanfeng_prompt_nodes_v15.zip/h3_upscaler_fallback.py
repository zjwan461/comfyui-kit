"""本机没有官方 H3LatentUpscalerNodeMegapixels 时，复用已装的 MiniMax H3 3D 放大器。"""
from __future__ import annotations

import math
import types

import torch
import comfy.nested_tensor


_PRECISION_MAP = {
    "fp16": torch.float16,
    "bf16": torch.bfloat16,
    "fp32": torch.float32,
}


def _load_upstream():
    import importlib.util
    import sys
    from pathlib import Path

    for module in sys.modules.values():
        if getattr(module, "__file__", "") and str(getattr(module, "__file__", "")).endswith(
            "minimax_h3_latent_upscaler_3d.py"
        ) and hasattr(module, "load_model"):
            return module

    path = (
        Path(__file__).resolve().parents[1]
        / "Comfyui_Minimax_h3_latent_Upscaler"
        / "nodes"
        / "minimax_h3_latent_upscaler_3d.py"
    )
    if not path.is_file():
        raise ImportError(f"未找到 MiniMax H3 3D 放大器：{path}")
    spec = importlib.util.spec_from_file_location("nanfeng_h3_upscaler_upstream", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _align_latent_to_grid(width_pixels, height_pixels, align):
    """像素目标转 latent 尺寸，并按 align 向上取整（与南风 V8 注释一致）。"""
    align = max(1, int(align))
    latent_w = int(math.ceil((float(width_pixels) / 16.0) / align) * align)
    latent_h = int(math.ceil((float(height_pixels) / 16.0) / align) * align)
    return max(align, latent_w), max(align, latent_h)


def run_upscale(video_latent, audio_latent, model_name, device, precision, target_width, target_height, target_scale):
    up = _load_upstream()
    src = video_latent["samples"]
    orig_dtype = src.dtype
    was_4d = src.dim() == 4
    dev = torch.device("cuda") if str(device) == "cuda" else torch.device(device)
    compute_dtype = _PRECISION_MAP.get(str(precision), torch.float16)
    if compute_dtype == torch.float32:
        raise ValueError("V8.1潜空间放大只允许fp16或bf16，禁止FP32造成显存峰值。")

    s = src.to(device=dev, dtype=compute_dtype, copy=True)
    if was_4d:
        s = s.unsqueeze(2)
    _batch, _channels, frames, height_in, width_in = s.shape
    target_width = int(target_width)
    target_height = int(target_height)
    if target_width < width_in or target_height < height_in:
        raise ValueError("target_megapixels 不能小于当前latent对应的总像素数")

    model = up.load_model(model_name, dev, precision)
    conv_in = getattr(model, "conv_in", None)
    in_channels = getattr(conv_in, "in_channels", 24)
    if int(in_channels) != 24:
        raise ValueError(
            f"二采放大器 {model_name} 不是 MiniMax H3 24通道 3D 权重（in_channels={in_channels}）。"
            "请改用 minimax_h3_latent_upscaler_3d_bf16.safetensors 或 fp16。"
        )

    norm_mean, norm_std = up._make_norm_tensors(dev, compute_dtype)
    with torch.inference_mode():
        normalized = (s - norm_mean) / norm_std
        del s
        out = model(
            normalized,
            scale=float(target_scale),
            target_size=(frames, target_height, target_width),
            enable_chunking=True,
        )
        del normalized
        out = out * norm_std + norm_mean
    if was_4d:
        out = out.squeeze(2)
    out = out.to(device="cpu", dtype=orig_dtype)

    merged = dict(video_latent)
    merged.update(audio_latent)
    merged["samples"] = comfy.nested_tensor.NestedTensor((out, audio_latent["samples"]))
    return merged


def get_common():
    up = _load_upstream()
    return types.SimpleNamespace(
        MODEL_CACHE=up.MODEL_CACHE,
        get_models_dir=up.get_models_dir,
        _load_raw_sd=up._load_raw_sd,
        _extract_upscaler_sd=up._extract_upscaler_sd,
        _detect_arch=up._detect_arch,
        LatentResizer3D=up.LatentResizer3D,
        _PRECISION_MAP=_PRECISION_MAP,
        _align_latent_to_grid=_align_latent_to_grid,
        run_upscale=run_upscale,
    )
