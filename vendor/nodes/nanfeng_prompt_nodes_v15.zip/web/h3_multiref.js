import { migrateV15WorkflowInfo } from "./workflow_schema_migration.mjs";
import { app } from "../../../scripts/app.js";
import { api } from "../../../scripts/api.js";
import { makeOwnerGuard, ownedBatches, rememberBatch, ownsActiveNode, stampOwner, installOwnedPreviewRouting } from "./workflow_isolation.mjs";
const ownsPreview = installOwnedPreviewRouting(app, api);
import { createSmartAssetDraft } from "./smart_asset_draft.mjs";
import { createImageParticipation, participationBrief, routeParticipatingSegments, imageParticipationControl } from "./smart_image_participation.mjs";
import { mountXiaoqing } from './skin_xiaoqing.mjs';
import { mountSkinController, mountSkinCatalog, attachSkinOverlay, applySkinChrome, skinCanvasColors } from './skin_menghui.mjs';
import { planContinuation, applyContinuationJob, installCurrentGroupQueue, batchRequest, submitContinuation } from "./latent_continuation.mjs";
const readJsonResponse = async response => {
  const text = await response.text();
  if (!text.trim()) throw new Error(`服务正在重启或返回了空响应（HTTP ${response.status}），请稍后重试。`);
  try {
    return JSON.parse(text);
  } catch (error) {
    throw new Error(`服务返回的不是有效JSON（HTTP ${response.status}）：${text.slice(0, 160)}`);
  }
};
const LIVE_MODEL_WIDGETS = new Set(["模型", "文本编码器", "视频VAE", "音频VAE", "H3潜空间放大模型"]);
const TARGETS = new Set(["NanFengH3MultiReferenceGeneratorV15"]);
const V7_BACKGROUND_URL = new URL("./assets/v7-dark-iridescent-bg.webp", import.meta.url).href;
// V11 uses the supplied artwork at its natural ratio, anchored from the left.
// Any uncovered space on the right remains the node's black background.
const V9_BACKGROUND_URL = new URL("./assets/v11-new-character-bg-left.webp", import.meta.url).href;
const CURVE_LABELS = {
  linear: "线性",
  cosine: "余弦",
  sine: "正弦"
};
const formatAudioDriveTime = value => {
  const seconds = Math.max(0, Number(value) || 0),
    minutes = Math.floor(seconds / 60);
  return `${minutes}:${String((seconds - minutes * 60).toFixed(2)).padStart(5, "0")}`;
};
const LIMITS = {
  图片: 9,
  视频: 3,
  音频: 3
};
const STORYBOARD_STORAGE_KEY = "nanfeng_h3_storyboards_v1";
const NANFENG_SMART_SKILL_STORAGE_KEY = "nanfeng_h3_v15_smart_storyboard_skill_v1";
const NANFENG_SMART_MODE_STORAGE_KEY = "nanfeng_h3_v15_smart_mode_v1";
const NANFENG_V10_LORA_STORAGE_KEY = "nanfeng_h3_v15_lora_state_v1";
const NANFENG_TAEH3_STORAGE_KEY = "nanfeng_h3_v15_taeh3_preview_v1";
function savePersistedTaeh3Preview(node) {
  node.properties ||= {};
  node.properties.nanfeng_taeh3_preview = widget(node, "启用TAEH3彩色预览")?.value === true;
  node.graph?.change?.();
  node.setDirtyCanvas?.(true, true);
}
function restorePersistedTaeh3Preview(node) {
  const w = widget(node, "启用TAEH3彩色预览");
  if (!w) return false;
  node.properties ||= {};
  node.properties.nanfeng_taeh3_preview = w.value === true;
  node.__nfh3UpdatePreviewControls?.();
  return false;
}
const workflowStorageScope = node => {
  const graph = node?.graph || app?.graph;
  if (!graph) return "no-graph";
  graph.extra ||= {};
  if (!graph.extra.nanfeng_storyboard_scope) {
    graph.extra.nanfeng_storyboard_scope = globalThis.crypto?.randomUUID?.() || `scope-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    graph.change?.();
  }
  return String(graph.extra.nanfeng_storyboard_scope);
};
const storyboardStorageKey = node => `${STORYBOARD_STORAGE_KEY}:${workflowStorageScope(node)}:${node.id}`;
const legacyNodeStoryboardStorageKey = node => `${STORYBOARD_STORAGE_KEY}:${node.id}`;
function parseStoryboardBackup(raw) {
  try {
    const data = JSON.parse(raw || "");
    return Array.isArray(data?.shots) && data.shots.length ? data : null;
  } catch {
    return null;
  }
}
// Workflow JSON is the sole restoration authority. Legacy backups are preserved,
// but never read automatically: copied workflow scopes/IDs are not unique tabs.
function loadPersistedStoryboards(node, allowLegacyRecovery = false) {
  return null;
}
function savePersistedStoryboards(node, shots, activeShot) {
  try {
    localStorage.setItem(storyboardStorageKey(node), JSON.stringify({
      shots,
      activeShot,
      updatedAt: Date.now()
    }));
  } catch {}
}
const AUDIO_DRIVE_WORKSPACE_FIELDS = ["音频驱动文件", "音频驱动打点", "音频驱动分段图片", "音频驱动分段分镜", "音频驱动创意", "音频驱动排除范围"];
const AUDIO_DRIVE_BACKUP_STORAGE_KEY = "nanfeng_h3_v15_audio_drive_backup_v1";
const audioDriveWorkspaceValue = (node, name, fallback) => {
  const saved = node?.properties?.nfh3_audio_drive_workspace;
  if (saved && Object.prototype.hasOwnProperty.call(saved, name)) return String(saved[name] ?? fallback);
  return String(widget(node, name)?.value ?? fallback);
};
const snapshotAudioDriveWorkspace = node => ({
  "音频驱动文件": String(widget(node, "音频驱动文件")?.value || ""),
  "音频驱动打点": String(widget(node, "音频驱动打点")?.value || "[]"),
  "音频驱动分段图片": String(widget(node, "音频驱动分段图片")?.value || "{}"),
  "音频驱动分段分镜": String(widget(node, "音频驱动分段分镜")?.value || "{}"),
  "音频驱动创意": String(widget(node, "音频驱动创意")?.value || ""),
  "音频驱动排除范围": String(widget(node, "音频驱动排除范围")?.value || "{}")
});
const parseAudioDriveCount = (value, fallback) => {
  try {
    const parsed = JSON.parse(String(value || fallback));
    return Array.isArray(parsed) ? parsed.length : parsed && typeof parsed === "object" ? Object.keys(parsed).length : 0;
  } catch {
    return 0;
  }
};
const scoreAudioDriveWorkspace = data => parseAudioDriveCount(data?.["音频驱动打点"], "[]") * 1000 + parseAudioDriveCount(data?.["音频驱动分段图片"], "{}") * 100 + parseAudioDriveCount(data?.["音频驱动分段分镜"], "{}");
const audioDriveBackupKey = node => `${AUDIO_DRIVE_BACKUP_STORAGE_KEY}:${String(widget(node, "音频驱动文件")?.value || node?.properties?.nfh3_audio_drive_workspace?.["音频驱动文件"] || "")}`;
const persistAudioDriveWorkspace = node => {
  if (!node) return;
  node.properties ||= {};
  const snapshot = snapshotAudioDriveWorkspace(node),
    previous = node.properties.nfh3_audio_drive_workspace;
  if (previous && typeof previous === "object" && scoreAudioDriveWorkspace(previous) > 0) {
    const history = Array.isArray(node.properties.nfh3_audio_drive_workspace_history) ? node.properties.nfh3_audio_drive_workspace_history : [];
    history.push({
      ...previous,
      savedAt: Date.now()
    });
    node.properties.nfh3_audio_drive_workspace_history = history.slice(-5);
  }
  node.properties.nfh3_audio_drive_workspace = snapshot;
  try {
    const key = audioDriveBackupKey(node),
      old = JSON.parse(localStorage.getItem(key) || "null");
    if (!old || scoreAudioDriveWorkspace(snapshot) >= scoreAudioDriveWorkspace(old)) localStorage.setItem(key, JSON.stringify({
      ...snapshot,
      savedAt: Date.now()
    }));
  } catch {}
  node.graph?.change?.();
  node.setDirtyCanvas?.(true, true);
};
const restoreAudioDriveWorkspace = node => {
  const saved = node?.properties?.nfh3_audio_drive_workspace;
  if (!saved || typeof saved !== "object") return false;
  node.__nfh3RestoringAudioDrive = true;
  try {
    for (const name of AUDIO_DRIVE_WORKSPACE_FIELDS) {
      if (Object.prototype.hasOwnProperty.call(saved, name)) setWidget(node, name, String(saved[name] ?? ""));
    }
  } finally {
    node.__nfh3RestoringAudioDrive = false;
  }
  return true;
};
// Do not hydrate another workflow's timeline merely because audio filenames match.
const restoreBestAudioDriveWorkspace = node => false;
const initializeAudioDriveMarkersFromTimedStoryboards = node => {
  node.properties ||= {};
  if (node.properties.nfh3_audio_drive_marker_authority === "internal-v2") return false;
  const audioFile = String(node.properties?.nfh3_audio_drive_workspace?.["音频驱动文件"] || widget(node, "音频驱动文件")?.value || "");
  const shots = (Array.isArray(node.properties.nanfeng_storyboards) ? node.properties.nanfeng_storyboards : []).filter(shot => shot?.audioDriveEnabled === true && (!audioFile || shot.audioDriveFilename === audioFile) && Number.isFinite(Number(shot.audioDriveStart)) && Number.isFinite(Number(shot.audioDriveEnd)) && Number(shot.audioDriveEnd) > Number(shot.audioDriveStart)).sort((a, b) => Number(a.audioDriveStart) - Number(b.audioDriveStart));
  node.properties.nfh3_audio_drive_marker_authority = "internal-v2";
  if (!shots.length) return false;
  const markers = [...new Set(shots.slice(0, -1).map(shot => Number(shot.audioDriveEnd)).filter(value => Number.isFinite(value) && value > 0))].sort((a, b) => a - b);
  const current = node.properties.nfh3_audio_drive_workspace && typeof node.properties.nfh3_audio_drive_workspace === "object" ? node.properties.nfh3_audio_drive_workspace : snapshotAudioDriveWorkspace(node);
  node.properties.nfh3_audio_drive_workspace = {
    ...current,
    "音频驱动打点": JSON.stringify(markers)
  };
  restoreAudioDriveWorkspace(node);
  node.graph?.change?.();
  node.setDirtyCanvas?.(true, true);
  return true;
};
const recoverAudioDriveWorkspaceFromStoryboards = node => {
  const audioFile = String(widget(node, "音频驱动文件")?.value || node?.properties?.nfh3_audio_drive_workspace?.["音频驱动文件"] || "");
  if (!audioFile) return false;
  const shots = Array.isArray(node?.properties?.nanfeng_storyboards) ? node.properties.nanfeng_storyboards : [],
    audioShots = shots.filter(shot => shot?.audioDriveEnabled === true && shot.audioDriveFilename === audioFile && Number.isFinite(Number(shot.audioDriveStart)) && Number.isFinite(Number(shot.audioDriveEnd))).sort((a, b) => Number(a.audioDriveStart) - Number(b.audioDriveStart));
  if (!audioShots.length) return false;
  const current = snapshotAudioDriveWorkspace(node);
  if (parseAudioDriveCount(current["音频驱动打点"], "[]") > 0) return false;
  const recoveredMarkers = [...new Set(audioShots.slice(0, -1).map(shot => Number(shot.audioDriveEnd)).filter(Number.isFinite))].sort((a, b) => a - b),
    recoveredImages = {},
    recoveredStoryboards = {};
  for (const shot of audioShots) {
    const key = `${Number(shot.audioDriveStart).toFixed(3)}-${Number(shot.audioDriveEnd).toFixed(3)}`;
    recoveredImages[key] = Array.isArray(shot.图片) ? shot.图片.filter(Boolean).slice(0, 9) : [];
    recoveredStoryboards[key] = {
      start: Number(shot.audioDriveStart),
      end: Number(shot.audioDriveEnd),
      duration: Number(shot.durationSeconds) || Math.max(1, Math.ceil(Number(shot.audioDriveEnd) - Number(shot.audioDriveStart))),
      text: String(shot.prompt || "")
    };
  }
  node.properties.nfh3_audio_drive_workspace = {
    ...current,
    "音频驱动打点": JSON.stringify(recoveredMarkers),
    "音频驱动分段图片": JSON.stringify(recoveredImages),
    "音频驱动分段分镜": JSON.stringify(recoveredStoryboards)
  };
  return restoreAudioDriveWorkspace(node);
};
function loadPersistedSmartSkill() {
  return "";
}
function savePersistedSmartSkill(skillId) {}
function loadPersistedSmartMode() {
  return "";
}
function savePersistedSmartMode(mode) {}
// Workflow widgets are the only LoRA authority. Never hydrate from global storage.
function loadPersistedLoraState() {
  return null;
}
function savePersistedLoraState(node) {
  if (!isV9(node) || node.__nfh3RestoringLora) return;
  node.graph?.change?.();
}
function restorePersistedLoraState(node) {
  if (!isV9(node)) return false;
  // Native configure has already restored serialized names, strengths and flags.
  // Empty or missing-on-disk selections must not be replaced or auto-enabled.
  node.properties ||= {};
  let highest = 0;
  for (let i = 1; i <= MAX_LORA_SLOTS; i++) {
    const value = widget(node, `LoRA${i}`)?.value;
    if (value && value !== "未选择") highest = i;
  }
  const count = Number(node.properties.nfh3_lora_slot_count);
  node.properties.nfh3_lora_slot_count = Math.min(MAX_LORA_SLOTS, Math.max(highest, Number.isInteger(count) ? count : 0, 0));
  node.__nfh3RebuildLoraRows?.();
  return false;
}
const ACCEPT = {
  图片: "image/png,image/jpeg,image/webp,image/bmp",
  视频: "video/mp4,video/webm,video/quicktime,video/x-matroska,video/x-msvideo",
  音频: "audio/mpeg,audio/wav,audio/flac,audio/x-wav"
};
const PANEL_FIELDS = [["模型", "生成模型", "select"], ["文本编码器", "文本编码器", "select"], ["视频VAE", "视频 VAE", "select"], ["音频VAE", "音频 VAE", "select"], ["画面比例", "画面比例", "select"], ["百万像素", "百万像素", "select"], ["尺寸倍数", "尺寸倍数", "select"], ["时长秒", "时长（秒）", "number"], ["随机种子", "随机种子", "number"], ["__固定随机种子", "固定随机种子", "seed-lock"], ["采样步数", "采样步数", "number"], ["__生成模式", "生成模式", "mode-switches"]];
const ADVANCED_FIELDS = [["文本编码器类型", "编码器类型", "select"], ["文本编码器设备", "编码器设备", "select"], ["模型权重精度", "模型权重精度", "select"], ["H3专用注意力", "注意力机制（通用Sage / H3专用）", "select"], ["启用H3 SLA", "启用 H3 SLA（与Sage互斥）", "boolean"], ["启用TAEH3彩色预览", "TAEH3彩色预览", "boolean"], ["SageAttention", "通用注意力补丁（旧版兼容）", "select"], ["允许编译", "允许 torch.compile", "boolean"], ["采样器", "采样器", "select"], ["调度器", "调度器", "select"], ["降噪强度", "降噪强度", "number"]];
const MAX_LORA_SLOTS = 8;
const V2_LORA_FIELDS = Array.from({
  length: MAX_LORA_SLOTS
}, (_, index) => {
  const i = index + 1;
  return [[`LoRA${i}启用`, `LoRA ${i} 启用`, "boolean"], [`LoRA${i}`, `LoRA ${i}`, "select"], [`LoRA${i}强度`, `LoRA ${i} 强度`, "number"]];
}).flat();
const LEGACY_LORA_MASTER_NAME = "启用" + "LoRA";
const V2_SOL_FIELDS = [["启用SolAttn", "启用 Sol-Attn", "boolean"], ["SolAttn_tau", "tau（速度 / 精度）", "number"], ["SolAttn阈值类型", "阈值类型", "select"], ["SolAttn精确模式", "精确模式", "select"], ["SolAttn完整末步", "完整末步数", "number"], ["SolAttn末段比例", "末段 Dense 比例", "number"], ["SolAttn前缀Token", "前缀 Token（0=自动）", "number"]];
const V3_T8_FIELDS = [["启用T8缓存", "启用 T8 Block Cache", "boolean"], ["T8残差阈值", "残差阈值", "number"], ["T8开始比例", "开始比例", "number"], ["T8结束比例", "结束比例", "number"], ["T8连续命中", "最大连续命中", "number"], ["T8缓存设备", "缓存设备", "select"], ["T8指标步幅", "指标步幅", "number"], ["T8详细日志", "详细日志", "boolean"]];
const V4_SIGMA_FIELDS = [["启用西格玛调节", "启用西格玛调节", "boolean"], ["视频西格玛偏移", "视频 Shift（默认12）", "number"], ["音频西格玛偏移", "音频 Shift（默认3）", "number"], ["西格玛模式", "调节模式", "select"], ["低西格玛开始", "低Sigma开始", "number"], ["低西格玛结束", "低Sigma结束", "number"], ["每区间细分", "每段增加步数", "number"], ["加密曲线", "加密曲线", "select"], ["手动西格玛", "手动Sigma序列", "text"], ["启用双采样", "启用双采样", "boolean"], ["双采后段比例", "后段占比", "number"], ["双采后段采样器", "后段采样器", "select"]];
const V5_SECOND_PASS_FIELDS = [["启用高清二采", "启用高清放大二采", "boolean"], ["二采模型", "二采模型（自动匹配Ref / FL）", "select"], ["一采步数", "一采步数", "number"], ["二采百万像素", "二采百万像素", "select"], ["二采放大方法", "二采放大方法", "select"], ["二采步数", "二采步数", "number"], ["二采采样器", "二采采样器", "select"], ["二采调度器", "二采调度器", "select"], ["二采起始Sigma", "二采起始 Sigma", "number"]];
const MP_16_9 = {
  0.2: "608×352",
  0.3: "736×416",
  0.4: "864×480",
  0.5: "960×544",
  0.6: "1056×608",
  0.7: "1152×640",
  0.8: "1216×672",
  0.9: "1280×736",
  0.98: "1344×768",
  1: "1376×768",
  1.2: "1504×832",
  1.5: "1664×928",
  1.8: "1824×1024",
  2: "1920×1088"
};
function widget(node, name) {
  return node.widgets?.find(w => w.name === name);
}
function promptInput(node) {
  return node.inputs?.find(input => input.name === "提示词" || input.widget?.name === "提示词");
}
function promptIsLinked(node) {
  const input = promptInput(node);
  return input?.link != null;
}
function choices(w) {
  return w?.options?.values || w?.options?.items || [];
}
function activeGenerationMode(node) {
  return ["文生视频", "图生视频", "首尾帧"].find(x => !!widget(node, x)?.value) || "";
}
function ratioChoicesForMode(node) {
  const vals = choices(widget(node, "画面比例"));
  const mode = activeGenerationMode(node);
  return mode === "图生视频" || mode === "首尾帧" ? vals : vals.filter(v => v !== "原图比例");
}
function setWidget(node, name, value) {
  if (node.__nfh3V15Disposed) return;
  const w = widget(node, name);
  if (!w) return;
  const changed = w.value !== value;
  if (typeof w.value === "number") value = Number(value);
  if (typeof w.value === "boolean") value = Boolean(value);
  w.value = value;
  w.callback?.(value);
  if (/^LoRA[1-8](?:启用|强度)?$/.test(name)) savePersistedLoraState(node);
  if (!node.__nfh3RestoringAudioDrive && AUDIO_DRIVE_WORKSPACE_FIELDS.includes(name)) persistAudioDriveWorkspace(node);
  node.__nfh3UpdateSigmaProfile?.();
  node.__nfh3UpdateSecondPass?.();
  node.__nfh3UpdateLatentUi?.();
  node.__nfh3UpdateAudioDrive?.();
  if (changed && !node.__nfh3V15Configuring) node.graph?.change?.();
  node.setDirtyCanvas(true, true);
}
function isV3(node) {
  return isV9(node) || ["NanFengH3MultiReferenceGeneratorV3", "NanFengH3MultiReferenceGeneratorV4", "NanFengH3MultiReferenceGeneratorV5", "NanFengH3MultiReferenceGeneratorV6", "NanFengH3MultiReferenceGeneratorV7", "NanFengH3MultiReferenceGeneratorV8", "NanFengH3MultiReferenceGeneratorV81"].includes(node.comfyClass) || ["NanFengH3MultiReferenceGeneratorV3", "NanFengH3MultiReferenceGeneratorV4", "NanFengH3MultiReferenceGeneratorV5", "NanFengH3MultiReferenceGeneratorV6", "NanFengH3MultiReferenceGeneratorV7", "NanFengH3MultiReferenceGeneratorV8", "NanFengH3MultiReferenceGeneratorV81"].includes(node.type);
}
function isV4(node) {
  return isV9(node) || ["NanFengH3MultiReferenceGeneratorV4", "NanFengH3MultiReferenceGeneratorV5", "NanFengH3MultiReferenceGeneratorV6", "NanFengH3MultiReferenceGeneratorV7", "NanFengH3MultiReferenceGeneratorV8", "NanFengH3MultiReferenceGeneratorV81"].includes(node.comfyClass) || ["NanFengH3MultiReferenceGeneratorV4", "NanFengH3MultiReferenceGeneratorV5", "NanFengH3MultiReferenceGeneratorV6", "NanFengH3MultiReferenceGeneratorV7", "NanFengH3MultiReferenceGeneratorV8", "NanFengH3MultiReferenceGeneratorV81"].includes(node.type);
}
function isV5(node) {
  return isV9(node) || ["NanFengH3MultiReferenceGeneratorV5", "NanFengH3MultiReferenceGeneratorV6", "NanFengH3MultiReferenceGeneratorV7", "NanFengH3MultiReferenceGeneratorV8", "NanFengH3MultiReferenceGeneratorV81"].includes(node.comfyClass) || ["NanFengH3MultiReferenceGeneratorV5", "NanFengH3MultiReferenceGeneratorV6", "NanFengH3MultiReferenceGeneratorV7", "NanFengH3MultiReferenceGeneratorV8", "NanFengH3MultiReferenceGeneratorV81"].includes(node.type);
}
function isV6(node) {
  return isV9(node) || ["NanFengH3MultiReferenceGeneratorV6", "NanFengH3MultiReferenceGeneratorV7", "NanFengH3MultiReferenceGeneratorV8", "NanFengH3MultiReferenceGeneratorV81"].includes(node.comfyClass) || ["NanFengH3MultiReferenceGeneratorV6", "NanFengH3MultiReferenceGeneratorV7", "NanFengH3MultiReferenceGeneratorV8", "NanFengH3MultiReferenceGeneratorV81"].includes(node.type);
}
function isV7(node) {
  return isV9(node) || ["NanFengH3MultiReferenceGeneratorV7", "NanFengH3MultiReferenceGeneratorV8", "NanFengH3MultiReferenceGeneratorV81"].includes(node.comfyClass) || ["NanFengH3MultiReferenceGeneratorV7", "NanFengH3MultiReferenceGeneratorV8", "NanFengH3MultiReferenceGeneratorV81"].includes(node.type);
}
function isV9(node) {
  return node.comfyClass === "NanFengH3MultiReferenceGeneratorV15" || node.type === "NanFengH3MultiReferenceGeneratorV15";
}
function isV81(node) {
  return isV9(node) || node.comfyClass === "NanFengH3MultiReferenceGeneratorV81" || node.type === "NanFengH3MultiReferenceGeneratorV81";
}
function isV8(node) {
  return isV9(node) || node.comfyClass === "NanFengH3MultiReferenceGeneratorV8" || node.type === "NanFengH3MultiReferenceGeneratorV8" || node.comfyClass === "NanFengH3MultiReferenceGeneratorV81" || node.type === "NanFengH3MultiReferenceGeneratorV81";
}
function hideWidget(w) {
  if (!w) return;
  w.hidden = true;
  w.computeSize = () => [0, -4];
  w.draw = () => {};
  w.value == null && (w.value = "");
  if (w.element) {
    w.element.style.display = "none";
    w.element.textContent = "";
  }
}
function valuesFor(node, kind) {
  const out = [];
  for (let i = 1; i <= LIMITS[kind]; i++) {
    const v = widget(node, `${kind}${i}`)?.value;
    if (v && v !== "未选择") out.push(v);
  }
  return out;
}
function writeValues(node, kind, values) {
  for (let i = 1; i <= LIMITS[kind]; i++) setWidget(node, `${kind}${i}`, values[i - 1] || "未选择");
}
function inferKind(f) {
  if (f.type.startsWith("image/")) return "图片";
  if (f.type.startsWith("video/")) return "视频";
  if (f.type.startsWith("audio/")) return "音频";
  const e = f.name.split(".").pop().toLowerCase();
  if (["png", "jpg", "jpeg", "webp", "bmp"].includes(e)) return "图片";
  if (["mp4", "mov", "webm", "mkv", "avi"].includes(e)) return "视频";
  if (["mp3", "wav", "flac"].includes(e)) return "音频";
}
function mediaRevision(node, file) {
  return Number(node?.properties?.nanfeng_media_revisions?.[file] || 0);
}
function bumpMediaRevision(node, file) {
  node.properties ||= {};
  node.properties.nanfeng_media_revisions ||= {};
  node.properties.nanfeng_media_revisions[file] = Date.now();
  return node.properties.nanfeng_media_revisions[file];
}
function mediaUrl(f, revision = 0) {
  const rev = Number(revision) || 0;
  return api.apiURL(`/view?filename=${encodeURIComponent(f)}&type=input${rev ? `&v=${rev}` : ""}`);
}
async function upload(file) {
  const b = new FormData();
  b.append("image", file);
  b.append("type", "input");
  b.append("overwrite", "false");
  const r = await api.fetchApi("/upload/image", {
    method: "POST",
    body: b
  });
  if (!r.ok) throw new Error(`上传失败 HTTP ${r.status}`);
  const d = await readJsonResponse(r);
  return d.subfolder ? `${d.subfolder}/${d.name}` : d.name;
}
async function uploadAudioDriveImage(file) {
  const ext = (String(file?.name || "").match(/\.[^.]+$/)?.[0] || ".png").toLowerCase(),
    safeBase = String(file?.name || "image").replace(/\.[^.]+$/, "").replace(/[^a-zA-Z0-9_-]+/g, "-").slice(0, 36) || "image",
    uniqueName = `nfh15-v11-${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${safeBase}${ext}`,
    uniqueFile = new File([file], uniqueName, {
      type: file.type,
      lastModified: file.lastModified
    });
  return upload(uniqueFile);
}
const megapixelLabel = (node, value) => {
  if (isV81(node)) return latentFinalSize(node, Number(value)).replace("目标", "").replace(" · 实际", ` MP · ${String(widget(node, "画面比例")?.value || "").match(/(\d+:\d+)/)?.[1] || ""} `);
  const ratio = widget(node, "画面比例")?.value,
    p = String(ratio || "").match(/(\d+):(\d+)/);
  if (!p) return `${value} MP`;
  const wr = +p[1],
    hr = +p[2],
    s = Math.sqrt(Number(value) * 1024 * 1024 / (wr * hr));
  return `${value} MP · ${p[1]}:${p[2]} ${Math.round(wr * s / 32) * 32}×${Math.round(hr * s / 32) * 32}`;
};
function resolutionLabel(node) {
  const ratio = widget(node, "画面比例")?.value,
    mp = Number(widget(node, "百万像素")?.value);
  if (ratio === "原图比例") return `当前比例：原图比例 · 目标：${mp}MP`;
  if (isV81(node)) return `一采尺寸：${latentFinalSize(node, mp)}`;
  const p = String(ratio || "").match(/(\d+):(\d+)/);
  if (!p) return `当前比例：${ratio || "未选择"} · 目标：${mp}MP`;
  const wr = +p[1],
    hr = +p[2],
    s = Math.sqrt(mp * 1024 * 1024 / (wr * hr));
  const w = Math.round(wr * s / 32) * 32,
    h = Math.round(hr * s / 32) * 32;
  return `当前比例：${ratio} · 目标：${mp}MP · 实际尺寸：${w}×${h}`;
}
function latentFinalSize(node, value) {
  const ratio = widget(node, "画面比例")?.value,
    align = Math.max(1, Number(widget(node, "H3潜空间对齐")?.value || 2)),
    p = String(ratio || "").match(/(\d+):(\d+)/),
    mp = Number(value);
  if (!p || !Number.isFinite(mp)) return `目标${value}MP`;
  const wr = +p[1],
    hr = +p[2],
    s = Math.sqrt(mp * 1_000_000 / (wr * hr));
  const lw = Math.ceil(wr * s / 16),
    lh = Math.ceil(hr * s / 16),
    w = Math.ceil(lw / align) * align * 16,
    h = Math.ceil(lh / align) * align * 16;
  return `目标${value}MP · 实际${w}×${h}`;
}
function openAudioDriveUI(node) {
  const audioOwner = makeOwnerGuard(node);
  document.querySelector(".nfh15-audio-drive-modal")?.remove();
  const modal = document.createElement("div");
  modal.className = "nfh15-audio-drive-modal";
  const dialog = document.createElement("div");
  dialog.className = "nfh15-audio-drive-dialog";
  const head = document.createElement("div");
  head.className = "nfh15-audio-drive-head";
  const audioDriveHeadTitle = document.createElement("div");
  audioDriveHeadTitle.innerHTML = '<b>智能音频驱动</b><small>数字人 · MV</small>';
  const audioDriveApiButton = document.createElement("button");
  audioDriveApiButton.type = "button";
  audioDriveApiButton.className = "nfh15-audio-drive-api-button";
  audioDriveApiButton.textContent = "API配置";
  head.append(audioDriveHeadTitle, audioDriveApiButton);
  const body = document.createElement("div");
  body.className = "nfh15-audio-drive-body";
  const audioDriveApiPanel = document.createElement("section");
  audioDriveApiPanel.className = "nfh15-audio-drive-api-panel";
  audioDriveApiPanel.hidden = true;
  audioDriveApiPanel.innerHTML = '<div class="nfh15-audio-drive-api-intro"><b>智能音频驱动专属API</b><span data-audio-drive-api-status>正在检查专属配置…</span></div><div class="nfh15-audio-drive-api-note">看图模型与语言模型只供智能音频驱动使用；不会读取或覆盖智能分镜配置。Key仅写入服务端独立的 .audio-drive.env。</div><div class="nfh15-audio-drive-api-grid"><div><b>看图模型</b><label>Base URL<input data-audio-drive-cfg="NANFENG_AUDIO_DRIVE_VISION_BASE_URL" placeholder="https://example.com/v1"></label><label>API Key<input data-audio-drive-cfg="NANFENG_AUDIO_DRIVE_VISION_API_KEY" type="password" placeholder="留空保留已保存Key" autocomplete="new-password"></label><label>模型ID<div class="nfh15-audio-drive-model-row"><input data-audio-drive-cfg="NANFENG_AUDIO_DRIVE_VISION_MODEL" list="nfh15-audio-drive-vision-models" placeholder="视觉模型ID"><button data-audio-drive-detect="vision" type="button">识别模型</button></div><datalist id="nfh15-audio-drive-vision-models"></datalist></label></div><div><b>语言模型</b><label>Base URL<input data-audio-drive-cfg="NANFENG_AUDIO_DRIVE_TEXT_BASE_URL" placeholder="https://example.com/v1"></label><label>API Key<input data-audio-drive-cfg="NANFENG_AUDIO_DRIVE_TEXT_API_KEY" type="password" placeholder="留空保留已保存Key" autocomplete="new-password"></label><label>模型ID<div class="nfh15-audio-drive-model-row"><input data-audio-drive-cfg="NANFENG_AUDIO_DRIVE_TEXT_MODEL" list="nfh15-audio-drive-text-models" placeholder="语言模型ID"><button data-audio-drive-detect="text" type="button">识别模型</button></div><datalist id="nfh15-audio-drive-text-models"></datalist></label></div></div><div data-audio-drive-api-message class="nfh15-audio-drive-api-message"></div><div class="nfh15-audio-drive-api-actions"><button data-audio-drive-api-clear type="button">清除专属配置</button><button data-audio-drive-api-save type="button">保存专属配置</button></div>';
  const toolbar = document.createElement("div");
  toolbar.className = "nfh15-audio-drive-toolbar";
  const audioDriveChoose = document.createElement("button");
  audioDriveChoose.type = "button";
  audioDriveChoose.textContent = "上传音频";
  const audioDrivePlay = document.createElement("button");
  audioDrivePlay.type = "button";
  audioDrivePlay.textContent = "播放";
  const audioDriveAddMarker = document.createElement("button");
  audioDriveAddMarker.type = "button";
  audioDriveAddMarker.textContent = "添加打点";
  const audioDriveRemoveMarker = document.createElement("button");
  audioDriveRemoveMarker.type = "button";
  audioDriveRemoveMarker.textContent = "删除选中";
  const audioDriveExcludeIntroLabel = document.createElement("label");
  audioDriveExcludeIntroLabel.className = "nfh15-audio-drive-exclude";
  const audioDriveExcludeIntro = document.createElement("input");
  audioDriveExcludeIntro.type = "checkbox";
  audioDriveExcludeIntroLabel.append(audioDriveExcludeIntro, document.createTextNode("排除首段"));
  const audioDriveExcludeOutroLabel = document.createElement("label");
  audioDriveExcludeOutroLabel.className = "nfh15-audio-drive-exclude";
  const audioDriveExcludeOutro = document.createElement("input");
  audioDriveExcludeOutro.type = "checkbox";
  audioDriveExcludeOutroLabel.append(audioDriveExcludeOutro, document.createTextNode("排除尾段"));
  const SILENT_TIMELINE_DURATION = 300;
  let silentTimeline = !!node.properties?.nfh3_audio_drive_silent_timeline,
    virtualTimelineTime = 0;
  const audioDriveSilentToggle = document.createElement("button");
  audioDriveSilentToggle.type = "button";
  audioDriveSilentToggle.className = "nfh15-audio-drive-silent-toggle";
  audioDriveSilentToggle.textContent = "用空5分钟声音";
  const audioDriveStatus = document.createElement("span");
  audioDriveStatus.textContent = "请先上传音频";
  toolbar.append(audioDriveChoose, audioDrivePlay, audioDriveAddMarker, audioDriveRemoveMarker, audioDriveExcludeIntroLabel, audioDriveExcludeOutroLabel, audioDriveSilentToggle, audioDriveStatus);
  const audioDriveCanvas = document.createElement("canvas");
  audioDriveCanvas.className = "nfh15-audio-drive-waveform";
  audioDriveCanvas.width = 1;
  audioDriveCanvas.height = 1;
  const audioDriveAudio = document.createElement("audio");
  audioDriveAudio.preload = "metadata";
  audioDriveAudio.hidden = true;
  const audioDriveUpload = document.createElement("input");
  audioDriveUpload.type = "file";
  audioDriveUpload.accept = "audio/*,.wav,.mp3,.flac,.ogg,.m4a,.aac";
  audioDriveUpload.hidden = true;
  const audioDriveMarkers = document.createElement("div");
  audioDriveMarkers.className = "nfh15-audio-drive-markers";
  const audioDriveIdeaPanel = document.createElement("section");
  audioDriveIdeaPanel.className = "nfh15-audio-drive-idea-panel";
  const audioDriveIdeaHead = document.createElement("div");
  audioDriveIdeaHead.className = "nfh15-audio-drive-idea-head";
  audioDriveIdeaHead.innerHTML = '<b>整支视频自然语言创意</b><span>上游大模型会结合每段秒数和图片顺序，自动拆分为各段分镜</span>';
  const audioDriveSkillLabel = document.createElement("label");
  audioDriveSkillLabel.className = "nfh15-audio-drive-skill-label";
  audioDriveSkillLabel.textContent = "提示词Skill";
  const audioDriveSkillSelect = document.createElement("select");
  audioDriveSkillSelect.innerHTML = '<option value="regular_storyboard">常规提示词分镜</option><option value="ns_storyboard">NS提示词分镜</option>';
  let audioDriveSkillId = String(node.properties?.nfh3_audio_drive_skill_id || "regular_storyboard");
  if (!["regular_storyboard", "ns_storyboard"].includes(audioDriveSkillId)) audioDriveSkillId = "regular_storyboard";
  audioDriveSkillSelect.value = audioDriveSkillId;
  audioDriveSkillSelect.onchange = () => {
    audioDriveSkillId = audioDriveSkillSelect.value;
    node.properties ||= {};
    node.properties.nfh3_audio_drive_skill_id = audioDriveSkillId;
    node.graph?.change?.();
    node.setDirtyCanvas?.(true, true);
  };
  audioDriveSkillLabel.append(audioDriveSkillSelect);
  audioDriveIdeaHead.append(audioDriveSkillLabel);
  const audioDriveIdea = document.createElement("textarea");
  audioDriveIdea.className = "nfh15-audio-drive-idea";
  audioDriveIdea.placeholder = "直接描述整支视频怎么拍：人物、动作、镜头、情绪、节奏、场景以及各段衔接要求……";
  audioDriveIdea.value = String(widget(node, "音频驱动创意")?.value || "");
  audioDriveIdea.oninput = () => setWidget(node, "音频驱动创意", audioDriveIdea.value);
  audioDriveIdeaPanel.append(audioDriveIdeaHead, audioDriveIdea);
  const audioDriveSegments = document.createElement("div");
  audioDriveSegments.className = "nfh15-audio-drive-segments";
  body.append(audioDriveApiPanel, toolbar, audioDriveCanvas, audioDriveAudio, audioDriveUpload, audioDriveMarkers, audioDriveIdeaPanel, audioDriveSegments);
  const audioDriveApiStatus = audioDriveApiPanel.querySelector('[data-audio-drive-api-status]'),
    audioDriveApiMessage = audioDriveApiPanel.querySelector('[data-audio-drive-api-message]');
  const paintAudioDriveApiConfig = data => {
    const d = data || {};
    for (const input of audioDriveApiPanel.querySelectorAll('[data-audio-drive-cfg]')) {
      if (input.type === 'password') {
        input.value = '';
        input.placeholder = input.dataset.audioDriveCfg.includes('VISION') ? d.vision_key_saved ? '已保存；留空保持不变' : '未保存API Key' : d.text_key_saved ? '已保存；留空保持不变' : '未保存API Key';
      } else input.value = d[input.dataset.audioDriveCfg] || '';
    }
    audioDriveApiStatus.textContent = `看图模型：${d.vision_configured ? '已配置' : '未配置'}　语言模型：${d.text_configured ? '已配置' : '未配置'}`;
  };
  const loadAudioDriveApiConfig = async (skillId = audioDriveSkillId) => {
    try {
      const response = await api.fetchApi(`/nanfeng/v15/h3/audio-drive/config?skill_id=${encodeURIComponent(skillId)}`, {
          cache: 'no-store'
        }),
        data = await readJsonResponse(response);
      if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
      paintAudioDriveApiConfig(data);
    } catch (error) {
      audioDriveApiStatus.textContent = `专属配置读取失败：${error.message}`;
    }
  };
  audioDriveSkillSelect.onchange = async () => {
    audioDriveSkillId = audioDriveSkillSelect.value;
    node.properties ||= {};
    node.properties.nfh3_audio_drive_skill_id = audioDriveSkillId;
    node.graph?.change?.();
    node.setDirtyCanvas?.(true, true);
    await loadAudioDriveApiConfig(audioDriveSkillId);
  };
  audioDriveApiButton.onclick = () => {
    const opening = audioDriveApiPanel.hidden;
    audioDriveApiPanel.hidden = !opening;
    audioDriveApiButton.classList.toggle('active', opening);
    body.classList.toggle('api-open', opening);
    if (opening) {
      audioDriveApiPanel.querySelector('[data-audio-drive-cfg]')?.focus();
      audioDriveApiPanel.scrollTop = 0;
    }
  };
  for (const button of audioDriveApiPanel.querySelectorAll('[data-audio-drive-detect]')) button.onclick = async () => {
    const kind = button.dataset.audioDriveDetect,
      prefix = kind === 'vision' ? 'NANFENG_AUDIO_DRIVE_VISION' : 'NANFENG_AUDIO_DRIVE_TEXT',
      base = audioDriveApiPanel.querySelector(`[data-audio-drive-cfg="${prefix}_BASE_URL"]`),
      key = audioDriveApiPanel.querySelector(`[data-audio-drive-cfg="${prefix}_API_KEY"]`),
      model = audioDriveApiPanel.querySelector(`[data-audio-drive-cfg="${prefix}_MODEL"]`),
      list = audioDriveApiPanel.querySelector(`#nfh15-audio-drive-${kind}-models`);
    button.disabled = true;
    audioDriveApiMessage.textContent = `正在识别${kind === 'vision' ? '看图' : '语言'}模型…`;
    try {
      const response = await api.fetchApi('/nanfeng/v15/h3/audio-drive/models', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            kind,
            skill_id: audioDriveSkillId,
            base_url: base.value,
            api_key: key.value
          })
        }),
        data = await readJsonResponse(response);
      if (!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);
      base.value = data.base_url;
      list.replaceChildren(...data.models.map(id => {
        const option = document.createElement('option');
        option.value = id;
        return option;
      }));
      if (!model.value && data.models.length === 1) model.value = data.models[0];
      audioDriveApiMessage.textContent = `已识别 ${data.models.length} 个模型。`;
      model.focus();
    } catch (error) {
      audioDriveApiMessage.textContent = `识别失败：${error.message}`;
    } finally {
      button.disabled = false;
    }
  };
  audioDriveApiPanel.querySelector('[data-audio-drive-api-save]').onclick = async () => {
    const button = audioDriveApiPanel.querySelector('[data-audio-drive-api-save]');
    button.disabled = true;
    audioDriveApiMessage.textContent = '正在保存智能音频驱动专属配置…';
    try {
      const payload = {
        skill_id: audioDriveSkillId
      };
      for (const input of audioDriveApiPanel.querySelectorAll('[data-audio-drive-cfg]')) payload[input.dataset.audioDriveCfg] = input.value;
      const response = await api.fetchApi('/nanfeng/v15/h3/audio-drive/config', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        }),
        data = await readJsonResponse(response);
      if (!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);
      paintAudioDriveApiConfig(data);
      audioDriveApiMessage.textContent = '已保存到独立 .audio-drive.env，未改动智能分镜配置。';
    } catch (error) {
      audioDriveApiMessage.textContent = `保存失败：${error.message}`;
    } finally {
      button.disabled = false;
    }
  };
  audioDriveApiPanel.querySelector('[data-audio-drive-api-clear]').onclick = async () => {
    if (!confirm('确认只清除智能音频驱动的看图与语言模型配置吗？智能分镜配置不会受影响。')) return;
    const response = await api.fetchApi('/nanfeng/v15/h3/audio-drive/config', {
        method: 'DELETE'
      }),
      data = await readJsonResponse(response);
    if (!response.ok || !data.ok) {
      audioDriveApiMessage.textContent = `清除失败：${data.error || response.status}`;
      return;
    }
    paintAudioDriveApiConfig(data);
    audioDriveApiMessage.textContent = '已清除智能音频驱动专属配置。';
  };
  loadAudioDriveApiConfig();
  let audioDriveResizeObserver = null,
    audioDriveFramePending = false;
  const closeAudioDriveModal = () => {
    audioDriveAudio.pause();
    audioDriveAudio.ontimeupdate = null;
    audioDriveAudio.onloadedmetadata = null;
    audioDriveResizeObserver?.disconnect();
    modal.remove();
  };
  node.__nfh3CloseAudio = closeAudioDriveModal;
  const backBar = document.createElement("div");
  backBar.className = "nfh15-audio-drive-footer";
  const audioDriveEnableBar = document.createElement("div");
  audioDriveEnableBar.className = "nfh15-audio-drive-enable-bar";
  const audioDriveEnableSummary = document.createElement("span");
  const audioDriveEnableAll = document.createElement("button");
  audioDriveEnableAll.type = "button";
  audioDriveEnableAll.textContent = "全选";
  const audioDriveEnableNone = document.createElement("button");
  audioDriveEnableNone.type = "button";
  audioDriveEnableNone.textContent = "全不选";
  audioDriveEnableBar.append(audioDriveEnableSummary, audioDriveEnableAll, audioDriveEnableNone);
  const generateAllStoryboards = document.createElement("button");
  generateAllStoryboards.type = "button";
  generateAllStoryboards.className = "nfh15-audio-drive-generate-storyboards";
  generateAllStoryboards.textContent = "生成智能分镜";
  const back = document.createElement("button");
  back.type = "button";
  back.className = "nfh15-audio-drive-back";
  back.textContent = "返回主界面";
  back.onclick = () => {
    saveDisabledSegmentKeys();
    saveExcludedRanges();
    closeAudioDriveModal();
  };
  backBar.append(audioDriveEnableBar, generateAllStoryboards, back);
  const parseMarkers = () => {
    try {
      const value = JSON.parse(audioDriveWorkspaceValue(node, "音频驱动打点", "[]"));
      return Array.isArray(value) ? value.map(Number).filter(Number.isFinite).filter(x => x >= 0).sort((a, b) => a - b) : [];
    } catch {
      return [];
    }
  };
  let peaks = [],
    duration = silentTimeline ? SILENT_TIMELINE_DURATION : 0,
    selectedMarker = -1,
    markers = parseMarkers();
  const currentTimelineTime = () => silentTimeline ? virtualTimelineTime : Number(audioDriveAudio.currentTime || 0);
  const parseSegmentImages = () => {
    try {
      const value = JSON.parse(audioDriveWorkspaceValue(node, "音频驱动分段图片", "{}"));
      return value && typeof value === "object" && !Array.isArray(value) ? value : {};
    } catch {
      return {};
    }
  };
  let segmentImages = parseSegmentImages(),
    segmentVisible = {};
  const parseSegmentStoryboards = () => {
    try {
      const value = JSON.parse(audioDriveWorkspaceValue(node, "音频驱动分段分镜", "{}"));
      return value && typeof value === "object" && !Array.isArray(value) ? value : {};
    } catch {
      return {};
    }
  };
  let segmentStoryboards = parseSegmentStoryboards();
  const saveSegmentStoryboards = () => setWidget(node, "音频驱动分段分镜", JSON.stringify(segmentStoryboards));
  const parseExcludedRanges = () => {
    const saved = node.properties?.nfh3_audio_drive_exclusions;
    if (saved && typeof saved === "object") return {
      intro: !!saved.intro,
      outro: !!saved.outro
    };
    try {
      const value = JSON.parse(audioDriveWorkspaceValue(node, "音频驱动排除范围", "{}"));
      return {
        intro: !!value?.intro,
        outro: !!value?.outro
      };
    } catch {
      return {
        intro: false,
        outro: false
      };
    }
  };
  let excludedRanges = parseExcludedRanges();
  const saveExcludedRanges = () => {
    node.properties ||= {};
    node.properties.nfh3_audio_drive_exclusions = {
      ...excludedRanges
    };
    setWidget(node, "音频驱动排除范围", JSON.stringify(excludedRanges));
    node.setDirtyCanvas?.(true, true);
  };
  const segmentBounds = () => {
    const ends = markers.filter(x => x > 0 && x < duration);
    return [0, ...ends, duration > 0 ? duration : ends.at(-1) || 0].filter((value, index, array) => index === 0 || value > array[index - 1]);
  };
  const segmentRanges = () => {
    const bounds = segmentBounds(),
      ranges = bounds.slice(0, -1).map((start, index) => ({
        start,
        end: bounds[index + 1],
        source_index: index
      }));
    if (excludedRanges.intro) ranges.shift();
    if (excludedRanges.outro) ranges.pop();
    return ranges;
  };
  const displayMarkers = () => markers;
  const markerHitRadiusPx = 8;
  const segmentKey = range => `${Number(range.start).toFixed(3)}-${Number(range.end).toFixed(3)}`;
  const disabledSegmentKeys = new Set(Array.isArray(node.properties?.nfh3_audio_drive_disabled_segments) ? node.properties.nfh3_audio_drive_disabled_segments.map(String) : []);
  const syncDisabledSegmentKeys = () => {
    const ranges = segmentRanges();
    if (!(duration > 0) || !ranges.length) return;
    const valid = new Set(ranges.map(segmentKey));
    for (const key of [...disabledSegmentKeys]) if (!valid.has(key)) disabledSegmentKeys.delete(key);
  };
  const saveDisabledSegmentKeys = () => {
    node.properties ||= {};
    node.properties.nfh3_audio_drive_disabled_segments = [...disabledSegmentKeys];
    delete node.properties.nfh3_audio_drive_enabled_segments;
    delete node.properties.nfh3_audio_drive_enabled_segments_explicit;
    node.graph?.change?.();
    node.setDirtyCanvas?.(true, true);
  };
  const saveSegmentImages = () => setWidget(node, "音频驱动分段图片", JSON.stringify(segmentImages));
  const remapRangeKeyedObject = (source, previousRanges, nextRanges) => {
    const next = {
      ...(source && typeof source === "object" ? source : {})
    };
    for (const previous of previousRanges) {
      const target = nextRanges.find(range => range.source_index === previous.source_index),
        oldKey = segmentKey(previous),
        newKey = target ? segmentKey(target) : "";
      if (!newKey || newKey === oldKey || !Object.prototype.hasOwnProperty.call(next, oldKey)) continue;
      if (!Object.prototype.hasOwnProperty.call(next, newKey)) next[newKey] = next[oldKey];
      delete next[oldKey];
    }
    return next;
  };
  const remapSegmentStateAfterBoundaryMove = (previousRanges, nextRanges = segmentRanges()) => {
    const oldDisabled = new Set(disabledSegmentKeys);
    segmentImages = remapRangeKeyedObject(segmentImages, previousRanges, nextRanges);
    segmentStoryboards = remapRangeKeyedObject(segmentStoryboards, previousRanges, nextRanges);
    segmentVisible = remapRangeKeyedObject(segmentVisible, previousRanges, nextRanges);
    disabledSegmentKeys.clear();
    for (const previous of previousRanges) {
      const target = nextRanges.find(range => range.source_index === previous.source_index);
      if (target && oldDisabled.has(segmentKey(previous))) disabledSegmentKeys.add(segmentKey(target));
    }
    saveSegmentImages();
    saveSegmentStoryboards();
    saveDisabledSegmentKeys();
  };
  const snapAudioDriveTime = value => Math.round(Math.max(0, Number(value) || 0));
  const formatTime = value => {
    const seconds = Math.max(0, Number(value) || 0),
      minutes = Math.floor(seconds / 60);
    return `${minutes}:${String((seconds - minutes * 60).toFixed(2)).padStart(5, "0")}`;
  };
  const saveMarkers = () => setWidget(node, "音频驱动打点", JSON.stringify(markers.map(x => Number(x.toFixed(3)))));
  let render = () => {};
  let segmentImageDrag = null;
  const moveSegmentImage = (key, from, to) => {
    const current = Array.isArray(segmentImages[key]) ? segmentImages[key].slice(0, 9) : [];
    if (!Number.isInteger(from) || !Number.isInteger(to) || from === to || from < 0 || to < 0 || from >= current.length || to >= 9) return false;
    while (current.length <= to) current.push("");
    [current[from], current[to]] = [current[to], current[from]];
    while (current.length && !current.at(-1)) current.pop();
    segmentImages[key] = current;
    saveSegmentImages();
    renderSegments();
    return true;
  };
  const copySegmentImage = (sourceKey, sourceIndex, targetKey, targetIndex) => {
    const source = Array.isArray(segmentImages[sourceKey]) ? segmentImages[sourceKey] : [],
      target = Array.isArray(segmentImages[targetKey]) ? segmentImages[targetKey].slice(0, 9) : [];
    if (!source[sourceIndex] || !Number.isInteger(targetIndex) || targetIndex < 0 || targetIndex >= 9) return false;
    while (target.length <= targetIndex) target.push("");
    target[targetIndex] = source[sourceIndex];
    segmentImages[targetKey] = target;
    segmentVisible[targetKey] = Math.min(9, Math.max(4, Number(segmentVisible[targetKey]) || 4, targetIndex + 1));
    saveSegmentImages();
    renderSegments();
    return true;
  };
  const resizeAudioDriveCanvas = () => {
    const rect = audioDriveCanvas.getBoundingClientRect(),
      dpr = Math.max(1, window.devicePixelRatio || 1);
    if (!(rect.width > 0 && rect.height > 0)) return;
    const nextWidth = Math.round(rect.width * dpr),
      nextHeight = Math.round(rect.height * dpr);
    if (audioDriveCanvas.width !== nextWidth || audioDriveCanvas.height !== nextHeight) {
      audioDriveCanvas.width = nextWidth;
      audioDriveCanvas.height = nextHeight;
    }
    render();
  };
  const renderSegments = () => {
    syncDisabledSegmentKeys();
    const ranges = segmentRanges();
    audioDriveStatus.title = "智能音频驱动内部打点与分段；只有上游推理成功后才写入主节点分镜。";
    audioDriveSegments.replaceChildren();
    for (const [segmentIndex, range] of ranges.entries()) {
      const key = segmentKey(range),
        segmentSeconds = Math.max(1, Math.ceil(range.end - range.start)),
        files = Array.isArray(segmentImages[key]) ? segmentImages[key].slice(0, 9) : [],
        visible = Math.min(9, Math.max(4, Number(segmentVisible[key]) || files.length || 4));
      segmentVisible[key] = visible;
      const segment = document.createElement("section");
      segment.className = "nfh15-audio-drive-segment";
      segment.dataset.start = String(range.start);
      segment.dataset.end = String(range.end);
      const title = document.createElement("div");
      title.className = "nfh15-audio-drive-segment-title";
      title.innerHTML = `<b>第 ${range.source_index + 1} 段</b><span>${formatTime(range.start)} → ${formatTime(range.end)}</span><small>${silentTimeline ? "纯时间轴 + 图片参考" : "本段音频 + 图片参考"}</small>`;
      const enableLabel = document.createElement("label");
      enableLabel.className = "nfh15-audio-drive-segment-enable";
      const enable = document.createElement("input");
      enable.type = "checkbox";
      enable.checked = !disabledSegmentKeys.has(key);
      enable.onchange = () => {
        if (enable.checked) disabledSegmentKeys.delete(key);else disabledSegmentKeys.add(key);
        saveDisabledSegmentKeys();
        segment.classList.toggle("disabled", !enable.checked);
        audioDriveEnableSummary.textContent = `已启用 ${segmentRanges().length - disabledSegmentKeys.size}/${segmentRanges().length} 段`;
      };
      enableLabel.append(enable, document.createTextNode("启用"));
      title.append(enableLabel);
      segment.classList.toggle("disabled", !enable.checked);
      const current = Number(currentTimelineTime());
      segment.classList.toggle("current", current >= Number(range.start) && current < Number(range.end));
      const list = document.createElement("div");
      list.className = "nfh15-audio-drive-image-list";
      for (let index = 0; index < visible; index++) {
        const file = files[index] || "",
          row = document.createElement("div");
        row.className = "nfh15-audio-drive-image-row";
        row.draggable = false;
        row.ondragstart = event => {
          if (!file) return;
          segmentImageDrag = {
            key,
            index
          };
          event.dataTransfer.effectAllowed = "copyMove";
        };
        row.ondragover = event => {
          if (segmentImageDrag) {
            event.preventDefault();
            event.dataTransfer.dropEffect = segmentImageDrag?.key === key ? "move" : "copy";
            row.classList.add("drag-target");
          }
        };
        row.ondragleave = () => row.classList.remove("drag-target");
        row.ondragend = () => {
          segmentImageDrag = null;
          for (const item of audioDriveSegments.querySelectorAll(".drag-target,.move-selected")) item.classList.remove("drag-target", "move-selected");
        };
        row.ondrop = event => {
          event.preventDefault();
          row.classList.remove("drag-target");
          if (segmentImageDrag?.key === key) moveSegmentImage(key, segmentImageDrag.index, index);else if (segmentImageDrag) copySegmentImage(segmentImageDrag.key, segmentImageDrag.index, key, index);
          segmentImageDrag = null;
        };
        const label = document.createElement("b");
        label.textContent = `图片${index + 1}`;
        const preview = document.createElement("button");
        preview.type = "button";
        preview.className = "nfh15-audio-drive-image-preview";
        preview.draggable = !!file;
        preview.ondragstart = event => {
          if (!file) return;
          segmentImageDrag = {
            key,
            index
          };
          event.dataTransfer.effectAllowed = "copyMove";
          event.stopPropagation();
        };
        preview.ondragend = () => {
          segmentImageDrag = null;
          for (const item of audioDriveSegments.querySelectorAll(".drag-target,.move-selected")) item.classList.remove("drag-target", "move-selected");
        };
        if (file) {
          const image = document.createElement("img");
          image.src = mediaUrl(file, mediaRevision(node, file));
          image.alt = `第${segmentIndex + 1}段 图片${index + 1}`;
          preview.append(image);
        } else preview.textContent = "＋ 选择图片";
        const picker = document.createElement("input");
        picker.type = "file";
        picker.accept = "image/*,.png,.jpg,.jpeg,.webp,.bmp";
        picker.hidden = true;
        preview.onclick = () => {
          picker.value = "";
          picker.click();
        };
        picker.onchange = async () => {
          const chosen = picker.files?.[0];
          if (!chosen) return;
          preview.disabled = true;
          try {
            const uploaded = await uploadAudioDriveImage(chosen);
            if (!audioOwner() || !modal.isConnected) return;
            const next = Array.isArray(segmentImages[key]) ? segmentImages[key].slice(0, 9) : [];
            while (next.length <= index) next.push("");
            next[index] = uploaded;
            segmentImages[key] = next;
            saveSegmentImages();
            renderSegments();
          } catch (error) {
            alert(error?.message || String(error));
            preview.disabled = false;
          }
        };
        const audioDriveImageMove = document.createElement("button");
        audioDriveImageMove.type = "button";
        audioDriveImageMove.className = "nfh15-audio-drive-image-move";
        audioDriveImageMove.textContent = "↔";
        audioDriveImageMove.title = "选择本图，再点击同段目标图片位置进行换位";
        audioDriveImageMove.disabled = !file;
        audioDriveImageMove.onclick = event => {
          event.stopPropagation();
          if (!file) return;
          if (segmentImageDrag?.key === key && segmentImageDrag.index !== index) {
            moveSegmentImage(key, segmentImageDrag.index, index);
            segmentImageDrag = null;
          } else {
            segmentImageDrag = {
              key,
              index
            };
            for (const item of list.children) item.classList.toggle("move-selected", item === row);
          }
        };
        const mediaWrap = document.createElement("div");
        mediaWrap.className = "nfh15-audio-drive-image-media";
        mediaWrap.append(preview, audioDriveImageMove);
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "nfh15-audio-drive-image-remove";
        remove.textContent = "删除";
        remove.disabled = !file;
        remove.onclick = () => {
          const next = Array.isArray(segmentImages[key]) ? segmentImages[key].slice(0, 9) : [];
          next[index] = "";
          while (next.length && !next.at(-1)) next.pop();
          segmentImages[key] = next;
          saveSegmentImages();
          renderSegments();
        };
        row.append(label, mediaWrap, remove, picker);
        list.append(row);
      }
      const add = document.createElement("button");
      add.type = "button";
      add.className = "nfh15-audio-drive-image-add";
      add.textContent = visible < 9 ? `＋ 添加图片栏（${visible}/9）` : "已达到9张上限";
      add.disabled = visible >= 9;
      add.onclick = () => {
        segmentVisible[key] = Math.min(9, visible + 1);
        renderSegments();
      };
      segment.append(title, list, add);
      audioDriveSegments.append(segment);
    }
    audioDriveEnableSummary.textContent = `已启用 ${ranges.length - disabledSegmentKeys.size}/${ranges.length} 段`;
  };
  render = () => {
    const ctx = audioDriveCanvas.getContext("2d"),
      dpr = Math.max(1, window.devicePixelRatio || 1),
      rect = audioDriveCanvas.getBoundingClientRect(),
      w = rect.width || 1,
      h = rect.height || 1,
      mid = h / 2;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const palette = skinCanvasColors(node);
    ctx.fillStyle = palette.background;
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = palette.grid;
    ctx.beginPath();
    ctx.moveTo(0, mid);
    ctx.lineTo(w, mid);
    ctx.stroke();
    if (peaks.length) {
      const bw = w / peaks.length;
      ctx.fillStyle = palette.wave;
      peaks.forEach((peak, index) => {
        const bh = Math.max(1, Math.min(1, Number(peak) || 0) * h * .42);
        ctx.fillRect(index * bw, mid - bh, Math.max(1, bw - 1), bh * 2);
      });
    }
    displayMarkers().forEach((time, index) => {
      const x = duration > 0 ? time / duration * w : 0;
      ctx.strokeStyle = index === selectedMarker ? palette.selected : palette.marker;
      ctx.lineWidth = index === selectedMarker ? 4 : 2;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
      ctx.fillStyle = ctx.strokeStyle;
      ctx.fillText(String(index + 1), Math.min(w - 18, x + 5), 18 + index % 2 * 16);
    });
    if (duration > 0) {
      const x = currentTimelineTime() / duration * w;
      ctx.strokeStyle = palette.playhead;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    audioDriveStatus.textContent = duration > 0 ? `时间 ${formatTime(currentTimelineTime())} / ${formatTime(duration)} · 内部打点 ${markers.length} · 内部分段 ${segmentRanges().length}` : "请先上传音频";
    audioDriveMarkers.textContent = displayMarkers().length ? displayMarkers().map((time, index) => `${index + 1}. ${formatTime(time)}`).join("   ") : "尚未打点";
  };
  const loadAudioFile = async audioFile => {
    if (silentTimeline) {
      duration = SILENT_TIMELINE_DURATION;
      peaks = [];
      markers = parseMarkers().filter(x => x < duration);
      render();
      renderSegments();
      return;
    }
    if (!audioFile) {
      duration = 0;
      render();
      renderSegments();
      return;
    }
    audioDriveStatus.textContent = "正在加载波形…";
    try {
      const response = await fetch(`/nanfeng/v15/h3/audio-media/waveform?audio_file=${encodeURIComponent(audioFile)}&bins=1400`),
        payload = await readJsonResponse(response);
      if (!response.ok) throw new Error(payload?.error || "波形加载失败");
      if (!audioOwner() || !modal.isConnected || String(widget(node, "音频驱动文件")?.value || "") !== audioFile) return;
      peaks = Array.isArray(payload.peaks) ? payload.peaks : [];
      duration = Number(payload.duration) || 0;
      audioDriveAudio.src = payload.audio_url || `/nanfeng/v15/h3/audio-media/file?audio_file=${encodeURIComponent(audioFile)}`;
      audioDriveAudio.load();
      markers = parseMarkers().filter(x => x < duration);
      render();
      renderSegments();
    } catch (error) {
      audioDriveStatus.textContent = error?.message || String(error);
    }
  };
  audioDriveChoose.onclick = () => {
    audioDriveUpload.value = "";
    audioDriveUpload.click();
  };
  audioDriveUpload.onchange = async () => {
    const file = audioDriveUpload.files?.[0];
    if (!file) return;
    audioDriveChoose.disabled = true;
    audioDriveStatus.textContent = "上传中…";
    try {
      const form = new FormData();
      form.append("image", new File([file], file.name, {
        type: file.type,
        lastModified: file.lastModified
      }));
      const response = await api.fetchApi("/upload/image", {
          method: "POST",
          body: form
        }),
        payload = await readJsonResponse(response);
      if (!response.ok || !payload?.name) throw new Error(payload?.error || `上传失败 HTTP ${response.status}`);
      if (!audioOwner() || !modal.isConnected) return;
      const audioFile = payload.subfolder ? `${payload.subfolder}/${payload.name}` : payload.name;
      setWidget(node, "音频驱动文件", audioFile);
      markers = [];
      segmentImages = {};
      segmentStoryboards = {};
      segmentVisible = {};
      excludedRanges = {
        intro: false,
        outro: false
      };
      disabledSegmentKeys.clear();
      delete node.properties.nfh3_audio_drive_disabled_segments;
      delete node.properties.nfh3_audio_drive_enabled_segments;
      delete node.properties.nfh3_audio_drive_enabled_segments_explicit;
      saveMarkers();
      saveSegmentImages();
      saveSegmentStoryboards();
      saveExcludedRanges();
      updateExcludedButtons();
      await loadAudioFile(audioFile);
    } catch (error) {
      audioDriveStatus.textContent = error?.message || String(error);
    } finally {
      audioDriveChoose.disabled = false;
    }
  };
  audioDrivePlay.onclick = async () => {
    if (audioDriveAudio.paused) await audioDriveAudio.play();else audioDriveAudio.pause();
  };
  audioDriveAudio.onplay = () => {
    audioDrivePlay.textContent = "暂停";
    render();
  };
  audioDriveAudio.onpause = () => {
    audioDrivePlay.textContent = "播放";
    render();
  };
  audioDriveAudio.ontimeupdate = () => {
    if (audioDriveFramePending) return;
    audioDriveFramePending = true;
    requestAnimationFrame(() => {
      audioDriveFramePending = false;
      render();
      for (const segment of audioDriveSegments.children) {
        const start = Number(segment.dataset.start),
          end = Number(segment.dataset.end),
          current = Number(audioDriveAudio.currentTime);
        segment.classList.toggle("current", current >= start && current < end);
      }
    });
  };
  audioDriveAudio.onloadedmetadata = render;
  let draggedMarker = -1,
    markerDragMoved = false,
    markerDragPreviousRanges = [];
  const markerTimeFromPointer = event => {
    const rect = audioDriveCanvas.getBoundingClientRect(),
      rawTime = Math.max(0, Math.min(duration, (event.clientX - rect.left) / rect.width * duration));
    return Math.min(snapAudioDriveTime(rawTime), Math.max(0, duration - .001));
  };
  audioDriveCanvas.onpointerdown = event => {
    if (!(duration > 0)) return;
    const rect = audioDriveCanvas.getBoundingClientRect(),
      time = markerTimeFromPointer(event);
    if (silentTimeline) virtualTimelineTime = time;else audioDriveAudio.currentTime = time;
    const clickX = event.clientX - rect.left;
    if (-1 < 0 && markers.length) {
      const hitIndex = markers.reduce((best, item, index) => Math.abs(item / duration * rect.width - clickX) < Math.abs((markers[best] ?? Infinity) / duration * rect.width - clickX) ? index : best, 0),
        markerX = (markers[hitIndex] || 0) / duration * rect.width;
      selectedMarker = Math.abs(markerX - clickX) <= markerHitRadiusPx ? hitIndex : -1;
    } else selectedMarker = -1;
    if (selectedMarker >= 0) {
      draggedMarker = selectedMarker;
      markerDragMoved = false;
      markerDragPreviousRanges = segmentRanges();
      audioDriveCanvas.setPointerCapture?.(event.pointerId);
      event.preventDefault();
    }
    render();
  };
  audioDriveCanvas.onpointermove = event => {
    if (draggedMarker < 0 || draggedMarker >= markers.length || !(duration > 0)) return;
    const time = markerTimeFromPointer(event);
    markerDragMoved = markerDragMoved || Math.abs(markers[draggedMarker] - time) > .001;
    markers[draggedMarker] = time;
    if (silentTimeline) virtualTimelineTime = time;else audioDriveAudio.currentTime = time;
    saveMarkers();
    render();
    renderSegments();
    audioDriveStatus.textContent = `正在移动内部打点到 ${formatTime(time)}（按整秒吸附）`;
  };
  const finishMarkerDrag = event => {
    if (draggedMarker < 0) return;
    const movedTime = markers[draggedMarker];
    markers.sort((a, b) => a - b);
    selectedMarker = markers.indexOf(movedTime);
    draggedMarker = -1;
    if (markerDragMoved) remapSegmentStateAfterBoundaryMove(markerDragPreviousRanges);else saveMarkers();
    markerDragPreviousRanges = [];
    render();
    renderSegments();
    if (markerDragMoved) audioDriveStatus.textContent = `已移动内部打点到 ${formatTime(movedTime)}（按整秒吸附）；分段图片和分镜已保留。`;
    markerDragMoved = false;
    try {
      audioDriveCanvas.releasePointerCapture?.(event.pointerId);
    } catch {}
  };
  audioDriveCanvas.onpointerup = finishMarkerDrag;
  audioDriveCanvas.onpointercancel = finishMarkerDrag;
  audioDriveAddMarker.onclick = () => {
    if (!(duration > 0)) return;
    const time = Math.min(snapAudioDriveTime(currentTimelineTime()), Math.max(0, duration - .001));
    if (!markers.some(x => Math.abs(x - time) < .05)) {
      markers.push(time);
      markers.sort((a, b) => a - b);
      selectedMarker = markers.indexOf(time);
      saveMarkers();
      render();
      renderSegments();
      audioDriveStatus.textContent = `已添加内部打点 ${formatTime(time)}；主节点分镜未改变。`;
    } else audioDriveStatus.textContent = `${formatTime(time)} 已存在内部打点。`;
  };
  audioDriveRemoveMarker.onclick = () => {
    if (selectedMarker < 0 || selectedMarker >= markers.length) return;
    const removed = markers[selectedMarker];
    markers.splice(selectedMarker, 1);
    selectedMarker = Math.min(selectedMarker, markers.length - 1);
    saveMarkers();
    render();
    renderSegments();
    audioDriveStatus.textContent = `已删除内部打点 ${formatTime(removed)}；主节点分镜未改变。`;
  };
  const updateSilentTimelineUi = () => {
    audioDriveSilentToggle.classList.toggle("active", silentTimeline && true);
    audioDriveSilentToggle.setAttribute("aria-pressed", String(silentTimeline && true));
    const timedMode = false;
    audioDrivePlay.disabled = silentTimeline;
    audioDriveChoose.disabled = silentTimeline;
    if (silentTimeline) {
      audioDriveAudio.pause();
      duration = SILENT_TIMELINE_DURATION;
      peaks = [];
      virtualTimelineTime = Math.min(virtualTimelineTime, duration - .001);
      setWidget(node, "启用锁音频", false);
      setWidget(node, "空5分钟时间轴模式", true);
    } else {
      setWidget(node, "空5分钟时间轴模式", false);
    }
    node.properties.nfh3_audio_drive_silent_timeline = silentTimeline && true;
    node.graph?.change?.();
    node.setDirtyCanvas?.(true, true);
    render();
    renderSegments();
  };
  audioDriveSilentToggle.onclick = () => {
    const next = !(silentTimeline && true);
    silentTimeline = next;
    if (!silentTimeline) {
      duration = 0;
      virtualTimelineTime = 0;
    }
    updateSilentTimelineUi();
    if (!silentTimeline) loadAudioFile(String(widget(node, "音频驱动文件")?.value || ""));
  };
  const updateExcludedButtons = () => {
    audioDriveExcludeIntro.checked = excludedRanges.intro;
    audioDriveExcludeOutro.checked = excludedRanges.outro;
  };
  audioDriveExcludeIntro.onchange = () => {
    excludedRanges.intro = audioDriveExcludeIntro.checked;
    saveExcludedRanges();
    renderSegments();
  };
  audioDriveExcludeOutro.onchange = () => {
    excludedRanges.outro = audioDriveExcludeOutro.checked;
    saveExcludedRanges();
    renderSegments();
  };
  updateExcludedButtons();
  updateSilentTimelineUi();
  render();
  renderSegments();
  audioDriveEnableAll.onclick = () => {
    disabledSegmentKeys.clear();
    saveDisabledSegmentKeys();
    renderSegments();
  };
  audioDriveEnableNone.onclick = () => {
    for (const range of segmentRanges()) disabledSegmentKeys.add(segmentKey(range));
    saveDisabledSegmentKeys();
    renderSegments();
  };
  generateAllStoryboards.onclick = async () => {
    syncDisabledSegmentKeys();
    const enabledRanges = segmentRanges().filter(range => !disabledSegmentKeys.has(segmentKey(range)));
    if (!enabledRanges.length) {
      audioDriveStatus.textContent = "请至少勾选一个启用分段。";
      return;
    }
    const ranges = enabledRanges;
    const segments = [];
    for (const [index, range] of ranges.entries()) {
      const key = segmentKey(range),
        segmentSeconds = Math.max(1, Math.ceil(range.end - range.start)),
        baseImages = (Array.isArray(segmentImages[key]) ? segmentImages[key] : []).filter(Boolean).slice(0, 9);
      const executionImages = baseImages;
      segments.push({
        segment_index: range.source_index + 1,
        source_segment_index: range.source_index + 1,
        start: range.start,
        end: range.end,
        duration_seconds: segmentSeconds,
        images: executionImages
      });
      segmentStoryboards[key] = {
        ...(segmentStoryboards[key] || {}),
        start: range.start,
        end: range.end,
        duration: segmentSeconds,
        text: String(segmentStoryboards[key]?.text || "")
      };
    }
    saveSegmentStoryboards();
    renderSegments();
    generateAllStoryboards.disabled = true;
    audioDriveStatus.textContent = `正在生成 ${segments.length} 段智能分镜…`;
    try {
      const response = await api.fetchApi('/nanfeng/v15/h3/audio-drive/generate', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            idea: audioDriveIdea.value,
            segments,
            timeline_only: silentTimeline,
            skill_id: audioDriveSkillId,
            skill_text: audioDriveSkillId === "ns_storyboard" ? await (await fetch("/extensions/nanfeng_prompt_nodes_v15/audio-drive-ns-skill.txt", {
              cache: "no-store"
            })).text() : ""
          })
        }),
        data = await readJsonResponse(response);
      if (!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);
      if (!audioOwner() || !modal.isConnected) return;
      const resultByOriginalIndex = new Map((data.segments || []).map(item => [Number(item.segment_index), item]));
      for (const range of ranges) {
        const result = resultByOriginalIndex.get(range.source_index + 1);
        if (!result) continue;
        const key = segmentKey(range);
        segmentStoryboards[key] = {
          start: Number(result.start),
          end: Number(result.end),
          duration: Number(result.duration_seconds),
          text: String(result.text || "")
        };
        result.images = segments.find(segment => Number(segment.segment_index) === range.source_index + 1)?.images || [];
      }
      saveSegmentStoryboards();
      const imported = node.__nfh3ImportAudioDriveStoryboards?.(data.segments || [], silentTimeline) || 0;
      renderSegments();
      saveExcludedRanges();
      closeAudioDriveModal();
      node.__nfh3Render?.();
      audioDriveStatus.textContent = `已生成 ${data.segments?.length || 0} 段智能分镜，并已写入外部节点分镜槽位 ${imported} 段；图片已去重看图并按段/槽位复用。`;
    } catch (error) {
      audioDriveStatus.textContent = `生成失败：${error.message}`;
    } finally {
      generateAllStoryboards.disabled = false;
    }
  };
  dialog.append(head, body, backBar);
  modal.append(dialog);
  document.body.append(modal);
  attachSkinOverlay(node, modal);
  audioDriveResizeObserver = new ResizeObserver(resizeAudioDriveCanvas);
  audioDriveResizeObserver.observe(audioDriveCanvas);
  modal.addEventListener("wheel", event => {
    if (!audioDriveSegments.contains(event.target) || Math.abs(event.deltaY) <= Math.abs(event.deltaX)) return;
    const card = event.target.closest?.(".nfh15-audio-drive-segment");
    if (card) {
      const canScrollUp = card.scrollTop > 0,
        canScrollDown = card.scrollTop + card.clientHeight < card.scrollHeight - 1;
      if (event.deltaY < 0 && canScrollUp || event.deltaY > 0 && canScrollDown) return;
    }
    if (audioDriveSegments.scrollWidth <= audioDriveSegments.clientWidth) return;
    event.preventDefault();
    audioDriveSegments.scrollLeft += event.deltaY;
  }, {
    passive: false
  });
  requestAnimationFrame(resizeAudioDriveCanvas);
  render();
  loadAudioFile(audioDriveWorkspaceValue(node, "音频驱动文件", ""));
}
function addStyle() {
  if (document.getElementById("nfh15-v42-style")) return;
  for (const id of ["nfh15-v20-style", "nfh15-v15-style", "nfh15-v18-style", "nfh15-v19-style", "nfh15-v25-style", "nfh15-v29-style", "nfh15-v30-style", "nfh15-v31-style", "nfh15-v32-style", "nfh15-v33-style", "nfh15-v34-style", "nfh15-v41-style"]) document.getElementById(id)?.remove();
  const s = document.createElement("style");
  s.id = "nfh15-v42-style";
  s.textContent = `
.nfh15-shell{position:relative;width:100%;height:100%;min-width:0;min-height:0;overflow:hidden}.nfh3{container-type:inline-size;width:100%!important;max-width:100%!important;min-width:0;height:100%!important;max-height:100%!important;align-self:stretch;font:12px 'Microsoft YaHei UI',sans-serif;color:#f6f1ff;background:radial-gradient(circle at 10% 0%,#51317166 0,transparent 34%),radial-gradient(circle at 96% 18%,#203f5f55 0,transparent 30%),linear-gradient(155deg,#24152f 0%,#120d1c 38%,#090811 72%,#191025 100%);border:1px solid #a77adc;border-radius:12px;padding:10px;box-sizing:border-box;overflow-x:hidden;overflow-y:scroll;scrollbar-gutter:stable;scrollbar-width:thin;scrollbar-color:#9b6fca #120d1c;display:flex;flex-direction:column;gap:9px;box-shadow:inset 0 1px 0 #d5b6ff2e,inset 0 0 32px #59317a44,0 0 22px #5d358455}
.nfh15-section{flex:none;border:1px solid #684b80;border-radius:10px;background:linear-gradient(145deg,#1b1225e8,#0d0a14e8);overflow:hidden;box-shadow:inset 0 1px 0 #d8bcff12,0 5px 14px #05030877}.nfh15-section-title{display:flex;align-items:center;min-height:40px;padding:10px 12px;color:#f2e5ff;background:#0a0a09;border-bottom:1px solid #282515;font-weight:700;letter-spacing:.2px}.nfh15-constant-trigger{display:grid;grid-template-columns:auto minmax(0,1fr);align-items:center;gap:10px}.nfh15-constant-trigger label{color:#ded39a;font-weight:750;white-space:nowrap}.nfh15-constant-trigger input{width:100%;min-width:0;box-sizing:border-box;padding:8px 10px;background:#0e0e0d;border:1px solid #292719;color:#f0eee6}.nfh15-section>summary{list-style:none;display:flex;align-items:center;justify-content:space-between;padding:10px 12px;color:#f2e5ff;background:linear-gradient(90deg,#503267 0%,#30203e 45%,#1c1729 100%);border-bottom:1px solid transparent;cursor:pointer;font-weight:700;letter-spacing:.2px;user-select:none;text-shadow:0 1px 5px #000}.nfh15-section[open]>summary{border-bottom-color:#72538d;box-shadow:inset 4px 0 0 #b887ee}.nfh15-section>summary::-webkit-details-marker{display:none}.nfh15-section>summary::after{content:'▸';color:#d2adfa;transition:transform .15s}.nfh15-section[open]>summary::after{transform:rotate(90deg)}.nfh15-section-body{display:flex;flex-direction:column;gap:9px;padding:10px;background:linear-gradient(150deg,#17101fe8,#0b0911e8)}.nfh15-section .nfh15-settings{padding:0}
.nfh3 *{box-sizing:border-box;min-width:0;max-width:100%}.nfh15-head{display:flex;align-items:center;justify-content:space-between;gap:8px;flex:none;overflow:hidden;padding:11px 13px;border:1px solid #825ca0;border-radius:10px;background:linear-gradient(100deg,#704394 0%,#3d2853 48%,#193044 100%);box-shadow:inset 0 1px 0 #e5d1ff38,0 6px 18px #07040c99}.nfh15-title{font-size:clamp(11px,1.85cqw,15px);font-weight:800;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-shadow:0 2px 7px #160821}.nfh15-badge{flex:none;white-space:nowrap;font-size:clamp(8px,1.35cqw,12px);color:#baffea;background:linear-gradient(135deg,#143b32,#10231f);border:1px solid #48a887;border-radius:12px;padding:clamp(3px,.6cqw,4px) clamp(6px,1.1cqw,9px);box-shadow:inset 0 1px 0 #a5ffe638}
.nfh15-settings{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:clamp(6px,1.1cqw,9px);flex:none}.nfh15-audio-drive-silent-toggle{min-width:156px!important;border:1px solid #f4d20b!important;background:#121107!important;color:#f4d20b!important;font-weight:900!important}.nfh15-audio-drive-silent-toggle.active{background:#f4d20b!important;color:#080806!important;box-shadow:0 0 0 2px #fff3a344,0 0 18px #f4d20b66!important}.nfh15-audio-drive-silent-toggle.active::before{content:'✓ ';}.nfh15-audio-drive-action{grid-column:1/-1;width:100%;min-height:38px;padding:8px 14px;border:1px solid #66571f!important;border-radius:7px;background:#0b0b08!important;color:#817a4c!important;font:850 13px/1.2 system-ui,sans-serif;letter-spacing:.3px;text-align:center;box-shadow:none!important;transition:none!important}.nfh15-audio-drive-action:disabled{cursor:not-allowed;opacity:.72}.nfh15-audio-drive-action.enabled{background:#f4d20b!important;border-color:#ffe86b!important;color:#090900!important;cursor:pointer;opacity:1}.nfh15-audio-drive-action.enabled:hover,.nfh15-audio-drive-action.enabled:active{background:#f4d20b!important;color:#090900!important;transform:none!important;box-shadow:none!important}.nfh15-audio-drive-modal{position:fixed;z-index:100000;inset:0;display:grid;place-items:center;padding:28px;background:rgba(0,0,0,.82)}.nfh15-audio-drive-dialog{width:min(1440px,96vw);height:min(920px,95vh);display:grid;grid-template-rows:auto 1fr auto;overflow:hidden;border:1px solid #9b852c;border-radius:10px;background:#050504;color:#efe7ad}.nfh15-audio-drive-head{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:14px 18px;border-bottom:1px solid #66571f;background:#171408}.nfh15-audio-drive-head>div{display:flex;align-items:baseline;gap:12px}.nfh15-audio-drive-head b{color:#ffe15a;font-size:17px}.nfh15-audio-drive-head small{color:#a69a5b}.nfh15-audio-drive-api-button{flex:none;min-width:92px;height:34px;border:1px solid #8e7924;border-radius:5px;background:#111107;color:#f4d20b;font-weight:800}.nfh15-audio-drive-api-button.active{background:#f4d20b;color:#080806}.nfh15-audio-drive-api-panel{flex:none;max-height:min(520px,55vh);padding:13px;border:1px solid #66571f;border-radius:6px;background:#0c0c08;overflow-x:hidden;overflow-y:auto;scrollbar-gutter:stable}.nfh15-audio-drive-api-panel[hidden]{display:none}.nfh15-audio-drive-api-intro{display:flex;justify-content:space-between;gap:12px;color:#f4d20b}.nfh15-audio-drive-api-intro span,.nfh15-audio-drive-api-note{color:#9e9455;font-size:11px}.nfh15-audio-drive-api-note{margin-top:5px}.nfh15-audio-drive-api-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:11px}.nfh15-audio-drive-api-grid>div>b{color:#f4d20b}.nfh15-audio-drive-api-panel label{display:block;margin-top:7px;color:#bfb36b}.nfh15-audio-drive-api-panel input{display:block;width:100%;height:32px;margin-top:4px;padding:0 9px;border:1px solid #4e451f;border-radius:4px;background:#080806;color:#eee7b9}.nfh15-audio-drive-model-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:6px}.nfh15-audio-drive-model-row button,.nfh15-audio-drive-api-actions button{min-height:32px;border:1px solid #8e7924;border-radius:4px;background:#15150d;color:#e7d96e;font-weight:750}.nfh15-audio-drive-api-message{min-height:18px;margin-top:9px;color:#d8c87c}.nfh15-audio-drive-api-actions{display:flex;justify-content:flex-end;gap:8px}.nfh15-audio-drive-api-actions [data-audio-drive-api-clear]{border-color:#70312c;color:#efaaa3}.nfh15-audio-drive-api-actions [data-audio-drive-api-save]{background:#f4d20b;color:#080806}.nfh15-audio-drive-footer{display:flex;align-items:center;justify-content:flex-end;gap:10px;min-height:64px;padding:12px 18px;border-top:1px solid #514719;background:#080806;overflow:hidden}.nfh15-audio-drive-footer .nfh15-audio-drive-enable-bar{flex:1 1 auto;width:auto;min-width:0;max-width:none;height:40px}.nfh15-audio-drive-footer>button{flex:0 0 220px;width:220px;min-width:220px;max-width:220px;height:40px;min-height:40px;max-height:40px;margin:0!important}.nfh15-audio-drive-footer .nfh15-audio-drive-back{margin:0}.nfh15-audio-drive-generate-storyboards{min-height:38px;border:1px solid #ffe86b;border-radius:6px;background:#f4d20b;color:#080806;font-weight:900}.nfh15-audio-drive-storyboard{margin-top:10px;border:1px solid #594e1e;border-radius:5px;background:#090906}.nfh15-audio-drive-storyboard>summary{padding:8px;color:#f4d20b;cursor:pointer;font-weight:800}.nfh15-audio-drive-storyboard-settings{padding:0 8px 8px}.nfh15-audio-drive-storyboard-settings label{display:grid;grid-template-columns:1fr 68px;align-items:center;gap:8px;color:#bfb36b}.nfh15-audio-drive-storyboard-settings input{width:68px;height:28px;border:1px solid #514719;background:#050504;color:#f4d20b;text-align:center}.nfh15-audio-drive-storyboard-settings textarea{display:block;width:100%;height:96px;margin-top:8px;padding:8px;resize:vertical;border:1px solid #514719;background:#050504;color:#eee7b9}.nfh15-audio-drive-body{display:grid;grid-template-rows:auto 160px 44px 132px minmax(0,1fr);gap:10px;min-height:0;overflow:hidden;padding:14px 18px;background:#080806}.nfh15-audio-drive-body.api-open{display:block;overflow-y:auto}.nfh15-audio-drive-body.api-open>.nfh15-audio-drive-api-panel{display:block;max-height:none;min-height:min-content}.nfh15-audio-drive-body.api-open>.nfh15-audio-drive-toolbar,.nfh15-audio-drive-body.api-open>.nfh15-audio-drive-waveform,.nfh15-audio-drive-body.api-open>.nfh15-audio-drive-markers,.nfh15-audio-drive-body.api-open>.nfh15-audio-drive-idea-panel,.nfh15-audio-drive-body.api-open>.nfh15-audio-drive-segments{display:none}.nfh15-audio-drive-toolbar{display:flex;align-items:center;flex-wrap:wrap;gap:8px}.nfh15-audio-drive-toolbar button,.nfh15-audio-drive-back{min-height:36px;padding:7px 13px;border:1px solid #66571f;border-radius:7px;background:#111107;color:#e6d88b;font-weight:800}.nfh15-audio-drive-toolbar button:hover,.nfh15-audio-drive-back:hover{border-color:#f4d20b;color:#fff3ae}.nfh15-audio-drive-toolbar button.active{border-color:#ffe15a;background:#f4d20b;color:#080806}.nfh15-audio-drive-exclude{display:inline-flex;align-items:center;gap:7px;min-height:36px;padding:7px 11px;border:1px solid #66571f;border-radius:7px;background:#111107;color:#e6d88b;font-weight:800;cursor:pointer;user-select:none}.nfh15-audio-drive-exclude:hover{border-color:#f4d20b;color:#fff3ae}.nfh15-audio-drive-exclude input{width:16px;height:16px;margin:0;accent-color:#f4d20b;cursor:pointer}.nfh15-audio-drive-toolbar span{margin-left:auto;color:#bfb36b;font-variant-numeric:tabular-nums}.nfh15-audio-drive-waveform{display:block;width:100%;height:160px;min-height:160px;max-height:160px;flex:0 0 160px;border:1px solid #66571f;border-radius:8px;background:#080806;cursor:crosshair}.nfh15-audio-drive-markers{min-height:44px;max-height:44px;padding:10px;border:1px solid #393313;border-radius:7px;background:#0b0b08;color:#d8c87c;overflow:auto;white-space:pre-wrap;font-variant-numeric:tabular-nums}.nfh15-audio-drive-idea-panel{height:132px;min-height:132px;max-height:132px;padding:8px;border:2px solid #c9aa22;border-radius:7px;background:#171407}.nfh15-audio-drive-idea-head{display:flex;align-items:baseline;justify-content:space-between;gap:14px;height:26px;padding:0 3px}.nfh15-audio-drive-idea-head b{color:#ffe15a;font-size:14px}.nfh15-audio-drive-idea-head span{color:#c9bd72;font-size:11px}.nfh15-audio-drive-idea{display:block;width:100%;height:96px;min-height:96px;max-height:96px;padding:10px 12px;resize:none;border:1px solid #8e7924;border-radius:5px;background:#050504;color:#fff4b0;font-size:13px;line-height:1.5}.nfh15-audio-drive-idea::placeholder{color:#8f864f}.nfh15-audio-drive-idea:focus{outline:none;border-color:#ffe15a;background:#0b0a04}.nfh15-audio-drive-segment.current{border-color:#ffe15a;background:#171408;outline:2px solid #8f7924}.nfh15-audio-drive-segment.disabled{opacity:.62;border-color:#3d371b}.nfh15-audio-drive-segment-enable{position:absolute;right:8px;top:8px;display:flex;align-items:center;gap:5px;color:#ffe15a;font-size:11px;font-weight:900}.nfh15-audio-drive-segment-enable input{width:16px;height:16px;accent-color:#f4d20b}.nfh15-audio-drive-segment-title{position:relative;padding-right:66px!important}.nfh15-audio-drive-enable-bar{display:flex;align-items:center;gap:8px;min-height:36px;padding:5px 8px;border:1px solid #66571f;border-radius:5px;background:#0b0b07}.nfh15-audio-drive-enable-bar span{flex:1;color:#c8bd75}.nfh15-audio-drive-enable-bar button{min-width:70px;height:28px;border:1px solid #8e7924;border-radius:4px;background:#171408;color:#f4d20b;font-weight:800}.nfh15-audio-drive-segments{display:flex;flex-direction:row;flex-wrap:nowrap;align-items:flex-start;gap:12px;width:100%;min-width:0;height:356px;min-height:356px;max-height:356px;padding:2px 4px 16px 0;overflow-x:scroll;overflow-y:hidden;overscroll-behavior-x:contain;scrollbar-gutter:stable;scrollbar-color:#d1b52d #161409}.nfh15-audio-drive-segments::-webkit-scrollbar{height:14px;background:#161409}.nfh15-audio-drive-segments::-webkit-scrollbar-thumb{background:#d1b52d;border:2px solid #161409;border-radius:7px}.nfh15-audio-drive-segment{flex:0 0 220px;width:220px;min-width:220px;max-width:220px;height:300px;min-height:300px;max-height:300px;padding:8px;border:1px solid #66571f;border-radius:8px;background:#0b0b08;overflow-x:hidden;overflow-y:auto;scrollbar-gutter:stable}.nfh15-audio-drive-segment-title{display:grid;grid-template-columns:1fr;align-items:start;gap:4px;margin-bottom:10px;color:#ffe15a}.nfh15-audio-drive-segment-title span{color:#fff3ae;font-variant-numeric:tabular-nums}.nfh15-audio-drive-segment-title small{justify-self:start;color:#9e9455}.nfh15-audio-drive-image-list{display:flex;flex-direction:column;gap:7px}.nfh15-audio-drive-image-row{display:grid;grid-template-columns:38px 78px 40px;align-items:center;justify-content:start;gap:5px;min-height:88px;padding:3px 1px;border-bottom:1px solid #302b10}.nfh15-v2-frame-control{grid-column:1/-1;display:grid;grid-template-rows:auto auto;grid-template-columns:minmax(0,1fr);align-items:center;gap:3px;width:100%;padding:8px 2px 9px}.nfh15-v2-frame-control>b{display:block;color:#ff6b6b;font-size:12px;line-height:18px;white-space:normal}.nfh15-v2-frame-control input[type="range"]{display:block;width:100%;height:34px;margin:0;padding:5px 0;accent-color:#ff3030;cursor:ew-resize;touch-action:none}.nfh15-audio-drive-image-row.drag-target,.nfh15-audio-drive-image-row.move-selected{border-color:#f4d20b;background:#1a1708}.nfh15-audio-drive-image-row>b{color:#f4d20b}.nfh15-audio-drive-image-preview{display:grid;place-items:center;width:78px;height:78px;min-width:78px;max-width:78px;min-height:78px;max-height:78px;aspect-ratio:1/1;overflow:hidden;border:1px dashed #66571f;border-radius:6px;background:#080806;color:#bfb36b;cursor:pointer}.nfh15-audio-drive-image-media{position:relative;width:78px;height:78px}.nfh15-audio-drive-image-move{position:absolute;left:4px;bottom:4px;z-index:2;width:25px;height:25px;padding:0;border:1px solid #a58d2c;border-radius:5px;background:#0b0b08dc;color:#f4d20b}.nfh15-audio-drive-image-preview:hover{border-color:#f4d20b;color:#fff3ae}.nfh15-audio-drive-image-preview img{display:block;width:100%;height:100%;object-fit:contain;background:#050504}.nfh15-audio-drive-image-remove,.nfh15-audio-drive-image-add{min-height:34px;border:1px solid #66571f;border-radius:6px;background:#111107;color:#d8c87c;font-weight:750}.nfh15-audio-drive-image-remove:disabled{opacity:.35}.nfh15-audio-drive-image-add{width:100%;margin-top:9px}.nfh15-audio-drive-image-add:hover:not(:disabled){border-color:#f4d20b;color:#fff3ae}.nfh15-audio-drive-placeholder{text-align:center;color:#d8c87c;font-size:18px}.nfh15-audio-drive-placeholder small{color:#807846;font-size:12px}.nfh15-audio-drive-back{margin:12px 18px 16px;min-height:38px;border:1px solid #66571f;border-radius:7px;background:#111107;color:#e6d88b;font-weight:800}.nfh15-audio-lock-action{grid-column:1/-1;width:100%;min-height:72px;padding:13px 16px;border:1px solid #ffe86b!important;border-radius:7px;background:#f4d20b!important;color:#090900!important;font:800 13px/1.55 system-ui,sans-serif;text-align:left;white-space:normal;cursor:default;box-shadow:none!important;outline:none!important}.nfh15-audio-lock-action:hover,.nfh15-audio-lock-action:active{background:#f4d20b!important;color:#090900!important;transform:none!important;box-shadow:none!important}.nfh15-field{min-width:0;overflow:visible}.nfh15-field label{display:block;color:#b9abc8;margin:0 0 3px 3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.nfh15-field select,.nfh15-field input,.nfh15-prompt textarea{display:block;width:100%;max-width:100%;min-width:0;border:1px solid #604675;border-radius:7px;background:linear-gradient(145deg,#23172e,#110d18);color:#f8f2ff;outline:none;font-size:inherit;box-shadow:inset 0 1px 5px #05030899}.nfh15-field select{color-scheme:dark;background-color:#17101f;color:#fff}.nfh15-field select option{background:#17101f!important;color:#fff!important}.nfh15-field select option:checked{background:#56336f!important;color:#fff!important}.nfh15-field select,.nfh15-field input{height:clamp(27px,4cqw,32px);padding:0 clamp(5px,1cqw,8px);text-overflow:ellipsis}.nfh15-field input[type=checkbox]{width:clamp(27px,4cqw,32px)}.nfh15-field select:focus,.nfh15-field input:focus,.nfh15-prompt textarea:focus{border-color:#c28cf1;box-shadow:0 0 0 1px #a36ed2,0 0 11px #8e55bd66}
.nfh15-sigma-preset-manager{display:grid;grid-template-columns:minmax(0,1fr) auto auto auto;gap:5px;margin-top:6px}.nfh15-sigma-preset-manager select,.nfh15-sigma-preset-manager button{min-width:0;height:30px;border:1px solid #4c4727;border-radius:4px;background:#0b0b09;color:#ece7c6}.nfh15-sigma-preset-manager button{padding:0 10px;color:#e3c83c}.nfh15-sigma-preset-manager button:disabled{color:#625f4c;opacity:.6}.nfh15-mode-field{grid-column:1/-1}.nfh15-modes{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px}.nfh15-mode-switch{display:grid;grid-template-columns:1fr auto;grid-template-areas:'name toggle' 'hint toggle';align-items:center;gap:1px 8px;min-height:48px;padding:7px 9px;border:1px solid #604675;border-radius:9px;background:linear-gradient(145deg,#24172f,#110d18);color:#c8b9d5;cursor:pointer;text-align:left}.nfh15-mode-switch:hover{border-color:#9a70bd;color:#fff}.nfh15-mode-switch.on{background:linear-gradient(135deg,#382047,#23152e 60%,#132a31);border-color:#72c9a9;box-shadow:0 0 12px #4fb08b55,inset 0 1px 0 #fff2}.nfh15-mode-name{grid-area:name;font-weight:800}.nfh15-mode-switch small{grid-area:hint;font-size:9px;color:#9e8fae}.nfh15-mode-switch.on small{color:#8ff0ce}.nfh15-switch-track{grid-area:toggle;position:relative;width:40px;height:22px;border-radius:12px;background:#30243a;border:1px solid #645371;box-shadow:inset 0 2px 5px #0008}.nfh15-switch-knob{position:absolute;left:2px;top:2px;width:16px;height:16px;border-radius:50%;background:#91849d;transition:left .16s,background .16s}.nfh15-mode-switch.on .nfh15-switch-track{background:#225e4d;border-color:#70d6b3}.nfh15-mode-switch.on .nfh15-switch-knob{left:20px;background:#caffed;box-shadow:0 0 8px #73e4bd}.nfh15-mode-switch.on .nfh15-switch-track::after{content:'开';position:absolute;left:5px;top:3px;font-size:9px;color:#bdffe8}.nfh15-mode-switch:not(.on) .nfh15-switch-track::after{content:'关';position:absolute;right:5px;top:3px;font-size:9px;color:#93899c}.nfh15-tab.disabled,.nfh15-drop.disabled,.nfh15-card.disabled{opacity:.34;filter:grayscale(.8);pointer-events:none}.nfh15-mode-note{grid-column:1/-1;color:#8fdcbf;border:1px solid #356e5d;background:#0d241d;border-radius:7px;padding:6px 9px}.nfh15-sigma-profiles{grid-column:1/-1;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px;margin-top:3px}.nfh15-sigma-profile-option{display:grid;grid-template-columns:22px 1fr;gap:7px;align-items:start;padding:8px;border:1px solid #503d5d;border-radius:8px;background:#160f1e;color:#887b92;opacity:.58}.nfh15-sigma-profile-option b{display:block;font-size:11px;color:#a597af}.nfh15-sigma-profile-option small{display:block;margin-top:3px;font-size:9px;line-height:1.35;color:#7e7287}.nfh15-sigma-check{display:grid;place-items:center;width:18px;height:18px;border:1px solid #65556e;border-radius:4px;color:transparent;background:#251b2d;font-weight:900}.nfh15-sigma-profile-option.active{opacity:1;border-color:#63d8ae;background:linear-gradient(135deg,#12352b,#182231);box-shadow:0 0 10px #35b98a44}.nfh15-sigma-profile-option.active .nfh15-sigma-check{color:#092117;background:#8ff0ce;border-color:#b8ffe5}.nfh15-sigma-profile-option.active b{color:#baffea}.nfh15-sigma-profile-option.active small{color:#92d9c0}
@container (max-width:350px){.nfh15-settings{grid-template-columns:1fr}.nfh15-prompt label{align-items:flex-start;flex-direction:column}}
.nfh15-resolution{white-space:normal;overflow-wrap:anywhere;color:#a8f2d8;background:linear-gradient(100deg,#12372e,#10221f 55%,#17243a);border:1px solid #3b8b72;border-radius:7px;padding:clamp(5px,1.1cqw,7px) clamp(6px,1.3cqw,10px);flex:none;box-shadow:inset 0 1px 8px #06130f99}.nfh15-prompt{position:relative;flex:none;min-width:0}.nfh15-prompt label{display:flex;justify-content:space-between;gap:4px;color:#cfbdec;margin:0 3px 4px}.nfh15-prompt small{color:#75dbb8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.nfh15-prompt textarea{display:block;height:clamp(340px,62cqw,520px);padding:clamp(5px,1.2cqw,9px) clamp(6px,1.3cqw,10px);resize:vertical;min-height:340px;line-height:1.45;font:clamp(9px,1.6cqw,13px) 'Microsoft YaHei UI',sans-serif}.nfh15-prompt textarea:disabled,.nfh15-prompt textarea.linked{background:#0c0912;color:#85788f;border-color:#5c466d;cursor:not-allowed;opacity:.78}.nfh15-prompt-tool:disabled{opacity:.42;cursor:not-allowed;filter:saturate(.35);transform:none!important}
.nfh15-storyboard-bar{display:grid;grid-template-columns:1fr;gap:8px;margin-top:9px}.nfh15-storyboard-tabs{display:grid;grid-template-columns:repeat(auto-fit,minmax(86px,1fr));gap:7px;width:100%;padding:2px}.nfh15-storyboard-actions{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px;width:100%}.nfh15-storyboard-action.batch{grid-column:1/-1;border-color:#3d8e88;background:linear-gradient(135deg,#153e42,#10272d);color:#dffffb;font-weight:800}.nfh15-storyboard-action.batch:hover{border-color:#69cfc3;background:linear-gradient(135deg,#1c5555,#14343a)}.nfh15-storyboard-tab,.nfh15-storyboard-action{width:100%;height:32px;border:1px solid #684d7f;border-radius:7px;background:#181020;color:#cdbbdd;padding:0 10px;cursor:pointer;white-space:nowrap}.nfh15-storyboard-tab.queued-range{border-color:#568e8c;background:linear-gradient(135deg,#24373b,#1b2c33);color:#c5eeea;box-shadow:inset 0 0 0 1px #78bbb62b}.nfh15-storyboard-tab.active{border-color:#73e0d5;background:linear-gradient(135deg,#286f6b,#234852 62%,#293a52);color:#fff;box-shadow:0 0 11px #57c8be78,inset 0 1px 0 #dfffff38}.nfh15-storyboard-action:hover,.nfh15-storyboard-tab:hover{border-color:#bc8be2;color:#fff}.nfh15-storyboard-time-icon{display:inline-grid;place-items:center;width:15px;height:15px;margin-right:4px;border:1px solid currentColor;border-radius:50%;font-size:10px;line-height:1;vertical-align:-1px}.nfh15-storyboard-tab.active .nfh15-storyboard-time-icon{color:#111}.nfh15-storyboard-action:disabled{opacity:.35;cursor:not-allowed}.nfh15-batch-icon{display:inline-grid;place-items:center;width:26px;height:26px;margin-right:8px;border-radius:8px;background:linear-gradient(135deg,#fff1a6 0%,#ffb648 42%,#ff7657 100%);color:#351504;font-size:14px;font-weight:1000;box-shadow:0 0 13px #ffad5199,inset 0 1px 0 #fffbd4;vertical-align:middle;transition:transform .16s ease,box-shadow .16s ease}.nfh15-storyboard-action.batch{min-height:44px;height:44px;border-color:#ffb85e;color:#fff8e8;background:linear-gradient(110deg,#8f3f55 0%,#76504d 42%,#18676b 100%);font-size:12.5px;font-weight:850;letter-spacing:.25px;text-shadow:0 1px 3px #35151ccc;box-shadow:0 8px 20px #160b1699,0 0 0 1px #ffbd6140,inset 0 1px 0 #fff2c94d;transition:transform .16s ease,border-color .16s ease,filter .16s ease,box-shadow .16s ease}.nfh15-storyboard-action.batch:hover{border-color:#ffe09c;color:#fff;background:linear-gradient(110deg,#ad4b61 0%,#92614e 43%,#1f7d7b 100%);filter:saturate(1.12) brightness(1.08);transform:translateY(-1px);box-shadow:0 10px 24px #160b16b8,0 0 16px #ffb65352,inset 0 1px 0 #fff7d76b}.nfh15-storyboard-action.batch:hover .nfh15-batch-icon{transform:scale(1.08);box-shadow:0 0 17px #ffc067c4,inset 0 1px 0 #fffbd4}.nfh15-storyboard-action.batch:active{transform:translateY(0);filter:brightness(.98)}
.nfh15-prompt-tools{display:flex;align-items:center;gap:7px;flex-wrap:wrap;padding:8px 9px;border:1px solid #674a7c;border-radius:9px;background:linear-gradient(135deg,#1e1428,#100c16);box-shadow:inset 0 1px 0 #fff1}.nfh15-prompt-tools.hidden{display:none}.nfh15-prompt-tools-title{flex:none;color:#bba7cb;font-weight:700;margin-right:2px}.nfh15-prompt-tool{flex:none;width:46px;height:46px;border-radius:50%;border:1px solid #9b6fc0;background:radial-gradient(circle at 35% 25%,#71458f,#352043 62%,#1b1223);color:#fff;font:700 11px 'Microsoft YaHei UI',sans-serif;cursor:pointer;box-shadow:inset 0 1px 0 #fff3,0 3px 9px #05030899}.nfh15-prompt-tool:hover{border-color:#d4a6f7;background:radial-gradient(circle at 35% 25%,#9864ba,#4a2a5e 62%,#24152e);transform:translateY(-1px)}.nfh15-prompt-tool:active{transform:translateY(1px)}.nfh15-prompt-tool.subject{border-color:#c88b55;background:radial-gradient(circle at 35% 25%,#9a653d,#50321f 62%,#25170f)}
.nfh15-prompt-tool.template{border-color:#ffd56a;background:radial-gradient(circle at 35% 25%,#ffe69a,#b9851f 48%,#5a3907 78%,#261704);color:#211200;text-shadow:0 1px 0 #fff8;box-shadow:inset 0 1px 0 #fff9,0 0 12px #e9af35aa}.nfh15-prompt-tool.template:hover{border-color:#fff0ac;background:radial-gradient(circle at 35% 25%,#fff3bd,#d5a02c 52%,#70480b 82%)}
.nfh15-prompt-tool.help{border-color:#68d9ce;background:radial-gradient(circle at 35% 25%,#4b9e9a,#24535c 58%,#10242c);color:#ecfffd;font-size:11px}.nfh15-prompt-tool.help:hover{border-color:#a7fff5;background:radial-gradient(circle at 35% 25%,#69bbb4,#2f6971 58%,#15323b)}.nfh15-smart-storyboard{flex:none;margin-left:auto;min-width:148px;height:38px;padding:0 14px;border:1px solid #333;border-radius:9px;background:#050505;color:#fff;font:700 12px 'Microsoft YaHei UI',sans-serif;letter-spacing:.1px;cursor:pointer;box-shadow:inset 0 1px 0 #ffffff1a,0 3px 9px #0008}.nfh15-smart-storyboard:hover{border-color:#666;background:#111;transform:translateY(-1px)}.nfh15-smart-storyboard:active{transform:translateY(1px)}.nfh15-smart-storyboard:disabled{opacity:.45;cursor:not-allowed;transform:none}.nfh15-prompt-help{display:none;flex:1 0 100%;margin-top:2px;padding:10px 11px;border:1px solid #4e8e91;border-radius:8px;background:linear-gradient(145deg,#14252d,#11141e);color:#dbeff0;line-height:1.55}.nfh15-prompt-help.open{display:block}.nfh15-prompt-help strong{color:#ffe09a}.nfh15-prompt-help .focus{margin-bottom:7px;padding:6px 8px;border-left:3px solid #e4ad43;background:#322817;color:#ffe9b6}.nfh15-prompt-help .warning{margin:7px 0;padding:7px 8px;border-left:3px solid #66d1c8;background:#122c30;color:#d6fffa}.nfh15-prompt-help dl{display:grid;grid-template-columns:max-content 1fr;gap:6px 9px;margin:0}.nfh15-prompt-help dt{color:#d6acf3;font-weight:700}.nfh15-prompt-help dd{margin:0;color:#c9d5dc}.nfh15-prompt-help code{color:#a9f1e1;background:#0c171c;padding:1px 4px;border-radius:3px;overflow-wrap:anywhere}
.nfh15-mentions{display:none;position:absolute;left:clamp(4px,1cqw,8px);right:clamp(4px,1cqw,8px);top:clamp(30px,5.2cqw,42px);z-index:10000;max-height:210px;overflow-y:auto;background:#171020;border:1px solid #8a65ba;border-radius:9px;padding:clamp(3px,.8cqw,6px);box-shadow:0 10px 30px #000b}.nfh15-mention{display:flex;align-items:center;gap:clamp(4px,1cqw,8px);width:100%;height:clamp(30px,5.2cqw,42px);border:0;border-radius:7px;background:transparent;color:#eee;text-align:left;padding:3px clamp(4px,1cqw,7px);cursor:pointer;overflow:hidden}.nfh15-mention:hover,.nfh15-mention.active{background:#5a3b78}.nfh15-mention img{width:clamp(24px,4.2cqw,34px);height:clamp(24px,4.2cqw,34px);border-radius:5px;object-fit:cover}.nfh15-mention-icon{flex:none;width:clamp(24px,4.2cqw,34px);height:clamp(24px,4.2cqw,34px);border-radius:5px;background:#2d2239;display:flex;align-items:center;justify-content:center;color:#cdb3ec}
.nfh15-tabs{display:flex;gap:clamp(3px,.9cqw,7px);flex:none}.nfh15-tab{min-width:0;flex:1;border:1px solid #5d456f;background:linear-gradient(145deg,#2a1c35,#17101f);color:#c8b9d5;border-radius:8px;padding:clamp(5px,1.1cqw,9px) 2px;cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:inherit;box-shadow:inset 0 1px 0 #fff1}.nfh15-tab:hover{border-color:#9a70bd;color:#f0e1ff}.nfh15-tab.active{background:linear-gradient(135deg,#9a64c7,#603b80 55%,#3b2f6d);color:white;border-color:#d0a2f5;box-shadow:inset 0 1px 0 #efdfff55,0 0 12px #8855b477}.nfh15-drop{border:1px dashed #80659d;border-radius:9px;padding:clamp(5px,1.2cqw,9px);text-align:center;color:#b8aac6;background:#0d0a11;cursor:pointer;flex:none;white-space:normal;overflow-wrap:anywhere}.nfh15-drop.drag{border-color:#c09bed;background:#2b1d3a}.nfh15-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:clamp(3px,1cqw,8px);flex:none}.nfh15-card{position:relative;min-width:0;aspect-ratio:1/1;height:auto;border:1px solid #453452;border-radius:9px;background:#09070d;overflow:hidden;padding:clamp(2px,.7cqw,5px);cursor:grab}.nfh15-card.dragging{opacity:.35}.nfh15-card.drag-target{border:2px solid #b58be6;background:#2a1c36}.nfh15-card img{display:block;width:100%;height:calc(100% - 20px);object-fit:contain;border-radius:6px}.nfh15-empty{width:100%;height:calc(100% - 20px);display:flex;align-items:center;justify-content:center;color:#776a82;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.nfh15-label{display:block;width:100%;height:20px;line-height:20px;padding:0 5px;color:#d4c0ef;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.nfh15-media-player{display:block;width:100%;height:calc(100% - 20px);min-height:54px;padding:8px;background:linear-gradient(145deg,#181220,#0b0910);border-radius:6px}.nfh15-media-player audio{display:block;width:100%;height:54px;margin-top:calc(50% - 27px);max-width:none}.nfh15-replace{position:absolute;right:clamp(25px,4cqw,31px);top:clamp(2px,.7cqw,5px);height:clamp(18px,3cqw,23px);border:1px solid #7d65a0;border-radius:7px;background:#352445;color:#eadcff;cursor:pointer;padding:0 7px;font-size:11px}.nfh15-replace:hover{background:#5a3b78;border-color:#b58be6}.nfh15-x{position:absolute;right:clamp(2px,.7cqw,5px);top:clamp(2px,.7cqw,5px);width:clamp(18px,3cqw,23px);height:clamp(18px,3cqw,23px);border:0;border-radius:7px;background:#65263a;color:#ffc0ce;cursor:pointer;padding:0}.nfh15-note{color:#72dcb8;flex:none;white-space:normal;overflow-wrap:anywhere}.nfh15-preview{border:1px solid #4b395c;border-radius:10px;background:#09070d;overflow:hidden;flex:none;height:64px}.nfh15-preview-head{display:flex;justify-content:space-between;gap:5px;padding:10px 12px;color:#d3c0ed;background:#181121;overflow:hidden}.nfh15-preview-head span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.nfh15-preview-state{color:#75ddba}.nfh15-progress{height:12px;margin:8px 12px;background:#271b31;border-radius:6px;overflow:hidden}.nfh15-progress i{display:block;width:0;height:100%;background:linear-gradient(90deg,#7653a6,#c5a0ef);transition:width .12s}.nfh15-advanced{border:1px solid #3e304a;border-radius:8px;background:#110d17;flex:none;overflow:hidden}.nfh15-advanced summary{padding:clamp(4px,1cqw,8px) clamp(6px,1.3cqw,10px);color:#ceb9e9;cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.nfh15-advanced .nfh15-settings{padding:0 clamp(4px,1cqw,8px) clamp(4px,1cqw,8px)}
.nfh15-v9-live-preview{display:flex;flex-direction:column;flex:none;height:430px;border:1px solid #2c7279;border-radius:12px;background:#030709;overflow:hidden;box-shadow:inset 0 1px #9dffff12,0 10px 28px #0008}.nfh15-v9-preview-head{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:9px 12px;color:#d9fffb;background:linear-gradient(90deg,#0d3439,#101b24);border-bottom:1px solid #285b61}.nfh15-v9-preview-head small{color:#70b8b6}.nfh15-v9-preview-stage{position:relative;display:grid;place-items:center;flex:1;min-width:0;min-height:0;padding:8px;background:radial-gradient(circle at 50% 45%,#11272c,#030709 68%);overflow:hidden}.nfh15-v9-preview-stage img,.nfh15-v9-preview-stage video{display:block;width:auto;height:auto;max-width:100%;max-height:100%;aspect-ratio:var(--nfh15-preview-aspect,auto);object-fit:contain;object-position:center;border-radius:4px;background:#000}.nfh15-v9-preview-stage[data-orientation="portrait"] img,.nfh15-v9-preview-stage[data-orientation="portrait"] video{height:100%;width:auto}.nfh15-v9-preview-stage[data-orientation="landscape"] img,.nfh15-v9-preview-stage[data-orientation="landscape"] video{width:100%;height:auto}.nfh15-v9-preview-empty{text-align:center;color:#60878a;line-height:1.7}.nfh15-v9-preview-status{padding:7px 10px;color:#8ed8d2;background:#071216;border-top:1px solid #173f45;font-size:11px;font-variant-numeric:tabular-nums}
.nfh3.nfh15-v9-horizontal{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));grid-template-rows:auto minmax(0,1fr);gap:12px;overflow:hidden;padding:12px;background-color:#050504!important;background-image:linear-gradient(90deg,rgba(3,3,2,.24) 0%,rgba(7,7,4,.16) 38%,rgba(7,7,3,.10) 64%,rgba(2,2,1,.20) 100%),var(--nfh15-v9-bg)!important;background-size:100% 100%,100% 100%!important;background-repeat:no-repeat,no-repeat!important;background-position:center center,center center!important;border-color:#9b852c!important;box-shadow:inset 0 1px 0 rgba(255,226,88,.18),0 18px 48px rgba(0,0,0,.8)!important}.nfh15-v9-horizontal .nfh15-head{border-color:#a78c27!important;background:linear-gradient(100deg,#171408ed,#30270be8 50%,#080806ec)!important}.nfh15-v9-horizontal .nfh15-title,.nfh15-v9-horizontal .nfh15-section>summary,.nfh15-v9-horizontal .nfh15-primary-fold>summary{color:#fff3ae!important}.nfh15-v9-horizontal .nfh15-section,.nfh15-v9-horizontal .nfh15-primary-fold,.nfh15-v9-horizontal .nfh15-advanced{border-color:#66571f!important;background:rgba(5,5,3,.46)!important;backdrop-filter:blur(2px)!important;-webkit-backdrop-filter:blur(2px)!important}.nfh15-v9-horizontal .nfh15-section>summary,.nfh15-v9-horizontal .nfh15-primary-fold>summary{background:linear-gradient(90deg,#332b0ce8,#171405e8,#080807e8)!important;border-bottom-color:#66571f!important}.nfh15-v9-horizontal .nfh15-section-body{background:rgba(4,4,3,.40)!important}.nfh15-v9-horizontal .nfh15-storyboard-tab{border-color:#6c5c23;background:#111107;color:#d8c87c}.nfh15-v9-horizontal .nfh15-storyboard-tab.queued-range{border-color:#83712c;background:linear-gradient(135deg,#201b09,#0e0e08);color:#e6d88b}.nfh15-v9-horizontal .nfh15-storyboard-tab.active{border-color:#ffe15a;background:linear-gradient(135deg,#8a7114,#4b3d08 58%,#151407);color:#fff7c8;box-shadow:0 0 13px rgba(255,220,55,.55),inset 0 1px rgba(255,255,210,.25)}.nfh15-v9-horizontal .nfh15-storyboard-action.batch{border-color:#b89720!important;background:linear-gradient(135deg,#4d3e08,#171405)!important;color:#fff2a8!important}.nfh15-v9-horizontal .nfh15-field select,.nfh15-v9-horizontal .nfh15-field input,.nfh15-v9-horizontal .nfh15-prompt textarea{border-color:#66571f!important;background:linear-gradient(145deg,#151307,#070705)!important}.nfh15-v9-horizontal .nfh15-note{color:#e0c94f!important}.nfh15-v9-horizontal>.nfh15-liquid-scene{display:none!important;grid-column:1/-1;grid-row:1/-1}.nfh15-v9-horizontal>.nfh15-head{grid-column:1/-1}.nfh15-v9-column{position:relative;z-index:2;display:flex;flex-direction:column;gap:11px;min-width:0;min-height:0;overflow-x:hidden;overflow-y:auto;padding:1px 5px 8px 1px;scrollbar-width:thin;scrollbar-color:#3b7f86 transparent}.nfh15-v9-column>.nfh15-section,.nfh15-v9-column>.nfh15-primary-fold,.nfh15-v9-column>.nfh15-advanced{flex:none}.nfh15-v9-horizontal .nfh15-settings{grid-template-columns:repeat(2,minmax(0,1fr))}.nfh15-v9-horizontal .nfh15-prompt{display:grid!important;grid-template-rows:auto 600px 268px!important;gap:9px!important;min-height:0}.nfh15-v9-horizontal .nfh15-prompt textarea{grid-row:2;height:600px!important;min-height:600px!important;max-height:600px!important;resize:none}.nfh15-v9-horizontal .nfh15-storyboard-bar{grid-row:3;position:static!important;display:grid!important;grid-template-rows:146px 114px!important;gap:8px!important;height:268px!important;min-height:268px!important;max-height:268px!important;overflow:hidden!important;align-self:stretch}.nfh15-v9-horizontal .nfh15-storyboard-tabs{position:static!important;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));grid-auto-rows:32px;height:146px;max-height:146px;overflow-x:hidden;overflow-y:auto;align-content:start;padding:2px 5px 4px 2px;scrollbar-gutter:stable;scrollbar-width:thin;scrollbar-color:#4d9695 #10171b}.nfh15-v9-horizontal .nfh15-storyboard-actions{position:static!important;z-index:auto!important;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px;margin:0!important;padding-top:8px;border-top:1px solid rgba(101,210,204,.2);background:#071014;transform:none!important}.nfh15-v9-horizontal .nfh15-storyboard-action.batch{position:relative;z-index:1;grid-column:1/-1}.nfh15-v9-horizontal .nfh15-v9-live-preview{height:500px}.nfh15-v9-horizontal>.nfh15-v9-column:first-of-type>.nfh15-mode-field{flex:none;margin:0;padding:12px;border-bottom:1px solid rgba(255,255,255,.12)}.nfh15-v9-horizontal .nfh15-media-external-drag{outline:2px dashed #6de0d5;outline-offset:-5px;background:linear-gradient(145deg,#10343ad9,#09171dd9)!important;box-shadow:inset 0 0 35px #45cab53b}.nfh15-v9-horizontal .nfh15-media-external-drag>summary{color:#cafff9!important}.nfh15-v9-horizontal>.nfh15-v9-column:nth-of-type(2)>.nfh15-prompt-tools{flex:none;margin:0 0 2px}.nfh15-v9-horizontal>.nfh15-v9-column:nth-of-type(3)>.nfh15-section:first-child{order:-10}.nfh15-v9-horizontal>.nfh15-v9-column:nth-of-type(3)>.nfh15-section:first-child>summary{display:none}.nfh15-v9-horizontal>.nfh15-v9-column:nth-of-type(3)>.nfh15-section:first-child>.nfh15-section-body{padding-top:0!important}
/* V3主功能折叠：与“高级模型、注意力与采样设置”保持同尺寸、同紫色层级，避免缩放后看不清。 */
.nfh15-primary-fold{border:1px solid #684b80;border-radius:10px;background:linear-gradient(145deg,#1b1225e8,#0d0a14e8);box-shadow:inset 0 1px 0 #d8bcff12,0 5px 14px #05030877}
.nfh15-primary-fold>summary{list-style:none;display:flex;align-items:center;justify-content:space-between;min-height:42px;padding:10px 12px;color:#f2e5ff;background:linear-gradient(90deg,#503267 0%,#30203e 45%,#1c1729 100%);border-bottom:1px solid transparent;cursor:pointer;font-weight:700;letter-spacing:.2px;user-select:none;text-shadow:0 1px 5px #000;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.nfh15-primary-fold[open]>summary{border-bottom-color:#72538d;box-shadow:inset 4px 0 0 #b887ee}.nfh15-primary-fold>summary::-webkit-details-marker{display:none}.nfh15-primary-fold>summary::after{content:'▸';color:#d2adfa;transition:transform .15s;flex:none;margin-left:8px}.nfh15-primary-fold[open]>summary::after{transform:rotate(90deg)}
.nfh15-primary-fold>.nfh15-settings{padding:10px}.nfh15-lora-settings>.nfh15-field:first-child{grid-column:1/-1}.nfh15-lora-settings>.nfh15-field:nth-child(2n){grid-column:1}.nfh15-lora-settings>.nfh15-field:nth-child(2n+1):not(:first-child){grid-column:2}
/* V7 月面玻璃主题：暖雾粉背景、半透明乳白卡片、石墨按钮与柔和高光。 */
.nfh15-v7-light{--glass:#ffffff82;--glass-strong:#ffffffe0;--glass-soft:#f6ecea9e;--stroke:#ffffffb8;--stroke-dark:#a895932e;--ink:#292525;--muted:#746a68;--accent:#9b7775;--graphite:#242323;color:var(--ink);background:radial-gradient(circle at 13% 2%,#fffaf3 0,transparent 27%),radial-gradient(circle at 91% 13%,#efd7d2d9 0,transparent 32%),radial-gradient(circle at 48% 73%,#dce6e8c4 0,transparent 38%),linear-gradient(155deg,#ead8d5 0%,#f5e9e2 38%,#d8e1e3 72%,#c8d2d5 100%);border:2px solid #ffffffed;border-radius:26px;padding:15px;gap:12px;scrollbar-color:#8e7d7a80 #ffffff38;box-shadow:inset 0 2px 0 #fff,inset 0 0 70px #ffffff5e,0 32px 80px #4d3e3b42;backdrop-filter:blur(36px) saturate(155%) contrast(104%);-webkit-backdrop-filter:blur(36px) saturate(155%) contrast(104%)}
.nfh15-v7-light .nfh15-head{padding:15px 17px;border:1px solid var(--stroke);border-radius:17px;background:linear-gradient(130deg,#ffffffe8,#f7ebe9a6 55%,#dce5e6a0);box-shadow:inset 0 1px 0 #fff,0 14px 36px #6a514b1f;backdrop-filter:blur(18px) saturate(145%)}.nfh15-v7-light .nfh15-title{color:#272222;font-size:clamp(12px,2cqw,16px);font-weight:760;text-shadow:none;letter-spacing:.45px}.nfh15-v7-light .nfh15-badge{color:#3a3332;background:#ffffff8f;border:1px solid #ffffffd1;border-radius:999px;padding:5px 10px;box-shadow:inset 0 1px 0 #fff,0 6px 16px #57444118;backdrop-filter:blur(12px)}
.nfh15-v7-light .nfh15-section,.nfh15-v7-light .nfh15-primary-fold{border:1px solid var(--stroke);border-radius:17px;background:linear-gradient(145deg,#ffffff91,#f6eeec66);box-shadow:inset 0 1px 0 #fff,0 12px 30px #58474418;backdrop-filter:blur(22px) saturate(135%);overflow:hidden}.nfh15-v7-light .nfh15-section>summary,.nfh15-v7-light .nfh15-primary-fold>summary{min-height:48px;padding:12px 15px;color:#302a29;background:linear-gradient(105deg,#ffffffe6,#f8efed9c 55%,#e1e7e89c);border-bottom-color:transparent;text-shadow:none;font-weight:720;letter-spacing:.28px}.nfh15-v7-light .nfh15-section[open]>summary,.nfh15-v7-light .nfh15-primary-fold[open]>summary{border-bottom-color:#ffffffad;box-shadow:inset 4px 0 0 #987976,0 1px 0 #fff}.nfh15-v7-light .nfh15-section>summary::after,.nfh15-v7-light .nfh15-primary-fold>summary::after{color:#8f7673}.nfh15-v7-light .nfh15-section-body{padding:12px;background:linear-gradient(145deg,#ffffff52,#f7efed38)}
.nfh15-v7-light .nfh15-field label,.nfh15-v7-light .nfh15-prompt label,.nfh15-v7-light .nfh15-prompt-tools-title{color:#655b59;font-weight:600}.nfh15-v7-light .nfh15-field select,.nfh15-v7-light .nfh15-field input,.nfh15-v7-light .nfh15-prompt textarea{color:#282424;background:linear-gradient(145deg,#ffffffe8,#f7efedb8);border:1px solid #ffffffd6;border-radius:11px;box-shadow:inset 0 1px 0 #fff,inset 0 -1px 0 #a98e8930,0 7px 18px #5d4b4714;backdrop-filter:blur(14px)}.nfh15-v7-light .nfh15-field select{color-scheme:light;background-color:#f8f0ee}.nfh15-v7-light .nfh15-field select option{background:#faf5f3!important;color:#282424!important}.nfh15-v7-light .nfh15-field select option:checked{background:#d9c8c4!important;color:#211d1c!important}.nfh15-v7-light .nfh15-field select:focus,.nfh15-v7-light .nfh15-field input:focus,.nfh15-v7-light .nfh15-prompt textarea:focus{border-color:#aa8884;box-shadow:0 0 0 2px #ffffffb8,0 0 0 4px #aa888438,0 10px 24px #5c48431d}
.nfh15-v7-light .nfh15-mode-switch{color:#4a4240;background:linear-gradient(145deg,#ffffffa8,#f3e9e680);border:1px solid #ffffffc9;border-radius:13px;box-shadow:inset 0 1px 0 #fff,0 7px 18px #58474414;backdrop-filter:blur(15px)}.nfh15-v7-light .nfh15-mode-switch:hover{color:#241f1e;border-color:#fff;transform:translateY(-1px);box-shadow:inset 0 1px 0 #fff,0 12px 24px #58474420}.nfh15-v7-light .nfh15-mode-switch small{color:#807371}.nfh15-v7-light .nfh15-mode-switch.on{color:#fff;background:linear-gradient(135deg,#4b4443,#242222 72%,#151515);border-color:#ffffff8a;box-shadow:inset 0 1px 0 #ffffff35,0 12px 28px #30272538}.nfh15-v7-light .nfh15-mode-switch.on small{color:#ded5d2}.nfh15-v7-light .nfh15-switch-track{background:#d8ccca;border-color:#ffffffc4;box-shadow:inset 0 2px 5px #58474428}.nfh15-v7-light .nfh15-mode-switch.on .nfh15-switch-track{background:#b78f8b;border-color:#d9b3af}.nfh15-v7-light .nfh15-mode-switch.on .nfh15-switch-knob{background:#fff;box-shadow:0 2px 7px #211c1b55}.nfh15-v7-light .nfh15-mode-switch.on .nfh15-switch-track::after{color:#fff}.nfh15-v7-light .nfh15-mode-switch:not(.on) .nfh15-switch-track::after{color:#756967}
.nfh15-v7-light .nfh15-resolution,.nfh15-v7-light .nfh15-note,.nfh15-v7-light .nfh15-mode-note{color:#554b49;background:linear-gradient(110deg,#ffffffa8,#f1e5e27d 60%,#dce5e67a);border:1px solid #ffffffc7;border-radius:11px;padding:8px 11px;box-shadow:inset 0 1px 0 #fff,0 8px 20px #55433f12;backdrop-filter:blur(14px)}
.nfh15-v7-light .nfh15-storyboard-tab,.nfh15-v7-light .nfh15-storyboard-action,.nfh15-v7-light .nfh15-tab{color:#4c4341;background:linear-gradient(145deg,#ffffffb8,#f0e6e387);border:1px solid #ffffffc9;border-radius:11px;box-shadow:inset 0 1px 0 #fff,0 6px 16px #57454112}.nfh15-v7-light .nfh15-storyboard-action:hover,.nfh15-v7-light .nfh15-storyboard-tab:hover,.nfh15-v7-light .nfh15-tab:hover{color:#211d1c;border-color:#fff;transform:translateY(-1px)}.nfh15-v7-light .nfh15-tab.active,.nfh15-v7-light .nfh15-storyboard-tab.active{color:#fff;background:linear-gradient(135deg,#514947,#272424);border-color:#ffffff9c;box-shadow:inset 0 1px 0 #ffffff38,0 10px 22px #3b302e30}.nfh15-v7-light .nfh15-storyboard-action.danger{color:#8a4f55;border-color:#ffffffc9;background:linear-gradient(145deg,#fff9f8c7,#ecd9d88c)}
.nfh15-v7-light .nfh15-drop,.nfh15-v7-light .nfh15-card,.nfh15-v7-light .nfh15-preview,.nfh15-v7-light .nfh15-advanced,.nfh15-v7-light .nfh15-prompt-tools{color:#5f5452;background:linear-gradient(145deg,#ffffff96,#f2e8e56e);border:1px solid #ffffffbf;border-radius:13px;box-shadow:inset 0 1px 0 #fff,0 9px 22px #57454114;backdrop-filter:blur(16px)}.nfh15-v7-light .nfh15-drop{border-style:dashed}.nfh15-v7-light .nfh15-drop.drag{background:#ffffffbd;border-color:#a9827e}.nfh15-v7-light .nfh15-card{background:linear-gradient(145deg,#ffffffe0,#eee4e1ad)}.nfh15-v7-light .nfh15-card.drag-target{border:2px solid #9f7a76;background:#fff}.nfh15-v7-light .nfh15-empty{color:#988987}.nfh15-v7-light .nfh15-label,.nfh15-v7-light .nfh15-advanced summary{color:#514845}.nfh15-v7-light .nfh15-media-player{background:linear-gradient(145deg,#fdf8f6,#e2dad8)}
.nfh15-v7-light .nfh15-prompt-tools{padding:10px}.nfh15-v7-light .nfh15-prompt-tool{color:#2e2928;border:1px solid #ffffffd1;background:radial-gradient(circle at 35% 25%,#fff,#e7d9d6 65%,#cfc0bd);box-shadow:inset 0 1px 0 #fff,0 8px 18px #57454120;text-shadow:none}.nfh15-v7-light .nfh15-prompt-tool:hover{border-color:#fff;background:radial-gradient(circle at 35% 25%,#fff,#eadbd7 64%,#c4aaa5);transform:translateY(-2px)}.nfh15-v7-light .nfh15-prompt-tool.template{color:#2d2726;border-color:#fff;background:radial-gradient(circle at 35% 25%,#fffdf5,#ead9ba 58%,#c3a77a);text-shadow:none;box-shadow:inset 0 1px 0 #fff,0 8px 20px #7a60442b}.nfh15-v7-light .nfh15-prompt-tool.help{color:#263133;border-color:#fff;background:radial-gradient(circle at 35% 25%,#fff,#cedfe0 62%,#9db7b8)}.nfh15-v7-light .nfh15-prompt-help{color:#463e3c;background:linear-gradient(145deg,#ffffffdf,#eee3e0d1);border-color:#ffffffd4;box-shadow:0 14px 35px #54413d25}.nfh15-v7-light .nfh15-prompt-help strong{color:#5d4642}.nfh15-v7-light .nfh15-prompt-help .focus{color:#594641;background:#eadbd6;border-left-color:#a77d76}.nfh15-v7-light .nfh15-prompt-help .warning{color:#405052;background:#dbe5e5;border-left-color:#829fa0}.nfh15-v7-light .nfh15-prompt-help dt{color:#795b57}.nfh15-v7-light .nfh15-prompt-help dd{color:#554e4c}.nfh15-v7-light .nfh15-prompt-help code{color:#3b3432;background:#e8ddda}.nfh15-v7-light .nfh15-mentions{background:#f7efedf0;border-color:#ffffffd6;box-shadow:0 18px 42px #49393630;backdrop-filter:blur(24px)}.nfh15-v7-light .nfh15-mention{color:#3c3533}.nfh15-v7-light .nfh15-mention:hover,.nfh15-v7-light .nfh15-mention.active{background:#dfcfcb}.nfh15-v7-light .nfh15-mention-icon{color:#725c58;background:#eadfdd}.nfh15-v7-light .nfh15-preview-head{color:#4a4140;background:#ffffff7d}.nfh15-v7-light .nfh15-preview-state{color:#896e6a}.nfh15-v7-light .nfh15-progress{background:#d8cecc}.nfh15-v7-light .nfh15-progress i{background:linear-gradient(90deg,#c89e99,#876d69,#4d4746)}
/* V7 BLUE LIQUID GLASS OVERRIDE */
.nfh15-v7-light{--ink:#153a58;--muted:#6386a0;position:relative;isolation:isolate;color:var(--ink);background:radial-gradient(ellipse at 10% 2%,#fff 0 8%,transparent 32%),radial-gradient(circle at 88% 9%,#3facff80,transparent 29%),radial-gradient(circle at 10% 61%,#c2e8ffb8,transparent 34%),radial-gradient(circle at 87% 80%,#73c5ff6b,transparent 32%),linear-gradient(150deg,#d9f2ff,#9bd2f7 34%,#effaff 62%,#84bee9);border:2px solid #fffffff0;border-radius:30px;padding:16px;box-shadow:inset 0 2px 1px #fff,inset 0 0 70px #ffffff69,inset 0 -2px 4px #2179b42b,0 34px 90px #0f4e8057;backdrop-filter:blur(42px) saturate(180%) contrast(108%);-webkit-backdrop-filter:blur(42px) saturate(180%) contrast(108%)}
.nfh15-v7-light::before{content:"";position:absolute;z-index:-1;inset:9px;border-radius:24px;pointer-events:none;background:linear-gradient(125deg,#ffffff8f,transparent 29%,transparent 70%,#5db4f429);box-shadow:inset 0 1px 0 #fffffff2,inset 0 0 45px #ffffff2b}
.nfh15-v7-light .nfh15-head{position:relative;padding:17px 19px;border:1px solid #ffffffe8;border-radius:20px;background:linear-gradient(128deg,#ffffffd1,#e5f7ff73 52%,#7ec8fa45);box-shadow:inset 0 1px 1px #fff,inset 0 -1px 1px #388bc838,0 16px 38px #1a5b8d33;backdrop-filter:blur(30px) saturate(175%)}.nfh15-v7-light .nfh15-head::after{content:"";position:absolute;left:7%;right:34%;top:1px;height:42%;border-radius:999px;background:linear-gradient(#ffffffb8,transparent);filter:blur(7px);pointer-events:none}.nfh15-v7-light .nfh15-title{color:#123a5b;text-shadow:0 1px 0 #fff;font-weight:780}.nfh15-v7-light .nfh15-badge{color:#0d568d;background:linear-gradient(145deg,#ffffffc7,#bce5ff5e);border-color:#ffffffe8;border-radius:999px;box-shadow:inset 0 1px #fff,0 7px 18px #18639a2b}
.nfh15-v7-light .nfh15-section,.nfh15-v7-light .nfh15-primary-fold{border:1px solid #ffffffe0;border-radius:20px;background:linear-gradient(145deg,#ffffff94,#d6f0ff40);box-shadow:inset 0 1px 1px #fff,inset 0 -1px 1px #2574af2b,0 14px 34px #13507f2b;backdrop-filter:blur(32px) saturate(170%)}.nfh15-v7-light .nfh15-section>summary,.nfh15-v7-light .nfh15-primary-fold>summary{color:#173e5d;background:linear-gradient(108deg,#ffffffc9,#e2f6ff70 56%,#89cdfa3b);text-shadow:0 1px #fff;min-height:50px}.nfh15-v7-light .nfh15-section[open]>summary,.nfh15-v7-light .nfh15-primary-fold[open]>summary{border-bottom-color:#ffffffc2;box-shadow:inset 4px 0 #2d9cff,inset 0 1px #fff}.nfh15-v7-light .nfh15-section-body{background:linear-gradient(145deg,#ffffff3b,#bfe3fa24)}
.nfh15-v7-light .nfh15-field label,.nfh15-v7-light .nfh15-prompt label,.nfh15-v7-light .nfh15-prompt-tools-title{color:#426b8a}.nfh15-v7-light .nfh15-field select,.nfh15-v7-light .nfh15-field input,.nfh15-v7-light .nfh15-prompt textarea{color:#143b5a;background:linear-gradient(145deg,#ffffffc9,#d9f2ff6b);border-color:#ffffffe8;border-radius:13px;box-shadow:inset 0 1px #fff,inset 0 -1px 1px #2b7bb533,0 8px 20px #0f528622}.nfh15-v7-light .nfh15-field select{background-color:#e8f6ff}.nfh15-v7-light .nfh15-field select option{background:#eff9ff!important;color:#153b59!important}.nfh15-v7-light .nfh15-field select option:checked{background:#b9e2ff!important;color:#0b3454!important}.nfh15-v7-light .nfh15-field select:focus,.nfh15-v7-light .nfh15-field input:focus,.nfh15-v7-light .nfh15-prompt textarea:focus{border-color:#fff;box-shadow:0 0 0 2px #ffffffcc,0 0 0 4px #188fe84d,0 12px 26px #0c538930}
.nfh15-v7-light .nfh15-mode-switch{position:relative;color:#275571;background:linear-gradient(145deg,#ffffffa8,#cdecff52);border-color:#ffffffe0;border-radius:999px;box-shadow:inset 0 1px #fff,inset 0 -1px 1px #2b78af24,0 9px 22px #14558624}.nfh15-v7-light .nfh15-mode-switch::before{content:"";position:absolute;left:12%;right:34%;top:2px;height:38%;border-radius:999px;background:linear-gradient(#ffffffc2,transparent);filter:blur(4px);pointer-events:none}.nfh15-v7-light .nfh15-mode-switch:hover{color:#0e3e61;border-color:#fff;transform:translateY(-2px);box-shadow:inset 0 1px #fff,0 14px 30px #0d568d38}.nfh15-v7-light .nfh15-mode-switch small{color:#6c8da5}.nfh15-v7-light .nfh15-mode-switch.on{color:#fff;background:linear-gradient(135deg,#1c97f6f0,#0c5cb4f7 66%,#06377bfa);border-color:#ffffffd6;box-shadow:inset 0 1px #ffffff8c,inset 0 -2px 4px #02245459,0 14px 32px #064d9457}.nfh15-v7-light .nfh15-mode-switch.on small{color:#d9f2ff}.nfh15-v7-light .nfh15-switch-track{background:#a6d1eda6;border-color:#ffffffe0}.nfh15-v7-light .nfh15-mode-switch.on .nfh15-switch-track{background:#0a5dae;border-color:#8fd0ff}
.nfh15-v7-light .nfh15-resolution,.nfh15-v7-light .nfh15-note,.nfh15-v7-light .nfh15-mode-note{color:#315f7d;background:linear-gradient(112deg,#ffffffa1,#d8f1ff57 62%,#83cbfa33);border-color:#ffffffd6;box-shadow:inset 0 1px #fff,0 9px 22px #0e50821f}.nfh15-v7-light .nfh15-storyboard-tab,.nfh15-v7-light .nfh15-storyboard-action,.nfh15-v7-light .nfh15-tab{color:#285672;background:linear-gradient(145deg,#ffffffa6,#caeaff59);border-color:#ffffffdb;border-radius:999px;box-shadow:inset 0 1px #fff,0 8px 18px #12548421}.nfh15-v7-light .nfh15-tab.active,.nfh15-v7-light .nfh15-storyboard-tab.active{color:#fff;background:linear-gradient(135deg,#28a5ff,#0874d4 62%,#07519f);border-color:#dff4ff;box-shadow:inset 0 1px #ffffff80,0 12px 26px #055ba94d}
.nfh15-v7-light .nfh15-drop,.nfh15-v7-light .nfh15-card,.nfh15-v7-light .nfh15-preview,.nfh15-v7-light .nfh15-advanced,.nfh15-v7-light .nfh15-prompt-tools{color:#416c88;background:linear-gradient(145deg,#ffffff87,#c9eaff40);border-color:#ffffffd1;border-radius:16px;box-shadow:inset 0 1px #fff,inset 0 -1px 1px #2b79b121,0 11px 26px #104f7f21}.nfh15-v7-light .nfh15-card{background:linear-gradient(145deg,#ffffffad,#d2efff59)}.nfh15-v7-light .nfh15-empty{color:#7293aa}.nfh15-v7-light .nfh15-label,.nfh15-v7-light .nfh15-advanced summary{color:#315d79}.nfh15-v7-light .nfh15-media-player{background:linear-gradient(145deg,#f4fcffe0,#bee0f499)}
.nfh15-v7-light .nfh15-prompt-tool{color:#16476d;border-color:#ffffffe6;background:radial-gradient(circle at 34% 24%,#fff 0 12%,#d9f1ff 50%,#82c8f6);box-shadow:inset 0 1px #fff,inset 0 -2px 4px #1769a438,0 10px 22px #0d538930}.nfh15-v7-light .nfh15-prompt-tool:hover{background:radial-gradient(circle at 34% 24%,#fff 0 13%,#e4f6ff 48%,#59b3ef);transform:translateY(-3px)}.nfh15-v7-light .nfh15-prompt-help{color:#264d69;background:linear-gradient(145deg,#fafeffe3,#d0edffb5);border-color:#fffffff0;box-shadow:0 18px 44px #0a46733d}.nfh15-v7-light .nfh15-mentions{background:#e9f8ffe0;border-color:#fffffff0;box-shadow:0 20px 48px #073e684a}.nfh15-v7-light .nfh15-mention{color:#244e6c}.nfh15-v7-light .nfh15-mention:hover,.nfh15-v7-light .nfh15-mention.active{background:#99d3f88a}.nfh15-v7-light .nfh15-preview-head{color:#285473;background:#ffffff73}.nfh15-v7-light .nfh15-preview-state{color:#0875bf}.nfh15-v7-light .nfh15-progress{background:#88bee178}.nfh15-v7-light .nfh15-progress i{background:linear-gradient(90deg,#54c1ff,#0b8ee9,#0750ad)}

/* Decorative scene: real depth behind the glass, not another flat gradient. */
.nfh15-v7-light>.nfh15-liquid-scene{position:absolute;z-index:-1;inset:0;overflow:hidden;border-radius:28px;pointer-events:none;transform:translateZ(0)}
.nfh15-liquid-scene .nfh15-orb{position:absolute;display:block;border-radius:50%;background:radial-gradient(circle at 28% 22%,#fff 0 7%,#e5f8ff 16%,#75c7fb 46%,#177bd1 71%,#053d82 100%);box-shadow:inset -12px -16px 26px #063b7f66,inset 9px 10px 20px #ffffffb8,0 20px 44px #064b9345;opacity:.76;filter:saturate(115%)}
.nfh15-liquid-scene .orb-a{width:112px;height:112px;right:-18px;top:82px}.nfh15-liquid-scene .orb-b{width:66px;height:66px;left:24px;top:565px;opacity:.55;filter:blur(.3px)}.nfh15-liquid-scene .orb-c{width:150px;height:150px;right:-58px;top:1120px;opacity:.34;filter:blur(2px)}
.nfh15-liquid-scene .nfh15-ribbon{position:absolute;display:block;border-radius:50%;border:38px solid #c9edff69;box-shadow:inset 0 0 28px #fff9,0 0 50px #2389d54f;filter:blur(3px);transform:rotate(-23deg)}.nfh15-liquid-scene .ribbon-a{width:430px;height:230px;left:-245px;top:265px}.nfh15-liquid-scene .ribbon-b{width:510px;height:290px;right:-360px;top:760px;transform:rotate(38deg);opacity:.55}
.nfh15-liquid-scene .nfh15-crystal{position:absolute;display:block;width:128px;height:155px;right:20px;top:470px;transform:rotate(16deg);filter:drop-shadow(0 25px 26px #06487c45);opacity:.72}.nfh15-liquid-scene .nfh15-crystal b{position:absolute;inset:0;display:block;clip-path:polygon(50% 0,100% 30%,84% 100%,17% 100%,0 30%);background:linear-gradient(130deg,#ffffffd9 0 16%,#a8ddfbab 31%,#2a96df7d 56%,#e5f8ffc9 72%,#247dba8f);border:1px solid #fff}.nfh15-liquid-scene .nfh15-crystal b:nth-child(2){clip-path:polygon(50% 0,50% 100%,17% 100%,0 30%);background:linear-gradient(145deg,#ffffffd1,#6cb8e891)}.nfh15-liquid-scene .nfh15-crystal b:nth-child(3){clip-path:polygon(50% 0,100% 30%,84% 100%,50% 100%);background:linear-gradient(215deg,#dff5ffdb,#1577bd80)}
.nfh15-v7-light>.nfh15-head,.nfh15-v7-light>.nfh15-section,.nfh15-v7-light>.nfh15-primary-fold{position:relative;z-index:1}
@media (prefers-reduced-motion:no-preference){.nfh15-liquid-scene .orb-a{animation:nfh3Float 9s ease-in-out infinite}.nfh15-liquid-scene .nfh15-crystal{animation:nfh3Crystal 12s ease-in-out infinite}}@keyframes nfh3Float{50%{transform:translate(-8px,16px) scale(1.04)}}@keyframes nfh3Crystal{50%{transform:translateY(-12px) rotate(20deg)}}

/* V7 embedded-background liquid glass final layer */
.nfh15-v7-light{--ice:#eaf8ff;--ink:#123b5a;--muted:#537996;background-image:linear-gradient(155deg,#dff6ff24,#68bce62e 58%,#d7f3ff21),var(--nfh15-v7-bg);background-size:cover;background-position:center top;background-attachment:local;border:1px solid #ffffffed;border-radius:30px;padding:17px;gap:13px;box-shadow:inset 0 2px 1px #fff,inset 0 -2px 5px #287db733,0 34px 90px #064a7d55}
.nfh15-v7-light::before{z-index:0;inset:0;border-radius:29px;background:linear-gradient(112deg,#ffffff2b 0 22%,transparent 43%,#59b6e52e 77%,#ffffff35);box-shadow:inset 0 1px 0 #fff,inset 0 0 68px #dff7ff32}
.nfh15-v7-light>.nfh15-liquid-scene{z-index:0;background:linear-gradient(180deg,#dff7ff0d,#3c9dd316 48%,#e6f8ff12)}
.nfh15-v7-light .nfh15-orb,.nfh15-v7-light .nfh15-ribbon,.nfh15-v7-light .nfh15-crystal{opacity:.14}
.nfh15-v7-light>.nfh15-head,.nfh15-v7-light>.nfh15-settings,.nfh15-v7-light>.nfh15-resolution,.nfh15-v7-light>.nfh15-prompt,.nfh15-v7-light>.nfh15-prompt-tools,.nfh15-v7-light>.nfh15-storyboard-bar,.nfh15-v7-light>.nfh15-tabs,.nfh15-v7-light>.nfh15-drop,.nfh15-v7-light>.nfh15-grid,.nfh15-v7-light>.nfh15-preview,.nfh15-v7-light>.nfh15-section,.nfh15-v7-light>.nfh15-primary-fold{position:relative;z-index:2}
.nfh15-v7-light .nfh15-head,.nfh15-v7-light .nfh15-section,.nfh15-v7-light .nfh15-primary-fold,.nfh15-v7-light .nfh15-prompt-tools,.nfh15-v7-light .nfh15-preview{border:1px solid #ffffffd6;background:linear-gradient(132deg,#ffffff82 0%,#dff5ff4d 48%,#8fd0f036 100%);box-shadow:inset 1px 1px 0 #fff,inset -1px -1px 0 #3586bc2e,0 16px 36px #0b4f7c30;backdrop-filter:blur(25px) saturate(165%) brightness(1.06);-webkit-backdrop-filter:blur(25px) saturate(165%) brightness(1.06)}
.nfh15-v7-light .nfh15-section>summary,.nfh15-v7-light .nfh15-primary-fold>summary{background:linear-gradient(105deg,#ffffffbd,#dff4ff70 58%,#6bbbe747);border-radius:19px 19px 0 0;color:#163f5d;text-shadow:0 1px #fff;box-shadow:inset 0 1px #fff}
.nfh15-v7-light .nfh15-section-body{background:linear-gradient(145deg,#ffffff45,#ccecff2e);backdrop-filter:blur(18px)}
.nfh15-v7-light .nfh15-field select,.nfh15-v7-light .nfh15-field input,.nfh15-v7-light .nfh15-prompt textarea{background:linear-gradient(145deg,#ffffffe0,#d9f2ff9c);border:1px solid #fffffff0;border-radius:14px;color:#123b58;box-shadow:inset 0 1px 1px #fff,inset 0 -2px 4px #2c80b52b,0 8px 18px #0b4f7926;backdrop-filter:blur(20px) saturate(145%)}
.nfh15-v7-light .nfh15-mode-switch,.nfh15-v7-light .nfh15-tab,.nfh15-v7-light .nfh15-storyboard-tab,.nfh15-v7-light .nfh15-storyboard-action{position:relative;overflow:hidden;border:1px solid #ffffffe9;border-radius:999px;background:linear-gradient(155deg,#ffffffe3 0%,#d7f0ffa1 48%,#86c8ec80 100%);color:#194a6b;box-shadow:inset 1px 1px 1px #fff,inset -1px -2px 3px #287eb440,0 9px 20px #0c4f7d30;backdrop-filter:blur(18px) saturate(155%);transition:transform .16s,box-shadow .16s,background .16s}
.nfh15-v7-light .nfh15-mode-switch::before,.nfh15-v7-light .nfh15-tab::before,.nfh15-v7-light .nfh15-storyboard-tab::before,.nfh15-v7-light .nfh15-storyboard-action::before{content:"";position:absolute;z-index:0;left:8%;right:28%;top:2px;height:40%;border-radius:999px;background:linear-gradient(#fff,transparent);opacity:.8;pointer-events:none}.nfh15-v7-light .nfh15-mode-switch>*{position:relative;z-index:1}
.nfh15-v7-light .nfh15-mode-switch:hover,.nfh15-v7-light .nfh15-tab:hover,.nfh15-v7-light .nfh15-storyboard-tab:hover,.nfh15-v7-light .nfh15-storyboard-action:hover{transform:translateY(-2px);box-shadow:inset 1px 1px #fff,inset -1px -2px 3px #287eb43d,0 14px 27px #08518a40}
.nfh15-v7-light .nfh15-mode-switch.on,.nfh15-v7-light .nfh15-tab.active,.nfh15-v7-light .nfh15-storyboard-tab.active{background:linear-gradient(145deg,#49b8f8 0%,#1286d7 48%,#07529f 100%);border-color:#eaf9ff;color:#fff;text-shadow:0 1px 2px #064776;box-shadow:inset 1px 1px #ffffff9c,inset -2px -3px 5px #043b7866,0 13px 28px #07569a55}
.nfh15-v7-light .nfh15-drop,.nfh15-v7-light .nfh15-card,.nfh15-v7-light .nfh15-resolution,.nfh15-v7-light .nfh15-note,.nfh15-v7-light .nfh15-mode-note{background:linear-gradient(145deg,#ffffff9c,#d5efff69);border:1px solid #ffffffe3;box-shadow:inset 1px 1px #fff,inset -1px -1px #397fae2b,0 10px 23px #0a4b7628;backdrop-filter:blur(20px) saturate(150%)}
.nfh15-v7-light .nfh15-card{border-radius:17px}.nfh15-v7-light .nfh15-drop{border-radius:17px;border-style:dashed}.nfh15-v7-light .nfh15-prompt-tool{border:1px solid #fff;border-radius:50%;background:radial-gradient(circle at 31% 23%,#fff 0 12%,#d9f3ff 44%,#65bcec 72%,#1676ba 100%);color:#123f60;box-shadow:inset 4px 5px 9px #ffffffbd,inset -5px -7px 10px #0d65a04a,0 11px 24px #084b7938}
.nfh15-v7-light .nfh15-switch-track{box-shadow:inset 0 2px 5px #07518445,inset 0 0 0 1px #fff}.nfh15-v7-light .nfh15-switch-knob{background:radial-gradient(circle at 35% 25%,#fff,#d6f1ff 55%,#79bfe7);box-shadow:inset 0 1px #fff,0 3px 8px #07518455}

/* V7 transparency correction: image is a real lower sibling layer so backdrop-filter can sample it. */
.nfh15-v7-light{isolation:isolate;background:transparent!important;border-color:#ffffffb8!important;box-shadow:inset 0 1px 0 #ffffffd9,inset 0 -1px 0 #2c80b52e,0 28px 70px #063e6945!important}
.nfh15-v7-light::before{z-index:1!important;background:linear-gradient(125deg,#ffffff14,transparent 42%,#6cc5f014)!important;pointer-events:none}
.nfh15-v7-light>.nfh15-liquid-scene{z-index:0!important;opacity:1!important;background-image:linear-gradient(180deg,#dff7ff0a,#167dc51a),var(--nfh15-v7-bg)!important;background-size:cover!important;background-position:center top!important;filter:none!important}
.nfh15-v7-light .nfh15-orb,.nfh15-v7-light .nfh15-ribbon,.nfh15-v7-light .nfh15-crystal{display:none!important}
.nfh15-v7-light .nfh15-head,.nfh15-v7-light .nfh15-section,.nfh15-v7-light .nfh15-primary-fold,.nfh15-v7-light .nfh15-prompt-tools,.nfh15-v7-light .nfh15-preview{background:linear-gradient(135deg,#ffffff35 0%,#e8f8ff1f 50%,#5db8e61a 100%)!important;border:1px solid #ffffffa8!important;box-shadow:inset 1px 1px 0 #ffffffc7,inset -1px -1px 0 #2c7fa62e,0 14px 32px #06426b2b!important;backdrop-filter:blur(18px) saturate(175%) brightness(1.08)!important;-webkit-backdrop-filter:blur(18px) saturate(175%) brightness(1.08)!important}
.nfh15-v7-light .nfh15-section>summary,.nfh15-v7-light .nfh15-primary-fold>summary{background:linear-gradient(105deg,#ffffff40,#dff4ff22 58%,#67b9e31c)!important;border-bottom:1px solid #ffffff69!important;color:#123e5e!important;box-shadow:inset 0 1px #ffffffbd!important;backdrop-filter:blur(12px) saturate(160%)!important}
.nfh15-v7-light .nfh15-section-body{background:#ffffff0a!important;backdrop-filter:none!important}
.nfh15-v7-light .nfh15-settings,.nfh15-v7-light .nfh15-field{background:transparent!important}
.nfh15-v7-light .nfh15-field select,.nfh15-v7-light .nfh15-field input,.nfh15-v7-light .nfh15-prompt textarea{background:linear-gradient(145deg,#ffffff62,#d9f2ff3d)!important;border:1px solid #ffffffad!important;color:#103a58!important;box-shadow:inset 1px 1px #ffffffc9,inset -1px -2px 3px #176f9d22,0 7px 16px #063c6420!important;backdrop-filter:blur(13px) saturate(165%)!important;-webkit-backdrop-filter:blur(13px) saturate(165%)!important}
.nfh15-v7-light .nfh15-mode-switch,.nfh15-v7-light .nfh15-tab,.nfh15-v7-light .nfh15-storyboard-tab,.nfh15-v7-light .nfh15-storyboard-action{background:linear-gradient(155deg,#ffffff61,#d8f1ff36 50%,#7ec5e72e)!important;border:1px solid #ffffffb8!important;color:#174765!important;box-shadow:inset 1px 1px #ffffffd1,inset -1px -2px 3px #287eae30,0 8px 18px #063d6629!important;backdrop-filter:blur(12px) saturate(175%)!important;-webkit-backdrop-filter:blur(12px) saturate(175%)!important}
.nfh15-v7-light .nfh15-mode-switch.on,.nfh15-v7-light .nfh15-tab.active,.nfh15-v7-light .nfh15-storyboard-tab.active{background:linear-gradient(145deg,#42b5f2d9,#087dccd6 55%,#064d98e3)!important;border-color:#effbffe0!important;color:#fff!important;box-shadow:inset 1px 1px #ffffffa6,inset -2px -3px 5px #04366c59,0 12px 26px #07579648!important}
.nfh15-v7-light .nfh15-drop,.nfh15-v7-light .nfh15-card,.nfh15-v7-light .nfh15-resolution,.nfh15-v7-light .nfh15-note,.nfh15-v7-light .nfh15-mode-note{background:linear-gradient(145deg,#ffffff45,#d5efff24)!important;border:1px solid #ffffff9c!important;box-shadow:inset 1px 1px #ffffffc2,inset -1px -1px #397fae25,0 9px 20px #063d6522!important;backdrop-filter:blur(14px) saturate(165%)!important;-webkit-backdrop-filter:blur(14px) saturate(165%)!important}
.nfh15-v7-light .nfh15-preview-head,.nfh15-v7-light .nfh15-media-player{background:#ffffff25!important}

/* V7 exact-source-color and aspect-ratio correction. */
.nfh15-v7-light{background:transparent!important;color:#183a50!important}
.nfh15-v7-light::before{background:transparent!important;box-shadow:inset 0 1px 0 #ffffffb8,inset 0 0 0 1px #ffffff3d!important}
.nfh15-v7-light>.nfh15-liquid-scene{background-color:#dceff8!important;background-image:var(--nfh15-v7-bg)!important;background-size:100% auto!important;background-position:center top!important;background-repeat:repeat-y!important}
/* Neutral glass only: no blue/cyan overlays changing the supplied artwork. */
.nfh15-v7-light .nfh15-head,.nfh15-v7-light .nfh15-section,.nfh15-v7-light .nfh15-primary-fold,.nfh15-v7-light .nfh15-prompt-tools,.nfh15-v7-light .nfh15-preview{background:rgba(255,255,255,.18)!important;border:1px solid rgba(255,255,255,.68)!important;box-shadow:inset 1px 1px 0 rgba(255,255,255,.78),inset -1px -1px 0 rgba(35,70,92,.12),0 13px 30px rgba(21,52,73,.18)!important;backdrop-filter:blur(14px) saturate(100%) brightness(1.01)!important;-webkit-backdrop-filter:blur(14px) saturate(100%) brightness(1.01)!important}
.nfh15-v7-light .nfh15-section>summary,.nfh15-v7-light .nfh15-primary-fold>summary{background:rgba(255,255,255,.20)!important;border-bottom:1px solid rgba(255,255,255,.48)!important;color:#173b53!important;text-shadow:0 1px rgba(255,255,255,.72)!important;backdrop-filter:blur(8px) saturate(100%)!important;-webkit-backdrop-filter:blur(8px) saturate(100%)!important}
.nfh15-v7-light .nfh15-section-body{background:rgba(255,255,255,.035)!important}
.nfh15-v7-light .nfh15-field select,.nfh15-v7-light .nfh15-field input,.nfh15-v7-light .nfh15-prompt textarea{background:rgba(255,255,255,.34)!important;border:1px solid rgba(255,255,255,.72)!important;color:#12364d!important;box-shadow:inset 1px 1px rgba(255,255,255,.82),inset -1px -1px rgba(27,61,84,.12),0 6px 14px rgba(22,49,67,.13)!important;backdrop-filter:blur(9px) saturate(100%)!important;-webkit-backdrop-filter:blur(9px) saturate(100%)!important}
.nfh15-v7-light .nfh15-mode-switch,.nfh15-v7-light .nfh15-tab,.nfh15-v7-light .nfh15-storyboard-tab,.nfh15-v7-light .nfh15-storyboard-action{background:rgba(255,255,255,.28)!important;border:1px solid rgba(255,255,255,.72)!important;color:#173b53!important;box-shadow:inset 1px 1px rgba(255,255,255,.84),inset -1px -2px rgba(25,57,78,.12),0 7px 17px rgba(19,48,67,.16)!important;backdrop-filter:blur(9px) saturate(100%)!important;-webkit-backdrop-filter:blur(9px) saturate(100%)!important}
.nfh15-v7-light .nfh15-mode-switch.on,.nfh15-v7-light .nfh15-tab.active,.nfh15-v7-light .nfh15-storyboard-tab.active{background:rgba(16,91,151,.72)!important;border-color:rgba(255,255,255,.82)!important;color:#fff!important;box-shadow:inset 1px 1px rgba(255,255,255,.58),inset -2px -3px rgba(5,44,86,.34),0 10px 23px rgba(7,60,109,.28)!important;backdrop-filter:blur(10px) saturate(100%)!important}
.nfh15-v7-light .nfh15-drop,.nfh15-v7-light .nfh15-card,.nfh15-v7-light .nfh15-resolution,.nfh15-v7-light .nfh15-note,.nfh15-v7-light .nfh15-mode-note{background:rgba(255,255,255,.22)!important;border:1px solid rgba(255,255,255,.62)!important;box-shadow:inset 1px 1px rgba(255,255,255,.76),inset -1px -1px rgba(24,56,78,.10),0 7px 17px rgba(18,46,66,.13)!important;backdrop-filter:blur(10px) saturate(100%)!important;-webkit-backdrop-filter:blur(10px) saturate(100%)!important}
.nfh15-v7-light .nfh15-preview-head,.nfh15-v7-light .nfh15-media-player{background:rgba(255,255,255,.16)!important}

/* V7 media-board and optical-glass correction */
.nfh15-v7-light .nfh15-grid{gap:10px!important;padding:2px}
.nfh15-v7-light .nfh15-card{isolation:isolate;aspect-ratio:1/1!important;padding:0!important;border-radius:18px!important;border:1px solid rgba(255,255,255,.74)!important;background:rgba(255,255,255,.16)!important;box-shadow:inset 1px 1px 0 rgba(255,255,255,.88),inset -1px -1px 0 rgba(24,55,75,.12),0 10px 24px rgba(17,44,63,.18)!important;backdrop-filter:blur(18px) saturate(105%) contrast(102%)!important;-webkit-backdrop-filter:blur(18px) saturate(105%) contrast(102%)!important}
.nfh15-v7-light .nfh15-card::before{content:"";position:absolute;z-index:3;pointer-events:none;inset:0;border-radius:inherit;background:linear-gradient(145deg,rgba(255,255,255,.55) 0 1px,rgba(255,255,255,.16) 2px 15%,transparent 38%,rgba(15,67,101,.10) 100%);box-shadow:inset 0 1px 0 rgba(255,255,255,.82),inset 1px 0 0 rgba(255,255,255,.52),inset 0 -2px 3px rgba(13,58,88,.14)}
.nfh15-v7-light .nfh15-card::after{content:"";position:absolute;z-index:3;pointer-events:none;left:9%;top:5%;width:58%;height:18%;border-radius:50%;background:linear-gradient(180deg,rgba(255,255,255,.44),transparent);filter:blur(5px);transform:rotate(-6deg)}
/* Occupied media fills the slot. No tiny portrait floating in a large blue tile. */
.nfh15-v7-light .nfh15-card img{position:absolute;z-index:1;inset:0;width:100%!important;height:100%!important;object-fit:cover!important;object-position:center!important;border-radius:17px!important;background:transparent!important}
.nfh15-v7-light .nfh15-card .nfh15-media-player{position:absolute;z-index:1;inset:0;width:100%;height:100%;min-height:0;padding:8px;border-radius:17px;background:rgba(255,255,255,.10)!important}
.nfh15-v7-light .nfh15-label{position:absolute;z-index:4;left:6px;right:6px;bottom:6px;width:auto;height:25px;line-height:25px;padding:0 9px;border-radius:999px;color:#fff!important;background:rgba(13,48,72,.54)!important;border:1px solid rgba(255,255,255,.42);box-shadow:inset 0 1px rgba(255,255,255,.34),0 4px 12px rgba(6,31,48,.25);backdrop-filter:blur(9px) saturate(100%);-webkit-backdrop-filter:blur(9px) saturate(100%);text-shadow:0 1px 2px rgba(0,0,0,.48);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.nfh15-v7-light .nfh15-empty{position:absolute;z-index:4;inset:0;width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#294e65!important;font-weight:650;text-shadow:0 1px rgba(255,255,255,.72);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.nfh15-v7-light .nfh15-card:has(img) .nfh15-empty{display:none}
.nfh15-v7-light .nfh15-replace,.nfh15-v7-light .nfh15-x{z-index:6;backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px)}
/* More convincing neutral optical edge for all principal glass surfaces. */
.nfh15-v7-light .nfh15-head,.nfh15-v7-light .nfh15-section,.nfh15-v7-light .nfh15-primary-fold,.nfh15-v7-light .nfh15-prompt-tools,.nfh15-v7-light .nfh15-preview{position:relative;overflow:hidden;background:rgba(255,255,255,.13)!important;border:1px solid rgba(255,255,255,.72)!important;box-shadow:inset 1px 1px 0 rgba(255,255,255,.82),inset -2px -2px 4px rgba(22,57,80,.13),0 14px 32px rgba(16,47,68,.17)!important;backdrop-filter:blur(20px) saturate(105%) contrast(102%)!important;-webkit-backdrop-filter:blur(20px) saturate(105%) contrast(102%)!important}
.nfh15-v7-light .nfh15-mode-switch,.nfh15-v7-light .nfh15-tab,.nfh15-v7-light .nfh15-storyboard-tab,.nfh15-v7-light .nfh15-storyboard-action{background:rgba(255,255,255,.18)!important;border-color:rgba(255,255,255,.78)!important;box-shadow:inset 1px 1px rgba(255,255,255,.9),inset -2px -2px 4px rgba(22,55,76,.14),0 8px 18px rgba(17,44,63,.17)!important;backdrop-filter:blur(14px) saturate(105%) contrast(102%)!important;-webkit-backdrop-filter:blur(14px) saturate(105%) contrast(102%)!important}

/* V7 dark iridescent floating UI — no nested panel boxes. */
.nfh15-v7-light{--v7-text:#f5f7ff;--v7-muted:#aeb7cb;--v7-line:rgba(255,255,255,.18);color:var(--v7-text)!important;background:transparent!important;padding:18px!important;gap:16px!important}
.nfh15-v7-light::before{background:linear-gradient(180deg,rgba(0,0,0,.05),rgba(0,0,0,.18))!important;box-shadow:inset 0 0 0 1px rgba(255,255,255,.12)!important;border-radius:28px!important}
.nfh15-v7-light>.nfh15-liquid-scene{background-color:#050509!important;background-image:var(--nfh15-v7-bg)!important;background-size:100% auto!important;background-position:center top!important;background-repeat:repeat-y!important}
/* Remove container-on-container look. Sections become spacing groups over the artwork. */
.nfh15-v7-light .nfh15-head,.nfh15-v7-light .nfh15-section,.nfh15-v7-light .nfh15-primary-fold,.nfh15-v7-light .nfh15-prompt-tools,.nfh15-v7-light .nfh15-preview{overflow:visible!important;background:transparent!important;border:0!important;border-radius:0!important;box-shadow:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important}
.nfh15-v7-light .nfh15-section,.nfh15-v7-light .nfh15-primary-fold{padding:0 0 15px!important;border-bottom:1px solid rgba(255,255,255,.12)!important}
.nfh15-v7-light .nfh15-section>summary,.nfh15-v7-light .nfh15-primary-fold>summary{min-height:42px;padding:0 4px!important;background:transparent!important;border:0!important;border-radius:0!important;color:#fff!important;font-size:14px!important;font-weight:750!important;letter-spacing:.02em;text-shadow:0 2px 8px #000!important;box-shadow:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important}
.nfh15-v7-light .nfh15-section-body{padding:12px 2px 0!important;background:transparent!important}
.nfh15-v7-light .nfh15-head{padding:4px 2px 12px!important;border-bottom:1px solid rgba(255,255,255,.16)!important}
.nfh15-v7-light .nfh15-title{color:#fff!important;text-shadow:0 2px 14px #000}.nfh15-v7-light .nfh15-subtitle,.nfh15-v7-light .nfh15-field label,.nfh15-v7-light .nfh15-mode-switch small{color:var(--v7-muted)!important}
/* Individual controls float directly above the artwork. */
.nfh15-v7-light .nfh15-field select,.nfh15-v7-light .nfh15-field input,.nfh15-v7-light .nfh15-prompt textarea{background:rgba(8,10,18,.48)!important;border:1px solid rgba(255,255,255,.20)!important;border-top-color:rgba(255,255,255,.34)!important;border-radius:13px!important;color:#f7f8ff!important;box-shadow:inset 0 1px rgba(255,255,255,.08),0 10px 24px rgba(0,0,0,.26)!important;backdrop-filter:blur(18px) saturate(125%)!important;-webkit-backdrop-filter:blur(18px) saturate(125%)!important}
.nfh15-v7-light .nfh15-field select:focus,.nfh15-v7-light .nfh15-field input:focus,.nfh15-v7-light .nfh15-prompt textarea:focus{border-color:rgba(134,169,255,.72)!important;box-shadow:0 0 0 3px rgba(94,113,255,.16),0 12px 28px rgba(0,0,0,.32)!important;outline:0}
.nfh15-v7-light .nfh15-field select option{background:#10111a;color:#f7f8ff}
.nfh15-v7-light .nfh15-resolution,.nfh15-v7-light .nfh15-note,.nfh15-v7-light .nfh15-mode-note{background:rgba(8,10,18,.34)!important;border:1px solid rgba(255,255,255,.14)!important;color:#d8ddeb!important;box-shadow:0 8px 20px rgba(0,0,0,.20)!important;backdrop-filter:blur(14px) saturate(115%)!important;-webkit-backdrop-filter:blur(14px) saturate(115%)!important}
/* Compact floating pills, not cards inside cards. */
.nfh15-v7-light .nfh15-mode-switch,.nfh15-v7-light .nfh15-tab,.nfh15-v7-light .nfh15-storyboard-tab,.nfh15-v7-light .nfh15-storyboard-action{background:rgba(12,13,22,.50)!important;border:1px solid rgba(255,255,255,.22)!important;color:#eef1fb!important;box-shadow:inset 0 1px rgba(255,255,255,.10),0 8px 20px rgba(0,0,0,.25)!important;backdrop-filter:blur(16px) saturate(125%)!important;-webkit-backdrop-filter:blur(16px) saturate(125%)!important}
.nfh15-v7-light .nfh15-mode-switch::before,.nfh15-v7-light .nfh15-tab::before,.nfh15-v7-light .nfh15-storyboard-tab::before,.nfh15-v7-light .nfh15-storyboard-action::before{opacity:.23!important}
.nfh15-v7-light .nfh15-mode-switch.on,.nfh15-v7-light .nfh15-tab.active,.nfh15-v7-light .nfh15-storyboard-tab.active{background:linear-gradient(120deg,rgba(76,92,255,.82),rgba(170,68,230,.72) 55%,rgba(27,181,213,.68))!important;border-color:rgba(255,255,255,.42)!important;color:#fff!important;box-shadow:inset 0 1px rgba(255,255,255,.26),0 9px 26px rgba(60,53,210,.28)!important}
/* Media cards remain independent floating tiles; no surrounding card frame. */
.nfh15-v7-light .nfh15-grid{gap:11px!important;padding:1px!important}
.nfh15-v7-light .nfh15-drop{background:rgba(8,10,18,.34)!important;border:1px dashed rgba(255,255,255,.28)!important;color:#d9deec!important;box-shadow:0 9px 22px rgba(0,0,0,.22)!important;backdrop-filter:blur(15px) saturate(120%)!important;-webkit-backdrop-filter:blur(15px) saturate(120%)!important}
.nfh15-v7-light .nfh15-card{background:rgba(8,10,18,.38)!important;border:1px solid rgba(255,255,255,.20)!important;border-top-color:rgba(255,255,255,.36)!important;box-shadow:0 12px 27px rgba(0,0,0,.30)!important;backdrop-filter:blur(16px) saturate(115%)!important;-webkit-backdrop-filter:blur(16px) saturate(115%)!important}
.nfh15-v7-light .nfh15-card::before{background:linear-gradient(145deg,rgba(255,255,255,.19) 0 1px,rgba(255,255,255,.05) 2px 13%,transparent 38%,rgba(0,0,0,.13) 100%)!important;box-shadow:inset 0 1px rgba(255,255,255,.20),inset 0 -2px 4px rgba(0,0,0,.16)!important}.nfh15-v7-light .nfh15-card::after{opacity:.20!important}
.nfh15-v7-light .nfh15-empty{color:#bdc5d8!important;text-shadow:0 2px 8px #000!important}.nfh15-v7-light .nfh15-label{background:rgba(4,5,10,.66)!important;border-color:rgba(255,255,255,.20)!important;color:#f8f9ff!important}
.nfh15-v7-light .nfh15-prompt-tool{background:rgba(10,11,19,.58)!important;border:1px solid rgba(255,255,255,.24)!important;color:#f2f4fc!important;box-shadow:inset 0 1px rgba(255,255,255,.12),0 9px 22px rgba(0,0,0,.28)!important;backdrop-filter:blur(15px)!important;-webkit-backdrop-filter:blur(15px)!important}
.nfh15-v7-light .nfh15-preview{height:68px!important;padding:0!important;border:1px solid rgba(255,255,255,.15)!important;border-radius:14px!important;background:rgba(8,10,18,.32)!important;backdrop-filter:blur(14px)!important;-webkit-backdrop-filter:blur(14px)!important}
.nfh15-v7-light .nfh15-preview-head,.nfh15-v7-light .nfh15-media-player{background:rgba(5,6,11,.38)!important;color:#e9edf8!important}

/* V7 final dark cleanup: forbid legacy ice-blue fills in every visible surface. */
.nfh15-v7-light,.nfh15-v7-light .nfh15-settings,.nfh15-v7-light .nfh15-prompt,.nfh15-v7-light .nfh15-storyboard-bar,.nfh15-v7-light .nfh15-storyboard-tabs,.nfh15-v7-light .nfh15-storyboard-actions,.nfh15-v7-light .nfh15-tabs,.nfh15-v7-light .nfh15-grid{background-color:transparent!important;background-image:none!important}
.nfh15-v7-light>.nfh15-liquid-scene{background-color:#050509!important;background-image:var(--nfh15-v7-bg)!important}
.nfh15-v7-light .nfh15-prompt textarea,.nfh15-v7-light .nfh15-field select,.nfh15-v7-light .nfh15-field input{background-color:rgba(7,8,14,.64)!important;background-image:none!important;color:#f5f7ff!important}
.nfh15-v7-light .nfh15-prompt textarea:disabled,.nfh15-v7-light .nfh15-prompt textarea.linked{background:#0a0b12cc!important;color:#9098aa!important;border-color:rgba(255,255,255,.14)!important}
.nfh15-v7-light .nfh15-card,.nfh15-v7-light .nfh15-drop,.nfh15-v7-light .nfh15-resolution,.nfh15-v7-light .nfh15-note,.nfh15-v7-light .nfh15-mode-note,.nfh15-v7-light .nfh15-preview,.nfh15-v7-light .nfh15-media-player{background-color:rgba(7,8,14,.44)!important;background-image:none!important}
.nfh15-v7-light .nfh15-tab,.nfh15-v7-light .nfh15-storyboard-tab,.nfh15-v7-light .nfh15-storyboard-action,.nfh15-v7-light .nfh15-mode-switch,.nfh15-v7-light .nfh15-prompt-tool{background-color:rgba(8,9,16,.62)!important;background-image:none!important}
.nfh15-v7-light .nfh15-tab.active,.nfh15-v7-light .nfh15-storyboard-tab.active,.nfh15-v7-light .nfh15-mode-switch.on{background-color:rgba(87,62,190,.78)!important;background-image:linear-gradient(120deg,rgba(75,86,238,.86),rgba(143,59,195,.78),rgba(23,147,176,.70))!important}

/* V7 sea-glass accent pass: graphite / deep ocean / cyan, no purple. */
.nfh15-v7-light .nfh15-title{background:linear-gradient(90deg,#ffffff 0%,#bff7f3 46%,#68d6df 74%,#d9fbff 100%);-webkit-background-clip:text;background-clip:text;color:transparent!important;text-shadow:none!important;filter:drop-shadow(0 2px 8px rgba(0,0,0,.52))}
.nfh15-v7-light .nfh15-badge{color:#c9fffb!important;background:rgba(5,28,32,.66)!important;border-color:rgba(72,211,214,.36)!important;box-shadow:inset 0 1px rgba(255,255,255,.10),0 6px 18px rgba(0,0,0,.24)!important}
.nfh15-v7-light .nfh15-section>summary::after,.nfh15-v7-light .nfh15-primary-fold>summary::after{color:#67d8dc!important}
.nfh15-v7-light .nfh15-field select:focus,.nfh15-v7-light .nfh15-field input:focus,.nfh15-v7-light .nfh15-prompt textarea:focus{border-color:rgba(68,205,211,.68)!important;box-shadow:0 0 0 3px rgba(39,176,184,.14),0 12px 28px rgba(0,0,0,.32)!important}
.nfh15-v7-light .nfh15-tab.active,.nfh15-v7-light .nfh15-storyboard-tab.active,.nfh15-v7-light .nfh15-mode-switch.on{background-color:rgba(10,105,119,.84)!important;background-image:linear-gradient(120deg,rgba(13,69,91,.94),rgba(16,127,141,.88) 52%,rgba(43,178,181,.78))!important;border-color:rgba(137,245,241,.44)!important;box-shadow:inset 0 1px rgba(255,255,255,.22),0 9px 25px rgba(0,126,137,.24)!important}
.nfh15-v7-light .nfh15-progress i{background:linear-gradient(90deg,#184d67,#1295a5,#42d2ca)!important}.nfh15-v7-light .nfh15-preview-state{color:#64dcd8!important}
.nfh15-v7-light .nfh15-switch-track{background:rgba(5,28,34,.78)!important}.nfh15-v7-light .nfh15-mode-switch.on .nfh15-switch-track{background:linear-gradient(90deg,#0b6274,#25b6b8)!important}
.nfh15-v7-light .nfh15-prompt-tool:hover{border-color:rgba(83,224,218,.48)!important;color:#d9fffc!important;box-shadow:inset 0 1px rgba(255,255,255,.14),0 9px 24px rgba(0,123,132,.22)!important}

/* V7 uniform button finish: simple natural gradients, no patchy highlight overlays. */
.nfh15-v7-light .nfh15-mode-switch::before,.nfh15-v7-light .nfh15-tab::before,.nfh15-v7-light .nfh15-storyboard-tab::before,.nfh15-v7-light .nfh15-storyboard-action::before{display:none!important}
.nfh15-v7-light .nfh15-mode-switch,.nfh15-v7-light .nfh15-tab,.nfh15-v7-light .nfh15-storyboard-tab,.nfh15-v7-light .nfh15-storyboard-action,.nfh15-v7-light .nfh15-prompt-tool{background-color:#111c21!important;background-image:linear-gradient(180deg,#17272d 0%,#101a1f 100%)!important;border:1px solid rgba(117,197,202,.22)!important;color:#e8f3f4!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 7px 16px rgba(0,0,0,.22)!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important;transition:transform .16s ease,border-color .16s ease,box-shadow .16s ease,background .16s ease!important}
.nfh15-v7-light .nfh15-mode-switch:hover,.nfh15-v7-light .nfh15-tab:hover,.nfh15-v7-light .nfh15-storyboard-tab:hover,.nfh15-v7-light .nfh15-storyboard-action:hover,.nfh15-v7-light .nfh15-prompt-tool:hover{background-image:linear-gradient(180deg,#1c3036 0%,#132229 100%)!important;border-color:rgba(91,213,214,.42)!important;transform:translateY(-1px)!important;box-shadow:inset 0 1px rgba(255,255,255,.07),0 9px 19px rgba(0,0,0,.26)!important}
.nfh15-v7-light .nfh15-mode-switch.on,.nfh15-v7-light .nfh15-tab.active,.nfh15-v7-light .nfh15-storyboard-tab.active{background-color:#116c77!important;background-image:linear-gradient(180deg,#198692 0%,#106874 100%)!important;border-color:rgba(145,239,237,.46)!important;color:#fff!important;box-shadow:inset 0 1px rgba(255,255,255,.15),0 8px 18px rgba(0,87,96,.28)!important}
.nfh15-v7-light .nfh15-mode-switch.on:hover,.nfh15-v7-light .nfh15-tab.active:hover,.nfh15-v7-light .nfh15-storyboard-tab.active:hover{background-image:linear-gradient(180deg,#1c929d 0%,#11717c 100%)!important}
.nfh15-v7-light .nfh15-storyboard-action.danger{background:#7f3038!important;border-color:#c85b65!important;color:#fff1f2!important}


/* V7 custom menu: selected item is unmistakably cyan; hover is neutral graphite. */
.nfh15-v7-light .nfh15-custom-select{position:relative;min-width:0}
.nfh15-v7-light .nfh15-select-button{display:grid;grid-template-columns:minmax(0,1fr) 18px;align-items:center;width:100%;height:clamp(31px,4.6cqw,38px);padding:0 10px;text-align:left;color:#f1f7f8;background:linear-gradient(180deg,#152329,#0d171b);border:1px solid rgba(104,190,194,.27);border-radius:10px;box-shadow:inset 0 1px rgba(255,255,255,.055),0 6px 15px rgba(0,0,0,.2);cursor:pointer}
.nfh15-v7-light .nfh15-select-button span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.nfh15-v7-light .nfh15-select-button i{font-style:normal;color:#72d8d8;text-align:right;transition:transform .15s ease}.nfh15-v7-light .nfh15-custom-select.open .nfh15-select-button{border-color:rgba(91,219,216,.62);box-shadow:0 0 0 3px rgba(30,173,177,.12),0 9px 22px rgba(0,0,0,.28)}.nfh15-v7-light .nfh15-custom-select.open .nfh15-select-button i{transform:rotate(180deg)}
.nfh15-select-menu.nfh15-v7-light .nfh15-select-search{display:block;width:calc(100% - 12px);height:32px;margin:0 6px 6px;padding:0 10px;border:1px solid rgba(87,190,194,.35);border-radius:7px;background:#111c21;color:#effcfc;outline:none;box-sizing:border-box}.nfh15-select-menu.nfh15-v7-light .nfh15-select-search:focus{border-color:#55d5d2;box-shadow:0 0 0 2px rgba(48,187,186,.13)}.nfh15-select-menu.nfh15-v7-light .nfh15-select-list{overflow:auto;overscroll-behavior:contain}.nfh15-select-menu.nfh15-v7-light .nfh15-select-option.keyboard{background:#182f34;color:#fff}.nfh15-select-menu.nfh15-v7-light .nfh15-select-empty{padding:12px 10px;color:#809296;text-align:center}
.nfh15-select-menu.nfh15-v7-light{position:fixed;z-index:100000;display:none;max-height:320px;overflow:auto;padding:6px 0!important;background:#090f12f7;border:1px solid rgba(90,205,205,.32);border-radius:11px;box-shadow:0 18px 45px rgba(0,0,0,.58),inset 0 1px rgba(255,255,255,.05);backdrop-filter:blur(18px) saturate(125%)}.nfh15-select-menu.nfh15-v7-light .nfh15-select-option{position:relative;display:block;width:100%!important;min-height:34px;padding:7px 32px 7px 10px;border:0;border-radius:7px;background:transparent;color:#c8d2d5;text-align:left;cursor:pointer}.nfh15-select-menu.nfh15-v7-light .nfh15-select-option:hover{background:#182429;color:#f8ffff}.nfh15-select-menu.nfh15-v7-light .nfh15-select-option .mark{position:absolute;right:10px;top:50%;transform:translateY(-50%);color:transparent;font-weight:900}.nfh15-select-menu.nfh15-v7-light .nfh15-select-option.selected{background:linear-gradient(90deg,#0d4f59,#116a73);color:#fff;box-shadow:inset 3px 0 #63e3de}.nfh15-select-menu.nfh15-v7-light .nfh15-select-option.selected .mark{color:#8ffff7}.nfh15-select-menu.nfh15-v7-light .nfh15-select-option .text{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
/* V11 detached searchable menus: replace every legacy yellow scrollbar. */
.nfh15-select-menu.nfh15-v7-light,.nfh15-select-menu.nfh15-v7-light .nfh15-select-list{scrollbar-width:thin!important;scrollbar-color:#2ab9ae #061817!important}
.nfh15-select-menu.nfh15-v7-light::-webkit-scrollbar,.nfh15-select-menu.nfh15-v7-light .nfh15-select-list::-webkit-scrollbar{width:10px!important;height:10px!important;background:#061817!important}
.nfh15-select-menu.nfh15-v7-light::-webkit-scrollbar-track,.nfh15-select-menu.nfh15-v7-light .nfh15-select-list::-webkit-scrollbar-track{background:#061817!important;background-image:none!important;box-shadow:none!important;border:0!important}
.nfh15-select-menu.nfh15-v7-light::-webkit-scrollbar-thumb,.nfh15-select-menu.nfh15-v7-light .nfh15-select-list::-webkit-scrollbar-thumb{background:#2ab9ae!important;background-image:none!important;border:2px solid #061817!important;border-radius:6px!important;box-shadow:none!important}
.nfh15-select-menu.nfh15-v7-light::-webkit-scrollbar-thumb:hover,.nfh15-select-menu.nfh15-v7-light .nfh15-select-list::-webkit-scrollbar-thumb:hover{background:#67eadd!important;background-image:none!important}
.nfh15-select-menu.nfh15-v7-light::-webkit-scrollbar-corner,.nfh15-select-menu.nfh15-v7-light .nfh15-select-list::-webkit-scrollbar-corner{background:#061817!important}
.nfh15-select-menu.nfh15-v7-light .nfh15-select-option.selected,.nfh15-select-menu.nfh15-v7-light .nfh15-select-option.keyboard{background:#176c67!important;background-image:none!important;color:#fff!important;box-shadow:inset 3px 0 #63e3de!important}
.nfh15-select-menu.nfh15-v7-light .nfh15-select-option:hover{background:#124d49!important;background-image:none!important;color:#fff!important}
.nfh15-v7-light .nfh15-select-menu{position:fixed;z-index:100000;display:none;max-height:320px;overflow:auto;padding:6px;background:#090f12f7;border:1px solid rgba(90,205,205,.32);border-radius:11px;box-shadow:0 18px 45px rgba(0,0,0,.58),inset 0 1px rgba(255,255,255,.05);backdrop-filter:blur(18px) saturate(125%)}.nfh15-v7-light .nfh15-custom-select.open .nfh15-select-menu{display:block}.nfh15-v7-light .nfh15-select-option{display:grid;grid-template-columns:18px minmax(0,1fr);gap:8px;align-items:center;width:100%;min-height:34px;padding:7px 9px;border:0;border-radius:7px;background:transparent;color:#c8d2d5;text-align:left;cursor:pointer}.nfh15-v7-light .nfh15-select-option:hover{background:#182429;color:#f8ffff}.nfh15-v7-light .nfh15-select-option .mark{color:transparent;font-weight:900}.nfh15-v7-light .nfh15-select-option.selected{background:linear-gradient(90deg,#0d4f59,#116a73);color:#fff;box-shadow:inset 3px 0 #63e3de}.nfh15-v7-light .nfh15-select-option.selected .mark{color:#8ffff7}.nfh15-v7-light .nfh15-select-option .text{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}


.nfh15-range-row{display:grid;grid-template-columns:minmax(0,1fr) 54px;gap:12px;align-items:center}.nfh15-range-row input[type=range]{width:100%;accent-color:#27aab8;cursor:pointer}.nfh15-range-value{display:grid;place-items:center;min-height:34px;border:1px solid rgba(74,190,202,.34);border-radius:9px;background:linear-gradient(180deg,#17272d,#101a1f);color:#eefcff;font-weight:700;font-variant-numeric:tabular-nums}

/* V9 premium transparent glass theme: exact background visibility, no frosted blur. */
.nfh3.nfh15-v9-horizontal{--v9-gold:#f2d257;--v9-gold-hot:#ffe787;--v9-gold-deep:#8d741e;--v9-line:rgba(242,210,87,.38);--v9-line-soft:rgba(255,239,156,.17);--v9-text:#f7f4e8;background-image:linear-gradient(90deg,rgba(0,0,0,.12),rgba(0,0,0,.04) 48%,rgba(0,0,0,.10)),var(--nfh15-v9-bg)!important;border:1px solid var(--v9-line)!important;border-radius:12px!important;box-shadow:inset 0 0 0 1px rgba(255,255,255,.025),0 24px 70px rgba(0,0,0,.72)!important;color:var(--v9-text)!important}
.nfh15-v9-horizontal,.nfh15-v9-horizontal *{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}
.nfh15-v9-horizontal::before{background:transparent!important;box-shadow:none!important}
.nfh15-v9-horizontal .nfh15-head{background:linear-gradient(90deg,rgba(5,6,6,.58),rgba(9,9,7,.30) 54%,rgba(5,6,6,.48))!important;border:1px solid rgba(242,210,87,.44)!important;border-radius:7px!important;box-shadow:inset 0 1px rgba(255,255,255,.055),0 8px 24px rgba(0,0,0,.22)!important}
.nfh15-v9-horizontal .nfh15-title{color:#fff8cf!important;letter-spacing:.055em!important;text-shadow:0 1px 12px rgba(0,0,0,.92)!important}.nfh15-v9-horizontal .nfh15-badge{background:rgba(6,7,7,.34)!important;border:1px solid rgba(242,210,87,.34)!important;color:#e8d77e!important;border-radius:4px!important}
.nfh15-v9-horizontal .nfh15-section,.nfh15-v9-horizontal .nfh15-primary-fold,.nfh15-v9-horizontal .nfh15-advanced{background:rgba(4,5,5,.23)!important;border:1px solid var(--v9-line-soft)!important;border-radius:7px!important;box-shadow:inset 0 1px rgba(255,255,255,.025),0 9px 24px rgba(0,0,0,.12)!important}
.nfh15-v9-horizontal .nfh15-section>summary,.nfh15-v9-horizontal .nfh15-primary-fold>summary,.nfh15-v9-horizontal .nfh15-advanced>summary{min-height:40px!important;background:linear-gradient(90deg,rgba(7,8,8,.54),rgba(10,10,8,.24))!important;border-bottom:1px solid rgba(242,210,87,.20)!important;border-radius:6px 6px 0 0!important;color:#f4e6a0!important;box-shadow:inset 3px 0 var(--v9-gold-deep)!important;text-shadow:0 1px 8px #000!important}
.nfh15-v9-horizontal .nfh15-section-body{background:rgba(5,6,6,.11)!important}.nfh15-v9-horizontal .nfh15-field label{color:#d7d1b5!important;letter-spacing:.025em!important;text-shadow:0 1px 4px #000!important}
.nfh15-v9-horizontal .nfh15-field select,.nfh15-v9-horizontal .nfh15-field input,.nfh15-v9-horizontal .nfh15-prompt textarea,.nfh15-v9-horizontal .nfh15-select-button{background:rgba(6,7,7,.42)!important;border:1px solid rgba(242,210,87,.25)!important;border-radius:5px!important;color:#faf8ef!important;box-shadow:inset 0 1px rgba(255,255,255,.035)!important}
.nfh15-v9-horizontal .nfh15-field select:focus,.nfh15-v9-horizontal .nfh15-field input:focus,.nfh15-v9-horizontal .nfh15-prompt textarea:focus,.nfh15-v9-horizontal .nfh15-select-button:focus{border-color:var(--v9-gold-hot)!important;box-shadow:0 0 0 1px rgba(255,224,98,.36),0 0 16px rgba(242,210,87,.12)!important}
.nfh15-v9-horizontal .nfh15-tab,.nfh15-v9-horizontal .nfh15-prompt-tool,.nfh15-v9-horizontal .nfh15-storyboard-action{background:linear-gradient(180deg,rgba(20,20,16,.50),rgba(5,6,6,.44))!important;border:1px solid rgba(242,210,87,.28)!important;border-radius:5px!important;color:#ddd8be!important;box-shadow:inset 0 1px rgba(255,255,255,.045)!important;transition:background .14s,border-color .14s,color .14s,transform .14s!important}
.nfh15-v9-horizontal .nfh15-tab:hover,.nfh15-v9-horizontal .nfh15-prompt-tool:hover,.nfh15-v9-horizontal .nfh15-storyboard-action:hover{background:linear-gradient(180deg,rgba(111,91,21,.58),rgba(18,17,10,.55))!important;border-color:rgba(255,231,135,.72)!important;color:#fff6c5!important;transform:translateY(-1px)!important}
.nfh15-v9-horizontal .nfh15-tab.active,.nfh15-v9-horizontal .nfh15-storyboard-tab.active,.nfh15-v9-horizontal .nfh15-mode-switch.on{background:linear-gradient(135deg,rgba(132,106,22,.78),rgba(33,29,13,.72))!important;border-color:var(--v9-gold-hot)!important;color:#fff9d6!important;box-shadow:inset 0 1px rgba(255,255,220,.16),0 0 14px rgba(242,210,87,.18)!important}
.nfh15-v9-horizontal .nfh15-storyboard-tab{background:rgba(6,7,7,.34)!important;border:1px solid rgba(242,210,87,.22)!important;border-radius:4px!important;color:#c9c3a9!important}.nfh15-v9-horizontal .nfh15-storyboard-actions{background:linear-gradient(180deg,rgba(4,5,5,0),rgba(4,5,5,.44))!important;border-top:1px solid rgba(242,210,87,.15)!important}
.nfh15-v9-horizontal .nfh15-storyboard-action.batch{background:linear-gradient(110deg,#806718,#d2ad31 52%,#735b12)!important;border:1px solid #ffe27a!important;color:#120f05!important;font-weight:900!important;letter-spacing:.04em!important;text-shadow:0 1px rgba(255,255,255,.28)!important;box-shadow:inset 0 1px #fff3b8,0 7px 18px rgba(0,0,0,.28)!important}.nfh15-v9-horizontal .nfh15-storyboard-action.batch:hover{background:linear-gradient(110deg,#9a7d1d,#efd05b 52%,#8b6d16)!important;color:#080703!important}
.nfh15-v9-horizontal .nfh15-drop{background:rgba(4,5,5,.20)!important;border:1px dashed rgba(242,210,87,.33)!important;border-radius:6px!important;color:#d1c9a8!important}.nfh15-v9-horizontal .nfh15-drop:hover,.nfh15-v9-horizontal .nfh15-drop.drag{background:rgba(112,91,22,.20)!important;border-color:var(--v9-gold-hot)!important;color:#fff3b4!important}
.nfh15-v9-horizontal .nfh15-card,.nfh15-v9-horizontal .nfh15-preview,.nfh15-v9-horizontal .nfh15-v9-live-preview{background:rgba(3,4,4,.22)!important;border:1px solid rgba(242,210,87,.19)!important;border-radius:6px!important;box-shadow:inset 0 1px rgba(255,255,255,.02)!important}.nfh15-v9-horizontal .nfh15-note,.nfh15-v9-horizontal .nfh15-preview-state,.nfh15-v9-horizontal .nfh15-v9-preview-status{color:#dfc95b!important}
.nfh15-v9-horizontal .nfh15-switch-track{background:rgba(5,6,6,.58)!important;border-color:rgba(242,210,87,.28)!important}.nfh15-v9-horizontal .nfh15-mode-switch{background:rgba(5,6,6,.30)!important;border-color:rgba(242,210,87,.20)!important;border-radius:6px!important}.nfh15-v9-horizontal .nfh15-mode-switch small{color:#aba68f!important}.nfh15-v9-horizontal .nfh15-mode-switch.on .nfh15-switch-track{background:#806819!important;border-color:#f2d257!important}.nfh15-v9-horizontal .nfh15-mode-switch.on .nfh15-switch-knob{background:#fff0a0!important;box-shadow:0 0 8px rgba(255,222,92,.42)!important}
.nfh15-v9-horizontal .nfh15-x{background:rgba(91,24,24,.62)!important;border:1px solid rgba(255,129,105,.32)!important;border-radius:4px!important}.nfh15-v9-horizontal .nfh15-replace{background:rgba(87,70,18,.55)!important;border:1px solid rgba(242,210,87,.42)!important;border-radius:4px!important;color:#fff0aa!important}


/* V9 flat black editorial theme: no glass, no blur, preserve all functionality. */
.nfh3.nfh15-v9-horizontal{--v9-yellow:#e6c83f;--v9-yellow-hi:#f5dd66;--v9-rule:#554a1e;--v9-rule-soft:#302b18;--v9-black:#050505;--v9-panel:#0a0a09;--v9-control:#11110f;--v9-text:#f1efe6;--v9-muted:#aaa796;background-image:linear-gradient(90deg,rgba(0,0,0,.08),rgba(0,0,0,.02) 58%,rgba(0,0,0,.08)),var(--nfh15-v9-bg)!important;background-color:#000!important;border:1px solid #4b421b!important;border-radius:4px!important;box-shadow:0 18px 48px rgba(0,0,0,.72)!important;color:var(--v9-text)!important}
.nfh15-v9-horizontal,.nfh15-v9-horizontal *{backdrop-filter:none!important;-webkit-backdrop-filter:none!important;filter:none}
.nfh15-v9-horizontal::before{display:none!important}
.nfh15-v9-horizontal .nfh15-head{background:#050505!important;border:0!important;border-bottom:1px solid #665820!important;border-radius:0!important;box-shadow:none!important;padding:12px 14px!important}
.nfh15-v9-horizontal .nfh15-title{color:#f4e8ad!important;font-weight:800!important;letter-spacing:.07em!important;text-shadow:none!important}.nfh15-v9-horizontal .nfh15-badge{background:#11100b!important;border:1px solid #4e451e!important;color:#cbbd76!important;border-radius:2px!important;box-shadow:none!important}
.nfh15-v9-horizontal .nfh15-v9-column{background:transparent!important;border:0!important;box-shadow:none!important}
.nfh15-v9-horizontal .nfh15-section,.nfh15-v9-horizontal .nfh15-primary-fold,.nfh15-v9-horizontal .nfh15-advanced{background:#080808!important;border:1px solid #262419!important;border-radius:3px!important;box-shadow:none!important}
.nfh15-v9-horizontal .nfh15-section>summary,.nfh15-v9-horizontal .nfh15-primary-fold>summary,.nfh15-v9-horizontal .nfh15-advanced>summary{min-height:39px!important;background:#0d0d0c!important;border:0!important;border-bottom:1px solid #332e18!important;border-radius:0!important;color:#ded39a!important;box-shadow:inset 3px 0 #927c26!important;text-shadow:none!important;font-weight:750!important;letter-spacing:.025em!important}
.nfh15-v9-horizontal .nfh15-section-body{background:#080808!important}
.nfh15-v9-horizontal .nfh15-field,.nfh15-v9-horizontal .nfh15-settings{background:transparent!important}.nfh15-v9-horizontal .nfh15-field label{color:#aaa796!important;text-shadow:none!important;font-weight:600!important}
.nfh15-v9-horizontal .nfh15-field select,.nfh15-v9-horizontal .nfh15-field input,.nfh15-v9-horizontal .nfh15-prompt textarea,.nfh15-v9-horizontal .nfh15-select-button{background:#11110f!important;border:1px solid #302d1d!important;border-radius:2px!important;color:#f0eee6!important;box-shadow:none!important}
.nfh15-v9-horizontal .nfh15-field select:hover,.nfh15-v9-horizontal .nfh15-field input:hover,.nfh15-v9-horizontal .nfh15-prompt textarea:hover,.nfh15-v9-horizontal .nfh15-select-button:hover{border-color:#625522!important}.nfh15-v9-horizontal .nfh15-field select:focus,.nfh15-v9-horizontal .nfh15-field input:focus,.nfh15-v9-horizontal .nfh15-prompt textarea:focus,.nfh15-v9-horizontal .nfh15-select-button:focus{border-color:#d7bb3a!important;box-shadow:0 0 0 1px #d7bb3a!important;outline:0!important}
.nfh15-v9-horizontal .nfh15-tab,.nfh15-v9-horizontal .nfh15-prompt-tool,.nfh15-v9-horizontal .nfh15-storyboard-action{background:#11110f!important;border:1px solid #302d1d!important;border-radius:2px!important;color:#c6c2b3!important;box-shadow:none!important;transform:none!important;transition:background .12s,border-color .12s,color .12s!important}
.nfh15-v9-horizontal .nfh15-tab:hover,.nfh15-v9-horizontal .nfh15-prompt-tool:hover,.nfh15-v9-horizontal .nfh15-storyboard-action:hover{background:#1a180e!important;border-color:#8d7727!important;color:#f2e8b1!important;transform:none!important}.nfh15-v9-horizontal .nfh15-tab.active,.nfh15-v9-horizontal .nfh15-storyboard-tab.active,.nfh15-v9-horizontal .nfh15-mode-switch.on{background:#d2b63a!important;border-color:#f1d75a!important;color:#080806!important;box-shadow:none!important}
.nfh15-v9-horizontal .nfh15-storyboard-tab{background:#0f0f0e!important;border:1px solid #2e2b1d!important;border-radius:2px!important;color:#aaa796!important;box-shadow:none!important}.nfh15-v9-horizontal .nfh15-storyboard-tab.queued-range{background:#12120f!important;border-color:#46401f!important;color:#c2b975!important}.nfh15-v9-horizontal .nfh15-storyboard-actions{background:#080808!important;border-top:1px solid #302b18!important}
.nfh15-v9-horizontal .nfh15-storyboard-action.batch{background:#d5b83b!important;border:1px solid #f0d35b!important;border-radius:2px!important;color:#090806!important;font-weight:900!important;letter-spacing:.035em!important;text-shadow:none!important;box-shadow:none!important}.nfh15-v9-horizontal .nfh15-storyboard-action.batch:hover{background:#ead051!important;color:#050504!important}
.nfh15-v9-horizontal .nfh15-drop{background:#090909!important;border:1px dashed #54491e!important;border-radius:2px!important;color:#bcb38a!important;box-shadow:none!important}.nfh15-v9-horizontal .nfh15-drop:hover,.nfh15-v9-horizontal .nfh15-drop.drag{background:#12110b!important;border-color:#e2c440!important;color:#f0e3a2!important}
/* The reference-image area stays unusually transparent so the full background artwork remains visible. */
.nfh15-v9-horizontal>.nfh15-v9-column:first-of-type .nfh15-section{background:rgba(3,3,3,.18)!important;border-color:rgba(207,181,58,.26)!important}.nfh15-v9-horizontal>.nfh15-v9-column:first-of-type .nfh15-section-body{background:rgba(3,3,3,.08)!important}.nfh15-v9-horizontal>.nfh15-v9-column:first-of-type .nfh15-section>summary{background:rgba(8,8,8,.68)!important}.nfh15-v9-horizontal>.nfh15-v9-column:first-of-type .nfh15-grid{background:transparent!important}
.nfh15-v9-horizontal .nfh15-card{background:rgba(4,4,4,.24)!important;border:1px solid rgba(213,184,59,.24)!important;border-radius:2px!important;box-shadow:none!important}.nfh15-v9-horizontal .nfh15-empty{color:#8f896d!important;background:rgba(0,0,0,.10)!important}.nfh15-v9-horizontal .nfh15-label{color:#ddd19a!important;background:rgba(0,0,0,.42)!important}
.nfh15-v9-horizontal .nfh15-preview,.nfh15-v9-horizontal .nfh15-v9-live-preview{background:#050505!important;border:1px solid #2d2919!important;border-radius:2px!important;box-shadow:none!important}.nfh15-v9-horizontal .nfh15-preview-head,.nfh15-v9-horizontal .nfh15-v9-preview-head{background:#0d0d0c!important;border-bottom:1px solid #332e18!important;color:#d9cf99!important}.nfh15-v9-horizontal .nfh15-v9-preview-stage{background:#020202!important}.nfh15-v9-horizontal .nfh15-note,.nfh15-v9-horizontal .nfh15-preview-state,.nfh15-v9-horizontal .nfh15-v9-preview-status{color:#c9b74d!important}
.nfh15-v9-horizontal .nfh15-mode-switch{background:#0d0d0c!important;border:1px solid #302d1d!important;border-radius:2px!important;box-shadow:none!important}.nfh15-v9-horizontal .nfh15-mode-switch small{color:#888577!important}.nfh15-v9-horizontal .nfh15-switch-track{background:#181815!important;border-color:#393522!important;box-shadow:none!important}.nfh15-v9-horizontal .nfh15-mode-switch.on .nfh15-switch-track{background:#75651f!important;border-color:#d7bb3a!important}.nfh15-v9-horizontal .nfh15-mode-switch.on .nfh15-switch-knob{background:#f3dc6e!important;box-shadow:none!important}
.nfh15-v9-horizontal .nfh15-x{background:#481b18!important;border:1px solid #78312b!important;border-radius:2px!important;color:#f0a098!important;box-shadow:none!important}.nfh15-v9-horizontal .nfh15-replace{background:#17150b!important;border:1px solid #685923!important;border-radius:2px!important;color:#e2ce76!important;box-shadow:none!important}


/* V9 definitive flat reset: overrides inherited V7 bevels and image-slot pills. */
.nfh3.nfh15-v9-horizontal{border-radius:0!important;box-shadow:none!important}
.nfh15-v9-horizontal .nfh15-head,.nfh15-v9-horizontal .nfh15-section,.nfh15-v9-horizontal .nfh15-primary-fold,.nfh15-v9-horizontal .nfh15-advanced,.nfh15-v9-horizontal .nfh15-section>summary,.nfh15-v9-horizontal .nfh15-primary-fold>summary,.nfh15-v9-horizontal .nfh15-advanced>summary,.nfh15-v9-horizontal .nfh15-mode-switch,.nfh15-v9-horizontal .nfh15-tab,.nfh15-v9-horizontal .nfh15-storyboard-tab,.nfh15-v9-horizontal .nfh15-storyboard-action,.nfh15-v9-horizontal .nfh15-prompt-tool,.nfh15-v9-horizontal .nfh15-field select,.nfh15-v9-horizontal .nfh15-field input,.nfh15-v9-horizontal .nfh15-prompt textarea,.nfh15-v9-horizontal .nfh15-select-button,.nfh15-v9-horizontal .nfh15-drop,.nfh15-v9-horizontal .nfh15-card,.nfh15-v9-horizontal .nfh15-preview,.nfh15-v9-horizontal .nfh15-v9-live-preview,.nfh15-v9-horizontal .nfh15-media-player{background-image:none!important;box-shadow:none!important;filter:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important;text-shadow:none!important}
.nfh15-v9-horizontal .nfh15-head::before,.nfh15-v9-horizontal .nfh15-head::after,.nfh15-v9-horizontal .nfh15-mode-switch::before,.nfh15-v9-horizontal .nfh15-mode-switch::after,.nfh15-v9-horizontal .nfh15-card::before,.nfh15-v9-horizontal .nfh15-card::after{content:none!important;display:none!important;background:none!important;box-shadow:none!important;filter:none!important}
.nfh15-v9-horizontal .nfh15-head{background:#000!important;border:0!important;border-bottom:1px solid #4a411b!important;padding:10px 12px!important}
.nfh15-v9-horizontal .nfh15-badge{background:#0a0a09!important;background-image:none!important;border:1px solid #373219!important;border-radius:0!important;box-shadow:none!important;text-shadow:none!important}
.nfh15-v9-horizontal .nfh15-section,.nfh15-v9-horizontal .nfh15-primary-fold,.nfh15-v9-horizontal .nfh15-advanced{background:#060606!important;border:1px solid #1e1d16!important;border-radius:0!important}
.nfh15-v9-horizontal .nfh15-section>summary,.nfh15-v9-horizontal .nfh15-primary-fold>summary,.nfh15-v9-horizontal .nfh15-advanced>summary{background:#0a0a09!important;border:0!important;border-bottom:1px solid #282515!important;border-radius:0!important;box-shadow:inset 2px 0 #8c7826!important}
.nfh15-v9-horizontal .nfh15-section[open]>summary,.nfh15-v9-horizontal .nfh15-primary-fold[open]>summary,.nfh15-v9-horizontal .nfh15-advanced[open]>summary{box-shadow:inset 2px 0 #c3a936!important}
.nfh15-v9-horizontal .nfh15-section-body{background:#060606!important}
.nfh15-v9-horizontal .nfh15-mode-switch{background:#0b0b0a!important;border:1px solid #272518!important;border-radius:0!important;transform:none!important}
.nfh15-v9-horizontal .nfh15-mode-switch:hover{background:#10100d!important;border-color:#5e5221!important;transform:none!important}.nfh15-v9-horizontal .nfh15-mode-switch.on{background:#c4a936!important;border-color:#c4a936!important;color:#060605!important}.nfh15-v9-horizontal .nfh15-mode-switch.on small{color:#342d0f!important}
.nfh15-v9-horizontal .nfh15-switch-track{border-radius:1px!important;background:#171713!important;border:1px solid #34311f!important;box-shadow:none!important}.nfh15-v9-horizontal .nfh15-switch-knob{border-radius:1px!important;background:#777464!important;box-shadow:none!important}.nfh15-v9-horizontal .nfh15-mode-switch.on .nfh15-switch-track{background:#5a4d18!important;border-color:#6e5f1e!important}.nfh15-v9-horizontal .nfh15-mode-switch.on .nfh15-switch-knob{background:#fff0a0!important;box-shadow:none!important}
/* Image supply zone: one flat transparent matrix, not nine raised cards. */
.nfh15-v9-horizontal>.nfh15-v9-column:first-of-type .nfh15-section,.nfh15-v9-horizontal>.nfh15-v9-column:first-of-type .nfh15-section-body{background:rgba(0,0,0,.06)!important;border-color:rgba(196,169,54,.20)!important}
.nfh15-v9-horizontal .nfh15-grid{gap:1px!important;background:rgba(196,169,54,.18)!important;border:1px solid rgba(196,169,54,.20)!important;padding:0!important}
.nfh15-v9-horizontal .nfh15-card{aspect-ratio:1/1!important;padding:0!important;border:0!important;border-radius:0!important;background:rgba(0,0,0,.10)!important;box-shadow:none!important;outline:0!important}
.nfh15-v9-horizontal .nfh15-card:hover{background:rgba(196,169,54,.055)!important}.nfh15-v9-horizontal .nfh15-card.drag-target{background:rgba(196,169,54,.12)!important;border:0!important;outline:1px solid #d4b83b!important;outline-offset:-1px!important}
.nfh15-v9-horizontal .nfh15-card img{position:absolute!important;inset:0!important;width:100%!important;height:100%!important;border-radius:0!important;object-fit:cover!important;background:transparent!important}
.nfh15-v9-horizontal .nfh15-empty{position:absolute!important;inset:0!important;width:100%!important;height:100%!important;background:transparent!important;color:#a69d70!important;font-weight:500!important;text-shadow:none!important}
.nfh15-v9-horizontal .nfh15-label{position:absolute!important;z-index:4!important;left:0!important;right:0!important;bottom:0!important;width:100%!important;height:21px!important;line-height:21px!important;padding:0 6px!important;border:0!important;border-top:1px solid rgba(196,169,54,.14)!important;border-radius:0!important;background:rgba(0,0,0,.58)!important;color:#c9bd79!important;box-shadow:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important;text-shadow:none!important}
.nfh15-v9-horizontal .nfh15-card:not(:has(img)) .nfh15-label{display:none!important}
.nfh15-v9-horizontal .nfh15-replace,.nfh15-v9-horizontal .nfh15-x{border-radius:0!important;box-shadow:none!important;background-image:none!important}
/* Flat controls and actions: no highlights, gradients, glow or elevation. */
.nfh15-v9-horizontal .nfh15-tab,.nfh15-v9-horizontal .nfh15-storyboard-tab,.nfh15-v9-horizontal .nfh15-storyboard-action,.nfh15-v9-horizontal .nfh15-prompt-tool{background:#0d0d0c!important;border:1px solid #282617!important;border-radius:0!important;transform:none!important}
.nfh15-v9-horizontal .nfh15-tab:hover,.nfh15-v9-horizontal .nfh15-storyboard-tab:hover,.nfh15-v9-horizontal .nfh15-storyboard-action:hover,.nfh15-v9-horizontal .nfh15-prompt-tool:hover{background:#15140d!important;border-color:#685922!important;transform:none!important}.nfh15-v9-horizontal .nfh15-tab.active,.nfh15-v9-horizontal .nfh15-storyboard-tab.active{background:#c4a936!important;border-color:#c4a936!important;color:#050504!important}
.nfh15-v9-horizontal .nfh15-storyboard-action.batch{background:#c4a936!important;background-image:none!important;border:1px solid #c4a936!important;border-radius:0!important;color:#050504!important;box-shadow:none!important;text-shadow:none!important}.nfh15-v9-horizontal .nfh15-storyboard-action.batch:hover{background:#d7bb42!important}
.nfh15-v9-horizontal .nfh15-field select,.nfh15-v9-horizontal .nfh15-field input,.nfh15-v9-horizontal .nfh15-prompt textarea,.nfh15-v9-horizontal .nfh15-select-button{background:#0e0e0d!important;border:1px solid #292719!important;border-radius:0!important}.nfh15-v9-horizontal .nfh15-drop{background:rgba(0,0,0,.16)!important;border:1px dashed #4b421d!important;border-radius:0!important}
.nfh15-v9-horizontal .nfh15-preview,.nfh15-v9-horizontal .nfh15-v9-live-preview,.nfh15-v9-horizontal .nfh15-preview-head,.nfh15-v9-horizontal .nfh15-v9-preview-head,.nfh15-v9-horizontal .nfh15-v9-preview-stage{border-radius:0!important;box-shadow:none!important;background-image:none!important}


/* V9 background-first balanced flat theme: separated translucent slots, solid actions. */
.nfh3.nfh15-v9-horizontal{background-image:linear-gradient(rgba(0,0,0,.025),rgba(0,0,0,.025)),var(--nfh15-v9-bg)!important;background-size:100% 100%,auto 100%!important;background-position:left top,left top!important;background-repeat:no-repeat,no-repeat!important;background-color:#000!important}
/* Content surfaces are translucent, but remain flat: no blur, highlights, gradients or elevation. */
.nfh15-v9-horizontal .nfh15-section,.nfh15-v9-horizontal .nfh15-primary-fold,.nfh15-v9-horizontal .nfh15-advanced{background:rgba(5,5,5,.42)!important;border-color:rgba(204,179,73,.20)!important}
.nfh15-v9-horizontal .nfh15-section-body{background:rgba(4,4,4,.28)!important}
.nfh15-v9-horizontal .nfh15-section>summary,.nfh15-v9-horizontal .nfh15-primary-fold>summary,.nfh15-v9-horizontal .nfh15-advanced>summary{background:rgba(8,8,8,.66)!important}
.nfh15-v9-horizontal .nfh15-prompt,.nfh15-v9-horizontal .nfh15-settings,.nfh15-v9-horizontal .nfh15-resolution{background:transparent!important}
.nfh15-v9-horizontal .nfh15-field select,.nfh15-v9-horizontal .nfh15-field input,.nfh15-v9-horizontal .nfh15-prompt textarea,.nfh15-v9-horizontal .nfh15-select-button{background:rgba(10,10,9,.66)!important}
.nfh15-v9-horizontal .nfh15-preview,.nfh15-v9-horizontal .nfh15-v9-live-preview{background:rgba(3,3,3,.52)!important}.nfh15-v9-horizontal .nfh15-preview-head,.nfh15-v9-horizontal .nfh15-v9-preview-head{background:rgba(8,8,8,.76)!important}.nfh15-v9-horizontal .nfh15-v9-preview-stage{background:rgba(2,2,2,.62)!important}
/* Reference supply area: clearly separated slots with breathing room and a visible continuous backdrop. */
.nfh15-v9-horizontal>.nfh15-v9-column:first-of-type .nfh15-section{background:rgba(2,2,2,.20)!important;border-color:rgba(204,179,73,.19)!important}
.nfh15-v9-horizontal>.nfh15-v9-column:first-of-type .nfh15-section-body{background:rgba(2,2,2,.10)!important}
.nfh15-v9-horizontal .nfh15-grid{gap:7px!important;padding:1px!important;background:transparent!important;border:0!important}
.nfh15-v9-horizontal .nfh15-card{padding:0!important;border:1px solid rgba(213,190,92,.26)!important;border-radius:2px!important;background:rgba(6,6,5,.36)!important;box-shadow:none!important;outline:0!important}
.nfh15-v9-horizontal .nfh15-card:hover{background:rgba(20,18,9,.43)!important;border-color:rgba(232,207,103,.48)!important}.nfh15-v9-horizontal .nfh15-card.drag-target{background:rgba(33,28,9,.48)!important;border:1px solid #d4b83b!important;outline:0!important}
.nfh15-v9-horizontal .nfh15-empty{background:transparent!important;color:rgba(224,211,148,.72)!important}
.nfh15-v9-horizontal .nfh15-card img{inset:0!important;border-radius:1px!important}.nfh15-v9-horizontal .nfh15-label{background:rgba(0,0,0,.64)!important}
/* Buttons stay solid and visually actionable; they are the only intentionally opaque controls. */
.nfh15-v9-horizontal .nfh15-tab,.nfh15-v9-horizontal .nfh15-storyboard-tab,.nfh15-v9-horizontal .nfh15-storyboard-action,.nfh15-v9-horizontal .nfh15-prompt-tool,.nfh15-v9-horizontal .nfh15-mode-switch,.nfh15-v9-horizontal .nfh15-replace,.nfh15-v9-horizontal .nfh15-x{background:#10100e!important;opacity:1!important}
.nfh15-v9-horizontal .nfh15-tab.active,.nfh15-v9-horizontal .nfh15-storyboard-tab.active,.nfh15-v9-horizontal .nfh15-mode-switch.on,.nfh15-v9-horizontal .nfh15-storyboard-action.batch{background:#c4a936!important;color:#050504!important;opacity:1!important}


/* V9 two-tone typography: gold headings/actions, neutral gray supporting text. */
.nfh15-v9-horizontal{--v9-type-gold:#d4bb52;--v9-type-gold-bright:#ead36e;--v9-type-gray:#aaa99f;--v9-type-gray-bright:#d3d1c7;--v9-type-gray-muted:#7f7e76}
.nfh15-v9-horizontal .nfh15-title,.nfh15-v9-horizontal .nfh15-section>summary,.nfh15-v9-horizontal .nfh15-primary-fold>summary,.nfh15-v9-horizontal .nfh15-advanced>summary,.nfh15-v9-horizontal .nfh15-v9-preview-head b,.nfh15-v9-horizontal .nfh15-prompt-tools-title{color:var(--v9-type-gold)!important}
.nfh15-v9-horizontal .nfh15-field label,.nfh15-v9-horizontal .nfh15-mode-switch small,.nfh15-v9-horizontal .nfh15-v9-preview-head small,.nfh15-v9-horizontal .nfh15-empty,.nfh15-v9-horizontal .nfh15-mode-note{color:var(--v9-type-gray)!important}
.nfh15-v9-horizontal .nfh15-field select,.nfh15-v9-horizontal .nfh15-field input,.nfh15-v9-horizontal .nfh15-prompt textarea,.nfh15-v9-horizontal .nfh15-select-button{color:var(--v9-type-gray-bright)!important}
.nfh15-v9-horizontal .nfh15-note,.nfh15-v9-horizontal .nfh15-preview-state,.nfh15-v9-horizontal .nfh15-v9-preview-status{color:var(--v9-type-gray)!important}
.nfh15-v9-horizontal .nfh15-v9-preview-status[hidden]{display:none!important}.nfh15-v9-horizontal .nfh15-v9-preview-status{background:rgba(5,5,5,.70)!important;border-top:1px solid rgba(212,187,82,.17)!important;font-variant-numeric:tabular-nums!important}


/* V9 strict color normalization: gold or neutral gray only, including arrows, placeholders and scrollbars. */
.nfh3.nfh15-v9-horizontal,.nfh15-v9-horizontal .nfh15-v9-column,.nfh15-v9-horizontal .nfh15-storyboard-tabs,.nfh15-v9-horizontal .nfh15-select-list{scrollbar-color:#8f7a2b rgba(10,10,9,.42)!important}
.nfh15-v9-horizontal::-webkit-scrollbar,.nfh15-v9-horizontal .nfh15-v9-column::-webkit-scrollbar,.nfh15-v9-horizontal .nfh15-storyboard-tabs::-webkit-scrollbar,.nfh15-v9-menu::-webkit-scrollbar,.nfh15-v9-menu .nfh15-select-list::-webkit-scrollbar{width:8px!important;height:8px!important}
.nfh15-v9-horizontal::-webkit-scrollbar-track,.nfh15-v9-horizontal .nfh15-v9-column::-webkit-scrollbar-track,.nfh15-v9-horizontal .nfh15-storyboard-tabs::-webkit-scrollbar-track,.nfh15-v9-menu::-webkit-scrollbar-track,.nfh15-v9-menu .nfh15-select-list::-webkit-scrollbar-track{background:rgba(10,10,9,.42)!important}
.nfh15-v9-horizontal::-webkit-scrollbar-thumb,.nfh15-v9-horizontal .nfh15-v9-column::-webkit-scrollbar-thumb,.nfh15-v9-horizontal .nfh15-storyboard-tabs::-webkit-scrollbar-thumb,.nfh15-v9-menu::-webkit-scrollbar-thumb,.nfh15-v9-menu .nfh15-select-list::-webkit-scrollbar-thumb{background:#8f7a2b!important;border:0!important;border-radius:0!important}
.nfh15-v9-horizontal .nfh15-select-button span{color:#d3d1c7!important}.nfh15-v9-horizontal .nfh15-select-button i{color:#d4bb52!important;text-shadow:none!important;filter:none!important}
.nfh15-v9-horizontal .nfh15-prompt textarea::placeholder,.nfh15-v9-horizontal .nfh15-field input::placeholder,.nfh15-v9-horizontal .nfh15-field textarea::placeholder{color:#8f8e86!important;opacity:1!important}
.nfh15-v9-horizontal .nfh15-prompt small,.nfh15-v9-horizontal .nfh15-prompt label,.nfh15-v9-horizontal .nfh15-resolution,.nfh15-v9-horizontal .nfh15-mode-note,.nfh15-v9-horizontal .nfh15-note{color:#aaa99f!important}
.nfh15-v9-horizontal .nfh15-tab,.nfh15-v9-horizontal .nfh15-storyboard-tab,.nfh15-v9-horizontal .nfh15-storyboard-action,.nfh15-v9-horizontal .nfh15-prompt-tool,.nfh15-v9-horizontal .nfh15-mode-switch{color:#c8c6bb!important}
.nfh15-v9-horizontal .nfh15-tab.active,.nfh15-v9-horizontal .nfh15-storyboard-tab.active,.nfh15-v9-horizontal .nfh15-storyboard-action.batch,.nfh15-v9-horizontal .nfh15-mode-switch.on{color:#050504!important}
/* Detached custom menus live under body, so V9 gets an explicit class instead of inheriting old teal V7 colors. */
.nfh15-select-menu.nfh15-v9-menu{background:#090909!important;border:1px solid #4a421e!important;border-radius:0!important;box-shadow:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important;scrollbar-color:#8f7a2b #10100e!important}
.nfh15-select-menu.nfh15-v9-menu .nfh15-select-search{background:#10100e!important;border:1px solid #302d1d!important;border-radius:0!important;color:#d3d1c7!important;box-shadow:none!important}.nfh15-select-menu.nfh15-v9-menu .nfh15-select-search::placeholder{color:#818078!important}.nfh15-select-menu.nfh15-v9-menu .nfh15-select-search:focus{border-color:#d4bb52!important;box-shadow:0 0 0 1px #d4bb52!important}
.nfh15-select-menu.nfh15-v9-menu .nfh15-select-option{background:#090909!important;color:#b8b6ac!important;border-radius:0!important;box-shadow:none!important}.nfh15-select-menu.nfh15-v9-menu .nfh15-select-option:hover,.nfh15-select-menu.nfh15-v9-menu .nfh15-select-option.keyboard{background:#17150c!important;color:#e0dcd0!important}.nfh15-select-menu.nfh15-v9-menu .nfh15-select-option.selected{background:#c4a936!important;color:#050504!important;box-shadow:none!important}.nfh15-select-menu.nfh15-v9-menu .nfh15-select-option .mark{color:transparent!important}.nfh15-select-menu.nfh15-v9-menu .nfh15-select-option.selected .mark{color:#050504!important}.nfh15-select-menu.nfh15-v9-menu .nfh15-select-empty{color:#85847c!important}


/* V9 fold indicators: gold only. */
.nfh15-v9-horizontal .nfh15-section>summary::after,.nfh15-v9-horizontal .nfh15-primary-fold>summary::after,.nfh15-v9-horizontal .nfh15-advanced>summary::after{color:#d4bb52!important;text-shadow:none!important;filter:none!important}
.nfh15-v9-horizontal .nfh15-section[open]>summary::after,.nfh15-v9-horizontal .nfh15-primary-fold[open]>summary::after,.nfh15-v9-horizontal .nfh15-advanced[open]>summary::after{color:#ead36e!important}


/* V9 preview empty state: large square yellow editorial wordmark. */
.nfh15-v9-horizontal .nfh15-v9-preview-empty{display:grid!important;place-items:center!important;width:auto!important;height:auto!important;padding:0!important;background:transparent!important;color:#d4bb52!important;font-family:"Microsoft YaHei UI","Arial Black",sans-serif!important;font-size:clamp(34px,5.4cqw,58px)!important;font-weight:900!important;line-height:1!important;letter-spacing:.18em!important;text-indent:.18em!important;text-align:center!important;text-shadow:none!important;border:0!important;border-radius:0!important}


/* V9 high-chroma yellow pass: clear yellow, not muted gold. */
.nfh15-v9-horizontal{--v9-yellow:#ffd21f;--v9-yellow-hi:#ffe45a;--v9-type-gold:#ffd21f;--v9-type-gold-bright:#ffe45a;--v9-gold:#ffd21f;--v9-gold-hot:#ffe45a;--v9-gold-deep:#a88400;--v9-line:#8f7410;--v9-line-soft:#55470b}
.nfh15-v9-horizontal .nfh15-title,.nfh15-v9-horizontal .nfh15-section>summary,.nfh15-v9-horizontal .nfh15-primary-fold>summary,.nfh15-v9-horizontal .nfh15-advanced>summary,.nfh15-v9-horizontal .nfh15-v9-preview-head b,.nfh15-v9-horizontal .nfh15-prompt-tools-title{color:#ffd21f!important}
.nfh15-v9-horizontal .nfh15-select-button i,.nfh15-v9-horizontal .nfh15-section>summary::after,.nfh15-v9-horizontal .nfh15-primary-fold>summary::after,.nfh15-v9-horizontal .nfh15-advanced>summary::after{color:#ffd21f!important}
.nfh15-v9-horizontal .nfh15-section[open]>summary::after,.nfh15-v9-horizontal .nfh15-primary-fold[open]>summary::after,.nfh15-v9-horizontal .nfh15-advanced[open]>summary::after{color:#ffe45a!important}
.nfh15-v9-horizontal .nfh15-v9-preview-empty{font-size:clamp(22px,3.4cqw,38px)!important;letter-spacing:.08em!important;text-indent:.08em!important;color:#ffd21f!important;font-weight:800!important}
.nfh15-v9-horizontal .nfh15-v9-preview-head small,.nfh15-v9-horizontal .nfh15-field label,.nfh15-v9-horizontal .nfh15-empty,.nfh15-v9-horizontal .nfh15-note,.nfh15-v9-horizontal .nfh15-preview-state,.nfh15-v9-horizontal .nfh15-v9-preview-status,.nfh15-v9-horizontal .nfh15-mode-switch small,.nfh15-v9-horizontal .nfh15-prompt small{color:#aaa99f!important}
.nfh15-v9-horizontal .nfh15-storyboard-action.batch,.nfh15-v9-horizontal .nfh15-tab.active,.nfh15-v9-horizontal .nfh15-storyboard-tab.active,.nfh15-v9-horizontal .nfh15-mode-switch.on{background:#ffd21f!important;border-color:#ffe45a!important;color:#070706!important}
.nfh15-v9-horizontal .nfh15-replace{border-color:#a48613!important;color:#ffd21f!important}.nfh15-v9-horizontal .nfh15-x{color:#e7a09a!important}
.nfh3.nfh15-v9-horizontal,.nfh15-v9-horizontal *{scrollbar-color:#c7a500 rgba(10,10,9,.42)!important}.nfh15-v9-horizontal::-webkit-scrollbar-thumb,.nfh15-v9-horizontal .nfh15-v9-column::-webkit-scrollbar-thumb,.nfh15-v9-horizontal .nfh15-storyboard-tabs::-webkit-scrollbar-thumb,.nfh15-v9-menu::-webkit-scrollbar-thumb{background:#c7a500!important}


/* V9 smart storyboard panel: flat high-chroma yellow/black, no teal inheritance. */
.nfh15-smart-overlay{background:rgba(0,0,0,.78)!important}
.nfh15-smart-panel{background:#080908!important;border:1px solid #7f6810!important;border-radius:3px!important;color:#e9e7dc!important;box-shadow:0 22px 60px rgba(0,0,0,.78)!important}
.nfh15-smart-panel>div:first-child{color:#ffd21f!important;font-size:18px!important;letter-spacing:.025em!important}
.nfh15-smart-panel label{color:#aaa99f!important}.nfh15-smart-panel b{color:#ffd21f!important}.nfh15-smart-panel [data-smart-config],.nfh15-smart-panel [data-smart-mode-hint],.nfh15-smart-panel [data-smart-skill-hint],.nfh15-smart-panel [data-smart-status]{color:#aaa99f!important}
.nfh15-smart-panel input,.nfh15-smart-panel textarea,.nfh15-smart-panel select{background:#11120f!important;color:#e7e5dc!important;border-color:#403818!important;border-radius:2px!important;box-shadow:none!important}
.nfh15-smart-panel input::placeholder,.nfh15-smart-panel textarea::placeholder{color:#77776f!important;opacity:1!important}.nfh15-smart-panel input:focus,.nfh15-smart-panel textarea:focus,.nfh15-smart-panel select:focus{border-color:#ffd21f!important;box-shadow:0 0 0 1px #ffd21f!important;outline:0!important}
.nfh15-smart-panel button{background:#15150f!important;color:#c9c7bb!important;border:1px solid #4a411e!important;border-radius:2px!important;box-shadow:none!important;text-shadow:none!important;transform:none!important}
.nfh15-smart-panel button:hover{background:#24200d!important;color:#ffd21f!important;border-color:#a98b16!important;transform:none!important}
.nfh15-smart-panel [data-smart-config-toggle],.nfh15-smart-panel [data-smart-add],.nfh15-smart-panel [data-detect-models]{color:#ffd21f!important;border-color:#a98b16!important}
.nfh15-smart-panel [data-smart-run]{background:#ffd21f!important;color:#080806!important;border-color:#ffe45a!important;font-weight:800!important}.nfh15-smart-panel [data-smart-run]:hover{background:#ffe45a!important;color:#080806!important}
.nfh15-smart-panel [data-config-clear]{background:#351817!important;color:#f0aaa2!important;border-color:#70312c!important}
.nfh15-smart-panel [data-smart-config-panel],.nfh15-smart-panel section{background:rgba(8,9,8,.46)!important;border-color:#383119!important;border-radius:2px!important;box-shadow:none!important}
.nfh15-smart-panel [data-smart-images]>div{background:rgba(6,7,6,.34)!important;border-color:#4a411e!important;border-radius:2px!important}.nfh15-smart-panel [data-smart-images] img{border-radius:1px!important}.nfh15-smart-panel [data-smart-images] span{background:rgba(0,0,0,.70)!important;color:#ffd21f!important}.nfh15-smart-panel [data-smart-images] button{color:#ffd21f!important}
.nfh15-smart-panel [data-smart-mode],.nfh15-smart-panel [data-smart-count]{color:#e7e5dc!important}.nfh15-smart-panel [data-smart-cancel]{color:#aaa99f!important}


.nfh15-v9-horizontal .nfh15-audio-drive-fold>summary{background:linear-gradient(90deg,rgba(5,5,3,.08) 0%,rgba(95,79,10,.54) 58%,#f4d20b 100%)!important;color:#fff3ae!important;border-color:#9b852c!important;text-shadow:0 1px 2px #000!important}.nfh15-v9-horizontal .nfh15-audio-drive-fold>summary::after{color:#161100!important}

/* V9/V10 compact LoRA rows: all controls share one baseline. */
.nfh15-v9-horizontal .nfh15-lora-dynamic{display:flex;flex-direction:column;gap:7px;padding:8px 10px 10px;background:transparent!important}
.nfh15-v9-horizontal .nfh15-lora-list{display:flex;flex-direction:column;gap:5px}
.nfh15-v9-horizontal .nfh15-lora-row{display:grid;grid-template-columns:28px 58px minmax(0,1fr) 86px 48px;align-items:end;gap:7px;min-width:0;padding:6px 0;border-bottom:1px solid #2d2918;background:transparent!important}
.nfh15-v9-horizontal .nfh15-lora-row:last-child{border-bottom:0}
.nfh15-v9-horizontal .nfh15-lora-title{align-self:center;color:#e3dba7;font-size:12px;white-space:nowrap}
.nfh15-v9-horizontal .nfh15-lora-row .nfh15-field{margin:0!important;min-width:0}
.nfh15-v9-horizontal .nfh15-lora-row .nfh15-field label{height:14px;margin:0 0 3px!important;font-size:10px;line-height:14px;color:#817d69!important}
.nfh15-v9-horizontal .nfh15-lora-enable{align-self:center;width:28px;overflow:hidden!important}
.nfh15-v9-horizontal .nfh15-lora-enable label{display:none!important}
.nfh15-v9-horizontal .nfh15-lora-enable input[type=checkbox]{display:block!important;width:20px!important;height:20px!important;margin:0!important;padding:0!important}
.nfh15-v9-horizontal .nfh15-lora-model select,.nfh15-v9-horizontal .nfh15-lora-model input,.nfh15-v9-horizontal .nfh15-lora-strength input{height:30px!important}
.nfh15-v9-horizontal .nfh15-lora-search input{width:100%!important;min-width:0!important;padding:0 9px!important;background:#0b0b08!important;border:1px solid #4e451f!important;color:#e8e3cd!important;border-radius:2px!important;box-shadow:none!important}
.nfh15-v9-horizontal .nfh15-lora-search input:focus{outline:none!important;border-color:#c2a72e!important}
.nfh15-v9-horizontal .nfh15-lora-missing{height:30px;display:flex;align-items:center;padding:0 8px;border:1px solid #6a382b;background:#21110e;color:#e6a193;font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.nfh15-v9-horizontal .nfh15-lora-delete{align-self:end;width:48px;height:30px;padding:0;border:1px solid #51472a;border-radius:2px;background:#15140f;color:#bdb79c;font-size:11px;box-shadow:none}
.nfh15-v9-horizontal .nfh15-lora-delete:hover{border-color:#a3872d;color:#f0d85c;background:#1d1a0f}
.nfh15-v9-horizontal .nfh15-lora-add{height:31px;margin-top:3px;border:1px solid #695a25;border-radius:2px;background:#17160f;color:#e0c84f;font-weight:700;box-shadow:none}
.nfh15-v9-horizontal .nfh15-lora-add:hover{background:#24200f;border-color:#c6a92f}
.nfh15-v9-horizontal .nfh15-lora-add:disabled{opacity:.45;cursor:not-allowed}

/* V11 jade-cyan finish: sampled from the supplied character artwork. */
.nfh3.nfh15-v9-horizontal{--v11-cyan:#57e3d2;--v11-cyan-hi:#a8fff4;--v11-cyan-mid:#27b9ae;--v11-cyan-deep:#0b706c;--v11-line:rgba(87,227,210,.34);--v11-line-soft:rgba(87,227,210,.17);--v11-ink:#eafffc;--v11-muted:#9dbbb8;border-color:#176a68!important;scrollbar-color:#218f88 rgba(3,15,15,.58)!important}
.nfh15-v9-horizontal .nfh15-head{background:linear-gradient(90deg,rgba(2,18,18,.96),rgba(6,60,57,.82) 46%,rgba(2,17,18,.96))!important;border-bottom-color:#258d87!important}
.nfh15-v9-horizontal .nfh15-title{background:linear-gradient(90deg,#eafffc 0%,#87f5e7 48%,#34cabe 76%,#c9fff8 100%)!important;-webkit-background-clip:text!important;background-clip:text!important;color:transparent!important}
.nfh15-v9-horizontal .nfh15-badge{background:#071c1b!important;border-color:#236d69!important;color:#8ee9de!important}
.nfh15-v9-horizontal .nfh15-section,.nfh15-v9-horizontal .nfh15-primary-fold,.nfh15-v9-horizontal .nfh15-advanced{border-color:var(--v11-line-soft)!important;background:rgba(2,13,13,.46)!important}
.nfh15-v9-horizontal .nfh15-section>summary,.nfh15-v9-horizontal .nfh15-primary-fold>summary,.nfh15-v9-horizontal .nfh15-advanced>summary{background:linear-gradient(90deg,rgba(3,33,32,.94),rgba(5,18,18,.84))!important;border-bottom-color:rgba(87,227,210,.20)!important;box-shadow:inset 2px 0 #27a99f!important;color:#79e7da!important}
.nfh15-v9-horizontal .nfh15-section[open]>summary,.nfh15-v9-horizontal .nfh15-primary-fold[open]>summary,.nfh15-v9-horizontal .nfh15-advanced[open]>summary{box-shadow:inset 2px 0 #76f3e4!important}
.nfh15-v9-horizontal .nfh15-section>summary::after,.nfh15-v9-horizontal .nfh15-primary-fold>summary::after,.nfh15-v9-horizontal .nfh15-advanced>summary::after,.nfh15-v9-horizontal .nfh15-select-button i{color:#62e3d6!important}
.nfh15-v9-horizontal .nfh15-section-body{background:rgba(2,12,12,.31)!important}
.nfh15-v9-horizontal .nfh15-field label,.nfh15-v9-horizontal .nfh15-mode-switch small,.nfh15-v9-horizontal .nfh15-prompt small,.nfh15-v9-horizontal .nfh15-empty,.nfh15-v9-horizontal .nfh15-note,.nfh15-v9-horizontal .nfh15-mode-note{color:#9dbbb8!important}
.nfh15-v9-horizontal .nfh15-field select,.nfh15-v9-horizontal .nfh15-field input,.nfh15-v9-horizontal .nfh15-prompt textarea,.nfh15-v9-horizontal .nfh15-select-button{background:linear-gradient(180deg,rgba(5,25,24,.88),rgba(3,14,14,.92))!important;border-color:rgba(77,202,191,.28)!important;color:#e7f8f5!important}
.nfh15-v9-horizontal .nfh15-field select:hover,.nfh15-v9-horizontal .nfh15-field input:hover,.nfh15-v9-horizontal .nfh15-prompt textarea:hover,.nfh15-v9-horizontal .nfh15-select-button:hover{border-color:rgba(93,232,218,.52)!important}
.nfh15-v9-horizontal .nfh15-field select:focus,.nfh15-v9-horizontal .nfh15-field input:focus,.nfh15-v9-horizontal .nfh15-prompt textarea:focus,.nfh15-v9-horizontal .nfh15-select-button:focus{border-color:#57e3d2!important;box-shadow:0 0 0 1px #57e3d2!important}
.nfh15-v9-horizontal .nfh15-tab,.nfh15-v9-horizontal .nfh15-storyboard-tab,.nfh15-v9-horizontal .nfh15-storyboard-action,.nfh15-v9-horizontal .nfh15-prompt-tool,.nfh15-v9-horizontal .nfh15-mode-switch{background:linear-gradient(180deg,#102725 0%,#071817 100%)!important;border-color:rgba(77,202,191,.28)!important;color:#cae2df!important}
.nfh15-v9-horizontal .nfh15-tab:hover,.nfh15-v9-horizontal .nfh15-storyboard-tab:hover,.nfh15-v9-horizontal .nfh15-storyboard-action:hover,.nfh15-v9-horizontal .nfh15-prompt-tool:hover,.nfh15-v9-horizontal .nfh15-mode-switch:hover{background:linear-gradient(180deg,#173a37 0%,#0a2422 100%)!important;border-color:rgba(108,241,227,.55)!important;color:#eafffc!important}
.nfh15-v9-horizontal .nfh15-tab.active,.nfh15-v9-horizontal .nfh15-storyboard-tab.active,.nfh15-v9-horizontal .nfh15-mode-switch.on,.nfh15-v9-horizontal .nfh15-storyboard-action.batch{background:linear-gradient(135deg,#66eadb 0%,#28b9af 52%,#117a76 100%)!important;border-color:#9cfff3!important;color:#02100f!important}
.nfh15-v9-horizontal .nfh15-batch-icon{background:linear-gradient(135deg,#d8fffa 0%,#5ce6d7 45%,#11847e 100%)!important;color:#03211f!important;box-shadow:0 0 13px rgba(67,222,207,.38)!important}
.nfh15-v9-horizontal .nfh15-drop{background:rgba(2,19,18,.58)!important;border-color:rgba(87,227,210,.34)!important;color:#a9cbc7!important}.nfh15-v9-horizontal .nfh15-drop:hover,.nfh15-v9-horizontal .nfh15-drop.drag{background:rgba(9,73,69,.42)!important;border-color:#67eadc!important;color:#e5fffb!important}
.nfh15-v9-horizontal>.nfh15-v9-column:first-of-type .nfh15-section,.nfh15-v9-horizontal>.nfh15-v9-column:first-of-type .nfh15-section-body{border-color:rgba(87,227,210,.20)!important}.nfh15-v9-horizontal .nfh15-card{border-color:rgba(91,220,207,.28)!important;background:rgba(2,22,21,.36)!important}.nfh15-v9-horizontal .nfh15-card:hover{background:rgba(8,60,57,.42)!important;border-color:rgba(126,246,234,.50)!important}.nfh15-v9-horizontal .nfh15-card.drag-target{background:rgba(10,87,82,.48)!important;border-color:#72ecdf!important}
.nfh15-v9-horizontal .nfh15-label{border-top-color:rgba(87,227,210,.20)!important;color:#9de9e0!important}.nfh15-v9-horizontal .nfh15-replace{background:#0d302e!important;border-color:#288f89!important;color:#7deade!important}
.nfh15-v9-horizontal .nfh15-preview,.nfh15-v9-horizontal .nfh15-v9-live-preview{border-color:rgba(87,227,210,.23)!important;background:rgba(2,16,16,.64)!important}.nfh15-v9-horizontal .nfh15-preview-head,.nfh15-v9-horizontal .nfh15-v9-preview-head{background:linear-gradient(90deg,#072725,#061817)!important;border-bottom-color:rgba(87,227,210,.24)!important;color:#79e7da!important}.nfh15-v9-horizontal .nfh15-v9-preview-empty,.nfh15-v9-horizontal .nfh15-v9-preview-status,.nfh15-v9-horizontal .nfh15-preview-state{color:#57e3d2!important}
.nfh15-v9-horizontal .nfh15-switch-track{background:#061c1b!important;border-color:#256864!important}.nfh15-v9-horizontal .nfh15-mode-switch.on .nfh15-switch-track{background:linear-gradient(90deg,#0b6d68,#31bdb3)!important;border-color:#74eadf!important}.nfh15-v9-horizontal .nfh15-mode-switch.on .nfh15-switch-knob{background:#d5fff9!important}
.nfh15-v9-horizontal .nfh15-constant-trigger label,.nfh15-v9-horizontal .nfh15-prompt-tools-title,.nfh15-v9-horizontal .nfh15-lora-title{color:#75dfd3!important}
.nfh15-v9-horizontal .nfh15-sigma-preset-manager button,.nfh15-v9-horizontal .nfh15-lora-add{background:linear-gradient(180deg,#12302e,#081b1a)!important;border-color:#287f7a!important;color:#70dfd3!important}.nfh15-v9-horizontal .nfh15-lora-search input{background:#061716!important;border-color:#25645f!important;color:#dcefeb!important}.nfh15-v9-horizontal .nfh15-lora-search input:focus{border-color:#57e3d2!important}.nfh15-v9-horizontal .nfh15-lora-row{border-bottom-color:rgba(87,227,210,.16)!important}.nfh15-v9-horizontal .nfh15-lora-delete{border-color:#28534f!important;background:#0b1b1a!important;color:#a9c2bf!important}.nfh15-v9-horizontal .nfh15-lora-delete:hover{border-color:#42b9b0!important;color:#8ff0e5!important;background:#0c2927!important}
.nfh3.nfh15-v9-horizontal,.nfh15-v9-horizontal *{scrollbar-color:#218f88 rgba(3,15,15,.58)!important}.nfh15-v9-horizontal::-webkit-scrollbar-thumb,.nfh15-v9-horizontal .nfh15-v9-column::-webkit-scrollbar-thumb,.nfh15-v9-horizontal .nfh15-storyboard-tabs::-webkit-scrollbar-thumb,.nfh15-v9-menu::-webkit-scrollbar-thumb{background:#218f88!important}
.nfh15-select-menu.nfh15-v9-menu{background:#061110!important;border-color:#266f6a!important}.nfh15-select-menu.nfh15-v9-menu .nfh15-select-search{background:#0a201e!important;border-color:#265e5a!important;color:#e7f8f5!important}.nfh15-select-menu.nfh15-v9-menu .nfh15-select-search:focus{border-color:#57e3d2!important;box-shadow:0 0 0 1px #57e3d2!important}.nfh15-select-menu.nfh15-v9-menu .nfh15-select-option{background:#061110!important;color:#b7cecb!important}.nfh15-select-menu.nfh15-v9-menu .nfh15-select-option:hover,.nfh15-select-menu.nfh15-v9-menu .nfh15-select-option.keyboard{background:#0d2927!important;color:#f0fffd!important}.nfh15-select-menu.nfh15-v9-menu .nfh15-select-option.selected{background:linear-gradient(90deg,#0b716b,#26b8ae)!important;color:#fff!important}.nfh15-select-menu.nfh15-v9-menu .nfh15-select-option.selected .mark{color:#d5fff9!important}
.nfh15-smart-panel{background:#06100f!important;border-color:#26746f!important;color:#dcefeb!important}.nfh15-smart-panel>div:first-child,.nfh15-smart-panel b{color:#64e4d7!important}.nfh15-smart-panel label,.nfh15-smart-panel [data-smart-config],.nfh15-smart-panel [data-smart-mode-hint],.nfh15-smart-panel [data-smart-skill-hint],.nfh15-smart-panel [data-smart-status]{color:#9dbbb8!important}.nfh15-smart-panel input,.nfh15-smart-panel textarea,.nfh15-smart-panel select{background:linear-gradient(180deg,#102725,#081817)!important;border-color:#276964!important;color:#e5f7f4!important}.nfh15-smart-panel input:focus,.nfh15-smart-panel textarea:focus,.nfh15-smart-panel select:focus{border-color:#57e3d2!important;box-shadow:0 0 0 1px #57e3d2!important}.nfh15-smart-panel button{background:linear-gradient(180deg,#15312f,#0a1e1d)!important;border-color:#287d77!important;color:#c9dfdc!important}.nfh15-smart-panel button:hover{background:linear-gradient(180deg,#1c4642,#0d2b29)!important;border-color:#55d9ce!important;color:#eafffc!important}.nfh15-smart-panel [data-smart-run]{background:linear-gradient(135deg,#68eadb,#28b9af 52%,#117a76)!important;border-color:#9cfff3!important;color:#02100f!important}.nfh15-smart-panel [data-smart-config-toggle],.nfh15-smart-panel [data-smart-add],.nfh15-smart-panel [data-detect-models]{color:#70e2d6!important;border-color:#2b918a!important}.nfh15-smart-panel [data-smart-config-panel],.nfh15-smart-panel section{border-color:#245b57!important;background:rgba(4,24,23,.58)!important}.nfh15-smart-panel [data-smart-images]>div{border-color:#276f69!important;background:rgba(4,27,26,.62)!important}.nfh15-smart-panel [data-smart-images] span,.nfh15-smart-panel [data-smart-images] button{color:#65e1d5!important}
.nfh15-v9-horizontal .nfh15-audio-drive-fold>summary{background:linear-gradient(90deg,rgba(3,20,19,.24) 0%,rgba(13,104,98,.72) 60%,#4ad8cb 100%)!important;color:#e7fffc!important;border-color:#2d8f88!important}.nfh15-v9-horizontal .nfh15-audio-drive-fold>summary::after{color:#052622!important}

/* V11 smart audio-drive workspace: complete jade-cyan theme. */
.nfh15-audio-drive-modal,.nfh15-audio-drive-modal *{box-sizing:border-box;scrollbar-color:#279e96 #061817!important}.nfh15-audio-drive-modal *::-webkit-scrollbar{width:10px!important;height:12px!important}.nfh15-audio-drive-modal *::-webkit-scrollbar-track{background:#061817!important}.nfh15-audio-drive-modal *::-webkit-scrollbar-thumb{background:linear-gradient(90deg,#176c67,#35c5ba)!important;border:2px solid #061817!important;border-radius:6px!important}.nfh15-audio-drive-modal *::-webkit-scrollbar-thumb:hover{background:linear-gradient(90deg,#23948c,#6be9dc)!important}
.nfh15-audio-drive-dialog{border-color:#207d77!important;background:#020c0c!important;color:#d8efec!important;box-shadow:0 24px 80px #000!important}.nfh15-audio-drive-head{border-bottom-color:#277d78!important;background:linear-gradient(90deg,#061918 0%,#0a4d49 52%,#061918 100%)!important}.nfh15-audio-drive-head b{color:#8bf5e8!important}.nfh15-audio-drive-head small{color:#8fb8b4!important}
.nfh15-audio-drive-api-button,.nfh15-audio-drive-toolbar button,.nfh15-audio-drive-back,.nfh15-audio-drive-enable-bar button,.nfh15-audio-drive-image-remove,.nfh15-audio-drive-image-add,.nfh15-audio-drive-model-row button,.nfh15-audio-drive-api-actions button{border-color:#26736e!important;background:linear-gradient(180deg,#12312f,#071a19)!important;color:#bde4df!important}.nfh15-audio-drive-api-button:hover,.nfh15-audio-drive-toolbar button:hover,.nfh15-audio-drive-back:hover,.nfh15-audio-drive-enable-bar button:hover,.nfh15-audio-drive-image-add:hover:not(:disabled),.nfh15-audio-drive-model-row button:hover,.nfh15-audio-drive-api-actions button:hover{border-color:#57e3d2!important;background:linear-gradient(180deg,#19433f,#092724)!important;color:#effffc!important}.nfh15-audio-drive-api-button.active,.nfh15-audio-drive-toolbar button.active,.nfh15-audio-drive-api-actions [data-audio-drive-api-save],.nfh15-audio-drive-generate-storyboards{border-color:#9cfff3!important;background:linear-gradient(135deg,#65e9db,#28b9af 52%,#117a76)!important;color:#02100f!important}
.nfh15-audio-drive-body{background:#041211!important}.nfh15-audio-drive-api-panel{border-color:#286e69!important;background:#061615!important}.nfh15-audio-drive-api-intro,.nfh15-audio-drive-api-grid>div>b{color:#69e8db!important}.nfh15-audio-drive-api-intro span,.nfh15-audio-drive-api-note,.nfh15-audio-drive-api-message{color:#91b8b4!important}.nfh15-audio-drive-api-panel label{color:#a8cbc7!important}.nfh15-audio-drive-api-panel input{border-color:#275f5b!important;background:#03100f!important;color:#e3f5f2!important}.nfh15-audio-drive-api-panel input:focus{outline:none!important;border-color:#57e3d2!important;box-shadow:0 0 0 1px #57e3d2!important}
.nfh15-audio-drive-exclude{border-color:#286d68!important;background:#0a2220!important;color:#b8d9d5!important}.nfh15-audio-drive-exclude:hover{border-color:#57e3d2!important;color:#effffc!important}.nfh15-audio-drive-exclude input,.nfh15-audio-drive-segment-enable input{accent-color:#36c5ba!important}.nfh15-audio-drive-toolbar span{color:#9fc4c0!important}
.nfh15-audio-drive-silent-toggle{border-color:#2da49c!important;background:#08201e!important;color:#68e7da!important;box-shadow:none!important}.nfh15-audio-drive-silent-toggle.active{border-color:#a4fff5!important;background:linear-gradient(135deg,#65e9db,#28b9af 52%,#117a76)!important;color:#02100f!important;box-shadow:0 0 0 1px rgba(164,255,245,.28),0 0 14px rgba(58,211,198,.24)!important}
.nfh15-audio-drive-waveform{border-color:#286e69!important;background:#031312!important}.nfh15-audio-drive-markers{border-color:#194b47!important;background:#061817!important;color:#84d9d0!important}.nfh15-audio-drive-idea-panel{border-color:#2eb5ab!important;background:linear-gradient(135deg,#092522,#061615)!important}.nfh15-audio-drive-idea-head b{color:#73ecdf!important}.nfh15-audio-drive-idea-head span{color:#9fc3bf!important}.nfh15-audio-drive-skill-label{color:#9fc3bf!important}.nfh15-audio-drive-skill-select{border-color:#28766f!important;background:#041514!important;color:#dcf2ef!important}.nfh15-audio-drive-idea{border-color:#28766f!important;background:#03100f!important;color:#e7faf7!important}.nfh15-audio-drive-idea::placeholder{color:#698d89!important}.nfh15-audio-drive-idea:focus{outline:none!important;border-color:#64e5d8!important;background:#061817!important;box-shadow:0 0 0 1px #64e5d8!important}
.nfh15-audio-drive-segments{scrollbar-color:#2fb8ae #061817!important}.nfh15-audio-drive-segments::-webkit-scrollbar{background:#061817!important}.nfh15-audio-drive-segments::-webkit-scrollbar-thumb{background:linear-gradient(90deg,#176c67,#35c5ba)!important;border-color:#061817!important}.nfh15-audio-drive-segment{border-color:#225c57!important;background:#061716!important;scrollbar-color:#258e87 #051514!important}.nfh15-audio-drive-segment.current{border-color:#67eadc!important;background:#0a2825!important;outline-color:#287d77!important}.nfh15-audio-drive-segment.disabled{border-color:#183d3a!important}.nfh15-audio-drive-segment-enable,.nfh15-audio-drive-segment-title,.nfh15-audio-drive-image-row>b{color:#70e6da!important}.nfh15-audio-drive-segment-title span{color:#c8e8e4!important}.nfh15-audio-drive-segment-title small{color:#7fa6a2!important}.nfh15-audio-drive-image-row{border-bottom-color:#17423f!important}.nfh15-audio-drive-image-row.drag-target,.nfh15-audio-drive-image-row.move-selected{border-color:#57e3d2!important;background:#0c2b28!important}.nfh15-audio-drive-image-preview{border-color:#286b66!important;background:#031110!important;color:#9fcac5!important}.nfh15-audio-drive-image-preview:hover{border-color:#57e3d2!important;color:#effffc!important}.nfh15-audio-drive-image-preview img{background:#020c0c!important}.nfh15-audio-drive-image-move{border-color:#2e8e87!important;background:#08201edc!important;color:#67e6da!important}.nfh15-audio-drive-placeholder{color:#83d8cf!important}.nfh15-audio-drive-placeholder small{color:#70918e!important}
.nfh15-audio-drive-enable-bar{border-color:#286b66!important;background:#061817!important}.nfh15-audio-drive-enable-bar span{color:#9fc6c2!important}.nfh15-audio-drive-footer{border-top-color:#235e59!important;background:#031110!important}.nfh15-audio-drive-storyboard{border-color:#245f5a!important;background:#051514!important}.nfh15-audio-drive-storyboard>summary{color:#69e6d9!important}.nfh15-audio-drive-storyboard-settings label{color:#9fc6c2!important}.nfh15-audio-drive-storyboard-settings input,.nfh15-audio-drive-storyboard-settings textarea{border-color:#245f5a!important;background:#020d0c!important;color:#dcefeb!important}.nfh15-audio-drive-action{border-color:#256a65!important;background:linear-gradient(180deg,#0d2927,#061817)!important;color:#6f9d98!important}.nfh15-audio-drive-action.enabled{border-color:#9cfff3!important;background:linear-gradient(135deg,#65e9db,#28b9af 52%,#117a76)!important;color:#02100f!important}.nfh15-audio-drive-action.enabled:hover,.nfh15-audio-drive-action.enabled:active{background:linear-gradient(135deg,#88f4e8,#38c9be 52%,#158b85)!important;color:#02100f!important}

.nfh15-audio-drive-api-actions [data-audio-drive-api-clear],.nfh15-audio-drive-image-remove:not(:disabled){border-color:#6f3532!important;color:#eaa49e!important}
/* Force the three V11 column scrollbars; Chromium kept the older gold thumb. */
.nfh3.nfh15-v9-horizontal,.nfh3.nfh15-v9-horizontal>.nfh15-v9-column,.nfh3.nfh15-v9-horizontal .nfh15-storyboard-tabs,.nfh3.nfh15-v9-horizontal .nfh15-select-list{scrollbar-width:thin!important;scrollbar-color:#2ab9ae #061817!important}
.nfh3.nfh15-v9-horizontal::-webkit-scrollbar,.nfh3.nfh15-v9-horizontal>.nfh15-v9-column::-webkit-scrollbar,.nfh3.nfh15-v9-horizontal .nfh15-storyboard-tabs::-webkit-scrollbar,.nfh3.nfh15-v9-horizontal .nfh15-select-list::-webkit-scrollbar{width:9px!important;height:9px!important;background:#061817!important}
.nfh3.nfh15-v9-horizontal::-webkit-scrollbar-track,.nfh3.nfh15-v9-horizontal>.nfh15-v9-column::-webkit-scrollbar-track,.nfh3.nfh15-v9-horizontal .nfh15-storyboard-tabs::-webkit-scrollbar-track,.nfh3.nfh15-v9-horizontal .nfh15-select-list::-webkit-scrollbar-track{background:#061817!important;background-image:none!important}
.nfh3.nfh15-v9-horizontal::-webkit-scrollbar-thumb,.nfh3.nfh15-v9-horizontal>.nfh15-v9-column::-webkit-scrollbar-thumb,.nfh3.nfh15-v9-horizontal .nfh15-storyboard-tabs::-webkit-scrollbar-thumb,.nfh3.nfh15-v9-horizontal .nfh15-select-list::-webkit-scrollbar-thumb{background:#2ab9ae!important;background-color:#2ab9ae!important;background-image:none!important;border:1px solid #0b3734!important;border-radius:4px!important;box-shadow:none!important}
.nfh3.nfh15-v9-horizontal::-webkit-scrollbar-thumb:hover,.nfh3.nfh15-v9-horizontal>.nfh15-v9-column::-webkit-scrollbar-thumb:hover,.nfh3.nfh15-v9-horizontal .nfh15-storyboard-tabs::-webkit-scrollbar-thumb:hover,.nfh3.nfh15-v9-horizontal .nfh15-select-list::-webkit-scrollbar-thumb:hover{background:#67eadd!important;background-color:#67eadd!important}
.nfh3.nfh15-v9-horizontal::-webkit-scrollbar-corner,.nfh3.nfh15-v9-horizontal>.nfh15-v9-column::-webkit-scrollbar-corner{background:#061817!important}
/* Override the old gold rules applied directly to preview title children. */
.nfh3.nfh15-v9-horizontal .nfh15-v9-preview-head b{color:#79e7da!important;text-shadow:none!important}
.nfh3.nfh15-v9-horizontal .nfh15-v9-preview-head small{color:#8fb8b4!important}
.nfh3.nfh15-v9-horizontal .nfh15-v9-preview-empty{color:#57e3d2!important;text-shadow:none!important}
.nfh3.nfh15-v9-horizontal .nfh15-v9-preview-status{color:#77d9cf!important;border-top-color:rgba(87,227,210,.18)!important}
/* Keep hover states in the same cyan family: brighter, never yellow or unrelated colors. */
.nfh3.nfh15-v9-horizontal .nfh15-storyboard-action,.nfh3.nfh15-v9-horizontal .nfh15-storyboard-action.batch{background:linear-gradient(180deg,#102725 0%,#071817 100%)!important;background-color:#102725!important;border-color:rgba(77,202,191,.34)!important;color:#cae2df!important;box-shadow:none!important;text-shadow:none!important;transform:none!important}
.nfh3.nfh15-v9-horizontal .nfh15-storyboard-action:hover,.nfh3.nfh15-v9-horizontal .nfh15-storyboard-action.batch:hover{background:linear-gradient(180deg,#1b4945 0%,#0c2f2c 100%)!important;background-color:#1b4945!important;border-color:#68eadd!important;color:#effffc!important;box-shadow:0 0 0 1px rgba(104,234,221,.14)!important;text-shadow:none!important;transform:none!important}
.nfh3.nfh15-v9-horizontal .nfh15-storyboard-action:active,.nfh3.nfh15-v9-horizontal .nfh15-storyboard-action.batch:active{background:linear-gradient(180deg,#22605b 0%,#10413d 100%)!important;border-color:#a0fff5!important;color:#fff!important;transform:none!important}
.nfh3.nfh15-v9-horizontal .nfh15-batch-icon{background:#2ab9ae!important;background-image:none!important;color:#031513!important;border:1px solid #71e9dd!important;box-shadow:none!important}
.nfh3.nfh15-v9-horizontal .nfh15-storyboard-action.batch:hover .nfh15-batch-icon{background:#67eadd!important;background-image:none!important;color:#031513!important;box-shadow:none!important;transform:none!important}
/* Segment states: previous segments keep cyan; only upcoming segments are neutral gray. */
.nfh3.nfh15-v9-horizontal .nfh15-storyboard-tab{background:linear-gradient(180deg,#102725 0%,#071817 100%)!important;border-color:rgba(77,202,191,.34)!important;color:#cae2df!important;box-shadow:none!important;text-shadow:none!important}
.nfh3.nfh15-v9-horizontal .nfh15-storyboard-tab:hover{background:linear-gradient(180deg,#1b4945 0%,#0c2f2c 100%)!important;border-color:#68eadd!important;color:#effffc!important;box-shadow:none!important;transform:none!important}
.nfh3.nfh15-v9-horizontal .nfh15-storyboard-tab.queued-range{background:#121514!important;background-image:none!important;border-color:#414846!important;color:#929997!important;box-shadow:none!important}
.nfh3.nfh15-v9-horizontal .nfh15-storyboard-tab.queued-range:hover{background:#1a211f!important;background-image:none!important;border-color:#6c7a77!important;color:#e1e7e5!important}
.nfh3.nfh15-v9-horizontal .nfh15-storyboard-tab.active{background:linear-gradient(135deg,#65e9db,#28b9af 52%,#117a76)!important;border-color:#9cfff3!important;color:#02100f!important;box-shadow:none!important}
.nfh3.nfh15-v9-horizontal .nfh15-storyboard-tab:not(.active):not(.queued-range) .nfh15-storyboard-time-icon{color:#69d9ce!important;border-color:#439e97!important}
.nfh3.nfh15-v9-horizontal .nfh15-storyboard-tab.queued-range .nfh15-storyboard-time-icon{color:#929997!important;border-color:#6f7775!important}
.nfh3.nfh15-v9-horizontal .nfh15-storyboard-tab.active .nfh15-storyboard-time-icon{color:#06312d!important;border-color:#06312d!important}
/* Native Skill dropdowns: force dark options with high-contrast text. */
.nfh15-smart-panel select,.nfh15-audio-drive-skill-select{color-scheme:dark!important;background-color:#061817!important;color:#f1fffd!important;border-color:#42bcb2!important;font-weight:700!important}
.nfh15-smart-panel select option,.nfh15-audio-drive-skill-select option{color-scheme:dark!important;background:#071b1a!important;background-color:#071b1a!important;color:#f1fffd!important;font-weight:700!important}
.nfh15-smart-panel select option:checked,.nfh15-smart-panel select option:hover,.nfh15-audio-drive-skill-select option:checked,.nfh15-audio-drive-skill-select option:hover{background:#176c67!important;background-color:#176c67!important;color:#ffffff!important}
/* Regular multimodal video cards use the browser's native playable preview. */
.nfh15-v9-horizontal .nfh15-video-player{position:absolute!important;inset:0!important;width:100%!important;height:100%!important;padding:0!important;background:#020c0c!important;overflow:hidden!important}
.nfh15-v9-horizontal .nfh15-video-player video{display:block!important;width:100%!important;height:100%!important;object-fit:contain!important;object-position:center!important;background:#020c0c!important;border:0!important;border-radius:1px!important}
.nfh15-v9-horizontal .nfh15-card:has(.nfh15-video-player) .nfh15-label{pointer-events:none!important}
.nfh15-v9-horizontal .nfh15-v9-preview-head>span{display:flex;align-items:center;gap:8px!important}.nfh15-v9-horizontal .nfh15-v9-preview-pause{width:auto!important;min-width:54px!important;height:25px!important;padding:0 9px!important;border:1px solid #287d76!important;background:#07302d!important;color:#a8fff4!important;border-radius:3px!important;box-shadow:none!important;cursor:pointer!important}.nfh15-v9-horizontal .nfh15-v9-preview-pause:hover{background:#0b4e49!important;border-color:#57e3d2!important;color:#fff!important}.nfh15-v9-horizontal .nfh15-v9-preview-pause.paused{background:#176c67!important;border-color:#79f3e6!important;color:#fff!important}
`;
  document.head.appendChild(s);
}
function seedControlMode(node) {
  return widget(node, "固定随机种子")?.value ? "fixed" : "randomize";
}
function syncSeedControlMode(node) {
  const seed = widget(node, "随机种子");
  if (!seed) return;
  seed.control_after_generate = seedControlMode(node);
  if (seed.options) seed.options.control_after_generate = seed.control_after_generate;
}
function makeControl(node, [name, label, type]) {
  const w = widget(node, name),
    box = document.createElement("div");
  box.className = "nfh15-field";
  box.dataset.controlName = name;
  if (name === "H3专用注意力" && !isV6(node)) {
    box.style.display = "none";
    return box;
  }
  const l = document.createElement("label");
  l.textContent = label;
  box.append(l);
  let el;
  if (type === "seed-lock") {
    if (!isV3(node)) {
      box.style.display = "none";
      return box;
    }
    const lock = widget(node, "固定随机种子");
    el = document.createElement("button");
    el.type = "button";
    el.className = "nfh15-mode-switch nfh15-seed-lock";
    el.dataset.widgetName = "固定随机种子";
    const paint = () => {
      const on = !!lock?.value;
      el.classList.toggle("on", on);
      el.innerHTML = `<span class="nfh15-mode-name">${on ? "种子已固定" : "种子随机变化"}</span><small>${on ? "每次生成保持当前种子" : "每次生成后自动换种子"}</small><span class="nfh15-switch-track"><span class="nfh15-switch-knob"></span></span>`;
    };
    el.onclick = () => {
      setWidget(node, "固定随机种子", !lock?.value);
      syncSeedControlMode(node);
      paint();
    };
    paint();
    box.append(el);
    return box;
  }
  if (type === "mode-switches") {
    box.classList.add("nfh15-mode-field");
    el = document.createElement("div");
    el.className = "nfh15-modes";
    for (const mode of ["文生视频", "图生视频", "首尾帧"]) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "nfh15-mode-switch";
      b.dataset.mode = mode;
      b.innerHTML = `<span class="nfh15-mode-name">${mode}</span><small>${mode === "文生视频" ? "不使用图片" : mode === "图生视频" ? "1张首帧" : "首帧＋尾帧"}</small><span class="nfh15-switch-track"><span class="nfh15-switch-knob"></span></span>`;
      b.onclick = () => {
        const turnOn = !widget(node, mode)?.value;
        for (const other of ["文生视频", "图生视频", "首尾帧"]) setWidget(node, other, turnOn && other === mode);
        if (turnOn) {
          for (let i = 1; i <= 3; i++) {
            setWidget(node, `视频${i}`, "未选择");
            setWidget(node, `音频${i}`, "未选择");
          }
          if (mode === "文生视频") for (let i = 1; i <= 9; i++) setWidget(node, `图片${i}`, "未选择");
          if (mode === "图生视频") for (let i = 2; i <= 9; i++) setWidget(node, `图片${i}`, "未选择");
          if (mode === "首尾帧") for (let i = 3; i <= 9; i++) setWidget(node, `图片${i}`, "未选择");
        }
        node.__nfh3Render?.();
      };
      el.append(b);
    }
    box.append(el);
    return box;
  }
  if (type === "select" && isV7(node) && !name.startsWith("LoRA")) {
    const wrap = document.createElement("div");
    wrap.className = "nfh15-custom-select";
    const button = document.createElement("button");
    button.type = "button";
    button.className = "nfh15-select-button";
    const caption = document.createElement("span"),
      arrow = document.createElement("i");
    arrow.textContent = "▾";
    button.append(caption, arrow);
    const menu = document.createElement("div");
    menu.className = "nfh15-select-menu nfh15-v7-light" + (isV9(node) ? " nfh15-v9-menu" : "");
    const search = document.createElement("input");
    search.type = "search";
    search.className = "nfh15-select-search";
    search.placeholder = "搜索选项…";
    search.autocomplete = "off";
    const list = document.createElement("div");
    list.className = "nfh15-select-list";
    menu.append(search, list);
    document.body.append(menu);
    attachSkinOverlay(node, menu);
    const getValues = () => name === "画面比例" ? ratioChoicesForMode(node) : choices(w);
    let anchorLeft = 0,
      anchorTop = 0,
      anchorFrame = 0;
    const labelFor = value => {
      const values = getValues(),
        raw = String(value ?? "");
      if (LIVE_MODEL_WIDGETS.has(name)) {
        if (!values.length) return "未检测到本机模型";
        if (raw && !values.some(item => String(item) === raw)) return `⚠ 未安装：${raw}`;
      }
      const displayValue = name === "加密曲线" ? CURVE_LABELS[value] || value : value;
      return name === "百万像素" ? megapixelLabel(node, value) : String(displayValue);
    };
    const close = () => {
      wrap.classList.remove("open");
      menu.style.display = "none";
      menu.style.visibility = "";
      search.value = "";
      if (anchorFrame) {
        cancelAnimationFrame(anchorFrame);
        anchorFrame = 0;
      }
    };
    const choose = value => {
      setWidget(node, name, value);
      close();
      paint();
      if (name === "H3专用注意力") {
        if (value === "H3专用Sage加速") setWidget(node, "SageAttention", "disabled");
        if (value === "自动") setWidget(node, "SageAttention", "auto");
        if (value === "关闭") setWidget(node, "SageAttention", "disabled");
        if (value !== "关闭") setWidget(node, "启用H3 SLA", false);
        setWidget(node, "启用SolAttn", false);
        setWidget(node, "启用T8缓存", false);
      }
      node.__nfh3Resolution?.();
      node.__nfh3Render?.();
    };
    const paint = () => {
      caption.textContent = labelFor(w?.value ?? "");
      list.replaceChildren();
      const q = search.value.trim().toLocaleLowerCase(),
        filtered = getValues().filter(value => labelFor(value).toLocaleLowerCase().includes(q) || String(value).toLocaleLowerCase().includes(q));
      for (const value of filtered) {
        const option = document.createElement("button");
        option.type = "button";
        option.className = "nfh15-select-option" + (String(value) === String(w?.value) ? " selected" : " ");
        option.dataset.value = String(value);
        const mark = document.createElement("span"),
          text = document.createElement("span");
        mark.className = "mark";
        mark.textContent = "✓";
        text.className = "text";
        text.textContent = labelFor(value);
        option.append(mark, text);
        option.onclick = e => {
          e.stopPropagation();
          choose(value);
        };
        list.append(option);
      }
      if (!filtered.length) {
        const empty = document.createElement("div");
        empty.className = "nfh15-select-empty";
        empty.textContent = "没有匹配项";
        list.append(empty);
      }
    };
    const position = () => {
      const viewportGap = 8,
        r = button.getBoundingClientRect();
      anchorLeft = r.left;
      anchorTop = r.top;
      menu.style.display = "block";
      menu.style.visibility = "hidden";
      menu.style.maxHeight = "320px";
      const width = Math.min(r.width, window.innerWidth - viewportGap * 2);
      menu.style.width = `${width}px`;
      const menuHeight = Math.min(menu.scrollHeight, 320),
        below = window.innerHeight - r.bottom - viewportGap,
        above = r.top - viewportGap;
      const openUp = below < menuHeight && above > below,
        available = Math.max(120, Math.min(menuHeight, openUp ? above : below));
      menu.style.maxHeight = `${available}px`;
      list.style.maxHeight = `${Math.max(64, available - search.offsetHeight - 13)}px`;
      const left = Math.max(viewportGap, Math.min(r.left, window.innerWidth - width - viewportGap));
      const top = openUp ? Math.max(viewportGap, r.top - available - 5) : Math.min(window.innerHeight - available - viewportGap, r.bottom + 5);
      menu.style.left = `${left}px`;
      menu.style.top = `${top}px`;
      menu.style.visibility = "visible";
    };
    search.oninput = () => paint();
    search.onkeydown = e => {
      const opts = [...list.querySelectorAll(".nfh15-select-option")],
        active = list.querySelector(".keyboard");
      let index = opts.indexOf(active);
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        active?.classList.remove("keyboard");
        index = e.key === "ArrowDown" ? Math.min(index + 1, opts.length - 1) : Math.max(index < 0 ? opts.length - 1 : index - 1, 0);
        opts[index]?.classList.add("keyboard");
        opts[index]?.scrollIntoView({
          block: "nearest"
        });
      }
      if (e.key === "Enter") {
        e.preventDefault();
        const target = active || opts[0];
        if (target) choose(getValues().find(v => String(v) === target.dataset.value));
      }
      if (e.key === "Escape") {
        e.preventDefault();
        close();
        button.focus();
      }
    };
    const anchorMoved = () => {
      if (!wrap.classList.contains("open")) {
        anchorFrame = 0;
        return;
      }
      const r = button.getBoundingClientRect();
      if (!button.isConnected || Math.abs(r.left - anchorLeft) > 2 || Math.abs(r.top - anchorTop) > 2) {
        close();
        return;
      }
      anchorFrame = requestAnimationFrame(anchorMoved);
    };
    button.onclick = e => {
      e.stopPropagation();
      const opening = !wrap.classList.contains("open");
      document.querySelectorAll(".nfh15-custom-select.open").forEach(x => x.__nfh3Close?.());
      if (opening) {
        wrap.classList.add("open");
        search.value = "";
        paint();
        position();
        anchorFrame = requestAnimationFrame(anchorMoved);
        requestAnimationFrame(() => search.focus());
      } else close();
    };
    menu.addEventListener("wheel", e => e.stopPropagation(), {
      passive: true
    });
    const onViewportChange = e => {
        if (menu.contains(e.target)) return;
        close();
      },
      onCanvasMotion = e => {
        if (menu.contains(e.target)) return;
        if (wrap.classList.contains("open") && (e.buttons || e.type === "wheel")) close();
      },
      onOutside = e => {
        if (!wrap.contains(e.target) && !menu.contains(e.target)) close();
      };
    window.addEventListener("scroll", onViewportChange, true);
    window.addEventListener("resize", onViewportChange);
    document.addEventListener("pointermove", onCanvasMotion, true);
    document.addEventListener("wheel", onCanvasMotion, true);
    document.addEventListener("pointerdown", onOutside);
    wrap.append(button);
    paint();
    box.append(wrap);
    wrap.dataset.widgetName = name;
    wrap.__nfh3Paint = paint;
    wrap.__nfh3SetValues = values => {
      w.options ||= {};
      w.options.values = Array.isArray(values) ? values : [];
      paint();
    };
    wrap.__nfh3Close = close;
    wrap.__nfh3Dispose = () => {
      if (anchorFrame) cancelAnimationFrame(anchorFrame);
      window.removeEventListener("scroll", onViewportChange, true);
      window.removeEventListener("resize", onViewportChange);
      document.removeEventListener("pointermove", onCanvasMotion, true);
      document.removeEventListener("wheel", onCanvasMotion, true);
      document.removeEventListener("pointerdown", onOutside);
      menu.remove();
    };
    return box;
  } else if (type === "select") {
    el = document.createElement("select");
    const selectValues = name === "画面比例" ? ratioChoicesForMode(node) : choices(w);
    for (const v of selectValues) {
      const o = document.createElement("option");
      o.value = v;
      o.textContent = name === "百万像素" ? megapixelLabel(node, v) : v;
      el.append(o);
    }
    el.value = selectValues.includes(w?.value) ? w.value : w?.options?.default ?? selectValues[0] ?? "";
    el.onchange = () => {
      setWidget(node, name, el.value);
      if (name === "H3专用注意力") {
        if (el.value === "H3专用Sage加速") setWidget(node, "SageAttention", "disabled");
        if (el.value === "自动") setWidget(node, "SageAttention", "auto");
        if (el.value === "关闭") setWidget(node, "SageAttention", "disabled");
        if (el.value !== "关闭") setWidget(node, "启用H3 SLA", false);
        setWidget(node, "启用SolAttn", false);
        setWidget(node, "启用T8缓存", false);
      }
      node.__nfh3Resolution?.();
      node.__nfh3Render?.();
    };
  } else if (type === "boolean") {
    el = document.createElement("input");
    el.type = "checkbox";
    el.checked = !!w?.value;
    el.onchange = () => {
      const checked = el.checked;
      setWidget(node, name, checked);
      if (checked && name === "启用SolAttn") {
        setWidget(node, "启用T8缓存", false);
        setWidget(node, "SageAttention", "disabled");
        setWidget(node, "H3专用注意力", "关闭");
      }
      if (checked && name === "启用T8缓存") {
        setWidget(node, "启用SolAttn", false);
        setWidget(node, "SageAttention", "disabled");
        setWidget(node, "H3专用注意力", "关闭");
      }
      if (checked && name === "启用H3 SLA") {
        setWidget(node, "H3专用注意力", "关闭");
        setWidget(node, "SageAttention", "disabled");
        setWidget(node, "启用SolAttn", false);
        setWidget(node, "启用T8缓存", false);
      }
      if (name === "启用TAEH3彩色预览") node.__nfh3UpdatePreviewControls?.();
      if (isV5(node) && checked && name === "启用高清二采") {
        setWidget(node, "启用西格玛调节", false);
        setWidget(node, "全局修复", false);
      }
      if (isV5(node) && checked && name === "启用西格玛调节") setWidget(node, "启用高清二采", false);
      node.__nfh3SyncExclusive?.();
    };
  } else if (type === "text") {
    el = document.createElement("textarea");
    el.value = w?.value ?? "";
    el.rows = 4;
    el.style.resize = "none";
    el.onchange = () => setWidget(node, name, el.value);
  } else if (name === "低显存注意力分头数") {
    const wrap = document.createElement("div");
    wrap.className = "nfh15-range-row";
    el = document.createElement("input");
    el.type = "range";
    el.min = 1;
    el.max = 56;
    el.step = 1;
    el.value = w?.value ?? 10;
    const value = document.createElement("output");
    value.className = "nfh15-range-value";
    const paint = () => {
      const n = Number(el.value);
      value.textContent = n === 4 ? "4 · KJ默认" : n === 10 ? "10 · 推荐" : n === 14 ? "14 · 更省显存" : n === 28 ? "28 · 紧张" : n === 56 ? "56 · 极限" : String(n);
    };
    el.oninput = () => {
      setWidget(node, name, Number(el.value));
      paint();
    };
    paint();
    wrap.append(el, value);
    box.append(wrap);
    el.dataset.widgetName = name;
    return box;
  } else if (name === "运行时预留显存GB") {
    const wrap = document.createElement("div");
    wrap.className = "nfh15-range-row";
    el = document.createElement("input");
    el.type = "range";
    el.min = 0;
    el.max = 24;
    el.step = .1;
    el.value = w?.value ?? .6;
    const value = document.createElement("input");
    value.type = "number";
    value.className = "nfh15-range-value";
    value.min = 0;
    value.max = 24;
    value.step = .1;
    value.setAttribute("aria-label", "实际预留显存GB");
    const clamp = n => Math.min(24, Math.max(0, Math.round((Number(n) || 0) * 10) / 10));
    const commit = n => {
      const exact = clamp(n);
      el.value = String(exact);
      value.value = exact.toFixed(1);
      setWidget(node, name, exact);
    };
    const paint = () => {
      const exact = clamp(w?.value ?? el.value);
      el.value = String(exact);
      value.value = exact.toFixed(1);
    };
    el.oninput = () => commit(el.value);
    value.onchange = () => commit(value.value);
    value.onkeydown = e => {
      if (e.key === "Enter") {
        commit(value.value);
        value.blur();
      }
    };
    paint();
    wrap.append(el, value);
    box.append(wrap);
    el.dataset.widgetName = name;
    el.__nfh3Paint = paint;
    return box;
  } else if (name === "UniBlockSwap常驻块数") {
    const wrap = document.createElement("div");
    wrap.className = "nfh15-range-row";
    el = document.createElement("input");
    el.type = "range";
    el.min = 1;
    el.max = 49;
    el.step = 1;
    const initial = Number(w?.value);
    el.value = Number.isFinite(initial) ? Math.min(49, Math.max(1, initial)) : 1;
    const value = document.createElement("output");
    value.className = "nfh15-range-value";
    const paint = () => {
      value.textContent = `${Number(el.value)} 块`;
    };
    el.oninput = () => {
      setWidget(node, name, Number(el.value));
      paint();
    };
    el.__nfh3Paint = paint;
    paint();
    wrap.append(el, value);
    box.append(wrap);
    el.dataset.widgetName = name;
    return box;
  } else if (name === "分块卸载层数") {
    const wrap = document.createElement("div");
    wrap.className = "nfh15-range-row";
    el = document.createElement("input");
    el.type = "range";
    el.min = w?.options?.min ?? 0;
    el.max = w?.options?.max ?? 48;
    el.step = w?.options?.step ?? 1;
    el.value = w?.value ?? 48;
    const value = document.createElement("output");
    value.className = "nfh15-range-value";
    value.textContent = el.value;
    el.oninput = () => {
      value.textContent = el.value;
      setWidget(node, name, Number(el.value));
    };
    wrap.append(el, value);
    box.append(wrap);
    el.dataset.widgetName = name;
    return box;
  } else {
    el = document.createElement("input");
    el.type = "number";
    el.value = w?.value;
    el.min = w?.options?.min ?? "";
    el.max = w?.options?.max ?? "";
    const numberStep = name === "时长秒" ? 1 : w?.options?.step2 ?? w?.options?.step ?? 1;
    el.step = numberStep;
    el.onchange = () => setWidget(node, name, Number(el.value));
  }
  el.dataset.widgetName = name;
  box.append(el);
  return box;
}
function sync(node, root) {
  for (const el of root.querySelectorAll("[data-widget-name]")) {
    const w = widget(node, el.dataset.widgetName);
    if (!w) continue;
    if (el.classList?.contains("nfh15-custom-select")) {
      el.__nfh3Paint?.();
      continue;
    }
    if (el.dataset.widgetName === "画面比例" && el.tagName === "SELECT") {
      const vals = ratioChoicesForMode(node),
        current = [...el.options].map(o => o.value);
      if (vals.join("\u0000") !== current.join("\u0000")) {
        el.replaceChildren();
        for (const v of vals) {
          const o = document.createElement("option");
          o.value = v;
          o.textContent = v;
          el.append(o);
        }
      }
    }
    if (el.type === "checkbox") el.checked = !!w.value;else if (document.activeElement !== el) {
      el.value = w.value;
      if (el.type === "range") el.__nfh3Paint?.();
    }
  }
}
function makeLoraSearchControl(node, index) {
  const name = `LoRA${index}`,
    w = widget(node, name),
    box = document.createElement("div");
  box.className = "nfh15-field nfh15-lora-search";
  const label = document.createElement("label");
  label.textContent = "模型";
  box.append(label);
  if (!w) {
    const missing = document.createElement("div");
    missing.className = "nfh15-lora-missing";
    missing.textContent = "需重启 ComfyUI 加载此 LoRA 槽位";
    box.append(missing);
    return box;
  }
  const values = choices(w).map(String),
    input = document.createElement("input"),
    datalist = document.createElement("datalist");
  input.type = "search";
  input.placeholder = "输入关键词搜索 LoRA…";
  input.autocomplete = "off";
  datalist.id = `nfh15-lora-${index}-${Math.random().toString(36).slice(2)}`;
  input.setAttribute("list", datalist.id);
  datalist.append(...values.map(value => {
    const option = document.createElement("option");
    option.value = value;
    return option;
  }));
  const current = String(w.value || "");
  input.value = current === "未选择" ? "" : current;
  const commit = () => {
    const value = input.value.trim();
    if (!value) {
      setWidget(node, name, "未选择");
      return;
    }
    const exact = values.find(item => item.toLocaleLowerCase() === value.toLocaleLowerCase());
    if (exact) {
      input.value = exact;
      setWidget(node, name, exact);
    }
  };
  input.onchange = commit;
  input.onblur = commit;
  input.onkeydown = event => {
    if (event.key === "Enter") {
      event.preventDefault();
      commit();
      input.blur();
    }
  };
  box.append(input, datalist);
  return box;
}
function buildDynamicLoraPanel(node) {
  const panel = document.createElement("div");
  panel.className = "nfh15-lora-dynamic";
  node.properties ||= {};
  const selected = index => {
    const value = widget(node, `LoRA${index}`)?.value;
    return !!value && value !== "未选择";
  };
  if (!Number.isInteger(node.properties.nfh3_lora_slot_count)) {
    let highest = 0;
    for (let i = 1; i <= MAX_LORA_SLOTS; i++) if (selected(i)) highest = i;
    node.properties.nfh3_lora_slot_count = highest;
  }
  const clearSlot = index => {
    setWidget(node, `LoRA${index}`, "未选择");
    setWidget(node, `LoRA${index}强度`, 1.0);
    setWidget(node, `LoRA${index}启用`, false);
  };
  const copySlot = (from, to) => {
    setWidget(node, `LoRA${to}`, widget(node, `LoRA${from}`)?.value || "未选择");
    setWidget(node, `LoRA${to}强度`, Number(widget(node, `LoRA${from}强度`)?.value ?? 1));
    setWidget(node, `LoRA${to}启用`, !!widget(node, `LoRA${from}启用`)?.value);
  };
  const list = document.createElement("div");
  list.className = "nfh15-lora-list";
  const add = document.createElement("button");
  add.type = "button";
  add.className = "nfh15-lora-add";
  const currentCount = () => Math.max(0, Math.min(MAX_LORA_SLOTS, Number(node.properties.nfh3_lora_slot_count) || 0));
  const updateAddButton = () => {
    const count = currentCount();
    add.textContent = count >= MAX_LORA_SLOTS ? `最多 ${MAX_LORA_SLOTS} 个 LoRA` : `＋ 添加 LoRA`;
    add.disabled = count >= MAX_LORA_SLOTS;
  };
  const appendLoraRow = index => {
    const row = document.createElement("div");
    row.className = "nfh15-lora-row";
    row.dataset.loraIndex = String(index);
    const title = document.createElement("b");
    title.className = "nfh15-lora-title";
    title.textContent = `LoRA ${index}`;
    const enabled = makeControl(node, [`LoRA${index}启用`, "启用", "boolean"]);
    enabled.classList.add("nfh15-lora-enable");
    const modelControl = makeLoraSearchControl(node, index);
    modelControl.classList.add("nfh15-lora-model");
    const strengthControl = makeControl(node, [`LoRA${index}强度`, "强度", "number"]);
    strengthControl.classList.add("nfh15-lora-strength");
    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "nfh15-lora-delete";
    remove.textContent = "删除";
    remove.onclick = () => {
      const count = currentCount();
      for (let j = index; j < count; j++) copySlot(j + 1, j);
      clearSlot(count);
      node.properties.nfh3_lora_slot_count = Math.max(0, count - 1);
      savePersistedLoraState(node);
      node.setDirtyCanvas?.(true, true);
      rebuildRows();
    };
    row.append(enabled, title, modelControl, strengthControl, remove);
    list.append(row);
  };
  const rebuildRows = () => {
    list.replaceChildren();
    for (let i = 1; i <= currentCount(); i++) appendLoraRow(i);
    updateAddButton();
  };
  add.onclick = () => {
    const count = currentCount();
    if (count >= MAX_LORA_SLOTS) return;
    const next = count + 1;
    clearSlot(next);
    setWidget(node, `LoRA${next}启用`, false);
    node.properties.nfh3_lora_slot_count = next;
    savePersistedLoraState(node);
    node.setDirtyCanvas?.(true, true);
    appendLoraRow(next);
    updateAddButton();
  };
  node.__nfh3RebuildLoraRows = rebuildRows;
  rebuildRows();
  panel.append(list, add);
  return panel;
}
function buildPanel(node) {
  const panelOwnerValid = makeOwnerGuard(node);
  installCurrentGroupQueue(app);
  addStyle();
  let active = "图片",
    dragIndex = null,
    dragCard = null,
    mentionIndex = 0,
    mentionButtons = [];
  const root = document.createElement("div");
  root.className = `nfh3${isV7(node) ? " nfh15-v7-light" : ""}`;
  if (isV9(node)) root.style.setProperty("--nfh15-v9-bg", `url("${V9_BACKGROUND_URL}")`);
  if (isV7(node)) {
    root.style.setProperty("--nfh15-v7-bg", `url("${V7_BACKGROUND_URL}")`);
    const scene = document.createElement("div");
    scene.className = "nfh15-liquid-scene";
    scene.setAttribute("aria-hidden", "true");
    scene.innerHTML = '<i class="nfh15-orb orb-a"></i><i class="nfh15-orb orb-b"></i><i class="nfh15-orb orb-c"></i><i class="nfh15-ribbon ribbon-a"></i><i class="nfh15-ribbon ribbon-b"></i><i class="nfh15-crystal"><b></b><b></b><b></b></i>';
    root.append(scene);
  }
  // 素材卡换位使用 Pointer Events，不再依赖会被 ComfyUI 画布拦截的原生 HTML5 drag。
  function cardAtPoint(x, y) {
    for (const card of grid?.children || []) {
      const r = card.getBoundingClientRect();
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return card;
    }
    return null;
  }
  function swapCards(from, to) {
    const next = valuesFor(node, active);
    if (!Number.isInteger(from) || !Number.isInteger(to) || from === to || from < 0 || from >= next.length) return false;
    if (to < next.length) [next[from], next[to]] = [next[to], next[from]];else {
      const [m] = next.splice(from, 1);
      next.push(m);
    }
    writeValues(node, active, next);
    return true;
  }
  function clearDragState() {
    dragIndex = null;
    if (dragCard) dragCard.classList.remove("dragging");
    dragCard = null;
    for (const q of root.querySelectorAll(".nfh15-card")) q.classList.remove("drag-target");
  }
  function beginCardDrag(event, index, card) {
    if (event.button !== 0 || event.target.closest?.(".nfh15-x,.nfh15-replace,audio,video,.nfh15-media-player")) return;
    event.preventDefault();
    event.stopPropagation();
    dragIndex = index;
    dragCard = card;
    card.classList.add("dragging");
    try {
      card.setPointerCapture?.(event.pointerId);
    } catch {}
  }
  function moveCardDrag(event) {
    if (dragIndex == null) return;
    event.preventDefault();
    event.stopPropagation();
    for (const q of root.querySelectorAll(".nfh15-card")) q.classList.remove("drag-target");
    cardAtPoint(event.clientX, event.clientY)?.classList.add("drag-target");
  }
  function endCardDrag(event) {
    if (dragIndex == null) return;
    event.preventDefault();
    event.stopPropagation();
    const target = cardAtPoint(event.clientX, event.clientY),
      to = target ? Number(target.dataset.index) : dragIndex,
      from = dragIndex;
    swapCards(from, to);
    clearDragState();
    render();
  }
  node.__nfh3SwapCards = (kind, from, to) => {
    active = kind;
    const changed = swapCards(from, to);
    render();
    return changed;
  };
  root.addEventListener("pointermove", moveCardDrag, true);
  root.addEventListener("pointerup", endCardDrag, true);
  root.addEventListener("pointercancel", clearDragState, true);
  // 外部文件拖入仍使用 drag/drop，但只在本节点内处理，避免创建额外 LoadImage 节点。
  for (const ev of ["dragstart", "dragover", "drop", "dragend"]) {
    root.addEventListener(ev, e => {
      if (e.target.closest?.(".nfh15-card,.nfh15-drop")) e.stopPropagation();
    }, true);
  }
  const head = document.createElement("div");
  head.className = "nfh15-head";
  head.innerHTML = '<span class="nfh15-title">南风 H3 本地多参考生成</span><button type="button" class="nfh15-badge" data-skin-entry title="皮肤" aria-label="打开皮肤页面" style="cursor:pointer;display:flex;align-items:center;justify-content:center;padding:6px 10px"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="M8 3 3 6l-2 5 5 2v8h12v-8l5-2-2-5-5-3c0 4-8 4-8 0Z"/></svg></button>';
  root.append(head);
  head.querySelector('[data-skin-entry]').onclick = () => {
    if (node.__nfh3SkinDialog?.isConnected) {
      node.__nfh3SkinDialog.focus();
      return;
    }
    const dialog = document.createElement('dialog');
    node.__nfh3SkinDialog = dialog;
    dialog.setAttribute('aria-label', '皮肤设置');
    dialog.style.cssText = 'width:min(1100px,92vw);height:min(740px,86vh);max-width:92vw;max-height:86vh;padding:0;background:#071b1a;color:#eafffb;border:1px solid #54d9ce;border-radius:10px;';
    dialog.innerHTML = '<div style="height:100%;display:flex;flex-direction:column"><header style="display:flex;align-items:center;justify-content:space-between;padding:18px 24px;border-bottom:1px solid #244944"><strong style="font-size:20px">皮肤</strong><button type="button" data-skin-close style="background:transparent;color:#eafffb;border:1px solid #54d9ce;padding:7px 16px;cursor:pointer">关闭返回</button></header><main style="flex:1;overflow:auto;padding:28px;color:#b5d4ce">皮肤页面已预留，选择与换肤逻辑待设置。</main></div>';
    dialog.querySelector('[data-skin-close]').onclick = () => dialog.close();
    dialog.addEventListener('close', () => {
      dialog.remove();
      if (node.__nfh3SkinDialog === dialog) node.__nfh3SkinDialog = null;
    });
    dialog.addEventListener('pointerdown', e => e.stopPropagation());
    dialog.addEventListener('keydown', e => e.stopPropagation());
    document.body.append(dialog);
    dialog.showModal();
    attachSkinOverlay(node, dialog);
    mountSkinCatalog(dialog.querySelector('main'), node, root);
  };
  const settings = document.createElement("div");
  settings.className = "nfh15-settings";
  const visiblePanelFields = isV81(node) ? PANEL_FIELDS.filter(x => x[0] !== "尺寸倍数").map(x => x[0] === "百万像素" ? [x[0], "一采百万像素", x[2]] : x) : PANEL_FIELDS;
  visiblePanelFields.forEach(x => settings.append(makeControl(node, x)));
  node.__nfh3SyncBasicDuration = value => {
    const control = settings.querySelector('[data-widget-name="时长秒"]');
    if (control && document.activeElement !== control) {
      control.value = String(value);
      control.__nfh3Paint?.();
    }
  };
  root.append(settings);
  const res = document.createElement("div");
  res.className = "nfh15-resolution";
  node.__nfh3Resolution = () => res.textContent = resolutionLabel(node);
  node.__nfh3Resolution();
  root.append(res);
  const promptBox = document.createElement("div");
  promptBox.className = "nfh15-prompt";
  promptBox.innerHTML = '<label><span>提示词</span><small class="nfh15-prompt-hint">输入 @ 选择已添加素材</small></label>';
  const promptHint = promptBox.querySelector(".nfh15-prompt-hint");
  const prompt = document.createElement("textarea");
  prompt.dataset.widgetName = "提示词";
  prompt.value = widget(node, "提示词")?.value || "";
  const menu = document.createElement("div");
  menu.className = "nfh15-mentions";
  promptBox.append(prompt, menu);
  function composeTriggeredPrompt(triggerText, promptText) {
    const head = String(triggerText || "").trim(),
      body = String(promptText || "").replace(/^[\r\n]+/, "");
    return head && body ? `${head}\n${body}` : head || body;
  }
  const triggerBox = document.createElement("div");
  triggerBox.className = "nfh15-constant-trigger";
  const triggerLabel = document.createElement("label");
  triggerLabel.textContent = "恒定触发词";
  const trigger = document.createElement("input");
  trigger.type = "text";
  trigger.dataset.widgetName = "恒定触发词";
  trigger.placeholder = "可选：每段生成时自动加在提示词第一行";
  trigger.value = String(widget(node, "恒定触发词")?.value || "");
  trigger.oninput = () => setWidget(node, "恒定触发词", trigger.value);
  triggerBox.append(triggerLabel, trigger);
  node.properties ||= {};
  const blankStoryboard = () => ({
    prompt: "",
    smartIdea: "",
    图片: [],
    视频: [],
    音频: [],
    durationSeconds: Number(widget(node, "时长秒")?.value || 5)
  });
  const nodeShots = Array.isArray(node.properties.nanfeng_storyboards) && node.properties.nanfeng_storyboards.length ? node.properties.nanfeng_storyboards : null;
  const persistedStoryboards = nodeShots ? null : loadPersistedStoryboards(node);
  const restoredFromStorage = !nodeShots && !!persistedStoryboards;
  let shots = (nodeShots ? JSON.parse(JSON.stringify(nodeShots)) : null) || persistedStoryboards?.shots || [{
    prompt: prompt.value,
    smartIdea: String(node.properties.nanfeng_smart_storyboard_idea ?? prompt.value ?? ""),
    图片: valuesFor(node, "图片"),
    视频: valuesFor(node, "视频"),
    音频: valuesFor(node, "音频")
  }];
  let activeShot = Math.max(0, Math.min(Number(node.properties.nanfeng_active_storyboard ?? persistedStoryboards?.activeShot) || 0, shots.length - 1));
  if (!Object.prototype.hasOwnProperty.call(shots[activeShot] || {}, "smartIdea")) {
    shots[activeShot].smartIdea = String(node.properties.nanfeng_smart_storyboard_idea ?? "");
  }
  const currentSmartIdea = () => String(shots[activeShot]?.smartIdea ?? "");
  const cloneStoryboard = shot => {
    try {
      if (typeof structuredClone === "function") return structuredClone(shot);
    } catch (e) {}
    return JSON.parse(JSON.stringify(shot));
  };
  const persistStoryboards = () => {
    node.properties.nanfeng_storyboards = shots.map(cloneStoryboard);
    node.properties.nanfeng_active_storyboard = activeShot;
    savePersistedStoryboards(node, shots, activeShot);
    node.graph?.change?.();
    node.setDirtyCanvas?.(true, true);
  };
  node.__nfh3RestoreStoryboardsFromProperties = () => {
    const configured = Array.isArray(node.properties?.nanfeng_storyboards) && node.properties.nanfeng_storyboards.length ? node.properties.nanfeng_storyboards : null;
    const backup = loadPersistedStoryboards(node);
    const candidate = configured || backup?.shots;
    if (!Array.isArray(candidate) || !candidate.length) return false;
    shots = candidate.map(cloneStoryboard);
    activeShot = Math.max(0, Math.min(Number(node.properties?.nanfeng_active_storyboard ?? backup?.activeShot) || 0, shots.length - 1));
    const shot = shots[activeShot] || blankStoryboard();
    setWidget(node, "提示词", shot.prompt || "");
    prompt.value = shot.prompt || "";
    if (Number.isFinite(Number(shot.durationSeconds))) setWidget(node, "时长秒", Number(shot.durationSeconds));
    setWidget(node, "开启音频驱动模式", !!shot.audioDriveEnabled);
    setWidget(node, "启用锁音频", !!shot.audioLockEnabled);
    setWidget(node, "空5分钟时间轴模式", !!shot.timelineOnly);

    setWidget(node, "图生视频", !!shot.图生视频);
    setWidget(node, "文生视频", !!shot.文生视频);
    setWidget(node, "首尾帧", !!shot.首尾帧);
    setWidget(node, "音频驱动文件", String(shot.audioDriveFilename || ""));
    setWidget(node, "音频驱动当前起点", Number(shot.audioDriveStart) || 0);
    setWidget(node, "音频驱动当前终点", Number(shot.audioDriveEnd) || 0);
    for (const kind of Object.keys(LIMITS)) writeValues(node, kind, Array.isArray(shot[kind]) ? shot[kind] : []);
    persistStoryboards();
    render();
    return true;
  };
  const captureStoryboard = () => {
    const existing = shots[activeShot] || {},
      next = {
        ...existing,
        prompt: prompt.value,
        smartIdea: currentSmartIdea(),
        图片: valuesFor(node, "图片"),
        视频: valuesFor(node, "视频"),
        音频: valuesFor(node, "音频"),
        durationSeconds: Number(widget(node, "时长秒")?.value || existing.durationSeconds || 5),
        audioDriveEnabled: existing.audioDriveEnabled === true,
        audioLockEnabled: existing.audioLockEnabled === true,
        timelineOnly: existing.timelineOnly === true
      };
    if (existing.audioDriveEnabled) {
      next.audioDriveFilename = String(existing.audioDriveFilename || "");
      next.audioDriveStart = Number(existing.audioDriveStart) || 0;
      next.audioDriveEnd = Number(existing.audioDriveEnd) || 0;
    } else {
      delete next.audioDriveStart;
      delete next.audioDriveEnd;
      delete next.audioDriveFilename;
    }
    shots[activeShot] = next;
    persistStoryboards();
  };
  const applyStoryboard = (index, skipCapture = false) => {
    if (!skipCapture) captureStoryboard();
    activeShot = Math.max(0, Math.min(index, shots.length - 1));
    const shot = shots[activeShot] || blankStoryboard();
    setWidget(node, "提示词", shot.prompt || "");
    prompt.value = shot.prompt || "";
    if (Number.isFinite(Number(shot.durationSeconds))) setWidget(node, "时长秒", Number(shot.durationSeconds));
    setWidget(node, "开启音频驱动模式", !!shot.audioDriveEnabled);
    setWidget(node, "启用锁音频", !!shot.audioLockEnabled);
    setWidget(node, "空5分钟时间轴模式", !!shot.timelineOnly);

    setWidget(node, "图生视频", !!shot.图生视频);
    setWidget(node, "文生视频", !!shot.文生视频);
    setWidget(node, "首尾帧", !!shot.首尾帧);
    setWidget(node, "音频驱动文件", String(shot.audioDriveFilename || ""));
    setWidget(node, "音频驱动当前起点", Number(shot.audioDriveStart) || 0);
    setWidget(node, "音频驱动当前终点", Number(shot.audioDriveEnd) || 0);
    for (const kind of Object.keys(LIMITS)) writeValues(node, kind, Array.isArray(shot[kind]) ? shot[kind] : []);
    sync(node, root);
    node.__nfh3SyncBasicDuration?.(Number(shot.durationSeconds));
    persistStoryboards();
    render();
  };
  const storyboardBar = document.createElement("div");
  storyboardBar.className = "nfh15-storyboard-bar";
  node.__nfh3ImportAudioDriveStoryboards = (generated, timelineOnly = false) => {
    if (!Array.isArray(generated) || !generated.length) return 0;
    captureStoryboard();
    const audioDriveFilename = timelineOnly ? "" : String(widget(node, "音频驱动文件")?.value || "");
    const imported = generated.map(item => {
      const integerDuration = Math.max(1, Math.ceil(Number(item.end) - Number(item.start))),
        importedImages = Array.isArray(item.images) ? item.images.filter(Boolean).slice(0, LIMITS.图片) : [],
        timelineI2V = timelineOnly && importedImages.length > 0;
      return {
        prompt: String(item.text || ""),
        smartIdea: String(widget(node, "音频驱动创意")?.value || ""),
        图片: importedImages,
        视频: [],
        音频: [],
        durationSeconds: integerDuration,
        audioDriveEnabled: true,
        audioLockEnabled: !timelineOnly,
        timelineOnly: !!timelineOnly,
        图生视频: timelineI2V,
        文生视频: timelineOnly && !timelineI2V,
        首尾帧: false,
        audioDriveFilename,
        audioDriveStart: Number(item.start),
        audioDriveEnd: Number(item.end)
      };
    });
    shots.push(...imported);
    persistStoryboards();
    applyStoryboard(shots.length - imported.length, true);
    return imported.length;
  };
  const storyboardTabs = document.createElement("div");
  storyboardTabs.className = "nfh15-storyboard-tabs";
  const storyboardActions = document.createElement("div");
  storyboardActions.className = "nfh15-storyboard-actions";
  const newShot = document.createElement("button");
  newShot.type = "button";
  newShot.className = "nfh15-storyboard-action";
  newShot.textContent = "＋ 新建分镜";
  newShot.onclick = () => {
    captureStoryboard();
    shots.push(blankStoryboard());
    applyStoryboard(shots.length - 1, true);
  };
  const copyShot = document.createElement("button");
  copyShot.type = "button";
  copyShot.className = "nfh15-storyboard-action";
  copyShot.textContent = "复制分镜";
  copyShot.onclick = () => {
    captureStoryboard();
    const group = shots[activeShot]?.continuationGroupId;
    if (!group) {
      shots.push(cloneStoryboard(shots[activeShot]));
      applyStoryboard(shots.length - 1, true);
      return;
    }
    const usedGroups = new Set(shots.map(shot => shot.continuationGroupId));
    const baseId = globalThis.crypto?.randomUUID?.() || `chain-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    let freshGroup = baseId,
      suffix = 1;
    while (usedGroups.has(freshGroup)) freshGroup = `${baseId}-${suffix++}`;
    const copies = shots.filter(shot => shot.continuationGroupId === group).map(shot => {
      const copy = cloneStoryboard(shot);
      copy.continuationGroupId = freshGroup;
      // Authored media filenames stay intact; only copied runtime handles are discarded.
      // Queue descriptors are generated afresh by planContinuation, never reused from a shot.
      for (const key of Object.keys(copy)) if (/descriptor|latent/i.test(key) || key === '潜空间续写任务') delete copy[key];
      return copy;
    });
    const firstCopy = shots.length;
    shots.push(...copies); // Append: existing C labels remain stable.
    applyStoryboard(firstCopy, true);
  };
  const deleteShot = document.createElement("button");
  deleteShot.type = "button";
  deleteShot.className = "nfh15-storyboard-action danger";
  deleteShot.textContent = "删除分镜";
  deleteShot.onclick = () => {
    if (shots.length <= 1) return;
    const group = shots[activeShot]?.continuationGroupId;
    if (!group) {
      shots.splice(activeShot, 1);
      applyStoryboard(Math.min(activeShot, shots.length - 1), true);
      return;
    }
    const firstMember = shots.findIndex(shot => shot.continuationGroupId === group);
    shots = shots.filter(shot => shot.continuationGroupId !== group);
    if (!shots.length) shots.push(blankStoryboard());
    // Load the survivor BEFORE render captures the editor, so deleted content cannot return.
    // This edits storyboard records only; queued snapshots and generated files are untouched.
    applyStoryboard(Math.min(firstMember, shots.length - 1), true);
  };
  storyboardActions.append(newShot, copyShot, deleteShot);
  const batchShots = document.createElement("button");
  batchShots.type = "button";
  batchShots.className = "nfh15-storyboard-action batch";
  batchShots.innerHTML = '<span class="nfh15-batch-icon">▶</span><span>生成当前及后续分镜</span>';
  batchShots.title = "从当前选中的分镜开始，把它和后续非空分镜按顺序加入ComfyUI队列";
  storyboardActions.append(batchShots);
  storyboardBar.append(storyboardTabs, storyboardActions);
  promptBox.append(storyboardBar);
  root.append(promptBox);
  function syncPromptConnection() {
    const linked = promptIsLinked(node);
    prompt.disabled = linked;
    prompt.readOnly = linked;
    prompt.classList.toggle("linked", linked);
    promptHint.textContent = linked ? "已连接外部提示词 · 文本框已锁定" : "输入 @ 选择已添加素材";
    promptTools?.querySelectorAll("button").forEach(button => button.disabled = linked);
    closeMentions();
  }
  node.__nfh3SyncPromptConnection = syncPromptConnection;
  const promptTools = document.createElement("div");
  promptTools.className = "nfh15-prompt-tools";
  batchShots.onclick = async () => {
    if (batchShots.disabled) return;
    captureStoryboard();
    const jobs = shots.map((shot, index) => ({
      shot,
      index
    })).filter(x => x.index >= activeShot && String(x.shot.prompt || '').trim());
    if (!jobs.length) {
      alert('当前及后续分镜中没有可生成的非空提示词');
      return;
    }
    batchShots.disabled = true;
    const originalIndex = activeShot,
      queueOwner = makeOwnerGuard(node);
    let submitted = 0;
    try {
      for (const {
        index
      } of jobs) {
        if (!queueOwner() || !ownsActiveNode(app, node)) throw Error("工作流已切换，停止提交剩余任务；已提交任务不受影响。");
        applyStoryboard(index, true);
        await app.queuePrompt(0, 1);
        submitted++;
      }
      console.info(`[南风H3 V8.1] 已从分镜 ${originalIndex + 1} 开始，通过标准单次运行路径依次提交 ${submitted} 个分镜任务`);
      batchShots.textContent = `✓ 已排队 ${submitted} 个分镜`;
      setTimeout(() => {
        batchShots.innerHTML = '<span class="nfh15-batch-icon">▶</span><span>生成当前及后续分镜</span>';
      }, 1800);
    } catch (error) {
      const details = error?.response?.error?.message || error?.response?.error?.details || error?.message || String(error);
      alert(`批量生成提交失败（已提交${submitted}/${jobs.length}）：${details}`);
    } finally {
      if (queueOwner()) applyStoryboard(originalIndex, true);
      batchShots.disabled = false;
    }
  };
  const originalIndependentBatch = batchShots.onclick;
  const runStoryboardQueue = async (scope = 'following') => {
    const queueOwner = makeOwnerGuard(node);
    const checkOwner = () => {
      if (!queueOwner() || !ownsActiveNode(app, node)) throw Error('工作流已切换，未提交的连续批次已停止。');
    };
    if (batchShots.disabled) return;
    if (promptIsLinked(node)) {
      alert('潜空间续写使用节点内分镜；请先断开外部提示词/提示词列表连接。');
      return;
    }
    captureStoryboard();
    const originalIndex = activeShot;
    let submitted = 0;
    let restored = false;
    batchShots.disabled = true;
    node.__nfh3ContinuationCancelled = false;
    try {
      const infoResponse = await api.fetchApi('/object_info/NanFengH3MultiReferenceGeneratorV15');
      const info = await infoResponse.json();
      checkOwner();
      if (!info.NanFengH3MultiReferenceGeneratorV15?.input?.required?.['启用潜空间续写']) throw new Error('后端尚未加载续写，请任务结束后重启ComfyUI。');
      const run = globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
      const jobs = planContinuation(shots, activeShot, {
        workflow: workflowStorageScope(node),
        node: String(node.id),
        run
      }, scope);
      // Snapshot all complete payloads before waiting: edits during a render cannot change a later shot.
      const payloads = new Map();
      for (const job of jobs) {
        checkOwner();
        applyStoryboard(job.index, true);
        const payload = structuredClone(await app.graphToPrompt());
        checkOwner();
        applyContinuationJob(payload, node.id, job);
        // Never accidentally start another enabled V15 chain in the same workflow.
        for (const [id, entry] of Object.entries(payload.output)) if (id !== String(node.id) && entry.class_type === 'NanFengH3MultiReferenceGeneratorV15' && entry.inputs['启用潜空间续写']) throw new Error('同一工作流一次只运行一个启用续写的V15节点。');
        payloads.set(job.index, payload);
      }
      applyStoryboard(originalIndex, true);
      restored = true;
      setWidget(node, '潜空间续写任务', '');
      node.__nfh3LastBatchId = run;
      rememberBatch(node, run);
      const acknowledgement = await submitContinuation({
        jobs,
        build: async job => payloads.get(job.index),
        api,
        nodeId: node.id,
        batchId: run
      });
      submitted = jobs.length;
      node.__nfh3LastBatchId = acknowledgement.id;
      refreshContinuationBatches().catch(() => {});
    } catch (error) {
      alert(`后台批次 ${node.__nfh3LastBatchId || '未创建'} 确认失败：${error.message || error}。请先刷新后台批次确认是否已接收，勿直接重复提交。`);
    } finally {
      if (queueOwner()) {
        if (!restored) applyStoryboard(originalIndex, true);
        setWidget(node, '潜空间续写任务', '');
      }
      batchShots.disabled = false;
      batchShots.innerHTML = '<span class="nfh15-batch-icon">▶</span><span>生成当前及后续分镜</span>';
    }
  };
  node.__nfh3RunCurrentGroup = () => runStoryboardQueue('current');
  batchShots.onclick = async () => {
    if (widget(node, "启用潜空间续写")?.value === true) return runStoryboardQueue('following');
    app.__nfh3V15IndependentBatch = true;
    try {
      return await originalIndependentBatch();
    } finally {
      app.__nfh3V15IndependentBatch = false;
    }
  };
  batchShots.title = '从当前段开始运行所有后续分镜；连续组各自从新链开始，普通分镜独立生成。仅剩一个组成员时也从首段安全新建。';
  const currentRunNote = document.createElement('div');
  currentRunNote.className = 'nfh15-note';
  currentRunNote.textContent = '潜空间续写开启时：上方单次运行只生成当前所在整组（从组首开始）；未分组仅生成当前段。批量按钮生成当前及全部后续分镜，各组独立续写。';
  storyboardActions.append(currentRunNote);
  function commitPrompt() {
    setWidget(node, "提示词", prompt.value);
    prompt.focus();
  }
  function openSmartStoryboard() {
    const dialogOwner = makeOwnerGuard(node);
    const assetDraft = createSmartAssetDraft({
      图片: valuesFor(node, '图片'),
      视频: valuesFor(node, '视频'),
      音频: valuesFor(node, '音频')
    });
    const imageParticipation = createImageParticipation(assetDraft.values('图片'), node.properties?.nanfeng_v15_smart_image_participation);
    const participationEnabled = () => widget(node, '启用潜空间续写')?.value === true;
    const persistParticipation = () => {
      if (!dialogOwner()) return;
      node.properties.nanfeng_v15_smart_image_participation = imageParticipation.snapshot();
      node.graph?.change?.();
      node.setDirtyCanvas?.(true, true);
    };
    let draftUploads = 0;
    async function uploadDraftImage(file) {
      const ext = file.name.match(/\.[^.]+$/)?.[0] || '.png';
      const unique = new File([file], `nfh15-smart-${crypto.randomUUID()}${ext}`, {
        type: file.type
      });
      const form = new FormData();
      form.append('image', unique);
      form.append('type', 'input');
      form.append('overwrite', 'false');
      const response = await api.fetchApi('/upload/image', {
        method: 'POST',
        body: form
      });
      const data = await readJsonResponse(response);
      if (!response.ok) throw Error(`上传失败 HTTP ${response.status}`);
      return data.subfolder ? `${data.subfolder}/${data.name}` : data.name;
    }
    const draftReplacePicker = document.createElement('input');
    draftReplacePicker.type = 'file';
    draftReplacePicker.accept = ACCEPT.图片;
    draftReplacePicker.hidden = true;
    let draftReplaceSlot = null;
    draftReplacePicker.onchange = async () => {
      const file = draftReplacePicker.files?.[0],
        slot = draftReplaceSlot;
      if (!file || !Number.isInteger(slot)) return;
      draftUploads++;
      try {
        if (inferKind(file) !== '图片') throw Error('请选择图片');
        const old = assetDraft.values('图片')[slot],
          uploaded = await uploadDraftImage(file);
        assetDraft.replace(slot, uploaded);
        imageParticipation.replace(old, uploaded);
        if (participationEnabled()) persistParticipation();
        renderSmartImages();
      } catch (e) {
        alert(e.message);
      } finally {
        draftUploads--;
        draftReplacePicker.value = '';
      }
    };
    const overlay = document.createElement("div");
    overlay.className = "nfh15-smart-overlay";
    overlay.style.cssText = "position:fixed;inset:0;z-index:100000;background:#05070bd9;display:grid;place-items:center;padding:20px";
    const panel = document.createElement("div");
    panel.className = "nfh15-smart-panel";
    panel.style.cssText = "width:min(760px,94vw);max-height:94vh;min-height:650px;overflow:auto;background:linear-gradient(145deg,#142127,#091015);border:1px solid #397f86;border-radius:16px;padding:20px;color:#effcff;box-shadow:0 24px 80px #000";
    panel.innerHTML = '<div style="font-size:20px;font-weight:800;margin-bottom:5px">智能分镜＆提示词</div><div style="display:flex;align-items:center;justify-content:space-between;gap:10px"><div class="nfh15-note" data-smart-config style="color:#88c9c5">正在检查节点包 .env…</div><button data-smart-config-toggle type="button" style="width:auto;height:30px;padding:0 11px;border:1px solid #3d7477;border-radius:7px;background:#10282d;color:#d9fffb;cursor:pointer">API配置</button></div><section data-smart-config-panel hidden style="margin-top:10px;padding:12px;border:1px solid #315d63;border-radius:11px;background:#081419"><div style="font-weight:800;color:#dffbf8">快速配置 · 自动保存到节点包 .env</div><div style="margin-top:4px;color:#78aaa9;font-size:11px">API Key只写入服务端.env，不进入工作流JSON；Key留空保存会保留原Key。</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:11px"><div><b style="color:#9de0d8">看图模型</b><label style="display:block;margin-top:7px">Base URL<input data-cfg="NANFENG_VISION_BASE_URL" placeholder="https://example.com/v1" style="width:100%;box-sizing:border-box;margin-top:4px;background:#061015;color:#fff;border:1px solid #315d63;border-radius:7px;padding:8px"></label><label style="display:block;margin-top:7px">API Key<input data-cfg="NANFENG_VISION_API_KEY" type="password" placeholder="未填写；留空保留已保存Key" autocomplete="new-password" style="width:100%;box-sizing:border-box;margin-top:4px;background:#061015;color:#fff;border:1px solid #315d63;border-radius:7px;padding:8px"></label><label style="display:block;margin-top:7px">模型ID<div style="display:grid;grid-template-columns:1fr auto;gap:6px;margin-top:4px"><input data-cfg="NANFENG_VISION_MODEL" list="nfh15-vision-models" placeholder="视觉模型ID" style="width:100%;box-sizing:border-box;background:#061015;color:#fff;border:1px solid #315d63;border-radius:7px;padding:8px"><button data-detect-models="vision" type="button" style="width:auto;padding:0 10px;border:1px solid #3d7477;border-radius:7px;background:#123438;color:#d9fffb;cursor:pointer">识别模型</button></div><datalist id="nfh15-vision-models"></datalist></label></div><div><b style="color:#9de0d8">语言模型</b><label style="display:block;margin-top:7px">Base URL<input data-cfg="NANFENG_TEXT_BASE_URL" placeholder="https://example.com/v1" style="width:100%;box-sizing:border-box;margin-top:4px;background:#061015;color:#fff;border:1px solid #315d63;border-radius:7px;padding:8px"></label><label style="display:block;margin-top:7px">API Key<input data-cfg="NANFENG_TEXT_API_KEY" type="password" placeholder="未填写；留空保留已保存Key" autocomplete="new-password" style="width:100%;box-sizing:border-box;margin-top:4px;background:#061015;color:#fff;border:1px solid #315d63;border-radius:7px;padding:8px"></label><label style="display:block;margin-top:7px">模型ID<div style="display:grid;grid-template-columns:1fr auto;gap:6px;margin-top:4px"><input data-cfg="NANFENG_TEXT_MODEL" list="nfh15-text-models" placeholder="语言模型ID" style="width:100%;box-sizing:border-box;background:#061015;color:#fff;border:1px solid #315d63;border-radius:7px;padding:8px"><button data-detect-models="text" type="button" style="width:auto;padding:0 10px;border:1px solid #3d7477;border-radius:7px;background:#123438;color:#d9fffb;cursor:pointer">识别模型</button></div><datalist id="nfh15-text-models"></datalist></label></div></div><div data-config-message style="min-height:18px;margin-top:9px;color:#82cfc5"></div><div style="display:flex;justify-content:flex-end;gap:8px"><button data-config-clear type="button" style="width:auto;height:33px;padding:0 12px;border:1px solid #76504f;border-radius:7px;background:#291a1b;color:#ffc9c5;cursor:pointer">清除全部配置</button><button data-config-save type="button" style="width:auto;height:33px;padding:0 14px;border:1px solid #3e9992;border-radius:7px;background:#17464a;color:#eafffc;font-weight:700;cursor:pointer">保存到.env</button></div></section><label style="display:block;margin-top:12px;font-weight:700">H3官方模式</label><select data-smart-mode style="width:100%;margin-top:7px;background:#071017;color:#fff;border:1px solid #397682;border-radius:9px;padding:9px"><option value="ref2va">多参 Ref2VA</option><option value="i2va">I2V 图生视频</option><option value="reference_i2va">非首帧I2V（图片参考）</option><option value="oneshot_continuation">严格一镜到底</option><option value="continuation_cuts">连续续写（允许切镜）</option><option value="t2va">T2V 文生视频</option><option value="fl2va">首尾帧 FL2VA</option></select><div data-smart-mode-hint style="margin-top:6px;color:#78aaa9;font-size:11px">多参：至少1张图片，输出官方六段结构。</div><label style="display:block;margin-top:12px;font-weight:700">选择 Skill</label><select data-smart-skill style="width:100%;margin-top:7px;background:#071017;color:#fff;border:1px solid #397682;border-radius:9px;padding:9px"><option value="regular_storyboard">常规提示词分镜</option><option value="ns_storyboard">NS提示词分镜</option></select><div data-smart-skill-hint style="margin-top:6px;color:#78aaa9;font-size:11px">语言模型配置随Skill独立保存；看图模型全局共用。</div><label style="display:block;margin-top:14px;font-weight:700">你想拍什么</label><textarea data-smart-idea style="width:100%;height:136px;box-sizing:border-box;margin-top:7px;background:#071017;color:#fff;border:1px solid #397682;border-radius:10px;padding:12px;resize:vertical"></textarea><section style="margin-top:14px;padding:12px;border:1px solid #315d63;border-radius:11px;background:#09161b"><div style="display:flex;align-items:center;justify-content:space-between;gap:12px"><div><b>参考图片</b><span style="display:block;margin-top:2px;color:#78aaa9;font-size:11px">从当前分镜复制素材；弹窗修改不改原分镜</span></div><button data-smart-add type="button" style="width:auto;height:32px;padding:0 12px;border:1px solid #3e8b8a;border-radius:8px;background:#123438;color:#d9fffb;cursor:pointer">＋ 批量添加</button></div><div data-smart-images style="display:grid;grid-template-columns:repeat(9,minmax(48px,1fr));gap:7px;margin-top:10px"></div><div style="margin-top:8px;color:#79aaa9;font-size:11px">点击空位上传；点击“换图”原位替换；拖动图片可交换位置，@图片编号始终按槽位固定。</div></section><label style="display:block;margin-top:12px;font-weight:700">生成段数</label><select data-smart-count style="width:100%;margin-top:7px;background:#071017;color:#fff;border:1px solid #397682;border-radius:9px;padding:9px"></select><div data-smart-status class="nfh15-note" style="margin-top:12px;color:#78c7b0">当前图片槽位会按固定编号逐张看图。</div><div style="display:flex;justify-content:flex-end;gap:9px;margin-top:16px"><button data-smart-cancel type="button" style="width:auto;min-width:84px;height:36px;padding:0 16px;border:1px solid #45575d;border-radius:8px;background:#182329;color:#dce9eb;cursor:pointer">取消</button><button data-smart-run type="button" style="width:auto;min-width:156px;height:36px;padding:0 16px;border:1px solid #3e9992;border-radius:8px;background:linear-gradient(135deg,#245f5b,#173f43);color:#eafffc;font-weight:700;cursor:pointer">生成并写入分镜</button></div>';
    overlay.append(panel);
    document.body.append(overlay);
    attachSkinOverlay(node, overlay);
    const idea = panel.querySelector('[data-smart-idea]'),
      count = panel.querySelector('[data-smart-count]'),
      mode = panel.querySelector('[data-smart-mode]'),
      modeHint = panel.querySelector('[data-smart-mode-hint]'),
      status = panel.querySelector('[data-smart-status]'),
      run = panel.querySelector('[data-smart-run]'),
      imageStrip = panel.querySelector('[data-smart-images]'),
      skillSelect = panel.querySelector('[data-smart-skill]'),
      skillHint = panel.querySelector('[data-smart-skill-hint]'),
      configLine = panel.querySelector('[data-smart-config]'),
      configPanel = panel.querySelector('[data-smart-config-panel]'),
      configMessage = panel.querySelector('[data-config-message]');
    idea.value = String(shots[activeShot]?.smartIdea ?? '');
    const rememberSmartIdea = () => {
      shots[activeShot] ||= blankStoryboard();
      shots[activeShot].smartIdea = idea.value;
      node.properties.nanfeng_smart_storyboard_idea = idea.value;
      persistStoryboards();
    };
    idea.oninput = rememberSmartIdea;
    count.innerHTML = Array.from({
      length: 12
    }, (_, i) => `<option value="${i + 1}">${i + 1}段</option>`).join('');
    const savedSegmentCount = Number(node.properties.nanfeng_v15_smart_segment_count);
    count.value = String(Number.isInteger(savedSegmentCount) && savedSegmentCount >= 1 && savedSegmentCount <= 12 ? savedSegmentCount : 3);
    count.onchange = () => {
      const value = Number(count.value);
      if (!Number.isInteger(value) || value < 1 || value > 12) return;
      node.properties.nanfeng_v15_smart_segment_count = value;
      node.graph?.change?.();
      node.setDirtyCanvas?.(true, true);
    };
    const rememberedSkill = String(node.properties.nanfeng_smart_storyboard_skill_id || loadPersistedSmartSkill() || 'regular_storyboard');
    if (skillSelect) skillSelect.value = rememberedSkill;
    const rememberSelectedSkill = () => {
      const selected = skillSelect?.value || 'regular_storyboard';
      node.properties.nanfeng_smart_storyboard_skill_id = selected;
      savePersistedSmartSkill(selected);
      node.setDirtyCanvas?.(true, true);
      return selected;
    };
    skillSelect?.addEventListener('change', () => {
      rememberSelectedSkill();
      loadConfig();
    });
    const modeHints = {
      continuation_cuts: '仅提示词允许用户明确要求的切镜；保留分组与latent接线，开头锚定不会被文字解除。',
      oneshot_continuation: '支持1～9图，各段联合规划为同一长镜头，连续继承动作与机位。提示词生成不自动排队；勾选潜空间续写后使用批量生成执行AV连续组。',
      reference_i2va: '支持1～9张图片：身份/外观参考，按图片槽位编号，文字控制首帧景别与构图，输出三段格式。仅写提示词；生成请手动使用多参路径，勿勾图生视频或首尾帧，勿设置首帧Guide。',
      ref2va: '多参：至少1张图片，输出subject_definitions等官方六段结构。',
      i2va: 'I2V：必须且只能使用@图片1作为0.00秒首帧。',
      t2va: 'T2V：不使用图片，输出官方基础三段结构。',
      fl2va: '首尾帧：必须使用@图片1首帧和@图片2尾帧。'
    };
    const modeValues = [...mode.options].map(option => option.value),
      rememberedMode = String(node.properties.nanfeng_smart_storyboard_mode || loadPersistedSmartMode() || 'ref2va');
    if (modeValues.includes(rememberedMode)) mode.value = rememberedMode;

    const rememberSelectedMode = () => {
      const selected = modeValues.includes(mode.value) ? mode.value : 'ref2va';
      node.properties.nanfeng_smart_storyboard_mode = selected;
      savePersistedSmartMode(selected);
      modeHint.textContent = modeHints[selected];
      node.graph?.change?.();
      node.setDirtyCanvas?.(true, true);
      return selected;
    };
    modeHint.textContent = modeHints[mode.value];
    const allContinuationModeOptions = mode.innerHTML;
    const applyContinuationRestriction = () => {
      const enabled = widget(node, "启用潜空间续写")?.value === true;
      const previous = mode.value;
      if (enabled) {
        mode.innerHTML = '<option value="oneshot_continuation">严格一镜到底</option><option value="continuation_cuts">连续续写（允许切镜）</option>';
        mode.value = previous === 'continuation_cuts' ? 'continuation_cuts' : 'oneshot_continuation';
      } else if (mode.options.length === 2) {
        mode.innerHTML = allContinuationModeOptions;
        mode.value = modeValues.includes(previous) ? previous : 'ref2va';
      }
      const minimum = enabled || ['oneshot_continuation', 'continuation_cuts'].includes(mode.value) ? 2 : 1,
        selectedCount = Math.max(minimum, Number(count.value) || 3);
      count.innerHTML = Array.from({
        length: 13 - minimum
      }, (_, i) => `<option value="${i + minimum}">${i + minimum}段</option>`).join('');
      count.value = String(selectedCount);
      modeHint.textContent = enabled ? '续写已勾选：可选严格一镜到底或允许切镜，至少2段。切镜仅改变提示词，不自动断开latent。' : modeHints[mode.value];
    };
    node.__nfh3ApplyContinuationRestriction = applyContinuationRestriction;
    mode.onchange = () => {
      rememberSelectedMode();
      applyContinuationRestriction();
    };
    applyContinuationRestriction();
    const close = () => overlay.remove();
    node.__nfh3CloseSmart = close;
    panel.querySelector('[data-smart-cancel]').onclick = close;
    let smartDrag = null,
      smartPicker = null;
    function smartMoveImage(from, to) {
      const moved = assetDraft.move(from, to);
      renderSmartImages();
      return moved;
    }
    function smartDeleteImage(slot) {
      assetDraft.remove(slot);
      renderSmartImages();
      return true;
    }
    mode.addEventListener('change', () => renderSmartImages());
    count.addEventListener('change', () => renderSmartImages());
    function renderSmartImages() {
      const images = assetDraft.values('图片');
      imageParticipation.sync(images);
      imageStrip.replaceChildren();
      for (let slot = 0; slot < LIMITS.图片; slot++) {
        const file = images[slot],
          cell = document.createElement('div');
        cell.dataset.smartSlot = String(slot);
        cell.style.cssText = 'position:relative;aspect-ratio:1;border:1px solid #31575d;border-radius:8px;background:#061015;overflow:hidden;display:grid;place-items:center;min-width:0';
        if (file) {
          cell.draggable = true;
          cell.innerHTML = `<img src="${mediaUrl(file, mediaRevision(node, file))}" alt="@图片${slot + 1}" style="width:100%;height:100%;object-fit:cover"><span style="position:absolute;left:4px;top:4px;padding:2px 5px;border-radius:5px;background:#041013d9;color:#eafffc;font-size:10px">@图片${slot + 1}</span><button type="button" data-smart-delete="${slot}" title="删除并让后续图片向前补位" style="position:absolute;right:3px;top:3px;width:22px;height:22px;padding:0;border:1px solid #7d4b52;border-radius:50%;background:#35171ddd;color:#ffd9dc;font-size:13px;cursor:pointer">×</button><button type="button" data-smart-move="${slot}" title="选择后再点击目标位置换位" style="position:absolute;left:3px;bottom:3px;width:22px;height:22px;padding:0;border:1px solid #3c7477;border-radius:5px;background:#0a2025df;color:#d7fffb;font-size:12px;cursor:pointer">↔</button><button type="button" data-smart-replace="${slot}" style="position:absolute;right:3px;bottom:3px;width:auto;height:22px;padding:0 6px;border:1px solid #3c7477;border-radius:5px;background:#0a2025df;color:#d7fffb;font-size:10px;cursor:pointer">换图</button>`;
          cell.ondragstart = e => {
            smartDrag = slot;
            e.dataTransfer.effectAllowed = 'move';
          };
          cell.ondragover = e => {
            e.preventDefault();
            cell.style.borderColor = '#62beb5';
          };
          cell.ondragleave = () => cell.style.borderColor = '#31575d';
          cell.ondrop = e => {
            e.preventDefault();
            cell.style.borderColor = '#31575d';
            if (Number.isInteger(smartDrag) && smartDrag !== slot) smartMoveImage(smartDrag, slot);
            smartDrag = null;
          };
          cell.onclick = e => {
            if (Number.isInteger(smartDrag) && !e.target.closest?.('button')) {
              smartMoveImage(smartDrag, slot);
              smartDrag = null;
            }
          };
        } else {
          cell.innerHTML = `<button type="button" data-smart-empty="${slot}" style="width:100%;height:100%;border:0;background:transparent;color:#5e8f91;cursor:pointer;font-size:18px">＋<span style="display:block;font-size:9px;margin-top:2px">图片${slot + 1}</span></button>`;
        }
        if (file && participationEnabled()) {
          const wrapper = document.createElement('div');
          wrapper.style.cssText = 'min-width:0;display:flex;flex-direction:column;gap:5px';
          wrapper.dataset.smartSlot = String(slot);
          cell.style.width = '100%';
          wrapper.append(cell, imageParticipationControl(imageParticipation, slot, Number(count.value), () => {
            persistParticipation();
            const expanded = Array.from(imageStrip.querySelectorAll('details[open]'), d => d.dataset.imageParticipation);
            renderSmartImages();
            for (const d of imageStrip.querySelectorAll('details')) d.open = expanded.includes(d.dataset.imageParticipation);
          }));
          imageStrip.append(wrapper);
        } else imageStrip.append(cell);
      }
      for (const button of imageStrip.querySelectorAll('[data-smart-empty]')) button.onclick = () => smartPicker?.click();
      for (const button of imageStrip.querySelectorAll('[data-smart-replace]')) button.onclick = () => {
        draftReplaceSlot = Number(button.dataset.smartReplace);
        draftReplacePicker.value = '';
        draftReplacePicker.click();
      };
      for (const button of imageStrip.querySelectorAll('[data-smart-delete]')) button.onclick = e => {
        e.stopPropagation();
        smartDeleteImage(Number(button.dataset.smartDelete));
      };
      for (const button of imageStrip.querySelectorAll('[data-smart-move]')) button.onclick = e => {
        e.stopPropagation();
        const slot = Number(button.dataset.smartMove);
        if (Number.isInteger(smartDrag) && smartDrag !== slot) {
          smartMoveImage(smartDrag, slot);
          smartDrag = null;
        } else {
          smartDrag = slot;
          for (const cell of imageStrip.children) cell.style.borderColor = Number(cell.dataset.smartSlot) === slot ? '#76ded2' : '#31575d';
        }
      };
    }
    renderSmartImages();
    smartPicker = document.createElement('input');
    smartPicker.type = 'file';
    smartPicker.accept = ACCEPT.图片;
    smartPicker.multiple = true;
    smartPicker.hidden = true;
    panel.append(smartPicker, draftReplacePicker);
    smartPicker.onchange = async () => {
      draftUploads++;
      try {
        for (const file of [...smartPicker.files]) {
          if (inferKind(file) !== '图片') throw Error('请选择图片');
          if (assetDraft.values('图片').length >= 9) throw Error('最多9张图片');
          assetDraft.add(await uploadDraftImage(file));
        }
      } catch (e) {
        alert(e.message);
      } finally {
        draftUploads--;
        smartPicker.value = '';
        renderSmartImages();
      }
    };
    for (const button of imageStrip.querySelectorAll('[data-smart-empty]')) button.onclick = () => smartPicker.click();
    panel.querySelector('[data-smart-add]').onclick = () => smartPicker.click();
    const originalRender = node.__nfh3Render;
    node.__nfh3Render = () => {
      originalRender?.();
      if (overlay.isConnected) renderSmartImages();
    };
    const closeAndRestore = () => {
      node.__nfh3Render = originalRender;
      close();
    };
    panel.querySelector('[data-smart-cancel]').onclick = closeAndRestore;
    let configData = {};
    function paintConfig(d) {
      if (!dialogOwner() || !overlay.isConnected) return;
      configData = d || {};
      if (skillSelect && Array.isArray(d.skills)) {
        const current = skillSelect.value;
        skillSelect.replaceChildren(...d.skills.map(item => {
          const option = document.createElement('option');
          option.value = item.id;
          option.textContent = item.label;
          return option;
        }));
        skillSelect.value = d.skills.some(item => item.id === current) ? current : d.skills.some(item => item.id === rememberedSkill) ? rememberedSkill : d.skill_id || 'regular_storyboard';
        rememberSelectedSkill();
      }
      if (skillHint && d.skill_description) skillHint.textContent = d.skill_description;
      configLine.textContent = `看图API：${d.vision_configured ? '已配置' : '未配置'} · 语言模型：${d.text_configured ? '已配置' : '未配置'} · Skill：${d.skill_exists ? '已就绪' : '缺失'}`;
      for (const el of configPanel.querySelectorAll('[data-cfg]')) {
        const key = el.dataset.cfg;
        if (key.endsWith('_API_KEY')) {
          el.value = '';
          el.placeholder = key.includes('VISION') ? d.vision_key_saved ? '已保存；留空保持不变' : '输入看图API Key' : d.text_key_saved ? '已保存；留空保持不变' : '输入语言模型API Key';
        } else el.value = d[key] || (key.endsWith('_PROTOCOL') ? 'chat_completions' : '');
      }
    }
    async function loadConfig() {
      try {
        const response = await api.fetchApi(`/nanfeng/v15/h3/storyboard/config?skill_id=${encodeURIComponent(skillSelect?.value || 'regular_storyboard')}`, {
          cache: 'no-store'
        });
        paintConfig(await readJsonResponse(response));
      } catch {
        configLine.textContent = '配置状态读取失败，请确认V15已重启。';
      }
    }
    panel.querySelector('[data-smart-config-toggle]').onclick = () => {
      configPanel.hidden = !configPanel.hidden;
      if (!configPanel.hidden) panel.querySelector('[data-cfg]')?.focus();
    };
    for (const button of configPanel.querySelectorAll('[data-detect-models]')) button.onclick = async () => {
      const kind = button.dataset.detectModels,
        prefix = kind === 'vision' ? 'NANFENG_VISION' : 'NANFENG_TEXT',
        base = panel.querySelector(`[data-cfg="${prefix}_BASE_URL"]`),
        key = panel.querySelector(`[data-cfg="${prefix}_API_KEY"]`),
        model = panel.querySelector(`[data-cfg="${prefix}_MODEL"]`),
        list = panel.querySelector(`#nfh15-${kind}-models`);
      button.disabled = true;
      configMessage.style.color = '#82cfc5';
      configMessage.textContent = `正在识别${kind === 'vision' ? '看图' : '语言'}模型…`;
      try {
        const response = await api.fetchApi('/nanfeng/v15/h3/storyboard/models', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            kind,
            base_url: base.value,
            api_key: key.value
          })
        });
        const data = await readJsonResponse(response);
        if (!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);
        base.value = data.base_url;
        list.replaceChildren(...data.models.map(id => {
          const option = document.createElement('option');
          option.value = id;
          return option;
        }));
        if (!model.value && data.models.length === 1) model.value = data.models[0];
        configMessage.textContent = `已识别 ${data.models.length} 个模型；点击模型ID框选择或搜索。`;
        model.focus();
        model.click();
      } catch (error) {
        configMessage.style.color = '#ffaaa4';
        configMessage.textContent = `识别失败：${error.message}`;
      } finally {
        button.disabled = false;
      }
    };
    panel.querySelector('[data-config-save]').onclick = async () => {
      const button = panel.querySelector('[data-config-save]');
      button.disabled = true;
      configMessage.style.color = '#82cfc5';
      configMessage.textContent = '正在安全写入节点包 .env…';
      try {
        const payload = {
          skill_id: skillSelect?.value || 'regular_storyboard'
        };
        for (const el of configPanel.querySelectorAll('[data-cfg]')) payload[el.dataset.cfg] = el.value;
        const response = await api.fetchApi('/nanfeng/v15/h3/storyboard/config', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        });
        const data = await readJsonResponse(response);
        if (!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);
        paintConfig(data);
        configMessage.textContent = '已保存到节点包 .env，立即生效。';
      } catch (error) {
        configMessage.style.color = '#ffaaa4';
        configMessage.textContent = `保存失败：${error.message}`;
      } finally {
        button.disabled = false;
      }
    };
    panel.querySelector('[data-config-clear]').onclick = async () => {
      if (!confirm('确认清除看图API和语言模型的URL、Key、模型ID吗？此操作会清空节点包.env中的智能分镜配置。')) return;
      const button = panel.querySelector('[data-config-clear]');
      button.disabled = true;
      configMessage.style.color = '#82cfc5';
      configMessage.textContent = '正在清除配置…';
      try {
        const response = await api.fetchApi('/nanfeng/v15/h3/storyboard/config', {
          method: 'DELETE'
        });
        const data = await readJsonResponse(response);
        if (!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);
        paintConfig(data);
        configMessage.textContent = '已清除全部API配置。';
      } catch (error) {
        configMessage.style.color = '#ffaaa4';
        configMessage.textContent = `清除失败：${error.message}`;
      } finally {
        button.disabled = false;
      }
    };
    loadConfig();
    let activeJobId = null,
      cancelRequested = false;
    const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
    async function pollStoryboardJob(jobId) {
      const started = Date.now();
      for (;;) {
        const response = await api.fetchApi(`/nanfeng/v15/h3/storyboard/jobs/${jobId}`, {
          cache: 'no-store'
        });
        const data = await readJsonResponse(response);
        if (!response.ok || !data.ok) throw new Error(data.error || `HTTP ${response.status}`);
        status.textContent = `任务 ${jobId.slice(0, 8)} · 已等待 ${Math.floor((Date.now() - started) / 1000)} 秒 · ${data.stage || '正在等待上游完整返回…'}${Date.now() - started > 45000 ? '；上游仍未完成，请勿重复点击生成' : ''}`;
        if (data.status === 'completed') return data.result;
        if (data.status === 'cancelled') throw new Error('任务已由你取消');
        if (data.status === 'failed') throw new Error(data.error || '任务失败');
        await wait(1500);
      }
    }
    panel.querySelector('[data-smart-cancel]').onclick = () => {
      if (activeJobId) {
        const jobId = activeJobId;
        cancelRequested = true;
        activeJobId = null;
        api.fetchApi(`/nanfeng/v15/h3/storyboard/jobs/${jobId}`, {
          method: 'DELETE'
        }).catch(() => {});
      }
      closeAndRestore();
    };
    run.onclick = async () => {
      if (run.disabled) return;
      status.style.color = '#78c7b0';
      status.textContent = '已收到点击，正在检查素材与保存创意…';
      try {
        if (draftUploads) {
          status.textContent = '图片正在上传，请完成后再生成。';
          return;
        }
        const submittedDraft = assetDraft.snapshot(),
          submittedCount = Number(count.value),
          submittedMode = mode.value,
          submittedIdea = idea.value;
        let participationPlan = null;
        try {
          if (participationEnabled() && ['oneshot_continuation', 'continuation_cuts'].includes(submittedMode) && imageParticipation.snapshot().rows.some(r => Array.isArray(r.segments))) {
            imageParticipation.sync(submittedDraft.assets.图片);
            participationPlan = imageParticipation.plan(submittedCount);
            if (participationPlan.some(p => !p.images.length)) throw Error('每段请至少选择一张参与图片；不自动改变现有视频模型路径。');
            persistParticipation();
          }
        } catch (error) {
          status.textContent = error.message;
          return;
        }
        rememberSmartIdea();
        const requestedDuration = Number(widget(node, "时长秒")?.value || 5),
          images = submittedDraft.assets.图片,
          videos = submittedDraft.assets.视频,
          audios = submittedDraft.assets.音频;
        run.disabled = true;
        cancelRequested = false;
        status.style.color = '#78c7b0';
        status.textContent = `正在分析 ${images.length} 张图片，并携带 ${videos.length} 段参考视频、${audios.length} 段参考音频，按当前时长生成 ${count.value} 段；除非你取消，否则会持续等待上游完整返回…`;
        try {
          const create = await api.fetchApi('/nanfeng/v15/h3/storyboard/jobs', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              idea: submittedIdea + (participationPlan ? participationBrief(participationPlan) : ''),
              segment_count: submittedCount,
              mode: submittedMode,
              skill_id: skillSelect?.value || 'regular_storyboard',
              images,
              videos,
              audios,
              duration_seconds: requestedDuration,
              ...{},
              ...(['oneshot_continuation', 'continuation_cuts'].includes(mode.value) && widget(node, "context_length")?.value != null ? {
                context_length: Number(widget(node, "context_length").value)
              } : {})
            })
          });
          const created = await readJsonResponse(create);
          if (!create.ok || !created.ok) throw new Error(created.error || `HTTP ${create.status}`);
          activeJobId = created.job_id;
          const data = await pollStoryboardJob(activeJobId);
          activeJobId = null;
          if (cancelRequested || !dialogOwner() || !overlay.isConnected) return;
          captureStoryboard();
          const global = String(data.global || '').trim(),
            segments = data.segments || [];
          if (!segments.length) throw new Error('语言模型没有返回分镜');
          const currentAssets = submittedDraft.assets;
          const compose = segment => [global ? `全局提示词：\n${global}` : '', segment].filter(Boolean).join('\n\n');
          const firstGeneratedIndex = shots.length;
          const continuationGroupId = ['oneshot_continuation', 'continuation_cuts'].includes(submittedMode) ? globalThis.crypto?.randomUUID?.() || `chain-${Date.now()}` : null;
          const routedSegments = participationPlan ? routeParticipatingSegments(participationPlan, global, segments) : null;
          for (const [segmentIndex, segment] of segments.entries()) shots.push({
            ...{},
            continuationGroupId,
            prompt: routedSegments ? routedSegments[segmentIndex].prompt : compose(segment),
            smartIdea: submittedIdea,
            图片: routedSegments ? [...routedSegments[segmentIndex].images] : [...currentAssets.图片],
            视频: [...currentAssets.视频],
            音频: [...currentAssets.音频],
            durationSeconds: requestedDuration
          });
          persistStoryboards();
          applyStoryboard(firstGeneratedIndex, true);
          closeAndRestore();
        } catch (error) {
          activeJobId = null;
          status.textContent = `生成失败：${error.message}`;
          status.style.color = '#ff9f9f';
          run.disabled = false;
        }
      } catch (error) {
        status.style.color = '#ff9f9f';
        status.textContent = `提交前失败：${error?.message || String(error)}`;
        run.disabled = false;
        console.error('[南风V15 智能分镜] 提交前失败', error);
      }
    };
  }
  // 每个结构块都从新行开始，避免标签粘在用户现有句子后面；光标停在新内容末尾继续填写。
  function insertPromptBlock(text) {
    const start = prompt.selectionStart ?? prompt.value.length,
      end = prompt.selectionEnd ?? start,
      before = prompt.value.slice(0, start),
      prefix = before && !before.endsWith("\n") ? "\n" : "";
    prompt.setRangeText(prefix + text, start, end, "end");
    commitPrompt();
  }
  const coreTemplate = "integrated_multimodal_description:\n\noverall_soundscape:\n\nnon_diegetic_music:\nN/A";
  function firstFrameInstruction() {
    return "For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.";
  }
  function firstLastInstruction() {
    const seconds = Number(widget(node, "时长秒")?.value || 5).toFixed(2);
    return `How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot 1) aligns with the ${seconds}-second mark of the target video.`;
  }
  function sharedBaseHelp(modeLabel, extra) {
    return `<div class="focus"><strong>${modeLabel}主要内容写在哪里？</strong> 人物、场景、动作、表情、运镜、镜头时间、对白和画面内声音，都写在<strong>「正文」</strong>的 <code>integrated_multimodal_description:</code> 下面。<br><code>[Shot 1] Live-action, cinematic, the subject turns toward the camera as the camera slowly pushes in.</code></div>${extra}<div class="warning"><strong>不让角色读出提示词：</strong>写在「正文」下面：<br><code>No dialogue, narration, voiceover, or singing. The subject keeps their mouth closed throughout.</code><br><code>non_diegetic_music: N/A</code> 只表示无背景配乐，不代表禁止说话。</div>`;
  }
  const refHelp = `<div class="focus"><strong>主要内容写在哪里？</strong> 人物动作、表情、运镜、镜头时间、对白和画面声音，主要由<strong>「分镜」</strong>控制。<br><code>detailed_description: [Shot 1] &lt;Subject 1&gt; turns toward the camera and says, &lt;d&gt;[Chinese] 你好！&lt;/d&gt;</code></div><div class="warning"><strong>不让角色读出提示词：</strong>写在「分镜」下面：<br><code>No dialogue, narration, voiceover, or singing. &lt;Subject 1&gt; keeps their mouth closed throughout.</code><br><code>non_diegetic_music: N/A</code> 只表示无背景配乐，不代表禁止说话。</div><dl><dt>模板</dt><dd>一次插入Ref2VA完整六段结构；只建骨架，不自动写内容。</dd><dt>定义</dt><dd>定义主体和来源。例：<code>&lt;Subject 1&gt; is the visual content referenced from &lt;Picture 1&gt;.</code></dd><dt>摘要</dt><dd>概括任务类型、目标视频和主要引用关系。</dd><dt>保留</dt><dd><code>fully_preserved</code>完整保留；<code>partially_preserved</code>部分保留；<code>attribute_transfer</code>属性迁移；<code>weak_reference</code>弱参考。</dd><dt>分镜</dt><dd>核心正文：按播放顺序写构图、位置、动作、灯光、运镜、声音和对白。</dd><dt>声景</dt><dd>全片环境声、动作声及非语言人声；对白仍写在分镜。</dd><dt>配乐</dt><dd>只有观众能听到的背景配乐；<code>N/A</code>表示无背景配乐。</dd></dl>`;
  function baseHelp(mode) {
    if (mode === "文生视频") return sharedBaseHelp("文生视频", `<div class="warning"><strong>文生规则：</strong>没有图片对齐指令，直接从「正文」开始完整描述开场、主体、场景和时间线。</div>`) + `<dl><dt>模板</dt><dd>插入文生三段官方骨架。</dd><dt>正文</dt><dd>从文字建立完整视听时间线。例：<code>[Shot 1] A woman enters a quiet café as the camera tracks left.</code></dd><dt>声景</dt><dd>环境声、动作声和非语言人声。</dd><dt>配乐</dt><dd>观众可听、角色听不到的背景音乐；默认<code>N/A</code>。</dd></dl>`;
    if (mode === "图生视频") return sharedBaseHelp("图生视频", `<div class="warning"><strong>首帧规则：</strong><code>&lt;Picture 1&gt;</code>是0秒真实首帧。正文按“首帧状态 → 动作开始 → 连续发展 → 结果”写，并保持身份、服装、颜色和空间关系一致。</div>`) + `<dl><dt>模板</dt><dd>插入首帧固定对齐指令和三段骨架。</dd><dt>首帧</dt><dd>单独插入官方0秒首帧对齐指令。</dd><dt>正文</dt><dd>从首帧现状向后发展，不要只重复描述图片。</dd><dt>声景</dt><dd>环境声、动作声和非语言人声。</dd><dt>配乐</dt><dd>背景配乐；默认<code>N/A</code>。</dd></dl>`;
    return sharedBaseHelp("首尾帧", `<div class="warning"><strong>首尾规则：</strong><code>Picture 1</code>是0秒首帧，<code>Picture 2</code>是视频结束尾帧。优先单镜头，正文写清“首帧状态 → 中间变化 → 差异逐步缩小 → 准确落到尾帧”。对齐按钮按当前时长自动写结束秒数。</div>`) + `<dl><dt>模板</dt><dd>按当前时长插入首尾帧对齐指令和三段骨架。</dd><dt>对齐</dt><dd>单独插入首图0秒、尾图结束时刻的官方对齐指令。</dd><dt>正文</dt><dd>描述两帧之间连续的动作、姿势、物体、构图和光线变化。</dd><dt>声景</dt><dd>环境声、动作声和非语言人声。</dd><dt>配乐</dt><dd>背景配乐；默认<code>N/A</code>。</dd></dl>`;
  }
  function renderPromptTools(mode) {
    promptTools.replaceChildren();
    const title = document.createElement("span");
    title.className = "nfh15-prompt-tools-title";
    title.textContent = mode ? `${mode}结构` : "多参结构";
    promptTools.append(title);
    let smart = null;
    if (isV81(node)) {
      smart = document.createElement("button");
      smart.type = "button";
      smart.className = "nfh15-smart-storyboard";
      smart.textContent = "✦ 智能分镜＆提示词";
      smart.onclick = openSmartStoryboard;
    }
    let specs, helpHtml;
    if (!mode) {
      const full = "subject_definitions:\n\nsummary:\n\nretention_analysis:\n\ndetailed_description:\n\noverall_soundscape:\n\nnon_diegetic_music:\nN/A";
      specs = [["模板", () => full, "template"], ["定义", () => "subject_definitions:\n", ""], ["摘要", () => "summary:\n", ""], ["保留", () => "retention_analysis:\n", ""], ["分镜", () => "detailed_description:\n", ""], ["声景", () => "overall_soundscape:\n", ""], ["配乐", () => "non_diegetic_music:\nN/A", ""]];
      helpHtml = refHelp;
    } else if (mode === "文生视频") {
      specs = [["模板", () => coreTemplate, "template"], ["正文", () => "integrated_multimodal_description:\n", ""], ["声景", () => "overall_soundscape:\n", ""], ["配乐", () => "non_diegetic_music:\nN/A", ""]];
      helpHtml = baseHelp(mode);
    } else if (mode === "图生视频") {
      specs = [["模板", () => `${firstFrameInstruction()}\n\n${coreTemplate}`, "template"], ["首帧", firstFrameInstruction, ""], ["正文", () => "integrated_multimodal_description:\n", ""], ["声景", () => "overall_soundscape:\n", ""], ["配乐", () => "non_diegetic_music:\nN/A", ""]];
      helpHtml = baseHelp(mode);
    } else {
      specs = [["模板", () => `${firstLastInstruction()}\n\n${coreTemplate}`, "template"], ["对齐", firstLastInstruction, ""], ["正文", () => "integrated_multimodal_description:\n", ""], ["声景", () => "overall_soundscape:\n", ""], ["配乐", () => "non_diegetic_music:\nN/A", ""]];
      helpHtml = baseHelp(mode);
    }
    for (const [label, getText, kind] of specs) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = `nfh15-prompt-tool${kind ? ` ${kind}` : ""}`;
      b.textContent = label;
      b.onclick = () => insertPromptBlock(getText());
      promptTools.append(b);
    }
    const help = document.createElement("div");
    help.className = "nfh15-prompt-help";
    help.innerHTML = helpHtml;
    const hb = document.createElement("button");
    hb.type = "button";
    hb.className = "nfh15-prompt-tool help";
    hb.textContent = "说明";
    hb.onclick = () => help.classList.toggle("open");
    promptTools.append(hb);
    if (smart) promptTools.append(smart);
    promptTools.append(help);
  }
  renderPromptTools("");
  function mentionItems() {
    const out = [];
    for (const k of Object.keys(LIMITS)) {
      valuesFor(node, k).forEach((v, i) => out.push({
        alias: `@${k}${i + 1}`,
        kind: k,
        file: v
      }));
    }
    return out;
  }
  function closeMentions() {
    menu.style.display = "none";
    menu.replaceChildren();
    mentionButtons = [];
    mentionIndex = 0;
  }
  function nativeMention(it) {
    const n = it.alias.match(/\d+$/)?.[0] || "1";
    if (it.kind === "图片") return `<Picture ${n}>`;
    if (it.kind === "视频") return `<Video ${n}>`;
    return `<Audio ${n}>`;
  }
  function insertMention(it) {
    const start = prompt.selectionStart,
      end = prompt.selectionEnd,
      before = prompt.value.slice(0, start),
      at = before.lastIndexOf("@");
    let from = at >= 0 ? at : start;
    const mode = ["文生视频", "图生视频", "首尾帧"].find(x => !!widget(node, x)?.value) || "";
    let value = nativeMention(it);
    // 多参图片统一一一绑定：@选择图片N，直接写入完整的 Subject N ↔ Picture N 定义。
    if (!mode && it.kind === "图片") {
      const n = it.alias.match(/\d+$/)?.[0] || "1";
      value = `<Subject ${n}> is the visual content referenced from <Picture ${n}>`;
    }
    prompt.setRangeText(value, from, end, "end");
    commitPrompt();
    closeMentions();
  }
  function selectMention(index) {
    if (!mentionButtons.length) return;
    mentionIndex = (index + mentionButtons.length) % mentionButtons.length;
    mentionButtons.forEach((b, i) => b.classList.toggle("active", i === mentionIndex));
    mentionButtons[mentionIndex].scrollIntoView({
      block: "nearest"
    });
  }
  function openMentions() {
    const mode = ["文生视频", "图生视频", "首尾帧"].find(x => !!widget(node, x)?.value) || "";
    if (mode) {
      closeMentions();
      return;
    }
    const items = mentionItems();
    menu.replaceChildren();
    mentionButtons = [];
    if (!items.length) {
      const b = document.createElement("button");
      b.className = "nfh15-mention";
      b.textContent = "请先在下方添加图片、视频或音频";
      menu.append(b);
    }
    for (const it of items) {
      const b = document.createElement("button");
      b.className = "nfh15-mention";
      b.__mentionItem = it;
      b.dataset.native = nativeMention(it);
      if (it.kind === "图片") {
        const im = document.createElement("img");
        im.src = mediaUrl(it.file);
        b.append(im);
      } else {
        const ic = document.createElement("span");
        ic.className = "nfh15-mention-icon";
        ic.textContent = it.kind === "视频" ? "▶" : "♫";
        b.append(ic);
      }
      const t = document.createElement("span");
      if (it.kind === "图片") {
        const n = it.alias.match(/\d+$/)?.[0] || "1";
        t.textContent = `<Subject ${n}> is the visual content referenced from <Picture ${n}> · ${it.file.split("/").pop()}`;
      } else t.textContent = `${b.dataset.native} · ${it.file.split("/").pop()}`;
      b.append(t);
      b.onmouseenter = () => selectMention(mentionButtons.indexOf(b));
      b.onmousedown = e => {
        e.preventDefault();
        insertMention(it);
      };
      menu.append(b);
      mentionButtons.push(b);
    }
    menu.style.display = "block";
    selectMention(0);
  }
  prompt.oninput = () => {
    setWidget(node, "提示词", prompt.value);
    captureStoryboard();
    const mode = ["文生视频", "图生视频", "首尾帧"].find(x => !!widget(node, x)?.value) || "",
      before = prompt.value.slice(0, prompt.selectionStart);
    if (!mode && /@[^\s@]*$/.test(before)) openMentions();else closeMentions();
  };
  prompt.onkeydown = e => {
    if (menu.style.display !== "none" && mentionButtons.length) {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        selectMention(mentionIndex + 1);
        return;
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        selectMention(mentionIndex - 1);
        return;
      }
      if (e.key === "Enter") {
        e.preventDefault();
        insertMention(mentionButtons[mentionIndex].__mentionItem);
        return;
      }
    }
    if (e.key === "Escape") closeMentions();
  };
  prompt.onblur = () => setTimeout(closeMentions, 120);
  const tabs = document.createElement("div");
  tabs.className = "nfh15-tabs";
  root.append(tabs);
  const drop = document.createElement("div");
  drop.className = "nfh15-drop";
  root.append(drop);
  const grid = document.createElement("div");
  grid.className = "nfh15-grid";
  root.append(grid);
  const note = document.createElement("div");
  note.className = "nfh15-note";
  note.textContent = "拖动素材卡可交换编号；拖动仅在本节点内生效，不会创建外部图片节点。";
  root.append(note);
  const ag = document.createElement("div");
  ag.className = "nfh15-settings";
  const visibleAdvanced = isV9(node) ? ADVANCED_FIELDS.filter(x => !["SageAttention", "采样器", "调度器"].includes(x[0])) : isV81(node) ? ADVANCED_FIELDS.filter(x => !["SageAttention", "采样器", "调度器", "启用H3 SLA"].includes(x[0])) : isV7(node) ? ADVANCED_FIELDS.filter(x => !["SageAttention", "允许编译", "采样器", "调度器", "启用H3 SLA"].includes(x[0])) : ADVANCED_FIELDS.filter(x => x[0] !== "启用H3 SLA");
  for (const field of visibleAdvanced) ag.append(makeControl(node, field));
  let slaDetails = null;
  if (isV9(node)) {
    const slaGrid = document.createElement("div");
    slaGrid.className = "nfh15-settings";
    const slaFields = [["SLA稀疏率", "稀疏率", "number"], ["SLA块大小", "块大小", "select"], ["SLA最短序列", "最短序列", "number"], ["SLA末尾稠密步数", "末尾稠密步数", "number"], ["SLA保护音频", "保护音频", "boolean"], ["SLA指定稠密步", "指定稠密步", "text"], ["SLA稠密后端", "稠密后端", "select"], ["SLA关闭FP16累加", "关闭FP16累加", "boolean"], ["SLA稳定运动", "稳定运动", "boolean"]];
    const slaReady = slaFields.every(([name]) => !!widget(node, name));
    if (slaReady) slaFields.forEach(x => slaGrid.append(makeControl(node, x)));
    const slaNote = document.createElement("div");
    slaNote.className = "nfh15-note";
    slaNote.textContent = slaReady ? "开启SLA时自动关闭上方通用Sage与H3专用Sage；关闭时完全旁路。" : "SLA字段尚未加载，请重启ComfyUI。";
    slaGrid.append(slaNote);
    slaDetails = document.createElement("details");
    slaDetails.className = "nfh15-advanced nfh15-primary-fold";
    slaDetails.innerHTML = "<summary>H3 SLA 稀疏注意力</summary>";
    slaDetails.append(slaGrid);
  }
  let reserveDetails = null;
  if (isV7(node)) {
    const reserveGrid = document.createElement("div");
    reserveGrid.className = "nfh15-settings";
    const reserveToggle = makeControl(node, ["启用运行时预留显存", "开启预留显存", "boolean"]);
    const reserveSlider = makeControl(node, ["运行时预留显存GB", "预留显存（GB）", "number"]);
    const reserveNote = document.createElement("div");
    reserveNote.className = "nfh15-note";
    reserveNote.textContent = "这里填写真实GiB数：会减少ComfyUI/AIMDO可使用的显存预算，不是增加显存。数值越高通常越省GPU显存、但更慢；8GB显卡应配合UniBlockSwap低常驻块与较低分辨率。";
    reserveGrid.append(reserveToggle, reserveSlider, reserveNote);
    reserveDetails = document.createElement("details");
    reserveDetails.className = "nfh15-advanced nfh15-primary-fold";
    reserveDetails.innerHTML = "<summary>预留显存</summary>";
    reserveDetails.append(reserveGrid);
  }
  let audioLockDetails = null;
  if (isV9(node)) {
    const audioLockGrid = document.createElement("div");
    audioLockGrid.className = "nfh15-settings";
    const audioLockReady = !!widget(node, "启用锁音频");
    if (audioLockReady) audioLockGrid.append(makeControl(node, ["启用锁音频", "开启锁音频", "boolean"]));
    const audioDriveToggle = makeControl(node, ["开启音频驱动模式", "开启音频驱动模式", "boolean"]);
    audioLockGrid.append(audioDriveToggle);
    const audioDriveAction = document.createElement("button");
    audioDriveAction.type = "button";
    audioDriveAction.className = "nfh15-audio-drive-action";
    audioDriveAction.textContent = "智能音频驱动";
    const updateAudioDrive = () => {
      const audioDriveEnabled = !!widget(node, "开启音频驱动模式")?.value;
      audioDriveAction.disabled = !audioDriveEnabled;
      audioDriveAction.classList.toggle("enabled", audioDriveEnabled);
      const regularMedia = node.__nfh3MediaSection;
      if (regularMedia) regularMedia.hidden = audioDriveEnabled;
    };
    audioDriveAction.onclick = () => openAudioDriveUI(node);
    audioLockGrid.append(audioDriveAction);
    const audioLockNote = document.createElement("div");
    audioLockNote.className = "nfh15-note";
    audioLockNote.textContent = "开启锁音频后：普通模式锁定音频1；智能音频驱动锁定当前分镜对应的专属音频区间，两者共用NativeAudioLock并直接输出源音频。";
    audioLockNote.title = "普通分镜使用音频1从0秒裁切；智能音频驱动分镜使用其专属上传音频和该分镜起止时间裁切。音频流使用零降噪遮罩，最终返回该段源音频。";
    audioLockGrid.append(audioLockNote);
    audioLockDetails = document.createElement("details");
    audioLockDetails.className = "nfh15-advanced nfh15-primary-fold nfh15-audio-drive-fold";
    audioLockDetails.innerHTML = "<summary><span style=\"position:relative\">数字人·MV·锁音频<span data-audio-favorite style=\"position:absolute;left:calc(100% + 12px);top:50%;transform:translateY(-50%) rotate(-4deg);display:inline-block;white-space:nowrap;font:700 12px KaiTi,STKaiti,serif!important;line-height:18px!important;letter-spacing:2px;padding:1px 6px 1px 8px;border:1px solid var(--mh-red,#2ab9ae)!important;background:var(--mh-red,#18776d)!important;background-image:none!important;color:#fff4df!important;-webkit-text-fill-color:#fff4df!important;border-radius:1px;pointer-events:none\">常用</span></span></summary>";
    audioLockDetails.append(audioLockGrid);
    node.__nfh3UpdateAudioDrive = updateAudioDrive;
    const audioDriveWidget = widget(node, "开启音频驱动模式");
    if (audioDriveWidget) {
      const previous = audioDriveWidget.callback;
      audioDriveWidget.callback = function (value) {
        previous?.call(this, value);
        updateAudioDrive();
      };
    }
    queueMicrotask(updateAudioDrive);
  }
  let blockSwapDetails = null,
    latentUpscaleDetails = null,
    referenceSizeDetails = null,
    rtxVsrDetails = null;
  if (isV8(node)) {
    const bg = document.createElement("div");
    bg.className = "nfh15-settings";
    bg.append(makeControl(node, ["启用UniBlockSwap", "开启UniBlockSwap", "boolean"]), makeControl(node, ["UniBlockSwap常驻块数", "GPU常驻块数", "number"]));
    const blockSwapNote = document.createElement("div");
    blockSwapNote.className = "nfh15-note";
    blockSwapNote.textContent = "数字越小越省显存，但速度越慢；数字越大速度通常越快，但占用更多显存。";
    bg.append(blockSwapNote);
    blockSwapDetails = document.createElement("details");
    blockSwapDetails.className = "nfh15-advanced nfh15-primary-fold";
    blockSwapDetails.innerHTML = "<summary>UniBlockSwap 模型分块换入</summary>";
    blockSwapDetails.append(bg);
    const ug = document.createElement("div");
    ug.className = "nfh15-settings";
    const latentControls = {};
    const v81Controls = isV81(node) ? [["采样器", "一采/二采共用采样器", "select"], ["调度器", "一采/二采共用调度器", "select"], ["H3一采步数", "V8.1 一采步数（开启二采时）", "number"], ["H3二采步数", "V8.1 二采步数（放大后）", "number"], ["V81一采使用手动Sigma", "一采使用手动Sigma序列", "boolean"], ["H3完整Sigma序列", "V8.1完整Sigma序列（留空自动）", "text"]] : [];
    let completeSigmaControl = null;
    v81Controls.forEach(x => {
      const control = makeControl(node, x);
      ug.append(control);
      if (x[0] === "采样器") {
        const nf = document.createElement('div');
        nf.style.cssText = 'grid-column:1/-1;border:1px solid #244944;padding:10px;';
        const title = document.createElement('div');
        title.textContent = '南风采样器 · 原生ER-SDE精调（一采/二采共用）';
        nf.append(title);
        for (const f of [['南风ER_solver_type', '求解方式 solver_type', 'select'], ['南风ER_max_stage', '修正阶数 max_stage', 'number'], ['南风ER_eta', '随机强度 eta', 'number'], ['南风ER_s_noise', '噪声幅度 s_noise', 'number']]) nf.append(makeControl(node, f));
        const note = document.createElement('div');
        note.className = 'nfh15-note';
        note.textContent = '默认 ER-SDE / 3 / 1 / 1 对应普通er_sde。不是步数或Sigma；eta=0转ODE。数值越大不代表质量越高，不影响独立音频精修。';
        nf.append(note);
        ug.append(nf);
        const sync = () => {
          nf.style.display = widget(node, '采样器')?.value === '南风采样器' ? 'block' : 'none';
        };
        const w = widget(node, '采样器');
        if (w) {
          const old = w.callback;
          w.callback = function () {
            const r = old?.apply(this, arguments);
            sync();
            return r;
          };
        }
        const old = node.onConfigure;
        node.onConfigure = function () {
          const r = old?.apply(this, arguments);
          sync();
          return r;
        };
        sync();
      }
      if (x[0] === "H3完整Sigma序列") completeSigmaControl = control;
    });
    if (isV9(node) && completeSigmaControl) {
      const NANFENG_10_STEP_SIGMA = "1, 0.988235, 0.972973, 0.952381, 0.923077, 0.878049, 0.8, 0.631579, 0.42, 0.18, 0";
      const builtInSigmaPresets = {
        "南风10步": NANFENG_10_STEP_SIGMA
      };
      const SIGMA_PRESET_STORAGE_KEY = "nanfeng_h3_v15_sigma_presets_v1";
      const readStoredSigmaState = () => ({});
      const storedSigmaState = readStoredSigmaState(),
        storedSigmaPresets = storedSigmaState.presets && typeof storedSigmaState.presets === "object" && !Array.isArray(storedSigmaState.presets) ? storedSigmaState.presets : {};
      node.properties ||= {};
      const nodeSigmaPresets = node.properties.nfh3_sigma_presets && typeof node.properties.nfh3_sigma_presets === "object" && !Array.isArray(node.properties.nfh3_sigma_presets) ? node.properties.nfh3_sigma_presets : {};
      const customSigmaPresets = {
        ...nodeSigmaPresets
      };
      const sigmaPresetManager = document.createElement("div");
      sigmaPresetManager.className = "nfh15-sigma-preset-manager";
      const sigmaPresetSelect = document.createElement("select");
      sigmaPresetSelect.title = "Sigma预设";
      const sigmaPresetSave = document.createElement("button");
      sigmaPresetSave.type = "button";
      sigmaPresetSave.textContent = "保存";
      const sigmaPresetNew = document.createElement("button");
      sigmaPresetNew.type = "button";
      sigmaPresetNew.textContent = "新建";
      const sigmaPresetDelete = document.createElement("button");
      sigmaPresetDelete.type = "button";
      sigmaPresetDelete.textContent = "删除";
      const completeSigmaInput = completeSigmaControl.querySelector('[data-widget-name="H3完整Sigma序列"]');
      const currentSigmaText = () => String(widget(node, "H3完整Sigma序列")?.value ?? "").trim();
      if (completeSigmaInput) completeSigmaInput.oninput = () => {
        setWidget(node, "H3完整Sigma序列", completeSigmaInput.value);
        renderSigmaPresets(node.properties.nfh3_selected_sigma_preset);
      };
      const allSigmaPresets = () => ({
        ...builtInSigmaPresets,
        ...customSigmaPresets
      });
      const renderSigmaPresets = selected => {
        const presets = allSigmaPresets(),
          text = currentSigmaText(),
          normalize = x => String(x ?? "").replace(/\s+/g, "");
        sigmaPresetSelect.replaceChildren();
        const custom = document.createElement("option");
        custom.value = "";
        custom.textContent = "当前工作流 · 自定义/未匹配";
        sigmaPresetSelect.append(custom);
        for (const name of Object.keys(presets)) {
          const option = document.createElement("option");
          option.value = name;
          option.textContent = name;
          sigmaPresetSelect.append(option);
        }
        const match = selected && Object.prototype.hasOwnProperty.call(presets, selected) && normalize(presets[selected]) === normalize(text) ? selected : Object.keys(presets).find(k => text && normalize(presets[k]) === normalize(text));
        sigmaPresetSelect.value = match || "";
        node.properties.nfh3_selected_sigma_preset = match || "";
        sigmaPresetDelete.disabled = !Object.prototype.hasOwnProperty.call(customSigmaPresets, sigmaPresetSelect.value);
        sigmaPresetSave.disabled = !sigmaPresetSelect.value || Object.prototype.hasOwnProperty.call(builtInSigmaPresets, sigmaPresetSelect.value);
      };
      const persistSigmaPresets = () => {
        node.properties.nfh3_sigma_presets = {
          ...customSigmaPresets
        };
        const selected_sigma_preset = String(node.properties.nfh3_selected_sigma_preset || sigmaPresetSelect.value || "");
        node.graph?.change?.();
        node.setDirtyCanvas?.(true, true);
      };
      const applySigmaPreset = name => {
        const value = allSigmaPresets()[name];
        if (value == null) return;
        node.properties.nfh3_selected_sigma_preset = name;
        setWidget(node, "H3完整Sigma序列", value);
        if (name === "南风10步") {
          setWidget(node, "H3一采步数", 6);
          setWidget(node, "H3二采步数", 4);
        }
        sync(node, root);
        if (completeSigmaInput) completeSigmaInput.value = value;
        persistSigmaPresets();
        renderSigmaPresets(name);
      };
      sigmaPresetSelect.onchange = () => applySigmaPreset(sigmaPresetSelect.value);
      sigmaPresetSave.onclick = () => {
        const name = sigmaPresetSelect.value,
          value = currentSigmaText();
        if (!name) {
          alert("请点新建，为当前序列命名。");
          return;
        }
        if (!value) {
          alert("完整Sigma序列不能为空。 ");
          return;
        }
        if (Object.prototype.hasOwnProperty.call(builtInSigmaPresets, name)) {
          alert("内置预设不能覆盖，请点击新建另存。 ");
          return;
        }
        customSigmaPresets[name] = value;
        setWidget(node, "H3完整Sigma序列", value);
        persistSigmaPresets();
        renderSigmaPresets(name);
      };
      sigmaPresetNew.onclick = () => {
        const value = currentSigmaText();
        if (!value) {
          alert("请先在完整Sigma序列中填写内容。 ");
          return;
        }
        const requested = window.prompt("新预设名称", `Sigma预设${Object.keys(customSigmaPresets).length + 1}`),
          name = String(requested || "").trim();
        if (!name) return;
        if (builtInSigmaPresets[name]) {
          alert("内置预设不能覆盖。 ");
          return;
        }
        customSigmaPresets[name] = value;
        node.properties.nfh3_selected_sigma_preset = name;
        setWidget(node, "H3完整Sigma序列", value);
        persistSigmaPresets();
        renderSigmaPresets(name);
      };
      sigmaPresetDelete.onclick = () => {
        const name = sigmaPresetSelect.value;
        if (!Object.prototype.hasOwnProperty.call(customSigmaPresets, name)) return;
        if (!confirm(`删除Sigma预设“${name}”？`)) return;
        delete customSigmaPresets[name];
        node.properties.nfh3_selected_sigma_preset = "";
        persistSigmaPresets();
        renderSigmaPresets("");
      };
      const previousSigmaConfigure = node.onConfigure;
      node.onConfigure = function () {
        const r = previousSigmaConfigure?.apply(this, arguments);
        for (const key of Object.keys(customSigmaPresets)) delete customSigmaPresets[key];
        Object.assign(customSigmaPresets, node.properties?.nfh3_sigma_presets || {});
        if (completeSigmaInput) completeSigmaInput.value = String(widget(node, "H3完整Sigma序列")?.value ?? "");
        renderSigmaPresets(node.properties?.nfh3_selected_sigma_preset);
        return r;
      };
      if (completeSigmaInput) completeSigmaInput.value = String(widget(node, "H3完整Sigma序列")?.value ?? "");
      renderSigmaPresets(node.properties.nfh3_selected_sigma_preset);
      sigmaPresetManager.append(sigmaPresetSelect, sigmaPresetSave, sigmaPresetNew, sigmaPresetDelete);
      completeSigmaControl.append(sigmaPresetManager);
    }
    const latentFields = [["启用H3潜空间放大二采", "开启潜空间放大二采", "boolean"], ["H3潜空间放大模型", "潜空间放大模型", "select"], ["H3潜空间目标百万像素", "目标百万像素（内部）", "number"], ["H3潜空间对齐", isV81(node) ? "二采Latent网格对齐" : "Latent网格对齐（内部）", "select"], ["H3潜空间精度", "放大精度", "select"]];
    if (!isV81(node)) latentFields.push(["H3二采LoRA模式", "二采LoRA模式", "select"], ["H3二采LoRA", "二采独立LoRA", "select"], ["H3二采LoRA强度", "二采LoRA强度", "number"], ["H3二采Sigma", "二采Sigma手动序列", "text"]);
    latentFields.forEach(x => {
      const el = makeControl(node, x);
      latentControls[x[0]] = el;
      ug.append(el);
    });
    const sizePreset = document.createElement("div");
    sizePreset.className = "nfh15-field";
    sizePreset.innerHTML = '<label>二采目标尺寸</label>';
    const sizeSelect = document.createElement("select");
    for (const value of choices(widget(node, "百万像素"))) {
      const option = document.createElement("option");
      option.value = String(value);
      sizeSelect.append(option);
    }
    sizePreset.append(sizeSelect);
    ug.insertBefore(sizePreset, latentControls["H3潜空间目标百万像素"]);
    const finalSize = document.createElement("div");
    finalSize.className = "nfh15-note";
    const updateFinalSize = () => {
      for (const option of sizeSelect.options) option.textContent = latentFinalSize(node, Number(option.value));
      finalSize.textContent = `最终二采尺寸：${latentFinalSize(node, Number(widget(node, "H3潜空间目标百万像素")?.value || 1))}`;
    };
    const syncLatentUi = () => {
      latentControls["H3潜空间目标百万像素"].style.display = "none";
      const enabled = !!widget(node, "启用H3潜空间放大二采")?.value,
        mainSteps = root.querySelector('[data-control-name="采样步数"]');
      if (mainSteps) mainSteps.style.display = isV81(node) && enabled ? "none" : "";
      const mp = Number(widget(node, "H3潜空间目标百万像素")?.value || 1);
      const exact = [...sizeSelect.options].find(x => Math.abs(Number(x.value) - mp) < 0.0001);
      sizeSelect.value = exact?.value || String(mp);
      updateFinalSize();
      node.__nfh3Resolution?.();
    };
    sizeSelect.onchange = () => {
      setWidget(node, "H3潜空间目标百万像素", Number(sizeSelect.value));
      syncLatentUi();
    };
    node.__nfh3UpdateLatentUi = syncLatentUi;
    syncLatentUi();
    ug.append(finalSize);
    latentUpscaleDetails = document.createElement("details");
    latentUpscaleDetails.className = "nfh15-advanced nfh15-primary-fold";
    latentUpscaleDetails.innerHTML = "<summary>H3 潜空间放大二采</summary>";
    latentUpscaleDetails.append(ug);
    if (isV81(node)) {
      const rg = document.createElement("div");
      rg.className = "nfh15-settings";
      rg.append(makeControl(node, ["参考图最长边", "最长边", "select"]));
      const note = document.createElement("div");
      note.className = "nfh15-note";
      note.textContent = "只缩小超过限制的参考图，不放大小图。1280快速、1536均衡、1920标准、2560高细节、3072超高细节、3840接近官方max上限；档位越高参考Token越多，生成会更慢并增加显存占用。";
      rg.append(note);
      referenceSizeDetails = document.createElement("details");
      referenceSizeDetails.className = "nfh15-advanced nfh15-primary-fold";
      referenceSizeDetails.innerHTML = "<summary>参考图尺寸限制</summary>";
      referenceSizeDetails.append(rg);
    }
    if (isV9(node)) {
      const rtxGrid = document.createElement("div");
      rtxGrid.className = "nfh15-settings";
      const rtxFields = [["启用RTX视频超分", "开启RTX Video Super Resolution", "boolean"], ["RTX缩放方式", "缩放方式", "select"], ["RTX缩放倍数", "缩放倍数", "number"], ["RTX目标宽度", "目标宽度", "number"], ["RTX目标高度", "目标高度", "number"], ["RTX质量", "质量", "select"]];
      const rtxReady = rtxFields.every(([name]) => !!widget(node, name));
      if (rtxReady) rtxFields.forEach(x => rtxGrid.append(makeControl(node, x)));
      const rtxNote = document.createElement("div");
      rtxNote.className = "nfh15-note";
      rtxNote.textContent = rtxReady ? "开启后在H3最终VAE解码之后调用RTX Video Super Resolution；关闭时完全旁路，不改变原输出。倍数缩放与目标尺寸二选一。" : "RTX参数尚未由当前ComfyUI后端注册。请在队列空闲时正常重启ComfyUI，再刷新页面；仅刷新网页无法加载新增Python字段。";
      rtxGrid.append(rtxNote);
      rtxVsrDetails = document.createElement("details");
      rtxVsrDetails.className = "nfh15-advanced nfh15-primary-fold";
      rtxVsrDetails.innerHTML = "<summary>RTX 视频超分</summary>";
      rtxVsrDetails.append(rtxGrid);
    }
  }
  const samplingScopeNote = document.createElement("div");
  samplingScopeNote.className = "nfh15-note";
  samplingScopeNote.textContent = isV81(node) ? "这里的设置控制主生成和放大后二采。" : "这里的设置控制主生成。人脸修复和二采会按各自设置执行。";
  const advancedChildren = [ag, samplingScopeNote];
  let loraDetails = null,
    solDetails = null,
    t8Details = null,
    sigmaDetails = null,
    secondPassDetails = null;
  if (widget(node, "启用LoRA")) {
    const lg = isV9(node) ? buildDynamicLoraPanel(node) : document.createElement("div");
    if (!isV9(node)) {
      lg.className = "nfh15-settings nfh15-lora-settings";
      const legacyFields = [[LEGACY_LORA_MASTER_NAME, "启用 LoRA", "boolean"], ["LoRA1", "LoRA 1", "select"], ["LoRA1强度", "LoRA 1 强度", "number"], ["LoRA2", "LoRA 2", "select"], ["LoRA2强度", "LoRA 2 强度", "number"], ["LoRA3", "LoRA 3", "select"], ["LoRA3强度", "LoRA 3 强度", "number"]];
      legacyFields.forEach(x => lg.append(makeControl(node, x)));
    }
    loraDetails = document.createElement("details");
    loraDetails.className = "nfh15-advanced nfh15-primary-fold";
    loraDetails.innerHTML = "<summary>LoRA 模型叠加（多参 / 文生 / 图生 / 首尾共同生效）</summary>";
    loraDetails.append(lg);
    if (!isV7(node)) {
      const sg = document.createElement("div");
      sg.className = "nfh15-settings";
      V2_SOL_FIELDS.forEach(x => sg.append(makeControl(node, x)));
      solDetails = document.createElement("details");
      solDetails.className = "nfh15-advanced nfh15-primary-fold";
      solDetails.innerHTML = "<summary>Sol-Attn Blackwell 加速（RTX 5090可开启）</summary>";
      solDetails.append(sg);
    }
    if (!isV7(node) && !widget(node, "启用T8缓存")?.value) advancedChildren.push(...(solDetails ? [solDetails] : []));
  }
  if (widget(node, "启用T8缓存") && !isV7(node)) {
    const tg = document.createElement("div");
    tg.className = "nfh15-settings";
    V3_T8_FIELDS.forEach(x => tg.append(makeControl(node, x)));
    t8Details = document.createElement("details");
    t8Details.className = "nfh15-advanced nfh15-primary-fold";
    t8Details.innerHTML = "<summary>MiniMax H3 Block Cache T8（通用加速，可开启）</summary>";
    const t8Note = document.createElement("div");
    t8Note.className = "nfh15-note";
    t8Note.textContent = "T8可在通用显卡上开启；与Sol-Attn互斥，开启其中一个会自动关闭另一个。";
    t8Details.append(tg, t8Note);
  }
  if (widget(node, "启用西格玛调节")) {
    const sigmaBaseFields = isV5(node) ? V4_SIGMA_FIELDS.filter(x => !["启用双采样", "双采后段比例", "双采后段采样器"].includes(x[0])) : V4_SIGMA_FIELDS;
    const sigmaFields = isV7(node) ? [["采样器", "采样器（ComfyUI原生列表）", "select"], ["调度器", "调度器（ComfyUI原生列表）", "select"], ...sigmaBaseFields] : sigmaBaseFields;
    const sigmaGrid = document.createElement("div");
    sigmaGrid.className = "nfh15-settings";
    sigmaFields.forEach(x => sigmaGrid.append(makeControl(node, x)));
    const sigmaProfiles = document.createElement("div");
    sigmaProfiles.className = "nfh15-sigma-profiles";
    const profileRows = isV7(node) ? [["原生轨迹（不加步）", "原生轨迹（不加步）", "不加步；LoRA和生成模式都不会自动改动"], ["面板Sigma轨迹", "面板Sigma轨迹", "按下方低Sigma或手动序列参数执行；适合手动增加后段步数"], ["最终区间增加1步", "最终区间增加1步", "只在最后一个非零→0区间增加1个中点"]] : [["ref", "多参 Ref2VA", "0.8→0 · 每区间细分按面板参数"], ["fl", "I2V / T2V / 首尾帧", "最终高频区间固定增加1步"], ["lora", "LoRA（Sigma关闭）", "任意有效LoRA启用后自动使用原生轨迹"]];
    const profileEls = new Map();
    for (const [key, title, desc] of profileRows) {
      const row = document.createElement(isV7(node) ? "button" : "div");
      if (isV7(node)) row.type = "button";
      row.className = "nfh15-sigma-profile-option";
      row.innerHTML = `<span class="nfh15-sigma-check">✓</span><span><b>${title}</b><small>${desc}</small></span>`;
      if (isV7(node)) row.onclick = () => {
        setWidget(node, "Sigma策略", key);
        updateSigmaProfile();
      };
      sigmaProfiles.append(row);
      profileEls.set(key, row);
    }
    const sigmaProfile = document.createElement("div");
    sigmaProfile.className = "nfh15-mode-note";
    const updateSigmaProfile = () => {
      const master = !!widget(node, "启用西格玛调节")?.value;
      if (isV7(node)) {
        const active = String(widget(node, "Sigma策略")?.value || "原生轨迹（不加步）");
        for (const [key, row] of profileEls) row.classList.toggle("active", key === active);
        sigmaProfile.textContent = !master ? "Sigma总开关关闭：使用原生轨迹。开启总开关后仍只执行你手动选择的策略。" : `当前手动策略：${active}。不会根据LoRA、生成模式自动切换。`;
        return;
      }
      const loraOn = !!widget(node, "启用LoRA")?.value && [1, 2, 3].some(i => {
        const name = widget(node, `LoRA${i}`)?.value;
        return name && name !== "未选择" && Number(widget(node, `LoRA${i}强度`)?.value || 0) !== 0;
      });
      const fl = ["文生视频", "图生视频", "首尾帧"].find(x => !!widget(node, x)?.value);
      const active = loraOn ? "lora" : fl ? "fl" : "ref";
      for (const [key, row] of profileEls) row.classList.toggle("active", master && key === active);
      if (!master) {
        sigmaProfile.textContent = "Sigma总开关关闭：当前使用原生采样轨迹。";
      } else if (loraOn) {
        sigmaProfile.textContent = "已自动勾选：LoRA（Sigma关闭）。";
      } else if (fl) {
        sigmaProfile.textContent = "已自动勾选：I2V / T2V / 首尾帧，最终高频区间增加1步。";
      } else {
        sigmaProfile.textContent = "已自动勾选：多参 Ref2VA，使用面板中的低Sigma参数。";
      }
    };
    updateSigmaProfile();
    node.__nfh3UpdateSigmaProfile = updateSigmaProfile;
    const sigmaNote = document.createElement("div");
    sigmaNote.className = "nfh15-note";
    sigmaNote.textContent = isV7(node) ? "纯手动：先开启Sigma总开关，再选择且只执行上面一个策略。LoRA和生成模式不会替你切换。" : "以上三个策略由当前生成模式和LoRA状态自动互斥勾选，不需要手动选择。";
    sigmaDetails = document.createElement("details");
    sigmaDetails.className = "nfh15-advanced nfh15-primary-fold";
    sigmaDetails.innerHTML = "<summary>西格玛调节</summary>";
    sigmaDetails.append(sigmaGrid, sigmaProfiles, sigmaProfile, sigmaNote);
  }
  if (isV5(node) && !isV7(node)) {
    const secondGrid = document.createElement("div");
    secondGrid.className = "nfh15-settings";
    V5_SECOND_PASS_FIELDS.forEach(x => secondGrid.append(makeControl(node, x)));
    const secondNote = document.createElement("div");
    secondNote.className = "nfh15-note";
    const updateSecondPass = () => {
      const enabled = !!widget(node, "启用高清二采")?.value;
      const mainSteps = widget(node, "采样步数"),
        visibleMain = root.querySelector('[data-widget-name="采样步数"]');
      for (const el of [mainSteps?.element, visibleMain]) if (el) {
        el.disabled = enabled;
        el.style.opacity = enabled ? ".45" : "1";
      }
      const family = activeGenerationMode(node) ? "FL2VA" : "Ref2VA",
        selection = String(widget(node, "二采模型")?.value || "");
      const modelNote = selection.startsWith("跟随一采") ? "二采沿用一采模型，质量优先。" : selection.startsWith("自动轻量") ? `二采自动选择${family}轻量权重，速度/显存优先，需A/B确认量化劣化。` : `二采使用手动选择的${family}模型。`;
      secondNote.textContent = enabled ? `主控采样步数已停用：使用独立一采步数 + 二采步数。高清二采与西格玛调节互斥；二采用独立“二采起始Sigma”。${modelNote}文本编码器和一采Conditioning直接复用，不重复编码。流程：一采解码 → 放大 → 重编码 → 卸载一采 → 加载二采模型 → H3低强度二采。` : "关闭时仍使用基础参数里的主控采样步数，只有一次原生采样。";
    };
    secondPassDetails = document.createElement("details");
    secondPassDetails.className = "nfh15-advanced nfh15-primary-fold";
    secondPassDetails.innerHTML = "<summary>高清放大二采重绘</summary>";
    secondPassDetails.append(secondGrid, secondNote);
    node.__nfh3UpdateSecondPass = updateSecondPass;
    updateSecondPass();
  }
  // 主窗口模式：外层节点只承载原生图像/音频输出口；全部内容在固定窗口内折叠和滚动。
  node.properties ||= {};
  node.properties.nfh3_sections ||= {
    基础参数: true,
    提示词: true,
    参考素材: true,
    高级设置: false
  };
  function section(title, key, children) {
    const d = document.createElement("details");
    d.className = "nfh15-section";
    d.open = node.properties.nfh3_sections[key] !== false;
    const s = document.createElement("summary");
    s.textContent = title;
    const body = document.createElement("div");
    body.className = "nfh15-section-body";
    for (const child of children) body.append(child);
    d.append(s, body);
    d.ontoggle = () => {
      node.properties.nfh3_sections[key] = d.open;
      node.setDirtyCanvas?.(true, true);
    };
    return d;
  }
  function plainSection(title, children) {
    const d = document.createElement("section");
    d.className = "nfh15-section nfh15-section-static";
    const s = document.createElement("div");
    s.className = "nfh15-section-title";
    s.textContent = title;
    const body = document.createElement("div");
    body.className = "nfh15-section-body";
    for (const child of children) body.append(child);
    d.append(s, body);
    return d;
  }
  const baseChildren = [settings, res];
  node.__nfh3SyncExclusive = () => sync(node, root);
  if (loraDetails) baseChildren.push(loraDetails);
  if (!isV9(node)) baseChildren.push(promptTools);
  let v9Preview = null;
  if (isV9(node)) {
    v9Preview = document.createElement("div");
    v9Preview.className = "nfh15-v9-live-preview";
    v9Preview.innerHTML = '<div class="nfh15-v9-preview-head"><b>H3 实时预览</b><span><small data-preview-decoder>Latent2RGB</small><button class="nfh15-v9-preview-pause" data-taeh3-toggle type="button" title="开启后从下一个新提交任务使用TAEH3彩色预览">TAEH3：关</button><button class="nfh15-v9-preview-pause" type="button" title="暂停或继续当前动态预览">暂停</button></span></div><div class="nfh15-v9-preview-stage"><div class="nfh15-v9-preview-empty">预览</div></div><div class="nfh15-v9-preview-status" hidden></div>';
    const stage = v9Preview.querySelector(".nfh15-v9-preview-stage"),
      statusEl = v9Preview.querySelector(".nfh15-v9-preview-status"),
      previewDecoderLabel = v9Preview.querySelector("[data-preview-decoder]"),
      previewTaeh3 = v9Preview.querySelector("[data-taeh3-toggle]"),
      previewPause = v9Preview.querySelector(".nfh15-v9-preview-pause:not([data-taeh3-toggle])");
    let objectUrl = null,
      previewPaused = false,
      currentPreviewMedia = null,
      pausedCanvas = null,
      lastActualDecoder = "";
    const paintPreviewControls = () => {
      const taeh3Enabled = !!widget(node, "启用TAEH3彩色预览")?.value;
      previewDecoderLabel.textContent = lastActualDecoder || (taeh3Enabled ? "TAEH3（下次任务）" : "Latent2RGB");
      previewTaeh3.textContent = taeh3Enabled ? "TAEH3：开" : "TAEH3：关";
      previewTaeh3.classList.toggle("paused", taeh3Enabled);
      previewPause.textContent = previewPaused ? "继续" : "暂停";
      previewPause.classList.toggle("paused", previewPaused);
    };
    node.__nfh3UpdatePreviewControls = () => {
      lastActualDecoder = "";
      paintPreviewControls();
    };
    previewTaeh3.onclick = event => {
      event.preventDefault();
      event.stopPropagation();
      setWidget(node, "启用TAEH3彩色预览", !widget(node, "启用TAEH3彩色预览")?.value);
      savePersistedTaeh3Preview(node);
      node.__nfh3UpdatePreviewControls?.();
    };
    const freezeCurrentPreview = () => {
      if (!currentPreviewMedia || currentPreviewMedia.tagName === "VIDEO") return;
      const w = Math.max(1, currentPreviewMedia.naturalWidth || currentPreviewMedia.width || 1),
        h = Math.max(1, currentPreviewMedia.naturalHeight || currentPreviewMedia.height || 1),
        canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      canvas.className = currentPreviewMedia.className;
      try {
        canvas.getContext("2d").drawImage(currentPreviewMedia, 0, 0, w, h);
        pausedCanvas = canvas;
        stage.replaceChildren(canvas);
      } catch (_) {
        pausedCanvas = null;
      }
    };
    previewPause.onclick = event => {
      event.preventDefault();
      event.stopPropagation();
      previewPaused = !previewPaused;
      if (currentPreviewMedia?.tagName === "VIDEO") {
        if (previewPaused) currentPreviewMedia.pause();else currentPreviewMedia.play().catch(() => {});
      } else if (currentPreviewMedia) {
        if (previewPaused) freezeCurrentPreview();else {
          pausedCanvas = null;
          stage.replaceChildren(currentPreviewMedia);
        }
      }
      paintPreviewControls();
    };
    paintPreviewControls();
    node.__nfh3PreviewHandler = data => {
      if (!data || typeof data.image !== "string" || !ownsPreview(node, data)) return;
      try {
        const bin = atob(data.image),
          bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        const mime = typeof data.mime === "string" ? data.mime : "image/jpeg";
        const url = URL.createObjectURL(new Blob([bytes], {
          type: mime
        }));
        const media = mime.startsWith("video/") ? document.createElement("video") : document.createElement("img");
        const previewW = Math.max(1, Number(data.w) || 1),
          previewH = Math.max(1, Number(data.h) || 1);
        stage.dataset.orientation = previewH > previewW ? "portrait" : "landscape";
        stage.style.setProperty("--nfh15-preview-aspect", `${previewW} / ${previewH}`);
        if (media.tagName === "VIDEO") {
          media.autoplay = !previewPaused;
          media.loop = true;
          media.muted = true;
          media.playsInline = true;
        }
        media.src = url;
        media.onload = media.onloadeddata = () => {
          if (objectUrl) URL.revokeObjectURL(objectUrl);
          objectUrl = url;
          if (media.tagName === "VIDEO") {
            if (previewPaused) media.pause();else media.play().catch(() => {});
          } else if (previewPaused) freezeCurrentPreview();
        };
        currentPreviewMedia = media;
        pausedCanvas = null;
        stage.replaceChildren(media);
        lastActualDecoder = typeof data.decoder === "string" ? data.decoder : "";
        paintPreviewControls();
        statusEl.hidden = false;
        statusEl.textContent = `${Number(data.step || 0)}/${Number(data.total || 0)}  ·  σ ${Number.isFinite(Number(data.sigma)) ? Number(data.sigma).toFixed(4) : "—"}  ·  ${data.w || "—"}×${data.h || "—"}`;
      } catch (error) {
        statusEl.hidden = false;
        statusEl.textContent = "预览失败";
      }
    };
    node.__nfh3DisposePreview = () => {
      if (currentPreviewMedia?.tagName === "VIDEO") currentPreviewMedia.pause();
      if (objectUrl) URL.revokeObjectURL(objectUrl);
      objectUrl = null;
      currentPreviewMedia = null;
      pausedCanvas = null;
      node.__nfh3PreviewHandler = null;
      node.__nfh3UpdatePreviewControls = null;
    };
  }
  const baseSection = section("基础参数与生成尺寸", "基础参数", baseChildren);
  const promptSection = isV9(node) ? plainSection("提示词与 @ 素材引用", [triggerBox, promptBox]) : section("提示词与 @ 素材引用", "提示词", [promptBox]);
  const previewSection = v9Preview || null;
  const mediaSection = section("图片 / 视频 / 音频参考素材", "参考素材", [tabs, drop, grid, note]);
  node.__nfh3MediaSection = mediaSection;
  node.__nfh3UpdateAudioDrive?.();
  const advancedSection = section(isV7(node) ? "模型、H3专用注意力与采样设置（全流程）" : "高级模型、注意力与主采样设置（一采）", "高级设置", advancedChildren);
  // V3/V4/V5: Sol-Attn、T8、Sigma与高清二采是独立顶层折叠。
  // 只追加真实DOM节点；Element.append(null)会在界面中直接绘制字符串“null”。
  // V15 native persisted execution controls; never auto-enable an old reservation.
  const latentContinuationDetails = document.createElement("details");
  latentContinuationDetails.className = "nfh15-advanced nfh15-primary-fold";
  latentContinuationDetails.innerHTML = '<summary>一镜到底潜空间续写</summary><div class="nfh15-settings"><label><input type="checkbox" data-latent-continuation> 勾选一镜到底潜空间续写</label><div class="nfh15-note">使用上方单次运行：只生成当前所在整组，从组首新建链；未分组只生成当前段。使用“生成当前及后续分镜”：从当前段起运行全部后续分镜，各连续组独立新链，普通分镜不启用latent。单成员后缀作为无前段的首段安全生成。每段完成后再提交下一段，不读取旧链。后续段交付裁去context_length帧（24fps）。要求同分辨率；连续段暂不混用潜空间放大二采、锁音频或时间轴。使用普通队列、批次数量1；输出视频保持24fps。</div></div>';
  const continuationToggle = latentContinuationDetails.querySelector("input");
  const syncContinuationToggle = () => {
    continuationToggle.checked = widget(node, "启用潜空间续写")?.value === true;
    continuationToggle.disabled = !widget(node, "启用潜空间续写");
  };
  syncContinuationToggle();
  continuationToggle.onchange = () => {
    setWidget(node, "启用潜空间续写", continuationToggle.checked);
    node.__nfh3ApplyContinuationRestriction?.();
    node.graph?.change?.();
    node.setDirtyCanvas?.(true, true);
  };
  const continuationBody = latentContinuationDetails.querySelector('.nfh15-settings');
  // Keep overlap controls above the long help text and outside generic field-hiding rules.
  continuationBody.style.setProperty('display', 'flex', 'important');
  continuationBody.style.setProperty('flex-direction', 'column', 'important');
  const overlapRow = document.createElement('div');
  overlapRow.style.cssText = 'display:flex!important;flex-wrap:wrap;gap:12px;width:100%;padding:10px 0;';
  const overlapLabel = document.createElement('label');
  overlapLabel.textContent = '画面重叠 / 承接帧数';
  overlapLabel.style.cssText = 'display:flex;flex-direction:column;gap:6px;flex:1;min-width:180px';
  const overlapSelect = document.createElement('select');
  overlapSelect.style.cssText = 'display:block!important;background:#071b1a;color:#eafffb;border:1px solid #54d9ce;padding:9px;font-size:14px';
  for (const [value, label] of [['5', '5帧 · 约0.21秒'], ['22', '22帧 · 约0.92秒（推荐）'], ['39', '39帧 · 1.625秒'], ['56', '56帧 · 约2.33秒']]) {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = label;
    overlapSelect.append(option);
  }
  const audioLabel = document.createElement('label');
  audioLabel.textContent = '音频承接帧数（0跟随画面）';
  audioLabel.style.cssText = overlapLabel.style.cssText;
  const overlapAudio = document.createElement('input');
  overlapAudio.type = 'number';
  overlapAudio.min = '0';
  overlapAudio.max = '240';
  overlapAudio.step = '1';
  overlapAudio.style.cssText = overlapSelect.style.cssText;
  const syncOverlap = () => {
    overlapSelect.value = String(widget(node, 'context_length')?.value || '22');
    overlapAudio.value = String(widget(node, 'audio_context_length')?.value ?? 24);
    overlapSelect.disabled = !widget(node, 'context_length');
    overlapAudio.disabled = !widget(node, 'audio_context_length');
  };
  overlapSelect.onchange = () => {
    setWidget(node, 'context_length', overlapSelect.value);
    node.graph?.change?.();
  };
  overlapAudio.onchange = () => {
    const v = Number(overlapAudio.value);
    if (!Number.isInteger(v) || v < 0 || v > 240) {
      syncOverlap();
      return;
    }
    setWidget(node, 'audio_context_length', v);
    node.graph?.change?.();
  };
  syncOverlap();
  overlapLabel.append(overlapSelect);
  audioLabel.append(overlapAudio);
  overlapRow.append(overlapLabel, audioLabel);
  continuationBody.insertBefore(overlapRow, continuationBody.querySelector('.nfh15-note'));
  const audioRefineLabel = document.createElement('label');
  audioRefineLabel.style.cssText = 'display:flex;align-items:center;gap:8px;padding:4px 0 10px;';
  const audioRefineToggle = document.createElement('input');
  audioRefineToggle.type = 'checkbox';
  audioRefineToggle.dataset.continuationAudioRefine = '';
  audioRefineLabel.append(audioRefineToggle, document.createTextNode('后续段音频精修（首段不处理）'));
  audioRefineLabel.title = '仅连续组第2段起生效。默认0.3降噪、4步，可在下方调整；保留画面与音频承接区。增加采样时间，不保证音质改善。';
  continuationBody.insertBefore(audioRefineLabel, overlapRow.nextSibling);
  const audioRefineSettings = document.createElement('div');
  audioRefineSettings.style.cssText = 'display:flex!important;flex-wrap:wrap;gap:10px;width:100%;padding:0 0 10px;';
  const audioRefineFields = [{
    name: '续写音频降噪强度',
    label: '音频降噪强度',
    value: 0.3,
    min: 0.01,
    max: 1,
    step: 0.01
  }, {
    name: '续写音频精修步数',
    label: '精修步数',
    value: 4,
    min: 1,
    max: 100,
    step: 1
  }, {
    name: '续写音频采样器',
    label: '音频采样器',
    value: 'euler',
    combo: true
  }, {
    name: '续写音频调度器',
    label: '音频调度器',
    value: 'simple',
    combo: true
  }];
  for (const field of audioRefineFields) {
    const label = document.createElement('label');
    label.textContent = field.label;
    label.style.cssText = 'display:flex;flex-direction:column;gap:6px;flex:1;min-width:150px';
    const control = document.createElement(field.combo ? 'select' : 'input');
    field.control = control;
    control.style.cssText = 'display:block!important;background:#071b1a;color:#eafffb;border:1px solid #54d9ce;padding:9px;font-size:14px;color-scheme:dark';
    if (field.combo) {
      const w = widget(node, field.name);
      const values = typeof w?.options?.values === 'function' ? w.options.values(w) : w?.options?.values;
      field.values = Array.isArray(values) ? values : [];
      for (const value of field.values) {
        const option = document.createElement('option');
        option.value = value;
        option.textContent = value;
        control.append(option);
      }
    } else {
      control.type = 'number';
      control.min = String(field.min);
      control.max = String(field.max);
      control.step = String(field.step);
    }
    control.onchange = () => {
      if (control.disabled) {
        syncAudioRefine();
        return;
      }
      const value = field.combo ? control.value : Number(control.value);
      if (field.combo ? !field.values.includes(value) : !control.value.trim() || !Number.isFinite(value) || value < field.min || value > field.max || field.step === 1 && !Number.isInteger(value)) {
        syncAudioRefine();
        return;
      }
      setWidget(node, field.name, value);
      node.graph?.change?.();
      node.setDirtyCanvas?.(true, true);
      syncAudioRefine();
    };
    label.append(control);
    audioRefineSettings.append(label);
  }
  const audioRefineNote = document.createElement('div');
  audioRefineNote.className = 'nfh15-note';
  audioRefineNote.style.cssText = 'width:100%';
  audioRefineSettings.append(audioRefineNote);
  continuationBody.insertBefore(audioRefineSettings, audioRefineLabel.nextSibling);
  const syncAudioRefine = () => {
    audioRefineToggle.checked = widget(node, '启用续写音频精修')?.value === true;
    audioRefineToggle.disabled = !widget(node, '启用续写音频精修');
    const ready = !audioRefineToggle.disabled && audioRefineFields.every(field => widget(node, field.name) && (!field.combo || field.values.length));
    for (const field of audioRefineFields) {
      field.control.value = String(widget(node, field.name)?.value ?? field.value);
      field.control.disabled = !ready || !audioRefineToggle.checked;
    }
    audioRefineNote.textContent = ready ? 'CFG 固定 1（不另建负向条件）；画面始终冻结，保留音频承接区。降噪越高，原音频变化越大。' : 'CFG 固定 1。后端尚未加载精修参数，请在当前任务结束后手动重启并刷新页面；下方参数暂不可用。';
    if (audioRefineToggle.disabled) audioRefineLabel.title = '后端尚未加载此字段，请在当前任务结束后手动重启。';
  };
  audioRefineToggle.onchange = () => {
    setWidget(node, '启用续写音频精修', audioRefineToggle.checked);
    node.graph?.change?.();
    node.setDirtyCanvas?.(true, true);
    syncAudioRefine();
  };
  syncAudioRefine();
  const oldOverlapConfigure = node.onConfigure;
  node.onConfigure = function () {
    const result = oldOverlapConfigure?.apply(this, arguments);
    syncOverlap();
    syncAudioRefine();
    return result;
  };
  const batchList = document.createElement('select');
  const batchStatus = document.createElement('div');
  batchStatus.className = 'nfh15-note';
  const batchRefresh = document.createElement('button');
  batchRefresh.type = 'button';
  batchRefresh.textContent = '刷新后台批次';
  let batchPollTimer = null;
  async function refreshContinuationBatches() {
    clearTimeout(batchPollTimer);
    try {
      const data = await batchRequest(api);
      if (node.__nfh3V15Disposed) return;
      data.batches = ownedBatches(node, data.batches);
      const selected = batchList.value || node.properties?.nfh3PendingBatchId;
      batchList.replaceChildren();
      for (const item of data.batches) {
        const option = document.createElement('option');
        option.value = item.id;
        option.textContent = `${item.id.slice(0, 8)} · 节点${item.node_id} · ${item.state} · ${item.cursor}/${item.total}`;
        batchList.append(option);
      }
      if ([...batchList.options].some(o => o.value === selected)) batchList.value = selected;
      const active = data.batches.find(b => b.id === batchList.value);
      batchStatus.textContent = active ? `${active.id}：${active.message || active.state}` : '没有后台批次。提交确认后可编辑、切换或继续加入新批次。';
    } catch (error) {
      batchStatus.textContent = String(error.message || error);
    }
    if (continuationBody.isConnected) batchPollTimer = setTimeout(() => refreshContinuationBatches(), 4000);
  }
  batchRefresh.onclick = () => refreshContinuationBatches();
  batchList.onchange = () => refreshContinuationBatches();
  const resetContinuation = document.createElement('button');
  resetContinuation.type = 'button';
  resetContinuation.textContent = '停止选中批次后续任务（不中断当前生成）';
  resetContinuation.onclick = async () => {
    const id = batchList.value;
    if (!id) return;
    if (!confirm(`只停止批次 ${id} 的后续任务？已提交生成不会中断，文件保留。`)) return;
    try {
      await batchRequest(api, `/${encodeURIComponent(id)}/cancel`, {});
      await refreshContinuationBatches();
    } catch (error) {
      alert(error.message || error);
    }
  };
  continuationBody.append(batchList, batchRefresh, batchStatus, resetContinuation);
  setTimeout(() => {
    if (continuationBody.isConnected) refreshContinuationBatches();
  }, 1000);
  if (!widget(node, "启用潜空间续写")) {
    const warning = document.createElement('div');
    warning.textContent = '后端尚未加载V15续写字段，请在当前任务结束后手动重启ComfyUI，再刷新页面。';
    continuationBody.append(warning);
  }
  const previousContinuationConfigure = node.onConfigure;
  node.onConfigure = function () {
    const result = previousContinuationConfigure?.apply(this, arguments);
    syncContinuationToggle();
    return result;
  };
  const trtDetails = document.createElement('details');
  trtDetails.className = 'nfh15-advanced nfh15-primary-fold';
  trtDetails.innerHTML = '<summary>TRT 视频VAE编码＋解码加速</summary><div class="nfh15-settings"><label><input type="checkbox"> 启用TRT视频VAE编码＋解码</label><label>视频编码引擎<select data-encoder></select></label><label>视频解码引擎<select data-decoder></select></label><div class="nfh15-note">勾选后参考素材编码及视频解码均使用TRT。需同时选择本机encoder.engine与decoder.engine。音频VAE保持原样；关闭恢复原生视频VAE。</div></div>';
  const trtToggle = trtDetails.querySelector('input'),
    trtSelect = trtDetails.querySelector('[data-decoder]'),
    trtEncoder = trtDetails.querySelector('[data-encoder]');
  for (const [control, name] of [[trtSelect, 'TRT视频解码引擎'], [trtEncoder, 'TRT视频编码引擎']]) {
    control.style.cssText = 'background:#071b1a;color:#eafffb;border:1px solid #54d9ce;padding:9px';
    for (const value of choices(widget(node, name))) {
      const op = document.createElement('option');
      op.value = value;
      op.textContent = value;
      control.append(op);
    }
    control.onchange = () => {
      setWidget(node, name, control.value);
      node.graph?.change?.();
    };
  }
  const syncTrt = () => {
    trtToggle.checked = widget(node, '启用TRT视频VAE')?.value === true;
    trtToggle.disabled = !widget(node, 'TRT视频编码引擎');
    for (const [control, name] of [[trtSelect, 'TRT视频解码引擎'], [trtEncoder, 'TRT视频编码引擎']]) {
      control.value = widget(node, name)?.value || 'None';
      control.disabled = trtToggle.disabled || !trtToggle.checked;
    }
  };
  trtToggle.onchange = () => {
    setWidget(node, '启用TRT视频VAE', trtToggle.checked);
    node.graph?.change?.();
    syncTrt();
  };
  syncTrt();
  const oldTrtConfigure = node.onConfigure;
  node.onConfigure = function () {
    const r = oldTrtConfigure?.apply(this, arguments);
    syncTrt();
    return r;
  };
  const dlssDetails = document.createElement('details');
  dlssDetails.className = 'nfh15-advanced nfh15-primary-fold';
  dlssDetails.innerHTML = '<summary>DLSS 末端超分＋补帧（完整参数）</summary><div class="nfh15-settings"><div class="nfh15-note">默认关闭。超分后补帧；图像批次模式忽略视频编码参数。补帧请把“最终视频”连接原生Save Video；若用VHS，必须把“最终帧率”连接frame_rate，不能仍固定24。报告会注明神经超分回退。HDR仅为输出选项，不能恢复原SDR没有的动态范围。</div></div>';
  const dlssBody = dlssDetails.querySelector('.nfh15-settings'),
    dlssControls = [];
  const dlssOff = document.createElement('button');
  dlssOff.type = 'button';
  dlssOff.textContent = '全部关闭DLSS · 恢复正常24 FPS';
  dlssOff.style.cssText = 'background:#071b1a;color:#eafffb;border:1px solid #54d9ce;padding:10px;font-size:15px';
  dlssOff.onclick = () => {
    setWidget(node, 'DLSS超分模式', '关闭');
    setWidget(node, '启用DLSS补帧', false);
    dlssControls.forEach(f => f());
    node.graph?.change?.();
    node.setDirtyCanvas?.(true, true);
  };
  dlssBody.prepend(dlssOff);
  for (const w of node.widgets || []) {
    if (!(w.name.startsWith('DLSS_') || w.name === 'DLSS超分模式' || w.name === '启用DLSS补帧')) continue;
    const label = document.createElement('label');
    label.textContent = w.name;
    label.style.cssText = 'display:flex;flex-direction:column;gap:5px';
    const vals = choices(w),
      c = document.createElement(vals.length ? 'select' : 'input');
    c.style.cssText = 'background:#071b1a;color:#eafffb;border:1px solid #54d9ce;padding:7px';
    if (vals.length) {
      for (const value of vals) {
        const o = document.createElement('option');
        o.value = value;
        o.textContent = value;
        c.append(o);
      }
    } else if (typeof w.value === 'boolean') c.type = 'checkbox';else if (typeof w.value === 'number') {
      c.type = 'number';
      for (const k of ['min', 'max', 'step']) if (w.options?.[k] != null) c[k] = w.options[k];
    } else c.type = 'text';
    const sync = () => {
      if (c.type === 'checkbox') c.checked = w.value === true;else c.value = String(w.value ?? '');
    };
    sync();
    dlssControls.push(sync);
    c.onchange = () => {
      let value = c.type === 'checkbox' ? c.checked : c.type === 'number' ? Number(c.value) : c.value;
      if (c.type === 'number' && (!Number.isFinite(value) || !c.checkValidity())) {
        sync();
        return;
      }
      setWidget(node, w.name, value);
      node.graph?.change?.();
    };
    label.append(c);
    dlssBody.append(label);
  }
  const oldDlssConfigure = node.onConfigure;
  node.onConfigure = function () {
    const r = oldDlssConfigure?.apply(this, arguments);
    dlssControls.forEach(f => f());
    return r;
  };
  const optionalTopLevel = [audioLockDetails, slaDetails, ...(widget(node, "启用T8缓存") && !isV7(node) ? [solDetails, t8Details] : []), blockSwapDetails, reserveDetails, latentUpscaleDetails, latentContinuationDetails, referenceSizeDetails, rtxVsrDetails, dlssDetails, trtDetails, ...(isV81(node) ? [] : [sigmaDetails]), secondPassDetails].filter(Boolean);
  if (isV9(node)) {
    root.classList.add("nfh15-v9-horizontal");
    const left = document.createElement("div"),
      middle = document.createElement("div"),
      right = document.createElement("div");
    left.className = middle.className = right.className = "nfh15-v9-column";
    // 左栏：最上方生成模式，紧接九宫格与全部参考素材。
    const modeField = settings.querySelector(".nfh15-mode-field");
    if (modeField) left.append(modeField);
    left.append(mediaSection);
    // 中栏：多参结构工具、分镜/提示词正文。
    middle.append(promptTools, promptSection);
    // 右栏：最上方实时预览，下面集中全部参数与高级设置。
    right.append(previewSection, baseSection, advancedSection, ...optionalTopLevel);
    root.append(left, middle, right);
  } else {
    root.append(baseSection, promptSection, mediaSection, advancedSection, ...optionalTopLevel);
  }
  const picker = document.createElement("input");
  picker.type = "file";
  picker.multiple = true;
  picker.hidden = true;
  root.append(picker);
  const replacePicker = document.createElement("input");
  replacePicker.type = "file";
  replacePicker.accept = ACCEPT.图片;
  replacePicker.hidden = true;
  root.append(replacePicker);
  let replaceImageSlot = null;
  async function addFiles(files) {
    const owner = makeOwnerGuard(node),
      ownerShot = shots[activeShot];
    const mode = ["文生视频", "图生视频", "首尾帧"].find(x => !!widget(node, x)?.value) || "";
    let added = 0,
      rejected = 0;
    for (const f of files) {
      const k = inferKind(f);
      if (!k) {
        rejected++;
        continue;
      }
      if (mode && k !== "图片") {
        rejected++;
        continue;
      }
      const cap = mode === "文生视频" ? 0 : mode === "图生视频" ? 1 : mode === "首尾帧" ? 2 : LIMITS[k];
      const vals = valuesFor(node, k);
      if (vals.length >= cap) {
        rejected++;
        continue;
      }
      try {
        const uploaded = await upload(f);
        if (!owner() || shots[activeShot] !== ownerShot) return added;
        vals.push(uploaded);
        writeValues(node, k, vals);
        added++;
      } catch (e) {
        alert(e.message);
      }
    }
    render();
    if (rejected) alert(added ? `已添加 ${added} 个参考素材；另有 ${rejected} 个因格式、模式或数量上限未添加。` : `这些文件无法添加：请检查图片/视频/音频格式、当前生成模式与素材数量上限。`);
    return added;
  }
  async function replaceImage(slot, file) {
    const owner = makeOwnerGuard(node),
      ownerShot = shots[activeShot];
    if (!file || inferKind(file) !== "图片") return;
    try {
      const uploaded = await upload(file);
      if (!owner() || shots[activeShot] !== ownerShot) return;
      bumpMediaRevision(node, uploaded);
      setWidget(node, `图片${slot + 1}`, uploaded);
      node.__nfh3Render?.();
      return uploaded;
    } catch (e) {
      alert(e.message);
    }
  }
  let v9GeometryFrame = 0,
    v9GeometryRetries = 0;
  function syncV9ColumnGeometry() {
    if (!isV9(node)) return;
    if (v9GeometryFrame) cancelAnimationFrame(v9GeometryFrame);
    v9GeometryFrame = requestAnimationFrame(() => {
      v9GeometryFrame = requestAnimationFrame(() => {
        v9GeometryFrame = 0;
        if (!root.isConnected) {
          if (v9GeometryRetries++ < 30) setTimeout(syncV9ColumnGeometry, 50);
          return;
        }
        v9GeometryRetries = 0;
      });
    });
  }
  node.__nfh3SyncV9Geometry = syncV9ColumnGeometry;
  const markCurrentChain = document.createElement("button");
  markCurrentChain.type = "button";
  markCurrentChain.textContent = "将当前全部分镜设为连续组";
  markCurrentChain.style.cssText = "color:#b6fff4;background:#07302d;border:1px solid #54d9ce;padding:7px 12px;cursor:pointer";
  storyboardTabs.parentElement?.append(markCurrentChain);
  markCurrentChain.onclick = () => {
    if (shots.length < 2) {
      alert("连续组至少需要2段");
      return;
    }
    if (!confirm("将当前全部分镜标为同一个连续组？只保存规划标记，不会生成或启用latent续写。")) return;
    captureStoryboard();
    const group = globalThis.crypto?.randomUUID?.() || `chain-${Date.now()}`;
    for (const item of shots) item.continuationGroupId = group;
    persistStoryboards();
    node.graph?.change?.();
    render();
  };
  function render() {
    captureStoryboard();
    storyboardTabs.replaceChildren();
    let activeStoryboardButton = null;
    shots.forEach((shot, i) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = `nfh15-storyboard-tab${i === activeShot ? " active" : i > activeShot ? " queued-range" : ""}`;
      const audioDriveShot = shot.audioDriveEnabled === true && Number.isFinite(Number(shot.audioDriveStart)) && Number.isFinite(Number(shot.audioDriveEnd));
      const segmentLabel = `第 ${i + 1} 段`;
      b.innerHTML = audioDriveShot ? `<span class="nfh15-storyboard-time-icon" aria-hidden="true">◷</span><span>${segmentLabel}</span>` : `<span>${segmentLabel}</span>`;
      b.title = audioDriveShot ? `音频驱动 · ${segmentLabel} · ${formatAudioDriveTime(shot.audioDriveStart)} → ${formatAudioDriveTime(shot.audioDriveEnd)} · ${Number(shot.durationSeconds) || 0}秒` : segmentLabel;
      const chain = shot.continuationGroupId;
      const connectedBefore = !!chain && shots[i - 1]?.continuationGroupId === chain,
        connectedAfter = !!chain && shots[i + 1]?.continuationGroupId === chain;
      if (connectedBefore || connectedAfter) {
        const groups = [...new Set(shots.map(item => item.continuationGroupId).filter(Boolean))];
        const groupIndex = groups.indexOf(chain) + 1;
        b.title += ` · 连续组 ${groupIndex}（规划）${!connectedBefore ? ' · 本组首段，不接上一组' : ''}`;
        b.style.setProperty("outline", "1px solid #54d9ce", "important");
        b.style.setProperty("outline-offset", "-2px", "important");
        b.style.setProperty("border-bottom", "2px solid #54d9ce", "important");
        const mark = document.createElement("small");
        mark.textContent = ` · C${groupIndex}`;
        mark.style.cssText = "display:inline;color:inherit;font-size:10px;opacity:.8;pointer-events:none";
        b.append(mark);
      }
      b.onclick = () => applyStoryboard(i);
      storyboardTabs.append(b);
      if (i === activeShot) activeStoryboardButton = b;
    }); /* Keep the segment grid at the user's current scroll position; selecting a segment must not auto-page downward. */
    deleteShot.disabled = shots.length <= 1;
    sync(node, root);
    node.__nfh3UpdateSigmaProfile?.();
    node.__nfh3UpdateSecondPass?.();
    node.__nfh3Resolution?.();
    const mode = ["文生视频", "图生视频", "首尾帧"].find(x => !!widget(node, x)?.value) || "";
    if (promptTools.dataset.mode !== mode) {
      promptTools.dataset.mode = mode;
      renderPromptTools(mode);
    }
    promptHint.textContent = mode ? `${mode}使用固定结构，无需 @ 素材引用` : "输入 @ 选择已添加素材";
    syncPromptConnection();
    if (mode) closeMentions();
    for (const b of root.querySelectorAll("[data-mode]")) b.classList.toggle("on", b.dataset.mode === mode);
    if (mode && active !== "图片") active = "图片";
    const imageLimit = mode === "文生视频" ? 0 : mode === "图生视频" ? 1 : mode === "首尾帧" ? 2 : 9;
    tabs.replaceChildren();
    for (const k of Object.keys(LIMITS)) {
      const disabled = !!mode && k !== "图片";
      const cap = k === "图片" ? imageLimit : LIMITS[k];
      const b = document.createElement("button");
      b.className = `nfh15-tab${k === active ? " active" : ""}`;
      b.disabled = disabled;
      b.textContent = `${k} ${valuesFor(node, k).length}/${cap}`;
      b.onclick = () => {
        active = k;
        render();
      };
      tabs.append(b);
    }
    picker.accept = ACCEPT[active];
    const currentDisabled = !!mode && (active !== "图片" || imageLimit === 0);
    drop.classList.toggle("disabled", currentDisabled);
    drop.textContent = mode === "文生视频" ? "文生视频：无需上传图片" : mode === "图生视频" ? "图生视频：上传1张首帧" : mode === "首尾帧" ? "首尾帧：依次上传首帧、尾帧" : `拖拽${active}文件到这里，或点击选择`;
    const vals = valuesFor(node, active);
    const renderLimit = active === "图片" && mode ? Math.max(imageLimit, 1) : LIMITS[active];
    grid.replaceChildren();
    for (let i = 0; i < renderLimit; i++) {
      const c = document.createElement("div");
      c.className = `nfh15-card${currentDisabled || i >= imageLimit && active === "图片" && mode ? " disabled" : ""}`;
      c.dataset.index = i;
      if (vals[i]) {
        c.onpointerdown = e => beginCardDrag(e, i, c);
        if (active === "图片") {
          const im = document.createElement("img");
          im.src = mediaUrl(vals[i], mediaRevision(node, vals[i]));
          im.draggable = false;
          c.append(im);
          const replace = document.createElement("button");
          replace.className = "nfh15-replace";
          replace.textContent = "替换";
          replace.title = `替换${mode === "首尾帧" ? i === 0 ? "首帧" : "尾帧" : `@图片${i + 1}`}，其他图片编号保持不变`;
          replace.onclick = e => {
            e.preventDefault();
            e.stopPropagation();
            replaceImageSlot = i;
            replacePicker.value = "";
            replacePicker.click();
          };
          c.append(replace);
        } else if (active === "音频") {
          const wrap = document.createElement("div");
          wrap.className = "nfh15-media-player";
          const audio = document.createElement("audio");
          audio.src = mediaUrl(vals[i]);
          audio.controls = true;
          audio.preload = "metadata";
          audio.onpointerdown = e => e.stopPropagation();
          audio.onclick = e => e.stopPropagation();
          wrap.onpointerdown = e => e.stopPropagation();
          wrap.append(audio);
          c.append(wrap);
        } else if (active === "视频") {
          const wrap = document.createElement("div");
          wrap.className = "nfh15-media-player nfh15-video-player";
          const video = document.createElement("video");
          video.src = mediaUrl(vals[i], mediaRevision(node, vals[i]));
          video.controls = true;
          video.preload = "metadata";
          video.playsInline = true;
          video.onpointerdown = e => e.stopPropagation();
          video.onclick = e => e.stopPropagation();
          video.ondblclick = e => e.stopPropagation();
          wrap.onpointerdown = e => e.stopPropagation();
          wrap.onclick = e => e.stopPropagation();
          wrap.append(video);
          c.append(wrap);
        } else {
          const e = document.createElement("div");
          e.className = "nfh15-empty";
          e.textContent = "▶ VIDEO";
          c.append(e);
        }
        const x = document.createElement("button");
        x.className = "nfh15-x";
        x.textContent = "×";
        x.onclick = e => {
          e.stopPropagation();
          vals.splice(i, 1);
          writeValues(node, active, vals);
          render();
        };
        c.append(x);
        const l = document.createElement("span");
        l.className = "nfh15-label";
        l.textContent = mode && active === "图片" ? `${i === 0 ? "首帧" : "尾帧"} · ${vals[i].split("/").pop()}` : `@${active}${i + 1} · ${vals[i].split("/").pop()}`;
        c.append(l);
      } else {
        const e = document.createElement("div");
        e.className = "nfh15-empty";
        e.textContent = currentDisabled ? "已禁用" : mode && active === "图片" ? i === 0 ? "＋ 首帧" : "＋ 尾帧" : `＋ @${active}${i + 1}`;
        c.append(e);
        if (!currentDisabled) c.onclick = () => picker.click();
      }
      grid.append(c);
    }
    syncV9ColumnGeometry();
  }
  picker.onchange = () => {
    addFiles([...picker.files]);
    picker.value = "";
  };
  replacePicker.onchange = async () => {
    const file = replacePicker.files?.[0],
      slot = replaceImageSlot;
    replaceImageSlot = null;
    replacePicker.value = "";
    if (Number.isInteger(slot) && file) await replaceImage(slot, file);
  };
  // V9支持从资源管理器或浏览器图片预览把素材拖到整个参考素材区域，按真实类型自动进入固定槽位。
  if (isV9(node)) {
    let externalDragDepth = 0;
    const dragTypes = e => Array.from(e.dataTransfer?.types || []);
    const isMediaDrag = e => {
      const types = dragTypes(e);
      return !types.includes("application/x-nanfeng-slot") && (types.includes("Files") || types.includes("text/uri-list") || types.includes("text/html"));
    };
    const isInsideMedia = e => {
      const r = mediaSection.getBoundingClientRect();
      return e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom;
    };
    const filesFromDrop = async e => {
      const direct = Array.from(e.dataTransfer?.files || []);
      if (direct.length) return direct;
      let url = String(e.dataTransfer?.getData("text/uri-list") || "").split(/\r?\n/).find(x => x && !x.startsWith("#")) || "";
      if (!url) {
        const html = e.dataTransfer?.getData("text/html") || "";
        url = html.match(/<(?:img|video|audio)[^>]+src=["']([^"']+)/i)?.[1] || "";
      }
      if (!url) return [];
      try {
        const response = await fetch(url, {
          credentials: new URL(url, location.href).origin === location.origin ? "include" : "omit"
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const blob = await response.blob();
        const pathname = new URL(url, location.href).pathname,
          name = decodeURIComponent(pathname.split("/").pop() || `拖入素材-${Date.now()}`);
        return [new File([blob], name, {
          type: blob.type || "application/octet-stream"
        })];
      } catch (error) {
        alert(`无法读取拖入的网页素材：${error.message}。如果来源网站禁止跨域，请先下载到电脑再拖入。`);
        return [];
      }
    };
    const enter = e => {
      if (!isMediaDrag(e) || !isInsideMedia(e)) return;
      e.preventDefault();
      e.stopPropagation();
      externalDragDepth++;
      mediaSection.classList.add("nfh15-media-external-drag");
    };
    const over = e => {
      if (!isMediaDrag(e) || !isInsideMedia(e)) return;
      e.preventDefault();
      e.stopPropagation();
      e.dataTransfer.dropEffect = "copy";
      mediaSection.classList.add("nfh15-media-external-drag");
    };
    const leave = e => {
      if (!isMediaDrag(e)) return;
      externalDragDepth = Math.max(0, externalDragDepth - 1);
      if (!externalDragDepth || !isInsideMedia(e)) mediaSection.classList.remove("nfh15-media-external-drag");
    };
    const receive = async e => {
      if (!isMediaDrag(e) || !isInsideMedia(e)) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      externalDragDepth = 0;
      mediaSection.classList.remove("nfh15-media-external-drag");
      const files = await filesFromDrop(e);
      if (files.length) await addFiles(files);
    };
    // 使用window捕获阶段兜底：ComfyUI画布会在DOM区之前截获drop，浏览器随后把图片导航成新网页。
    window.addEventListener("dragenter", enter, true);
    window.addEventListener("dragover", over, true);
    window.addEventListener("dragleave", leave, true);
    window.addEventListener("drop", receive, true);
    node.__nfh3DisposeExternalDrop = () => {
      window.removeEventListener("dragenter", enter, true);
      window.removeEventListener("dragover", over, true);
      window.removeEventListener("dragleave", leave, true);
      window.removeEventListener("drop", receive, true);
    };
  }
  drop.onclick = () => {
    if (!drop.classList.contains("disabled")) picker.click();
  };
  drop.ondragover = e => {
    if (drop.classList.contains("disabled")) return;
    e.preventDefault();
    drop.classList.add("drag");
  };
  drop.ondragleave = () => drop.classList.remove("drag");
  drop.ondrop = e => {
    if (drop.classList.contains("disabled")) return;
    e.preventDefault();
    e.stopPropagation();
    drop.classList.remove("drag");
    if (!e.dataTransfer.types.includes("application/x-nanfeng-slot")) addFiles([...e.dataTransfer.files]);
  };
  node.__nfh3Root = root;
  mountSkinController(node, root);
  node.__nfh3Render = render;
  if (restoredFromStorage) applyStoryboard(activeShot, true);else render();
  return root;
}
async function refreshNanFengModelCombos() {
  const response = await api.fetchApi("/nanfeng/v15/h3/refresh-models", {
      method: "POST",
      cache: "no-store"
    }),
    live = await readJsonResponse(response);
  if (!response.ok || !live.ok) throw new Error(live.error || `HTTP ${response.status}`);
  const refreshGraph = app.graph;
  const defs = await api.getNodeDefs();
  if (app.graph !== refreshGraph) return;
  for (const node of refreshGraph?._nodes || []) {
    if (!TARGETS.has(node.comfyClass || node.type)) continue;
    const required = defs?.[node.comfyClass || node.type]?.input?.required || {};
    for (const name of ["模型", "文本编码器", "视频VAE", "音频VAE", ...Array.from({
      length: MAX_LORA_SLOTS
    }, (_, i) => `LoRA${i + 1}`), "H3潜空间放大模型", "H3二采LoRA"]) {
      const values = live[name === "模型" ? "模型" : name.startsWith("LoRA") ? "LoRA" : name] || required?.[name]?.[0];
      if (!Array.isArray(values)) continue;
      const w = widget(node, name);
      if (!w) continue;
      w.options ||= {};
      w.options.values = values;
      if (!name.startsWith("LoRA") && !values.includes(w.value) && values.length) setWidget(node, name, values[0]);
      const select = node.__nfh3Root?.querySelector?.(`[data-widget-name="${name}"]`);
      if (select?.classList?.contains("nfh15-custom-select")) {
        select.__nfh3SetValues?.(values);
        select.__nfh3Paint?.();
      } else if (select?.tagName === "SELECT") {
        select.replaceChildren();
        for (const item of values) {
          const option = document.createElement("option");
          option.value = item;
          option.textContent = item;
          select.append(option);
        }
        select.value = w.value;
      }
    }
    node.__nfh3Render?.();
    node.setDirtyCanvas?.(true, true);
  }
}
const applyV7CanvasTheme = node => {
  if (applySkinChrome(node)) return;
  if (!isV7(node)) return;
  if (isV9(node)) {
    node.color = "#031a19";
    node.bgcolor = "#020d0d";
    node.boxcolor = "#54d9ce";
    node.shape = window.LiteGraph?.BOX_SHAPE ?? node.shape;
  } else {
    node.color = "#12252c";
    node.bgcolor = "#071014";
    node.boxcolor = "#37b7c5";
    node.shape = window.LiteGraph?.ROUND_SHAPE ?? node.shape;
  }
  node.setDirtyCanvas?.(true, true);
};
app.registerExtension({
  name: "nanfeng.h3.multi.reference.v15",
  init() {
    installCurrentGroupQueue(app);
    api.addEventListener("kj_preview_override", e => {
      const data = e.detail;
      if (!data || data.node_id == null) return;
      const parts = String(data.node_id).split(":");
      let graph = app.graph,
        node = null;
      for (let i = 0; i < parts.length; i++) {
        node = graph?.getNodeById?.(Number(parts[i]));
        if (i < parts.length - 1) graph = node?.subgraph;
      }
      if (node?.comfyClass === "NanFengH3MultiReferenceGeneratorV15" || node?.type === "NanFengH3MultiReferenceGeneratorV15") node.__nfh3PreviewHandler?.(data);
    });
    if (!app.__nfh3RefreshWrappedV15 && app.refreshComboInNodes) {
      const original = app.refreshComboInNodes;
      app.refreshComboInNodes = async function () {
        const result = await original.apply(this, arguments);
        await refreshNanFengModelCombos();
        return result;
      };
      app.__nfh3RefreshWrappedV15 = true;
    }
    if (!app.__nfh3RefreshKeyBoundV15) {
      document.addEventListener("keydown", async event => {
        if (event.key.toLocaleLowerCase() !== "r" || event.ctrlKey || event.metaKey || event.altKey) return;
        if (["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName) || document.activeElement?.isContentEditable) return;
        try {
          await refreshNanFengModelCombos();
        } catch (error) {
          console.error("[南风H3] 模型列表刷新失败", error);
        }
      });
      app.__nfh3RefreshKeyBoundV15 = true;
    }
  },
  async beforeRegisterNodeDef(nodeType, nodeData) {
    if (!TARGETS.has(nodeData.name)) return;
    const originalConfigureNode = nodeType.prototype.configure;
    nodeType.prototype.configure = function(info){ return originalConfigureNode.call(this,migrateV15WorkflowInfo(info)); };
    const original = nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated = function () {
      const result = original?.apply(this, arguments);
      this.__nfh3V15Disposed = false;
      this.__nfh3V15RuntimeOwner = crypto.randomUUID();
      for (const w of this.widgets || []) hideWidget(w);
      if (isV7(this)) {
        applyV7CanvasTheme(this);
      } else {
        this.color = "#211329";
        this.bgcolor = "#130c1b";
        this.boxcolor = "#b07add";
      }
      this.properties ||= {};
      this.properties.nanfeng_layout_version = 43;
      restorePersistedLoraState(this);
      restorePersistedTaeh3Preview(this);
      syncSeedControlMode(this);
      // V3只保留真正的STRING接口：圆点旁直接显示名称，不再在DOM面板内重复增加标题栏。
      const promptSlot = this.inputs?.find(input => input.name === "提示词" || input.widget?.name === "提示词");
      if (promptSlot) promptSlot.label = "提示词列表输入";
      for (const output of this.outputs || []) {
        if (output.name === "图像") output.label = "图像输出";
        if (output.name === "音频") output.label = "音频输出";
      }
      const originalGetConnectionPos = this.getConnectionPos;
      this.getConnectionPos = function (isInput, slotNumber, out) {
        const slotName = isInput ? this.inputs?.[slotNumber]?.name || this.inputs?.[slotNumber]?.widget?.name : "";
        const outputName = !isInput ? this.outputs?.[slotNumber]?.name || "" : "";
        if (isInput && slotName === "提示词") {
          out = out || new Float32Array(2);
          out[0] = this.pos[0] + 10;
          out[1] = this.pos[1] + 72;
          return out;
        }
        if (!isInput && (outputName === "图像" || outputName === "音频")) {
          out = out || new Float32Array(2);
          out[0] = this.pos[0] + this.size[0] - 10;
          out[1] = this.pos[1] + (outputName === "图像" ? 52 : 72);
          return out;
        }
        return originalGetConnectionPos?.apply(this, arguments) || out;
      };
      const originalConnectionsChange = this.onConnectionsChange;
      this.onConnectionsChange = function (type, index, connected, linkInfo, ioSlot) {
        const changed = originalConnectionsChange?.apply(this, arguments);
        if (type === LiteGraph.INPUT) {
          const input = this.inputs?.[index];
          if (input?.name === "提示词" || input?.widget?.name === "提示词") setTimeout(() => this.__nfh3SyncPromptConnection?.(), 0);
        }
        return changed;
      };
      // V1–V8.1维持原尺寸；V9改为三栏横版，宽度是原来的3倍，高度约减少三分之一。
      const FIXED_WIDTH = isV9(this) ? 2400 : 800,
        WIDGET_HEIGHT = isV9(this) ? 1180 : 1800,
        FIXED_HEIGHT = isV9(this) ? 1320 : 2300;
      const panel = buildPanel(this);
      const shell = document.createElement("div");
      shell.className = "nfh15-shell";
      shell.append(panel);
      const enforceHostSize = () => {
        applyV7CanvasTheme(this);
        const host = shell.parentElement;
        if (!host) return;
        host.style.width = `${FIXED_WIDTH - 20}px`;
        host.style.minWidth = `${FIXED_WIDTH - 20}px`;
        host.style.maxWidth = `${FIXED_WIDTH - 20}px`;
        host.style.height = `${WIDGET_HEIGHT}px`;
        host.style.minHeight = `${WIDGET_HEIGHT}px`;
        host.style.maxHeight = `${WIDGET_HEIGHT}px`;
        shell.style.width = "100%";
        shell.style.height = "100%";
      };
      const dom = this.addDOMWidget("完整控制台", "nanfeng_media", shell, {
        serialize: false,
        hideOnZoom: false,
        getMinHeight: () => WIDGET_HEIGHT,
        getMaxHeight: () => WIDGET_HEIGHT,
        getHeight: () => WIDGET_HEIGHT,
        onDraw: enforceHostSize,
        beforeResize: enforceHostSize,
        afterResize: enforceHostSize
      });
      dom.computeSize = () => [FIXED_WIDTH - 20, WIDGET_HEIGHT];
      dom.computedHeight = WIDGET_HEIGHT;
      // 唯一尺寸权威：节点 computeSize 永远返回固定尺寸。点击/聚焦控件时前端重算尺寸也只能得到这个值，
      // 从根源上杜绝"一点鼠标节点就缩小"。onResize 同步兜底（不用 requestAnimationFrame，避免闪缩）。
      let locking = false;
      const originalResize = this.onResize;
      const lockSize = () => {
        if (locking) return;
        locking = true;
        try {
          dom.computedHeight = WIDGET_HEIGHT;
          if (this.size[0] !== FIXED_WIDTH) this.size[0] = FIXED_WIDTH;
          if (this.size[1] !== FIXED_HEIGHT) this.size[1] = FIXED_HEIGHT;
          enforceHostSize();
          this.setDirtyCanvas?.(true, true);
        } finally {
          locking = false;
        }
      };
      this.computeSize = () => [FIXED_WIDTH, FIXED_HEIGHT];
      this.onResize = function (size) {
        const value = originalResize?.apply(this, arguments);
        lockSize();
        this.__nfh3SyncV9Geometry?.();
        return value;
      };
      const oldConfig = this.onConfigure;
      this.onConfigure = function (info) {
        this.__nfh3V15Epoch = (this.__nfh3V15Epoch || 0) + 1;
        this.__nfh3V15Configuring = true;
        this.__nfh3CloseSmart?.();
        this.__nfh3CloseAudio?.();
        this.__nfh3V15RuntimeOwner = crypto.randomUUID();
        this.properties = JSON.parse(JSON.stringify(this.properties || {}));
        oldConfig?.call(this, info);
        this.properties ||= {};
        restorePersistedLoraState(this);
        restorePersistedTaeh3Preview(this);
        const oldVersion = Number(this.properties.nanfeng_layout_version || 0);
        const modelWidget = widget(this, "模型"),
          sageWidget = widget(this, "SageAttention"),
          h3SageWidget = widget(this, "H3专用注意力"),
          mpWidget = widget(this, "百万像素"),
          refSizeWidget = widget(this, "参考图尺寸"),
          denoiseWidget = widget(this, "降噪强度"),
          seedLockWidget = widget(this, "固定随机种子");
        if (seedLockWidget && typeof seedLockWidget.value !== "boolean") {
          seedLockWidget.value = false;
          seedLockWidget.callback?.(false);
        }
        syncSeedControlMode(this);
        if (oldVersion < 25) {
          const stable = choices(modelWidget).find(x => /minimax_h3_ref2va_int8_convrot\.safetensors$/i.test(String(x)) && !/pruned/i.test(String(x)));
          if (stable && /minimax_h3_ref2va_(?:bf16|pruned_int8_convrot)\.safetensors$/i.test(String(modelWidget?.value || ""))) setWidget(this, "模型", stable);
          if (sageWidget?.value === "disabled") setWidget(this, "SageAttention", "auto");
          if (Number(mpWidget?.value) === 0.98) setWidget(this, "百万像素", 0.4);
        }
        if (!Number.isFinite(Number(denoiseWidget?.value))) setWidget(this, "降噪强度", 1.0);
        if (!choices(refSizeWidget).includes(refSizeWidget?.value)) setWidget(this, "参考图尺寸", "match");
        for (const modeName of ["文生视频", "图生视频", "首尾帧"]) {
          const mw = widget(this, modeName);
          if (typeof mw?.value !== "boolean") {
            mw.value = false;
            mw.callback?.(false);
          }
        }
        if (isV81(this)) {
          setWidget(this, "H3二采LoRA模式", "继承一采LoRA");
          setWidget(this, "H3二采LoRA", "");
          const completeSigma = String(widget(this, "H3完整Sigma序列")?.value || "").trim();
          const legacySigma = String(widget(this, "手动西格玛")?.value || "").trim();
          const firstSteps = Number(widget(this, "H3一采步数")?.value || 6),
            secondSteps = Number(widget(this, "H3二采步数")?.value || 4);
          const values = legacySigma.split(/[，,\s]+/).map(Number).filter(Number.isFinite);
          if (!completeSigma && values.length === firstSteps + secondSteps + 1 && values.at(-1) === 0) setWidget(this, "H3完整Sigma序列", legacySigma);
        }
        const solWidget = widget(this, "启用SolAttn"),
          t8Widget = widget(this, "启用T8缓存");
        if (solWidget?.value === true && t8Widget?.value === true) setWidget(this, "启用T8缓存", false);
        if (solWidget?.value === true || t8Widget?.value === true) setWidget(this, "SageAttention", "disabled");
        this.properties.nanfeng_layout_version = 44;
        initializeAudioDriveMarkersFromTimedStoryboards(this);
        restoreAudioDriveWorkspace(this);
        restoreBestAudioDriveWorkspace(this);
        syncSeedControlMode(this);
        this.__nfh3RestoreStoryboardsFromProperties?.();
        lockSize();
        setTimeout(() => {
          syncSeedControlMode(this);
          lockSize();
          this.__nfh3RestoreStoryboardsFromProperties?.();
          this.__nfh3Render?.();
          this.__nfh3Resolution?.();
          this.__nfh3SyncPromptConnection?.();
        }, 30);
        this.__nfh3V15Configuring = false;
        this.__nf15SkinController?.restore();
      };
      lockSize();
      setTimeout(lockSize, 0);
      const oldSerialize = this.onSerialize;
      this.onSerialize = function (info) {
        oldSerialize?.call(this, info);
        if (info?.properties) info.properties = JSON.parse(JSON.stringify(info.properties));
        stampOwner(this, info);
      };
      const oldRemoved = this.onRemoved;
      this.onRemoved = function () {
        this.__nfh3V15Disposed = true;
        this.__nfh3V15Epoch = (this.__nfh3V15Epoch || 0) + 1;
        this.__nfh3CloseSmart?.();
        this.__nfh3CloseAudio?.();
        this.__nfh3SkinDialog?.close?.();

        this.__nf15SkinController?.dispose();
        this.__nfh3DisposePreview?.();
        this.__nfh3DisposeExternalDrop?.();
        this.__nfh3Root?.querySelectorAll?.(".nfh15-custom-select").forEach(x => x.__nfh3Dispose?.());
        oldRemoved?.call(this);
      };
      return result;
    };
  }
});