import { api, app } from "@/composable/comfyAPI";

// 全局Seed
function globalSeedHandler(event) {
    let nodes = app.graph._nodes_by_id;
    for(let i in nodes) {
        let node = nodes[i];
        if(node.type == 'easy globalSeed') {
            if(node.widgets) {
                const w = node.widgets.find((w) => w.name == 'value');
                const last_w = node.widgets.find((w) => w.name == 'last_seed');
                last_w.value = w.value;
                w.value = event.detail.value;
            }
        }
        else{
            if(node.widgets) {
                const w = node.widgets.find((w) => w.name == 'seed_num' || w.name == 'seed' || w.name == 'noise_seed');
                if(w && event.detail.seed_map[node.id] != undefined) {
                    w.value = event.detail.seed_map[node.id];
                }
            }
        }

    }
}

api.addEventListener("easyuse-global-seed", globalSeedHandler);

function addSeedWidgetsToWorkflow(prompt, graph) {
    const workflow = prompt?.workflow;
    if (!workflow || typeof workflow !== 'object') return prompt;

    workflow.seed_widgets = {};
    const nodes = graph?._nodes_by_id || {};
    for(let i in nodes) {
        let widgets = nodes[i].widgets;
        if(widgets) {
            for(let j in widgets) {
                if((widgets[j].name == 'seed_num' || widgets[j].name == 'seed' || widgets[j].name == 'noise_seed') && widgets[j].type != 'converted-widget')
                    workflow.seed_widgets[i] = parseInt(j);
            }
        }
    }
    return prompt;
}

// Add EasyUse metadata while the workflow is being built. Do not wrap
// api.queuePrompt: ComfyUI owns its validation/error handling and now passes
// execution options through that method (partial execution, preview method,
// authentication, etc.). Wrapping it makes normal prompt validation failures
// appear to originate from EasyUse and is fragile when the API evolves.
const original_graphToPrompt = app.graphToPrompt;
app.graphToPrompt = function graphToPrompt_with_seed(...args) {
    const graph = args[0] || app.rootGraph || app.graph;
    return Promise.resolve(original_graphToPrompt.apply(this, args))
        .then(prompt => addSeedWidgetsToWorkflow(prompt, graph));
};
