"""把软链上的 h3_multiref.js 按真实文件送出去。

ComfyUI 的静态路由不跟随指向 WEB_DIRECTORY 之外的符号链接，
/extensions/.../h3_multiref.js 会 404。浏览器就继续用缓存里的旧脚本。
"""
from __future__ import annotations

from pathlib import Path

WEB_JS = Path(__file__).resolve().parent / "web" / "h3_multiref.js"
ROUTE = "/extensions/nanfeng_prompt_nodes_v10/h3_multiref.js"


def _register() -> None:
    try:
        from aiohttp import web
        from server import PromptServer
    except Exception:
        return

    prompt_server = getattr(PromptServer, "instance", None)
    if prompt_server is None:
        return

    @prompt_server.routes.get(ROUTE)
    async def serve_h3_multiref(_request):
        path = WEB_JS.resolve()
        if not path.is_file():
            return web.Response(status=404, text="missing h3_multiref.js")
        return web.FileResponse(path, headers={"Cache-Control": "no-store"})


_register()
