import json
import math
import os
import re
import asyncio
import subprocess
import shutil
import sys
import time
import wave
import base64
import array
import gc
import ssl
import urllib.error
import urllib.parse
import urllib.request
import tempfile
import zipfile
import threading

import folder_paths
from aiohttp import web
from PIL import Image
from server import PromptServer

from .VRGDG_ModelPathSettings import register_custom_model_root
from .VRGDG_MiniMaxH3LatentManager import SceneLatentManager, scene_latent_manager
from .VRGDG_VideoEditorNodes import (
    _clean_gemma_prompt_text,
    _clean_visual_gemma_text,
    _image_from_data_url,
    _I2V_INSTRUCTIONS,
    _TEXT_ONLY_T2I_INSTRUCTIONS,
    _VISUAL_T2I_INSTRUCTIONS,
)
from .VRGDG_WorkflowRunnerNodes import _resolve_comfy_image_path
from .VRGDG_LUTVideoTools import register_lut_routes
from .VRGDG_FaceFix import register_face_fix_routes
from .VRGDG_GemmaPromptSanitizer import extract_prompt_text_from_gemma_output
from .VRGDG_StoryboardBuilderNodes import _STORYBOARD_T2I_GEMMA_INSTRUCTIONS
from .VRGDG_MiniMaxH3PromptInstructions import (
    MINIMAX_H3_IMAGE_REFERENCE_TO_VIDEO_INSTRUCTIONS,
    MINIMAX_H3_IMAGE_TO_VIDEO_INSTRUCTIONS,
    MINIMAX_H3_FRAME_CONTINUITY_INSTRUCTIONS,
    MINIMAX_H3_REFERENCE_TO_VIDEO_INSTRUCTIONS,
    MINIMAX_H3_TEXT_TO_VIDEO_INSTRUCTIONS,
    MINIMAX_H3_VIDEO_TO_VIDEO_INSTRUCTIONS,
    MINIMAX_H3_SHORT_FILM_GUIDED_INSTRUCTIONS_BY_MODE,
    MINIMAX_H3_SHORT_FILM_CUSTOM_INSTRUCTIONS_BY_MODE,
)


_VRGDG_MUSIC_BUILDER_ROUTES_REGISTERED = False
_BUILDER_SAVE_LOCK = threading.RLock()

_LM_STUDIO_DEFAULT_BASE_URL = "http://127.0.0.1:1234/v1"
_OWN_SERVER_DEFAULT_BASE_URL = "http://127.0.0.1:8000/v1"
_EXTERNAL_LLM_RUNNERS = frozenset({"lm_studio", "llm_api", "own_server"})

_T2V_INSTRUCTIONS = """Convert the user's concept prompt into a dynamic text-to-video prompt.

Use the user's prompt as the full scene foundation. Preserve the original subject, setting, outfit, mood, atmosphere, and scene identity. Infer only the missing video details needed to make the scene feel complete, including time of day, weather, lighting behavior, environmental movement, subject movement, camera movement, and performance energy. Do not add unrelated characters, new locations, major story changes, captions, text overlays, dialogue, or audio instructions.

Add fast, cinematic motion by giving the subject a clear action sequence, expressive facial expressions, strong gestures, and intentional camera movement. Keep the subject visible, centered, and clearly framed throughout. Add lighting only as natural scene behavior, such as flickering stage lights, passing sunlight, glowing streetlights, storm flashes, reflections, or shifting shadows, based on what best fits the user's prompt.

Output one polished paragraph using this structure:

The [Subject] in [setting/environment] during [time/weather]. The subject [dynamic performance action with expressive face, body movement, and strong gestures]. Their clothing/hair [reacts to movement, wind, or performance energy]. The lighting [changes or reacts naturally within the scene]. The camera [Camera Motion] while maintaining [subject visibility and framing]. The environment [reacts dynamically].

Each word in brackets should be chosen based on the user input and what best fits the scene.

Rules:
- This is text-to-video
- Never output square brackets or placeholder text. Replace every bracketed example with concrete scene details.
- Do not force singing. Follow user notes for singing, speaking, narration, instrumental, b-roll, or no-lip-sync behavior.
- Do not invent lyric/dialogue text. If exact lyric or dialogue text is provided in the user notes, use only that exact text when the performance direction calls for singing, speaking, or lip-sync. If no exact text is provided, describe the visible performance without inventing words.
- Do not add audio, dialogue, captions, text overlays, unrelated characters, new locations, major story changes, color grading, camera photo style, or static image-quality descriptions.
- Keep it vivid, fast, cinematic, dynamic, and video-ready
- Use one location inferred by the user's concept prompt. If one is not listed use one from the location list.
- Must use user input to help create the prompt
- User notes take priority. If user notes ask for no singing, silent b-roll, instrumental motion, no lip movement, or non-performance action, follow the user notes instead.
- Do not mention source prompts, notes, lyrics, segments, JSON, or instructions.
- Do not include markdown, labels, quotes, or explanations."""

_ID_LORA_INSTRUCTIONS = """Create one short-film ID-LoRA prompt for LTX 2.3 ID-LoRA.

Use the user's scene concept, story context, mapped character/location notes, and motion notes to write a compact in-context video script. The workflow receives a reference image and a reference voice sample separately, so the prompt should describe the visible person, action, camera, and spoken vocal content without mentioning files, inputs, samples, LoRAs, or cloning.

Output exactly three labeled sections:

[VISUAL]: One cinematic paragraph describing the visible subject identity, setting, action, facial expression, camera movement, lighting, and environment motion.
[SPEECH]: One or two short spoken lines for the character to say, or a concise narration line if the scene calls for narration. This section is required. If user notes include an exact required [SPEECH] line, copy that line into this section. If no words are provided, write natural short dialogue that fits the scene.
[SOUNDS]: Brief non-speech sound cues such as room tone, footsteps, ambience, music bed, or silence.

Rules:
- Keep the whole prompt short enough for a single 3-8 second shot.
- Preserve the subject, location, mood, and story intent from the user input.
- Do not add unrelated characters, captions, subtitles, text overlays, credits, or UI text.
- Do not mention reference images, voice samples, cloning, ID-LoRA, LoRA files, workflow nodes, source prompts, segments, JSON, or instructions.
- Do not output markdown fences, bullets, explanations, or extra labels.
- Never omit [SPEECH] or [SOUNDS].
- The final answer must contain only [VISUAL], [SPEECH], and [SOUNDS]."""


_FLUX_KLEIN_T2I_INSTRUCTIONS = """Create one concise Flux/Klein image prompt from the user input and any available reference context or image ingredients.

Output one normal paragraph, not sections, not markdown, not labels, not explanations.

Prompt style:
- If character and location references are available, start with: Using the provided character reference and location reference, create...
- If only a character reference is available, start with: Using the provided character reference, create...
- If only a location reference is available, start with: Using the provided location reference, create...
- If no visual reference is available, start directly with the shot and subject; do not claim a provided reference exists.
- Use a clear cinematic shot type such as close-up, profile close-up, medium close-up, upper body shot, waist-up shot, three-quarter shot, seated shot, over-the-shoulder shot, or low-angle portrait.
- Use the user's scene/concept notes as the main creative direction.
- Preserve character identity from character references when provided: face, hair, outfit, makeup, and overall identity.
- Preserve location identity from location references when provided: environment, architecture, layout, atmosphere, and major visible setting details.
- Create a new camera angle, new pose, and new composition.
- Do not paste the character into the location image.
- Do not copy the character reference pose, full-body standing pose, studio background, panel layout, crop, camera angle, or lens distance.
- Do not copy the exact location reference camera angle, framing, perspective, or composition.
- Avoid full-body walking or standing shots unless the user specifically asks for them.
- Prefer intimate cinematic compositions when no shot type is specified: close-up, medium close-up, profile, upper body, shallow depth of field, foreground framing, soft bokeh, rim light, atmospheric lighting.
- Keep it cinematic, detailed, visually specific, and practical for image generation.
- Do not include captions, text overlays, dialogue, markdown, labels, bullet points, or section headers.
- Keep the prompt under 120 words.

Good output examples:
Using the provided character reference and location reference, create a close-up profile shot of the woman in the misty forest. Focus on her expression and the intricate details of her crown while the pale trees and fog appear softly blurred in the background. Use a cool moody palette, atmospheric haze, shallow depth of field, dramatic rim lighting, and high cinematic detail.
Using the provided character reference and location reference, create an intimate upper body shot of the woman framed by gnarled forest branches. Preserve her identity, hair, outfit, and crown from the character reference while using the forest reference for the white fibrous trees, mist, and eerie atmosphere. New pose, new camera angle, soft bokeh, high cinematic quality."""


_NANO_B_T2I_INSTRUCTIONS = """Create one concise NanoBanana image prompt from the user input and any available reference context.

Output one normal paragraph, not sections, not markdown, not labels, not explanations.

Prompt style:
- Use advanced Krea 2-style image prompting: concrete subject identity, wardrobe, hair, makeup, pose, camera framing, lens feel, lighting setup, environment, materials, atmosphere, color palette, texture, and cinematic finish.
- Use a clear cinematic shot type such as close-up, profile close-up, medium close-up, upper body shot, waist-up shot, three-quarter shot, seated shot, over-the-shoulder shot, or low-angle portrait.
- Use the user's scene/concept notes as the main creative direction.
- Create a new camera angle, new pose, and new composition.
- Avoid full-body walking or standing shots unless the user specifically asks for them.
- Prefer intimate cinematic compositions when no shot type is specified: close-up, medium close-up, profile, upper body, shallow depth of field, foreground framing, soft bokeh, rim light, atmospheric lighting.
- Keep the prompt visually specific and practical for image generation.
- Do not include captions, text overlays, dialogue, markdown, labels, bullet points, or section headers."""


_FLOW_GPT_T2I_INSTRUCTIONS = """Create one concise browser image prompt for Flow/GPT from the user input and any available reference context.

Output one normal paragraph, not sections, not markdown, not labels, not explanations.

Prompt style:
- Write a direct image-generation prompt that can be pasted into Flow or GPT Image.
- Use the user's scene/concept notes as the main creative direction.
- If character or location references are available, preserve their important identity and setting details without overexplaining the reference system.
- Use concrete subject identity, wardrobe, hair, makeup, pose, camera framing, lens feel, lighting setup, environment, materials, atmosphere, color palette, texture, and cinematic finish.
- Create a clear still-image composition, not a video prompt.
- Create a new camera angle, new pose, and new composition.
- Avoid full-body walking or standing shots unless the user specifically asks for them.
- Prefer intimate cinematic compositions when no shot type is specified: close-up, medium close-up, profile, upper body, shallow depth of field, foreground framing, soft bokeh, rim light, atmospheric lighting.
- Do not include captions, text overlays, dialogue, markdown, labels, bullet points, or section headers.
- Do not include aspect ratio text; GPT Image aspect ratio is appended separately by the browser runner."""


_STANDARD_IMAGE_T2I_INSTRUCTIONS = """You are a text-to-image prompt builder for a music-video storyboard.

The user will provide a JSON scene-card bundle. Your job is to read the JSON and create one polished text-to-image prompt for the selected scene.

Use `selected_scene_number` to choose the scene.

Rules:

* Create one cinematic still-frame prompt, not a video prompt.
* Use advanced Krea 2-style image prompting: concrete subject identity, wardrobe, hair, makeup, pose, camera framing, lens feel, lighting setup, environment, materials, atmosphere, color palette, texture, and cinematic finish.
* Pull the visible subject list only from the selected scene's `subject_refs`.
* Never use subjects from the project catalog, another scene, the song story brief, or the user story arc unless that subject is also present in the selected scene's `subject_refs`.
* If `subject_refs` has more than one subject, every listed subject must be visibly present in the image prompt. Do not drop, merge, hide, imply, or omit any listed subject.
* If `subject_refs` has one subject, describe only that one visible subject. Do not create duplicates, backup singers, crowds, or extra people unless the scene notes explicitly ask for them.
* If `vocal_status.no_character_present` is true, do not include, mention, imply, or describe any mapped character/singer/subject. Use the location, props, environment, objects, atmosphere, and composition instead.
* Pull the setting from `location_ref`.
* Include the mapped subject descriptions and location description when available.
* Use the scene lyrics, lyric section, story beat, song story brief, and user story arc only as visual guidance. Do not quote long lyrics.
* If the scene is a singing scene, show performance energy and emotion as a still expression only. Do not mention lip sync, audio behavior, mouth movement, eye movement, blinking, or animation.
* If the scene is instrumental or no-lip-sync, do not mention singing, lip-syncing, vocals, mouth movement, or no-vocal status.
* Use `shot_type` as the still-frame composition when available.
* If `global_consistency_phrase` is present, include it in the final image prompt. Preserve its wording as much as possible, but lightly adapt grammar if needed so it fits the scene naturally.
* Use `performance_style` and `performance_direction` for body language, wardrobe energy, and genre feel.
* Follow `character_motion_guidance` when present, but express it as still-image pose/action/body language only. Do not describe animation or future movement.
* Use `facial_performance` and `facial_performance_direction` only for still-image facial emotion: eye direction, brows, cheeks, jaw tension, mouth expression, gaze, and pose.
* Do not describe future camera movement, animation, transitions, frame changes, blinking, eye movement, mouth movement, or what happens next.
* Do not mention JSON, IDs, file paths, image names, or metadata.
* Do not include explanations.
* Output only the final image prompt.
* Use natural language, not bracket labels.
* Keep it as one clean paragraph.

When information is missing, infer a fitting cinematic still image from the available subject, setting, tone, and notes."""


def _vrgdg_textfile_path(folder_name, file_name):
    return os.path.join(
        folder_paths.get_output_directory(),
        "VRGDG_TEMP",
        "TextFiles",
        folder_name,
        file_name,
    )


def _default_context_paths():
    return {
        "concept_prompts_path": _vrgdg_textfile_path("ConceptPrompts", "ConceptPrompts.txt"),
        "i2v_motion_notes_path": _vrgdg_textfile_path("I2VMotionNotes", "I2VMotionNotes.txt"),
        "theme_style_path": _vrgdg_textfile_path("themestyle", "themestyle.txt"),
        "story_idea_path": _vrgdg_textfile_path("storyconcept", "storyconcept.txt"),
        "subject_scene_path": _vrgdg_textfile_path("subjectandscenes", "subjectsandscenes.txt"),
    }


def _project_prompt_creator_paths(project_folder):
    folder = os.path.abspath(str(project_folder or "").strip().strip('"'))
    if not folder:
        raise ValueError("Create or load a project before importing Prompt Creator data.")

    context = _context_folder(folder)
    audio_folder = os.path.join(folder, "audio")
    paths = {
        "project_folder": folder,
        "audio_path": _newest_file(audio_folder, (".wav", ".mp3", ".flac", ".m4a", ".ogg", ".mp4")),
        "srt_path": _srt_path(folder),
        "lyric_segments_path": os.path.join(folder, "prompts", "lyric_segments.json"),
        "concept_prompts_path": os.path.join(context, "ConceptPrompts.txt"),
        "i2v_motion_notes_path": os.path.join(context, "I2VMotionNotes.txt"),
        "theme_style_path": os.path.join(context, "themestyle.txt"),
        "story_idea_path": os.path.join(context, "storyconcept.txt"),
        "subject_scene_path": os.path.join(context, "subjectsandscenes.txt"),
    }
    exists = {key: bool(value and os.path.isfile(value)) for key, value in paths.items() if key.endswith("_path")}
    paths["exists"] = exists
    paths["ready"] = bool(exists.get("srt_path") and exists.get("concept_prompts_path"))
    return paths


def _json_file_has_text_values(path):
    if not path or not os.path.isfile(path):
        return False
    try:
        with open(path, "r", encoding="utf-8-sig") as handle:
            data = json.load(handle)
    except Exception:
        try:
            with open(path, "r", encoding="utf-8-sig") as handle:
                return bool(handle.read().strip())
        except Exception:
            return False
    if isinstance(data, dict):
        return any(str(value or "").strip() for value in data.values())
    if isinstance(data, list):
        return any(str(item or "").strip() for item in data)
    return False


def _is_prompt_creator_output_folder(context_folder):
    marker_path = os.path.join(context_folder, "prompt_creator_output.json")
    if os.path.isfile(marker_path):
        try:
            with open(marker_path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
            if str(data.get("type", "") or "") == "vrgdg_prompt_creator_output":
                return True
        except Exception:
            return True

    project_folder = os.path.dirname(context_folder)
    legacy_markers = (
        os.path.join(project_folder, "prompt_creator_draft.json"),
        os.path.join(project_folder, "prompts", "lyric_segments.json"),
        os.path.join(context_folder, "full_lyrics.txt"),
    )
    return any(os.path.isfile(path) for path in legacy_markers)


def _last_prompt_creator_pointer_source(exclude_project_folder=""):
    pointer_path = os.path.join(folder_paths.get_output_directory(), "VRGDG_LastPromptCreatorProject.json")
    if not os.path.isfile(pointer_path):
        return "", ""
    try:
        with open(pointer_path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    except Exception:
        return "", ""
    if str(data.get("type", "") or "") != "vrgdg_last_prompt_creator_project":
        return "", ""
    project_folder = os.path.abspath(str(data.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder or not os.path.isdir(project_folder):
        return "", ""
    exclude = os.path.normcase(os.path.abspath(str(exclude_project_folder or ""))) if exclude_project_folder else ""
    if exclude and os.path.normcase(project_folder) == exclude:
        return "", ""
    raw_context = str(data.get("context_folder", "") or "").strip().strip('"')
    context_folder = os.path.abspath(raw_context) if raw_context else _context_folder(project_folder)
    concept_path = os.path.join(context_folder, "ConceptPrompts.txt")
    srt_path = _srt_path(project_folder)
    if not os.path.isfile(concept_path) or not os.path.isfile(srt_path):
        return "", ""
    if not _json_file_has_text_values(concept_path):
        return "", ""
    return project_folder, context_folder


def _latest_prompt_creator_source(exclude_project_folder=""):
    pointer_project, pointer_context = _last_prompt_creator_pointer_source(exclude_project_folder)
    if pointer_project and pointer_context:
        return pointer_project, pointer_context

    output_dir = folder_paths.get_output_directory()
    exclude = os.path.normcase(os.path.abspath(str(exclude_project_folder or ""))) if exclude_project_folder else ""
    candidates = []
    for root, dirs, _files in os.walk(output_dir):
        if os.path.basename(root) != "project_context":
            continue
        project_folder = os.path.dirname(root)
        if exclude and os.path.normcase(os.path.abspath(project_folder)) == exclude:
            continue
        concept_path = os.path.join(root, "ConceptPrompts.txt")
        srt_path = _srt_path(project_folder)
        if not os.path.isfile(concept_path) or not os.path.isfile(srt_path):
            continue
        if not _is_prompt_creator_output_folder(root):
            continue
        if not _json_file_has_text_values(concept_path):
            continue
        motion_path = os.path.join(root, "I2VMotionNotes.txt")
        has_motion = _json_file_has_text_values(motion_path)
        related = [
            concept_path,
            srt_path,
            motion_path,
            os.path.join(root, "themestyle.txt"),
            os.path.join(root, "storyconcept.txt"),
            os.path.join(root, "subjectsandscenes.txt"),
        ]
        newest = max((os.path.getmtime(path) for path in related if os.path.isfile(path)), default=0)
        candidates.append((1 if has_motion else 0, newest, project_folder, root))
    if not candidates:
        raise ValueError("No previous Prompt Creator output was found. Run Prompt Creator first, then import it into this project.")
    candidates.sort(key=lambda item: (item[0], item[1]), reverse=True)
    return candidates[0][2], candidates[0][3]


def _copy_prompt_creator_outputs_from_source(project_folder, source_project_folder=""):
    target = os.path.abspath(str(project_folder or "").strip().strip('"'))
    if not target:
        raise ValueError("Create or load a project before importing Prompt Creator data.")
    os.makedirs(target, exist_ok=True)
    os.makedirs(_context_folder(target), exist_ok=True)
    os.makedirs(os.path.join(target, "audio"), exist_ok=True)
    if source_project_folder:
        source_project = os.path.abspath(str(source_project_folder or "").strip().strip('"'))
        source_context = _context_folder(source_project)
        if os.path.normcase(source_project) == os.path.normcase(target):
            return _project_prompt_creator_paths(target)
        if not os.path.isfile(os.path.join(source_context, "ConceptPrompts.txt")) or not os.path.isfile(_srt_path(source_project)):
            raise ValueError("The selected Prompt Creator project does not have saved ConceptPrompts.txt and builder_segments.srt outputs.")
    else:
        source_project, source_context = _latest_prompt_creator_source(target)
    copied = {}
    for filename in ("ConceptPrompts.txt", "I2VMotionNotes.txt", "themestyle.txt", "storyconcept.txt", "subjectsandscenes.txt", "subject.txt", "full_lyrics.txt"):
        source_path = os.path.join(source_context, filename)
        if os.path.isfile(source_path):
            copied[filename] = _copy_file_if_exists(source_path, os.path.join(_context_folder(target), filename))
    source_lyrics = os.path.join(source_project, "prompts", "lyric_segments.json")
    if os.path.isfile(source_lyrics):
        copied["lyric_segments.json"] = _copy_file_if_exists(source_lyrics, os.path.join(_prompts_folder(target), "lyric_segments.json"))
    source_srt = _srt_path(source_project)
    if os.path.isfile(source_srt):
        copied["builder_segments.srt"] = _copy_file_if_exists(source_srt, _srt_path(target))
    source_audio = _newest_file(os.path.join(source_project, "audio"), (".wav", ".mp3", ".flac", ".m4a", ".ogg", ".mp4"))
    if source_audio:
        if os.path.splitext(source_audio)[1].lower() == ".m4a":
            copied["audio"] = _convert_audio_to_wav(source_audio, os.path.join(target, "audio", "project_audio.wav"))
        else:
            copied["audio"] = _copy_file_if_exists(source_audio, os.path.join(target, "audio", os.path.basename(source_audio)))
    result = _project_prompt_creator_paths(target)
    result["source_project_folder"] = source_project
    result["copied"] = copied
    return result


def _copy_latest_prompt_creator_outputs(project_folder):
    return _copy_prompt_creator_outputs_from_source(project_folder, "")


def _newest_file(folder, extensions):
    if not os.path.isdir(folder):
        return ""
    candidates = []
    for name in os.listdir(folder):
        path = os.path.join(folder, name)
        if os.path.isfile(path) and name.lower().endswith(tuple(extensions)):
            candidates.append(path)
    if not candidates:
        return ""
    return max(candidates, key=lambda path: os.path.getmtime(path))


def _default_audio_srt_paths():
    repo_dir = os.path.dirname(os.path.abspath(__file__))
    srt_folder = os.path.join(repo_dir, "srt_files")
    legacy_srt_folder = os.path.join(repo_dir, "SRT_Files")
    audio_folder = os.path.join(folder_paths.get_output_directory(), "VRGDG_AudioFiles")
    srt_path = _newest_file(srt_folder, (".srt",)) or _newest_file(legacy_srt_folder, (".srt",))
    return {
        "audio_path": _newest_file(audio_folder, (".wav", ".mp3", ".flac", ".m4a", ".ogg")),
        "srt_path": srt_path,
        "audio_folder": audio_folder,
        "srt_folder": srt_folder,
    }


def _llm_multi_choices():
    try:
        from .LLM import VRGDG_LLM_Multi
    except Exception as exc:
        raise RuntimeError(f"Could not load VRGDG LLM Multi choices: {exc}") from exc
    provider_models = getattr(VRGDG_LLM_Multi, "PROVIDER_MODELS", {}) or {}
    default_model = getattr(VRGDG_LLM_Multi, "DEFAULT_MODEL", {}) or {}
    label_map = {
        "openai": "OpenAI",
        "anthropic": "Anthropic",
        "google": "Google Gemini",
        "grok": "Grok",
        "deepseek": "DeepSeek",
        "openrouter": "OpenRouter",
        "apifreellm": "APIFreeLLM",
    }
    providers = []
    for provider, models in provider_models.items():
        clean_provider = str(provider or "").strip().lower()
        if not clean_provider or clean_provider == "xai":
            continue
        model_list = [str(model or "").strip() for model in (models or []) if str(model or "").strip()]
        providers.append({
            "id": clean_provider,
            "label": label_map.get(clean_provider, clean_provider),
            "models": model_list,
            "default_model": str(default_model.get(clean_provider) or (model_list[0] if model_list else "")),
        })
    return {"providers": providers}


def _test_llm_api(payload):
    try:
        from .LLM import VRGDG_LLM_Multi
    except Exception as exc:
        raise RuntimeError(f"Could not load LLM API runner: {exc}") from exc
    provider = str(payload.get("provider") or payload.get("llm_api_provider") or "openai").strip().lower()
    if provider == "xai":
        provider = "grok"
    model = str(payload.get("model") or payload.get("llm_api_model") or "").strip()
    api_key = str(payload.get("api_key") or payload.get("llm_api_key") or "").strip()
    custom_model = str(payload.get("custom_model") or "").strip()
    if not api_key:
        raise ValueError("API key is missing.")
    if not provider:
        raise ValueError("Provider is missing.")
    prompt = str(payload.get("prompt") or "Reply with OK only.").strip() or "Reply with OK only."
    runner = VRGDG_LLM_Multi()
    text, used_provider, used_model, status, _image = runner.generate_text(
        api_key=api_key,
        provider=provider,
        model=model,
        prompt=prompt,
        custom_model=custom_model,
    )
    status = str(status or "").strip()
    if status.lower().startswith("error"):
        raise RuntimeError(status)
    text = str(text or "").strip()
    if not text:
        raise RuntimeError("LLM API returned empty text.")
    return {
        "text": text[:1000],
        "used_provider": used_provider,
        "used_model": used_model,
        "status": status or "ok",
    }


def _open_native_picker(kind):
    try:
        return _open_tk_picker(kind)
    except Exception as tk_exc:
        try:
            return _open_powershell_picker(kind)
        except Exception as ps_exc:
            raise RuntimeError(f"Native file dialog is not available. tkinter error: {tk_exc}; PowerShell error: {ps_exc}")


def _open_tk_picker(kind):
    try:
        import tkinter as tk
        from tkinter import filedialog
    except Exception as exc:
        raise RuntimeError(f"Native file dialog is not available: {exc}")

    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    try:
        if kind == "audio":
            path = filedialog.askopenfilename(
                title="Choose audio file",
                filetypes=[
                    ("Audio files", "*.wav *.mp3 *.flac *.m4a *.ogg"),
                    ("All files", "*.*"),
                ],
            )
        elif kind == "srt":
            path = filedialog.askopenfilename(
                title="Choose SRT file",
                filetypes=[("SRT files", "*.srt"), ("All files", "*.*")],
            )
        elif kind == "video":
            path = filedialog.askopenfilename(
                title="Choose video file",
                filetypes=[
                    ("Video files", "*.mp4 *.mov *.mkv *.webm *.avi"),
                    ("All files", "*.*"),
                ],
            )
        elif kind == "gguf":
            path = filedialog.askopenfilename(
                title="Choose GGUF model file",
                filetypes=[("GGUF model files", "*.gguf"), ("All files", "*.*")],
            )
        elif kind in {"project_folder", "project_root"}:
            title = "Choose projects root folder" if kind == "project_root" else "Choose project folder"
            path = filedialog.askdirectory(title=title)
        else:
            raise ValueError(f"Unknown picker type: {kind}")
        return str(path or "")
    finally:
        root.destroy()


def _open_powershell_picker(kind):
    if kind == "audio":
        script = r"""
Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object System.Windows.Forms.OpenFileDialog
$dialog.Title = 'Choose audio file'
$dialog.Filter = 'Audio files (*.wav;*.mp3;*.flac;*.m4a;*.ogg)|*.wav;*.mp3;*.flac;*.m4a;*.ogg|All files (*.*)|*.*'
if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Write($dialog.FileName) }
"""
    elif kind == "srt":
        script = r"""
Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object System.Windows.Forms.OpenFileDialog
$dialog.Title = 'Choose SRT file'
$dialog.Filter = 'SRT files (*.srt)|*.srt|All files (*.*)|*.*'
if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Write($dialog.FileName) }
"""
    elif kind == "image":
        script = r"""
Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object System.Windows.Forms.OpenFileDialog
$dialog.Title = 'Choose image file'
$dialog.Filter = 'Image files (*.png;*.jpg;*.jpeg;*.webp)|*.png;*.jpg;*.jpeg;*.webp|All files (*.*)|*.*'
if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Write($dialog.FileName) }
"""
    elif kind == "video":
        script = r"""
Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object System.Windows.Forms.OpenFileDialog
$dialog.Title = 'Choose video file'
$dialog.Filter = 'Video files (*.mp4;*.mov;*.mkv;*.webm;*.avi)|*.mp4;*.mov;*.mkv;*.webm;*.avi|All files (*.*)|*.*'
if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Write($dialog.FileName) }
"""
    elif kind == "gguf":
        script = r"""
Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object System.Windows.Forms.OpenFileDialog
$dialog.Title = 'Choose GGUF model file'
$dialog.Filter = 'GGUF model files (*.gguf)|*.gguf|All files (*.*)|*.*'
if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Write($dialog.FileName) }
"""
    elif kind == "project_folder":
        script = r"""
Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = 'Choose project folder'
if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Write($dialog.SelectedPath) }
"""
    elif kind == "project_root":
        script = r"""
Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = 'Choose projects root folder'
if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Write($dialog.SelectedPath) }
"""
    else:
        raise ValueError(f"Unknown picker type: {kind}")

    result = subprocess.run(
        ["powershell", "-NoProfile", "-STA", "-Command", script],
        capture_output=True,
        text=True,
        errors="replace",
        timeout=300,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError((result.stderr or result.stdout or "PowerShell picker failed.").strip())
    return result.stdout.strip()


def _resolve_existing_file(raw_path, label="file"):
    text = str(raw_path or "").strip().strip('"')
    if not text:
        raise ValueError(f"{label} path is empty.")
    path = os.path.abspath(text)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"{label} was not found: {path}")
    return path


def _safe_project_name(value):
    text = str(value or "").strip()
    text = re.sub(r"[^A-Za-z0-9_. -]+", "_", text).strip(" ._")
    return text or "VRGDG_MusicVideoBuilder"


def _default_project_folder(audio_path, project_name):
    parent = os.path.dirname(audio_path)
    stem = os.path.splitext(os.path.basename(audio_path))[0]
    name = _safe_project_name(project_name or f"{stem}_builder")
    return os.path.join(parent, name)


def _unique_folder_path(path):
    folder = os.path.abspath(str(path or "").strip().strip('"'))
    if not folder:
        raise ValueError("Project folder is empty.")
    if not os.path.exists(folder):
        return folder
    for index in range(2, 10000):
        candidate = f"{folder}_{index:03d}"
        if not os.path.exists(candidate):
            return candidate
    raise RuntimeError(f"Could not create a unique project folder for: {folder}")


def _project_target_from_payload(payload, preferred_key="project_folder"):
    raw = str(payload.get(preferred_key, "") or "").strip().strip('"')
    if not raw:
        raw = str(payload.get("project_name", "") or "").strip().strip('"')
    if not raw:
        raw = f"VRGDG_Project_{time.strftime('%Y%m%d_%H%M%S')}"
    if os.path.isabs(raw) or os.path.dirname(raw):
        return os.path.abspath(raw)
    project_root = str(payload.get("project_root", "") or "").strip().strip('"')
    if project_root:
        if not os.path.isabs(project_root):
            raise ValueError("Custom project root must be a full absolute folder path.")
        return os.path.join(os.path.abspath(project_root), _safe_project_name(raw))
    return os.path.join(folder_paths.get_output_directory(), _safe_project_name(raw))


def _new_builder_project(payload):
    target = _unique_folder_path(_project_target_from_payload(payload, "project_folder"))
    os.makedirs(target, exist_ok=True)
    os.makedirs(_images_folder(target), exist_ok=True)
    os.makedirs(_prompts_folder(target), exist_ok=True)
    os.makedirs(_context_folder(target), exist_ok=True)
    os.makedirs(os.path.join(target, "latents"), exist_ok=True)
    for filename in ("ConceptPrompts.txt", "I2VMotionNotes.txt", "themestyle.txt", "storyconcept.txt", "subjectsandscenes.txt", "full_lyrics.txt"):
        path = os.path.join(_context_folder(target), filename)
        if not os.path.exists(path):
            with open(path, "w", encoding="utf-8") as handle:
                handle.write("")
    return {
        "project_folder": target,
        "session_path": _session_path(target),
        "srt_path": _srt_path(target),
        "images_folder": _images_folder(target),
        "prompts_folder": _prompts_folder(target),
        "context_folder": _context_folder(target),
        "concept_prompts_path": os.path.join(_context_folder(target), "ConceptPrompts.txt"),
        "i2v_motion_notes_path": os.path.join(_context_folder(target), "I2VMotionNotes.txt"),
        "theme_style_path": os.path.join(_context_folder(target), "themestyle.txt"),
        "story_idea_path": os.path.join(_context_folder(target), "storyconcept.txt"),
        "subject_scene_path": os.path.join(_context_folder(target), "subjectsandscenes.txt"),
    }


def _save_builder_project_as(payload):
    source = os.path.abspath(str(payload.get("source_project_folder", "") or "").strip().strip('"'))
    if not source:
        source = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))

    target = _project_target_from_payload(payload, "target_project_folder")
    target = _unique_folder_path(target)
    if source and os.path.isdir(source):
        try:
            common = os.path.commonpath([source, target])
        except ValueError:
            common = ""
    else:
        common = ""
    if source and common == source:
        raise ValueError("Save Project As target cannot be inside the current project folder.")

    keep = _normalize_branch_keep(payload)
    os.makedirs(target, exist_ok=True)
    os.makedirs(_images_folder(target), exist_ok=True)
    os.makedirs(_prompts_folder(target), exist_ok=True)
    os.makedirs(_context_folder(target), exist_ok=True)
    if source and os.path.isdir(source):
        _copy_project_tree(source, target, keep)
        try:
            SceneLatentManager.copy_latents_folder(source, target)
        except Exception as exc:
            print(f"[VRGDG Latent] Failed to copy latents during branch: {exc}")

    session = payload.get("session") if isinstance(payload.get("session"), dict) else {}
    session = _apply_branch_keep_to_session(session, keep)
    _prune_unkept_project_folders(target, keep)
    segments = session.get("segments", [])
    if not isinstance(segments, list):
        segments = []
        session["segments"] = segments
    overlay_segments = session.get("overlay_segments", [])
    if not isinstance(overlay_segments, list):
        overlay_segments = []
        session["overlay_segments"] = overlay_segments
    overlay_segments = _assign_overlay_scene_numbers(overlay_segments)
    session["overlay_segments"] = overlay_segments
    audio_raw = str(payload.get("audio_path", "") or "").strip().strip('"')
    audio_path = _resolve_existing_file(audio_raw, "Audio file") if audio_raw else ""
    audio_path, session = _snapshot_project_assets(target, session, audio_path, source)
    session = _copy_session_assets_to_project(target, session)
    session = _rebase_project_owned_paths(target, source, session)
    if keep.get("videos"):
        session = _relocate_external_minimax_stage_media(session, target)
    segments = session.get("segments") if isinstance(session.get("segments"), list) else []
    session = {
        **session,
        "audio_path": audio_path,
        "project_folder": target,
        "updated": time.time(),
        "segments": segments,
    }

    with open(_session_path(target), "w", encoding="utf-8") as handle:
        json.dump(session, handle, indent=2, ensure_ascii=False)
        handle.write("\n")
    with open(_srt_path(target), "w", encoding="utf-8") as handle:
        handle.write(_segments_to_srt(segments))
    scene_notes_path = _write_scene_notes_json(target, segments)
    if keep.get("mappings"):
        _save_reference_descriptions(target, session)
    if keep.get("notes") or keep.get("prompts"):
        _save_project_context_files(target, session)
    return {
        "project_folder": target,
        "session_path": _session_path(target),
        "srt_path": _srt_path(target),
        "scene_notes_path": scene_notes_path,
        "images_folder": _images_folder(target),
        "prompts_folder": _prompts_folder(target),
        "context_folder": _context_folder(target),
        "session": session,
    }


def _session_path(project_folder):
    return os.path.join(project_folder, "vrgdg_builder_session.json")


def _atomic_write_text(path, content, encoding="utf-8"):
    """Replace one project file atomically, leaving the previous file intact on error."""
    path = os.path.abspath(path)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{os.path.basename(path)}.", suffix=".tmp", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "w", encoding=encoding, newline="") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


def _atomic_write_json(path, value):
    _atomic_write_text(path, json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def _fallback_project_context_text(filename, session):
    """Build portable context from canonical session state when no legacy file exists."""
    session = session if isinstance(session, dict) else {}
    story_layer = session.get("builder_story_layer") if isinstance(session.get("builder_story_layer"), dict) else {}
    storyboard = session.get("builder_storyboard_defaults") if isinstance(session.get("builder_storyboard_defaults"), dict) else {}
    segments = session.get("segments") if isinstance(session.get("segments"), list) else []
    refs = session.get("flux_reference_builder") if isinstance(session.get("flux_reference_builder"), dict) else {}

    if filename == "storyconcept.txt":
        lines = []
        for label, key in (
            ("Overall story idea", "overall_story_idea"),
            ("Story arc", "user_story_arc"),
            ("Song/story brief", "song_story_brief"),
        ):
            value = str(story_layer.get(key) or "").strip()
            if value:
                lines.append(f"{label}: {value}")
        if not lines:
            for index, segment in enumerate(segments, start=1):
                if not isinstance(segment, dict):
                    continue
                value = str(segment.get("scene_summary") or segment.get("timeline_note") or segment.get("t2i_prompt") or "").strip()
                if value:
                    lines.append(f"Scene {index}: {value}")
        return "\n\n".join(lines) or "Use the saved scene prompts, lyrics, and timeline order as the canonical project story."

    if filename == "subjectsandscenes.txt":
        lines = []
        for kind, items_key in (("Subject", "subjects"), ("Location", "locations")):
            items = refs.get(items_key) if isinstance(refs.get(items_key), list) else []
            for index, item in enumerate(items, start=1):
                if not isinstance(item, dict):
                    continue
                name = str(item.get("name") or f"{kind} {index}").strip()
                description = str(item.get("description") or "").strip()
                lines.append(f"{kind}: {name}" + (f"\n{description}" if description else ""))
        for map_name in ("subject_scene_map", "performer_scene_map", "scene_map", "scene_trigger_map"):
            mapping = refs.get(map_name)
            if isinstance(mapping, dict) and mapping:
                lines.append(f"{map_name}:\n" + json.dumps(mapping, indent=2, ensure_ascii=False))
        return "\n\n".join(lines) or "No subjects or locations are currently mapped; use the saved scene records as canonical scene context."

    if filename == "themestyle.txt":
        lines = []
        for label, source, key in (
            ("Image world style", story_layer, "image_world_style"),
            ("Custom style direction", story_layer, "image_custom_style_direction"),
            ("Image aesthetic", storyboard, "image_aesthetic"),
            ("Video style", storyboard, "video_style"),
            ("Custom video style", storyboard, "video_style_custom"),
            ("Performance style", storyboard, "performance_style"),
            ("Global consistency", storyboard, "global_consistency_phrase"),
        ):
            value = str(source.get(key) or "").strip()
            if value:
                lines.append(f"{label}: {value}")
        return "\n".join(lines) or "Preserve the visual style, wardrobe, lighting, materials, and continuity established by the saved scene prompts and reference images."
    return ""


def _save_project_context_files(project_folder, session):
    context_files = session.get("project_context_files") if isinstance(session, dict) else None
    if not isinstance(context_files, dict):
        return []
    context = _context_folder(project_folder)
    saved = []
    for filename in ("storyconcept.txt", "subjectsandscenes.txt", "themestyle.txt"):
        value = str(context_files.get(filename, "") or "").strip()
        path = os.path.join(context, filename)
        # A caller that did not manage to read a context file must never erase
        # an existing non-empty project brief during autosave.
        if not value and os.path.isfile(path):
            with open(path, "r", encoding="utf-8-sig", errors="replace") as handle:
                value = handle.read().strip()
        if not value:
            value = _fallback_project_context_text(filename, session)
        _atomic_write_text(path, value.rstrip() + "\n")
        saved.append(path)
    return saved


def _validate_saved_project(project_folder, session, context_paths):
    required = [_session_path(project_folder), _srt_path(project_folder)]
    required.extend(context_paths or [])
    refs = session.get("flux_reference_builder") if isinstance(session, dict) else None
    if isinstance(refs, dict):
        required.append(os.path.join(project_folder, "subject_location", "reference_descriptions.json"))
    missing = [path for path in required if not os.path.isfile(path)]
    if missing:
        raise IOError("Project save validation failed; missing files: " + ", ".join(missing))
    empty = [os.path.basename(path) for path in (context_paths or []) if os.path.getsize(path) == 0]
    if empty:
        raise IOError("Project save validation failed; empty context files: " + ", ".join(empty))
    if isinstance(refs, dict):
        with open(required[-1], "r", encoding="utf-8-sig") as handle:
            manifest = json.load(handle)
        if not isinstance(manifest, dict) or not isinstance(manifest.get("subjects"), list) or not isinstance(manifest.get("locations"), list):
            raise IOError("Project save validation failed; reference-builder manifest is invalid.")
        expected = json.loads(json.dumps(refs, ensure_ascii=False))
        expected.setdefault("subjects", [])
        expected.setdefault("locations", [])
        if manifest != expected:
            raise IOError("Project save validation failed; reference-builder manifest does not match the saved session state.")


def _scene_notes_path(project_folder):
    return os.path.join(project_folder, "SceneNotes.json")


def _srt_path(project_folder):
    return os.path.join(project_folder, "builder_segments.srt")


def _render_logs_folder(project_folder):
    return os.path.join(project_folder, "render_logs")


def _render_log_duration_text(milliseconds):
    try:
        total_seconds = max(0, int(round(float(milliseconds or 0) / 1000.0)))
    except (TypeError, ValueError):
        total_seconds = 0
    hours, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    if hours:
        return f"{hours}h {minutes:02d}m {seconds:02d}s"
    if minutes:
        return f"{minutes}m {seconds:02d}s"
    return f"{seconds}s"


def _render_log_text(log):
    log = log if isinstance(log, dict) else {}
    summary = log.get("summary") if isinstance(log.get("summary"), dict) else {}
    scenes = log.get("scenes") if isinstance(log.get("scenes"), list) else []
    lines = [
        "VRGDG Video Builder Render Log",
        "=" * 32,
        f"Session: {log.get('id', '')}",
        f"Status: {str(log.get('status') or 'unknown').upper()}",
        f"Project: {log.get('project_folder', '')}",
        f"Mode: {log.get('mode_label') or log.get('scene_scope') or 'Render All'}",
        f"Started: {log.get('started_at', '')}",
        f"Finished: {log.get('ended_at', '')}",
        "",
        "Summary",
        "-" * 32,
        f"Total wall time: {_render_log_duration_text(summary.get('total_ms', log.get('total_ms', 0)))}",
        f"Active scene rendering: {_render_log_duration_text(summary.get('render_ms', 0))}",
        f"Between-render time: {_render_log_duration_text(summary.get('between_render_ms', 0))}",
        f"Setup time: {_render_log_duration_text(summary.get('setup_ms', 0))}",
        f"Final stitching: {_render_log_duration_text(summary.get('stitch_ms', 0))}",
        f"Other overhead: {_render_log_duration_text(summary.get('overhead_ms', 0))}",
        f"Scenes completed: {int(summary.get('completed_scenes', 0) or 0)}/{int(summary.get('target_scenes', len(scenes)) or 0)}",
        f"Existing scenes skipped: {int(summary.get('skipped_existing_scenes', 0) or 0)}",
        f"Average render per completed scene: {_render_log_duration_text(summary.get('average_render_ms', 0))}",
    ]
    if log.get("final_video_path"):
        lines.append(f"Final video: {log.get('final_video_path')}")
    if log.get("error"):
        lines.extend(["", f"Error: {log.get('error')}"])
    lines.extend(["", "Scene Details", "-" * 32])
    if not scenes:
        lines.append("No scene render timing has been recorded yet.")
    for scene in scenes:
        if not isinstance(scene, dict):
            continue
        label = scene.get("label") or f"Scene {scene.get('scene_number', '?')}"
        lines.extend([
            f"{label} [{str(scene.get('status') or 'pending').upper()}]",
            f"  Total scene step: {_render_log_duration_text(scene.get('total_ms', 0))}",
            f"  Preparation: {_render_log_duration_text(scene.get('preparation_ms', 0))}",
            f"  Video render: {_render_log_duration_text(scene.get('render_ms', 0))}",
            f"  Post-processing/cleanup: {_render_log_duration_text(scene.get('post_ms', 0))}",
            f"  Time since previous render: {_render_log_duration_text(scene.get('gap_before_render_ms', 0))}",
        ])
        if scene.get("video_path"):
            lines.append(f"  Video: {scene.get('video_path')}")
        if scene.get("error"):
            lines.append(f"  Error: {scene.get('error')}")
    return "\n".join(lines).rstrip() + "\n"


def _save_builder_render_log(payload):
    project_folder_raw = str(payload.get("project_folder", "") or "").strip().strip('"')
    if not project_folder_raw:
        raise ValueError("Project folder is required before saving a render log.")
    project_folder = os.path.abspath(project_folder_raw)
    os.makedirs(project_folder, exist_ok=True)
    log = payload.get("log") if isinstance(payload.get("log"), dict) else {}
    if not log:
        raise ValueError("Render log data is empty.")
    log_id = re.sub(r"[^A-Za-z0-9._-]+", "_", str(log.get("id") or "").strip()).strip("._")
    if not log_id:
        log_id = f"render_{time.strftime('%Y%m%d_%H%M%S')}"
    log = {**log, "id": log_id, "project_folder": project_folder}
    logs_folder = _render_logs_folder(project_folder)
    os.makedirs(logs_folder, exist_ok=True)
    json_path = os.path.join(logs_folder, f"{log_id}.json")
    text_path = os.path.join(logs_folder, f"{log_id}.txt")
    log["report_json_path"] = json_path
    log["report_text_path"] = text_path
    json_temp = json_path + ".tmp"
    text_temp = text_path + ".tmp"
    with open(json_temp, "w", encoding="utf-8") as handle:
        json.dump(log, handle, indent=2, ensure_ascii=False)
        handle.write("\n")
    with open(text_temp, "w", encoding="utf-8") as handle:
        handle.write(_render_log_text(log))
    os.replace(json_temp, json_path)
    os.replace(text_temp, text_path)

    session_path = _session_path(project_folder)
    if os.path.isfile(session_path):
        try:
            with open(session_path, "r", encoding="utf-8-sig") as handle:
                session = json.load(handle)
            if not isinstance(session, dict):
                session = {}
        except Exception:
            session = {}
        logs = session.get("render_logs") if isinstance(session.get("render_logs"), list) else []
        logs = [item for item in logs if isinstance(item, dict) and item.get("id") != log_id]
        logs.append(log)
        session["render_logs"] = logs[-20:]
        session["active_render_log_id"] = log_id if log.get("status") == "running" else ""
        session["updated"] = time.time()
        session_temp = session_path + ".render-log.tmp"
        with open(session_temp, "w", encoding="utf-8") as handle:
            json.dump(session, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        os.replace(session_temp, session_path)
    return {
        "log": log,
        "report_json_path": json_path,
        "report_text_path": text_path,
    }


def _images_folder(project_folder):
    return os.path.join(project_folder, "zimage_approved")


def _prompts_folder(project_folder):
    return os.path.join(project_folder, "prompts")


def _context_folder(project_folder):
    return os.path.join(project_folder, "project_context")


def _save_canonical_full_lyrics(project_folder, lyrics):
    """Persist the user's complete source lyrics without timeline reconstruction."""
    text = str(lyrics or "").strip()
    if not text:
        return ""
    context_folder = _context_folder(project_folder)
    os.makedirs(context_folder, exist_ok=True)
    path = os.path.join(context_folder, "full_lyrics.txt")
    temporary_path = path + ".tmp"
    with open(temporary_path, "w", encoding="utf-8") as handle:
        handle.write(text)
        handle.write("\n")
    os.replace(temporary_path, path)
    return path


_BUILDER_INSTRUCTION_DEFAULTS = {
    "flux_klein_t2i": _FLUX_KLEIN_T2I_INSTRUCTIONS,
    "flow_gpt_t2i": _FLOW_GPT_T2I_INSTRUCTIONS,
    "ernie_t2i": _STANDARD_IMAGE_T2I_INSTRUCTIONS,
    "id_lora": _ID_LORA_INSTRUCTIONS,
    "ingredients": _T2V_INSTRUCTIONS,
    "i2v": _I2V_INSTRUCTIONS,
    "krea2_t2i": _STANDARD_IMAGE_T2I_INSTRUCTIONS,
    "minimax_h3_image_to_video": MINIMAX_H3_IMAGE_TO_VIDEO_INSTRUCTIONS,
    "minimax_h3_frame_continuity": MINIMAX_H3_FRAME_CONTINUITY_INSTRUCTIONS,
    "minimax_h3_image_reference_to_video": MINIMAX_H3_IMAGE_REFERENCE_TO_VIDEO_INSTRUCTIONS,
    "minimax_h3_reference_to_video": MINIMAX_H3_REFERENCE_TO_VIDEO_INSTRUCTIONS,
    "minimax_h3_text_to_video": MINIMAX_H3_TEXT_TO_VIDEO_INSTRUCTIONS,
    "minimax_h3_video_to_video": MINIMAX_H3_VIDEO_TO_VIDEO_INSTRUCTIONS,
    "nano_b_t2i": _NANO_B_T2I_INSTRUCTIONS,
    "rtv": _T2V_INSTRUCTIONS,
    "t2v": _T2V_INSTRUCTIONS,
    "zimage_t2i": _STANDARD_IMAGE_T2I_INSTRUCTIONS,
}
for _minimax_mode, _instructions in MINIMAX_H3_SHORT_FILM_GUIDED_INSTRUCTIONS_BY_MODE.items():
    _BUILDER_INSTRUCTION_DEFAULTS[f"minimax_h3_short_film_guided_{_minimax_mode}"] = _instructions
for _minimax_mode, _instructions in MINIMAX_H3_SHORT_FILM_CUSTOM_INSTRUCTIONS_BY_MODE.items():
    _BUILDER_INSTRUCTION_DEFAULTS[f"minimax_h3_short_film_custom_{_minimax_mode}"] = _instructions

_BUILDER_INSTRUCTION_LABELS = {
    "flux_klein_t2i": "Flux/Klein Text to Image",
    "flow_gpt_t2i": "Flow/GPT Text to Image",
    "ernie_t2i": "Ernie Text to Image",
    "id_lora": "ID-LoRA I2V",
    "ingredients": "Ingredients to Video",
    "i2v": "Image to Video",
    "krea2_t2i": "Krea 2 Text to Image",
    "minimax_h3_image_to_video": "MiniMax H3 Image to Video",
    "minimax_h3_frame_continuity": "MiniMax H3 Frame-to-Frame Continuity",
    "minimax_h3_image_reference_to_video": "MiniMax H3 Image + Reference to Video",
    "minimax_h3_reference_to_video": "MiniMax H3 Reference to Video",
    "minimax_h3_text_to_video": "MiniMax H3 Text to Video",
    "minimax_h3_video_to_video": "MiniMax H3 Video to Video",
    "nano_b_t2i": "Nano B Text to Image",
    "rtv": "Reference to Video",
    "t2v": "Text to Video",
    "zimage_t2i": "ZImage Text to Image",
}
for _minimax_mode in MINIMAX_H3_SHORT_FILM_GUIDED_INSTRUCTIONS_BY_MODE:
    _mode_label = _minimax_mode.replace("_", " ").title()
    _BUILDER_INSTRUCTION_LABELS[f"minimax_h3_short_film_guided_{_minimax_mode}"] = f"MiniMax H3 Guided Short Film - {_mode_label}"
    _BUILDER_INSTRUCTION_LABELS[f"minimax_h3_short_film_custom_{_minimax_mode}"] = f"MiniMax H3 Fully Custom Short Film - {_mode_label}"

_BUILDER_INSTRUCTION_PRESET_GROUPS = {
    "ernie_t2i": "standard_image_t2i",
    "krea2_t2i": "standard_image_t2i",
    "zimage_t2i": "standard_image_t2i",
    "flow_gpt_t2i": "reference_image_t2i",
    "flux_klein_t2i": "reference_image_t2i",
    "nano_b_t2i": "reference_image_t2i",
}

_BUILDER_INSTRUCTION_PRESET_GROUP_LABELS = {
    "standard_image_t2i": "Standard Image T2I",
    "reference_image_t2i": "Reference/Image Edit T2I",
}


def _safe_builder_instruction_key(value):
    key = re.sub(r"[^a-z0-9_]+", "_", str(value or "").strip().lower()).strip("_")
    if key not in _BUILDER_INSTRUCTION_DEFAULTS:
        raise ValueError(f"Unknown Builder instruction key: {value}")
    return key


def _safe_builder_scene_id(value):
    scene_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value or "").strip()).strip("._-")
    return scene_id[:120]


def _safe_preset_name(value):
    text = str(value or "").strip()
    text = re.sub(r"[^A-Za-z0-9_. -]+", "_", text).strip(" ._")
    if not text:
        raise ValueError("Preset name is empty.")
    return text[:80]


def _builder_instruction_folder(project_folder):
    return os.path.join(_context_folder(project_folder), "custom_builder_instructions")


def _builder_instruction_all_scenes_path(project_folder, key):
    return os.path.join(_builder_instruction_folder(project_folder), f"{_safe_builder_instruction_key(key)}.txt")


def _builder_instruction_scene_path(project_folder, key, scene_id):
    safe_scene = _safe_builder_scene_id(scene_id)
    if not safe_scene:
        raise ValueError("Scene id is missing.")
    return os.path.join(_builder_instruction_folder(project_folder), "scenes", safe_scene, f"{_safe_builder_instruction_key(key)}.txt")


def _builder_instruction_preset_root():
    return os.path.join(folder_paths.get_output_directory(), "VRGDG_LLM_Instruction_Presets", "builder")


def _builder_instruction_preset_group(key):
    safe_key = _safe_builder_instruction_key(key)
    return _BUILDER_INSTRUCTION_PRESET_GROUPS.get(safe_key, safe_key)


def _builder_instruction_preset_group_label(key):
    group = _builder_instruction_preset_group(key)
    return _BUILDER_INSTRUCTION_PRESET_GROUP_LABELS.get(group, _BUILDER_INSTRUCTION_LABELS.get(group, group))


def _builder_instruction_preset_path(key, name):
    return os.path.join(_builder_instruction_preset_root(), _builder_instruction_preset_group(key), f"{_safe_preset_name(name)}.txt")


def _legacy_builder_instruction_preset_path(key, name):
    return os.path.join(_builder_instruction_preset_root(), _safe_builder_instruction_key(key), f"{_safe_preset_name(name)}.txt")


def _read_optional_text_file(path):
    if not path or not os.path.isfile(path):
        return ""
    with open(path, "r", encoding="utf-8-sig", errors="replace") as handle:
        return handle.read().strip()


def _project_folder_from_builder_payload(payload):
    raw = str(payload.get("project_folder", "") or "").strip().strip('"')
    if not raw:
        raise ValueError("Create or load a Builder project before editing instructions.")
    return os.path.abspath(raw)


def _builder_instruction_state(project_folder, key, scene_id=""):
    key = _safe_builder_instruction_key(key)
    default_text = _BUILDER_INSTRUCTION_DEFAULTS[key]
    scene_path = ""
    scene_text = ""
    if scene_id:
        scene_path = _builder_instruction_scene_path(project_folder, key, scene_id)
        scene_text = _read_optional_text_file(scene_path)
    all_path = _builder_instruction_all_scenes_path(project_folder, key)
    all_text = _read_optional_text_file(all_path)
    if scene_text:
        source = "scene"
        text = scene_text
        path = scene_path
    elif all_text:
        source = "all_scenes"
        text = all_text
        path = all_path
    else:
        source = "default"
        text = default_text
        path = ""
    return {
        "key": key,
        "label": _BUILDER_INSTRUCTION_LABELS.get(key, key),
        "scene_id": str(scene_id or ""),
        "default_text": default_text,
        "scene_text": scene_text,
        "all_scenes_text": all_text,
        "text": text,
        "source": source,
        "path": path,
        "scene_path": scene_path,
        "all_scenes_path": all_path,
        "has_scene_custom": bool(scene_text),
        "has_all_scenes_custom": bool(all_text),
    }


def _effective_builder_instruction(payload, key, default_text):
    project_folder = str(payload.get("project_folder", "") or "").strip().strip('"')
    if not project_folder:
        return str(default_text or "")
    try:
        state = _builder_instruction_state(os.path.abspath(project_folder), key, payload.get("scene_id", ""))
        return str(state.get("text") or default_text or "")
    except Exception:
        return str(default_text or "")


def _get_builder_instruction(payload):
    project_folder = _project_folder_from_builder_payload(payload)
    key = _safe_builder_instruction_key(payload.get("key"))
    return {
        "project_folder": project_folder,
        **_builder_instruction_state(project_folder, key, payload.get("scene_id", "")),
    }


def _save_builder_instruction(payload):
    project_folder = _project_folder_from_builder_payload(payload)
    key = _safe_builder_instruction_key(payload.get("key"))
    scope = str(payload.get("scope", "scene") or "scene").strip().lower()
    text = str(payload.get("text", "") or "").strip()
    if not text:
        raise ValueError("Instruction text is empty.")
    if scope in {"all", "all_scenes", "global"}:
        path = _builder_instruction_all_scenes_path(project_folder, key)
    else:
        path = _builder_instruction_scene_path(project_folder, key, payload.get("scene_id", ""))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
        handle.write("\n")
    return _get_builder_instruction({"project_folder": project_folder, "key": key, "scene_id": payload.get("scene_id", "")})


def _reset_builder_instruction(payload):
    project_folder = _project_folder_from_builder_payload(payload)
    key = _safe_builder_instruction_key(payload.get("key"))
    scope = str(payload.get("scope", "scene") or "scene").strip().lower()
    if scope in {"all", "all_scenes", "global"}:
        path = _builder_instruction_all_scenes_path(project_folder, key)
    else:
        path = _builder_instruction_scene_path(project_folder, key, payload.get("scene_id", ""))
    if os.path.isfile(path):
        os.remove(path)
    return _get_builder_instruction({"project_folder": project_folder, "key": key, "scene_id": payload.get("scene_id", "")})


def _list_builder_instruction_presets(payload):
    key = _safe_builder_instruction_key(payload.get("key"))
    group = _builder_instruction_preset_group(key)
    folder = os.path.join(_builder_instruction_preset_root(), group)
    presets = []
    seen = set()
    folders = [(folder, False)]
    legacy_folder = os.path.join(_builder_instruction_preset_root(), key)
    if os.path.normcase(os.path.abspath(legacy_folder)) != os.path.normcase(os.path.abspath(folder)):
        folders.append((legacy_folder, True))
    for scan_folder, legacy in folders:
        if not os.path.isdir(scan_folder):
            continue
        for filename in os.listdir(scan_folder):
            if not filename.lower().endswith(".txt"):
                continue
            preset_name = os.path.splitext(filename)[0]
            dedupe_key = preset_name.lower()
            if dedupe_key in seen:
                continue
            path = os.path.join(scan_folder, filename)
            if os.path.isfile(path):
                seen.add(dedupe_key)
                presets.append({
                    "name": preset_name,
                    "path": os.path.abspath(path),
                    "updated": os.path.getmtime(path),
                    "legacy": legacy,
                })
    presets.sort(key=lambda item: item.get("updated", 0), reverse=True)
    return {
        "key": key,
        "label": _BUILDER_INSTRUCTION_LABELS.get(key, key),
        "preset_group": group,
        "preset_group_label": _builder_instruction_preset_group_label(key),
        "presets": presets,
        "preset_folder": folder,
    }


def _save_builder_instruction_preset(payload):
    key = _safe_builder_instruction_key(payload.get("key"))
    name = _safe_preset_name(payload.get("name"))
    text = str(payload.get("text", "") or "").strip()
    if not text:
        raise ValueError("Preset instruction text is empty.")
    path = _builder_instruction_preset_path(key, name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
        handle.write("\n")
    return {
        "key": key,
        "name": name,
        "path": path,
        "preset_folder": os.path.dirname(path),
        "preset_group": _builder_instruction_preset_group(key),
        "preset_group_label": _builder_instruction_preset_group_label(key),
    }


def _load_builder_instruction_preset(payload):
    key = _safe_builder_instruction_key(payload.get("key"))
    name = _safe_preset_name(payload.get("name"))
    path = _builder_instruction_preset_path(key, name)
    text = _read_optional_text_file(path)
    if not text:
        legacy_path = _legacy_builder_instruction_preset_path(key, name)
        if os.path.normcase(os.path.abspath(legacy_path)) != os.path.normcase(os.path.abspath(path)):
            legacy_text = _read_optional_text_file(legacy_path)
            if legacy_text:
                path = legacy_path
                text = legacy_text
    if not text:
        raise FileNotFoundError(f"Instruction preset was not found or is empty: {path}")
    return {
        "key": key,
        "name": name,
        "path": path,
        "preset_folder": os.path.dirname(path),
        "preset_group": _builder_instruction_preset_group(key),
        "preset_group_label": _builder_instruction_preset_group_label(key),
        "text": text,
    }


def _wizard_folder(project_folder):
    return os.path.join(project_folder, "wizard")


def _wizard_draft_path(project_folder):
    return os.path.join(_wizard_folder(project_folder), "wizard_draft.json")


def _wizard_lyrics_path(project_folder):
    return os.path.join(_wizard_folder(project_folder), "lyrics.txt")


def _scene_image_path(project_folder, scene_number, extension=".png"):
    scene = max(1, int(scene_number or 1))
    ext = str(extension or ".png").lower()
    if ext not in {".png", ".jpg", ".jpeg", ".webp"}:
        ext = ".png"
    return os.path.join(_images_folder(project_folder), f"image_{scene:04d}{ext}")


def _is_internal_approved_image_path(path):
    parts = os.path.normpath(str(path or "")).split(os.sep)
    return "zimage_approved" in {part.lower() for part in parts}


def _scene_preview_folder(project_folder, scene_number):
    scene = max(1, int(scene_number or 1))
    return os.path.join(project_folder, "scene_image_previews", f"scene_{scene:04d}")


def _scene_audio_folder(project_folder):
    return os.path.join(project_folder, "scene_audio")


def _scene_audio_path(project_folder, scene_number, extension=".wav"):
    scene = max(1, int(scene_number or 1))
    ext = str(extension or ".wav").lower()
    if ext not in {".wav", ".mp3", ".flac", ".m4a", ".ogg"}:
        ext = ".wav"
    return os.path.join(_scene_audio_folder(project_folder), f"audio_{scene:04d}{ext}")


def _unique_preview_path(project_folder, scene_number, extension=".png"):
    folder = _scene_preview_folder(project_folder, scene_number)
    os.makedirs(folder, exist_ok=True)
    ext = str(extension or ".png").lower()
    if ext not in {".png", ".jpg", ".jpeg", ".webp"}:
        ext = ".png"
    stamp = time.strftime("%Y%m%d_%H%M%S")
    base = os.path.join(folder, f"preview_{stamp}{ext}")
    if not os.path.exists(base):
        return base
    index = 2
    while True:
        candidate = os.path.join(folder, f"preview_{stamp}_{index:02d}{ext}")
        if not os.path.exists(candidate):
            return candidate
        index += 1


def _unique_file_path(path):
    base = os.path.abspath(str(path or "").strip().strip('"'))
    folder = os.path.dirname(base)
    stem, ext = os.path.splitext(os.path.basename(base))
    os.makedirs(folder, exist_ok=True)
    if not os.path.exists(base):
        return base
    index = 2
    while True:
        candidate = os.path.join(folder, f"{stem}_{index:02d}{ext}")
        if not os.path.exists(candidate):
            return candidate
        index += 1


def _is_inside_folder(path, folder):
    try:
        path = os.path.normcase(os.path.abspath(path))
        folder = os.path.normcase(os.path.abspath(folder))
        return os.path.commonpath([path, folder]) == folder
    except Exception:
        return False


_BRANCH_KEEP_KEYS = ("lyrics", "notes", "prompts", "mappings", "images", "videos", "overlays")
_BRANCH_VIDEO_DIRS = {"rendered_scene_videos", "rendered_scene_videos_backup", "scene_video_thumbnails"}
_BRANCH_IMAGE_DIRS = {"zimage_approved", "scene_image_previews"}
_BRANCH_SEGMENT_NOTE_KEYS = ("timeline_note", "notes", "i2v_notes", "flux_notes", "nb_notes", "enhance_notes", "story_beat")
_BRANCH_SEGMENT_PROMPT_KEYS = (
    "t2i_prompt", "flux_prompt", "nb_prompt", "enhance_prompt", "i2v_prompt", "t2v_prompt",
    "flow_gpt_prompt", "ernie_t2i_prompt", "krea2_t2i_prompt", "minimax_h3_prompt", "minimax_h3_pass2_prompt",
)
_BRANCH_SEGMENT_IMAGE_KEYS = (
    "custom_image_path", "custom_image_data", "custom_image_name", "approved_image_path", "image",
    "image_history", "image_history_index", "ref_image_path", "flux_subject_image_path",
    "flux_location_image_path", "image_output", "image_status", "minimax_h3_continuity_frame_path",
    "adjust_preview_image_path",
)
_BRANCH_SEGMENT_VIDEO_KEYS = (
    "video_path", "video_folder", "video_thumbnail_path", "video_history", "video_thumbnail_history",
    "video_backup_paths", "video_backup_thumbnail_paths", "video_history_index", "video_output",
    "video_original_path", "video_original_thumbnail_path", "video_source_path",
    "minimax_h3_continuity_source_video_path", "minimax_h3_video_references",
    "minimax_h3_stage1_path", "minimax_h3_stage1_source_path", "minimax_h3_stage1_backup_path",
    "minimax_h3_stage2_path", "minimax_h3_stage2_source_path", "minimax_h3_stage2_backup_path",
)
_MINIMAX_H3_STAGE_PATH_KEYS = (
    "minimax_h3_stage1_path", "minimax_h3_stage1_source_path", "minimax_h3_stage1_backup_path",
    "minimax_h3_stage2_path", "minimax_h3_stage2_source_path", "minimax_h3_stage2_backup_path",
)
_BRANCH_SEGMENT_MAPPING_KEYS = (
    "subject_ids", "location_id", "reference_subject_ids", "reference_location_id",
    "flux_image_ingredients", "nb_image_ingredients", "minimax_h3_reference_keys",
)
_BRANCH_SEGMENT_AUDIO_KEYS = ("custom_audio_path", "custom_audio_name")


def _normalize_branch_keep(payload):
    raw = payload.get("keep") if isinstance(payload, dict) else None
    if not isinstance(raw, dict):
        return {key: True for key in _BRANCH_KEEP_KEYS}
    return {key: bool(raw.get(key, False)) for key in _BRANCH_KEEP_KEYS}


def _looks_like_filesystem_path(text):
    value = str(text or "").strip().strip('"')
    if not value or "\n" in value or len(value) > 4096:
        return False
    if re.match(r"^[A-Za-z]:[\\/]", value):
        return True
    if value.startswith("\\\\") or value.startswith("/"):
        return True
    return False


def _rewrite_project_path_string(text, old_folder, new_folder):
    value = str(text or "")
    stripped = value.strip().strip('"')
    if not stripped or not old_folder or not new_folder or not _looks_like_filesystem_path(stripped):
        return value
    try:
        old_abs = os.path.abspath(old_folder)
        new_abs = os.path.abspath(new_folder)
        raw_abs = os.path.abspath(stripped)
    except (OSError, ValueError, TypeError):
        return value
    if not _is_inside_folder(raw_abs, old_abs):
        return value
    relative = os.path.relpath(raw_abs, old_abs)
    rewritten = os.path.abspath(os.path.join(new_abs, relative))
    old_exists = os.path.exists(raw_abs)
    new_exists = os.path.exists(rewritten)
    if old_exists and not new_exists:
        return ""
    return rewritten


def _rewrite_project_paths(value, old_folder, new_folder):
    if isinstance(value, dict):
        return {key: _rewrite_project_paths(item, old_folder, new_folder) for key, item in value.items()}
    if isinstance(value, list):
        return [_rewrite_project_paths(item, old_folder, new_folder) for item in value]
    if isinstance(value, str):
        return _rewrite_project_path_string(value, old_folder, new_folder)
    return value


def _clear_remaining_source_paths(value, old_folder):
    if not old_folder:
        return value
    if isinstance(value, dict):
        return {key: _clear_remaining_source_paths(item, old_folder) for key, item in value.items()}
    if isinstance(value, list):
        return [_clear_remaining_source_paths(item, old_folder) for item in value]
    if isinstance(value, str) and _looks_like_filesystem_path(value):
        try:
            if _is_inside_folder(os.path.abspath(value.strip().strip('"')), old_folder):
                return ""
        except (OSError, ValueError, TypeError):
            return value
    return value


def _rewrite_project_json_file(path, old_folder, new_folder):
    if not os.path.isfile(path):
        return
    with open(path, "r", encoding="utf-8-sig") as handle:
        data = json.load(handle)
    data = _clear_remaining_source_paths(_rewrite_project_paths(data, old_folder, new_folder), old_folder)
    _atomic_write_json(path, data)


def _rewrite_project_sidecar_json(project_folder, old_folder):
    files = [
        os.path.join(project_folder, "storyboard", "storyboard.json"),
        os.path.join(project_folder, "subject_location", "reference_descriptions.json"),
    ]
    prompts = os.path.join(project_folder, "prompts")
    if os.path.isdir(prompts):
        for name in os.listdir(prompts):
            if name.lower().endswith(".json"):
                files.append(os.path.join(prompts, name))
    for path in files:
        try:
            _rewrite_project_json_file(path, old_folder, project_folder)
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            continue


def _is_project_root_export_video(name):
    stem, ext = os.path.splitext(str(name or ""))
    if ext.lower() != ".mp4":
        return False
    upper = stem.upper()
    return upper.startswith("FINAL_VIDEO") or upper.startswith("PREVIEW_SCENES_")


def _remove_project_root_export_videos(project_folder):
    if not os.path.isdir(project_folder):
        return
    for name in os.listdir(project_folder):
        if not _is_project_root_export_video(name):
            continue
        path = os.path.join(project_folder, name)
        if os.path.isfile(path):
            try:
                os.remove(path)
            except OSError:
                pass


def _branch_copy_ignore(keep, source=""):
    skip_names = {"__pycache__", "session_backups"}
    source_abs = os.path.normcase(os.path.abspath(source)) if source else ""
    if not keep.get("videos"):
        skip_names |= _BRANCH_VIDEO_DIRS
        skip_names.add("render_logs")
    if not keep.get("images"):
        skip_names |= _BRANCH_IMAGE_DIRS
    if not keep.get("mappings"):
        skip_names.add("subject_location")
    if not keep.get("prompts"):
        skip_names.add("prompts")
    if not keep.get("notes") and not keep.get("prompts"):
        skip_names.add("storyboard")

    def ignore(directory, names):
        ignored = [name for name in names if name in skip_names or name.endswith(".tmp")]
        basename = os.path.basename(directory)
        if source_abs and os.path.normcase(os.path.abspath(directory)) == source_abs:
            ignored.extend(name for name in names if _is_project_root_export_video(name))
        if not keep.get("mappings") and basename == "project_context" and "flux_references" in names:
            ignored.append("flux_references")
        if not keep.get("images") and basename == "storyboard":
            ignored.extend(
                name for name in names
                if os.path.splitext(name)[1].lower() in {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}
            )
        return ignored

    return ignore


def _copy_project_tree(source, target, keep):
    if not source or not os.path.isdir(source):
        os.makedirs(target, exist_ok=True)
        return
    os.makedirs(target, exist_ok=True)
    shutil.copytree(source, target, dirs_exist_ok=True, ignore=_branch_copy_ignore(keep, source))
    _remove_project_root_export_videos(target)
    shutil.rmtree(os.path.join(target, "session_backups"), ignore_errors=True)


def _empty_keep_value(key, current):
    if key.endswith("_index"):
        return -1
    if key in {"image", "image_output", "video_output"}:
        return None
    if key == "image_status" or key == "video_status":
        return "none"
    if isinstance(current, list):
        return []
    if isinstance(current, dict):
        return {}
    if isinstance(current, bool):
        return False
    return ""


def _strip_segment_keep_fields(segment, keep):
    if not isinstance(segment, dict):
        return segment
    if not keep.get("lyrics"):
        segment["lyric_text"] = ""
    if not keep.get("notes"):
        for key in _BRANCH_SEGMENT_NOTE_KEYS:
            if key in segment:
                segment[key] = ""
    if not keep.get("prompts"):
        for key in _BRANCH_SEGMENT_PROMPT_KEYS:
            if key in segment:
                segment[key] = ""
    if not keep.get("mappings"):
        for key in _BRANCH_SEGMENT_MAPPING_KEYS:
            if key in segment:
                segment[key] = _empty_keep_value(key, segment.get(key))
    if not keep.get("images"):
        for key in _BRANCH_SEGMENT_IMAGE_KEYS:
            if key in segment:
                segment[key] = _empty_keep_value(key, segment.get(key))
        segment["preview_mode"] = "image"
    if not keep.get("videos"):
        for key in _BRANCH_SEGMENT_VIDEO_KEYS:
            if key in segment:
                segment[key] = _empty_keep_value(key, segment.get(key))
        segment["video_status"] = "none"
        if isinstance(segment.get("minimax_h3_video_references"), list):
            segment["minimax_h3_video_references"] = []
    if not keep.get("images") and not keep.get("videos"):
        for key in _BRANCH_SEGMENT_AUDIO_KEYS:
            if key in segment:
                segment[key] = ""
    return segment


def _apply_branch_keep_to_session(session, keep):
    if not isinstance(session, dict):
        return {}
    if all(keep.get(key) for key in _BRANCH_KEEP_KEYS):
        return session
    segments = session.get("segments") if isinstance(session.get("segments"), list) else []
    session["segments"] = [_strip_segment_keep_fields(item if isinstance(item, dict) else {}, keep) for item in segments]
    overlays = session.get("overlay_segments") if isinstance(session.get("overlay_segments"), list) else []
    if keep.get("overlays"):
        session["overlay_segments"] = [_strip_segment_keep_fields(item if isinstance(item, dict) else {}, keep) for item in overlays]
    else:
        session["overlay_segments"] = []
        if isinstance(session.get("overlay_track"), dict):
            session["overlay_track"] = {**session["overlay_track"], "enabled": False}
    if not keep.get("notes"):
        session["timeline_markers"] = []
    if not keep.get("prompts"):
        for key in ("prompt_json_path", "i2v_motion_json_path", "theme_style_path", "story_idea_path", "subject_scene_path"):
            session[key] = ""
    if not keep.get("mappings"):
        session["flux_reference_builder"] = {}
        session["id_lora_reference_builder"] = {}
    if not keep.get("images"):
        session["flux_global_image_ingredients"] = []
        session["use_flux_global_image_ingredients"] = False
        session["builder_agent_reference_images"] = []
        session["builder_story_reference_images"] = []
        session["builder_story_source_path"] = ""
    if not keep.get("lyrics"):
        mapper = session.get("lyric_mapper") if isinstance(session.get("lyric_mapper"), dict) else {}
        if mapper:
            mapper["source_text"] = ""
            session["lyric_mapper"] = mapper
    return session


def _branch_scene_number(segment, index):
    if isinstance(segment, dict):
        for key in ("scene_slot_number", "overlay_slot_number", "scene_number"):
            try:
                value = int(segment.get(key) or 0)
            except (TypeError, ValueError):
                value = 0
            if value > 0:
                return value
    return max(1, int(index or 1))


def _copy_external_media_into_branch(source_path, project_folder, scene_number, key, copied):
    text = str(source_path or "").strip().strip('"')
    if not text:
        return ""
    try:
        abs_path = os.path.abspath(text)
    except (OSError, ValueError, TypeError):
        return ""
    if _is_inside_folder(abs_path, project_folder):
        return abs_path if os.path.isfile(abs_path) else ""
    if abs_path in copied:
        return copied[abs_path]
    if not os.path.isfile(abs_path):
        return ""
    backup_dir = os.path.join(project_folder, "rendered_scene_videos_backup", f"scene_{int(scene_number):04d}")
    os.makedirs(backup_dir, exist_ok=True)
    stem = os.path.splitext(os.path.basename(abs_path))[0]
    ext = os.path.splitext(abs_path)[1] or ".mp4"
    safe_key = re.sub(r"[^A-Za-z0-9_-]+", "_", str(key or "media")).strip("_") or "media"
    target = os.path.join(backup_dir, f"{safe_key}_{stem}{ext}")
    index = 2
    while os.path.exists(target):
        target = os.path.join(backup_dir, f"{safe_key}_{stem}_{index:02d}{ext}")
        index += 1
    shutil.copy2(abs_path, target)
    copied[abs_path] = target
    return target


def _relocate_external_minimax_stage_media(session, project_folder):
    if not isinstance(session, dict) or not project_folder:
        return session
    copied = {}

    def relocate_segment(segment, index):
        if not isinstance(segment, dict):
            return
        scene_number = _branch_scene_number(segment, index)
        for key in _MINIMAX_H3_STAGE_PATH_KEYS:
            if key in segment:
                segment[key] = _copy_external_media_into_branch(
                    segment.get(key, ""), project_folder, scene_number, key, copied,
                )
        backups = segment.get("video_backup_paths")
        if isinstance(backups, list):
            segment["video_backup_paths"] = [
                _copy_external_media_into_branch(item, project_folder, scene_number, "video_backup", copied)
                for item in backups
            ]
            segment["video_backup_paths"] = [item for item in segment["video_backup_paths"] if item]
        thumbs = segment.get("video_backup_thumbnail_paths")
        if isinstance(thumbs, list):
            segment["video_backup_thumbnail_paths"] = [
                _copy_external_media_into_branch(item, project_folder, scene_number, "video_backup_thumb", copied)
                for item in thumbs
            ]
            segment["video_backup_thumbnail_paths"] = [item for item in segment["video_backup_thumbnail_paths"] if item]
        if segment.get("video_source_path"):
            segment["video_source_path"] = _copy_external_media_into_branch(
                segment.get("video_source_path", ""), project_folder, scene_number, "video_source", copied,
            )

    segments = session.get("segments") if isinstance(session.get("segments"), list) else []
    for index, segment in enumerate(segments, start=1):
        relocate_segment(segment, index)
    overlays = session.get("overlay_segments") if isinstance(session.get("overlay_segments"), list) else []
    for index, segment in enumerate(overlays, start=1):
        relocate_segment(segment, index)
    return session


def _strip_storyboard_images(project_folder):
    path = os.path.join(project_folder, "storyboard", "storyboard.json")
    if not os.path.isfile(path):
        return
    try:
        with open(path, "r", encoding="utf-8-sig") as handle:
            data = json.load(handle)
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return
    if not isinstance(data, dict):
        return
    scenes = data.get("scenes") if isinstance(data.get("scenes"), list) else []
    for scene in scenes:
        if not isinstance(scene, dict):
            continue
        scene["image_path"] = ""
        scene["image_data"] = ""
        scene["image_name"] = ""
    data["scenes"] = scenes
    _atomic_write_json(path, data)


def _prune_unkept_project_folders(project_folder, keep):
    removals = []
    if not keep.get("videos"):
        removals.extend(_BRANCH_VIDEO_DIRS)
        removals.append("render_logs")
    if not keep.get("images"):
        removals.extend(_BRANCH_IMAGE_DIRS)
        _strip_storyboard_images(project_folder)
    if not keep.get("mappings"):
        removals.append("subject_location")
        flux_refs = os.path.join(project_folder, "project_context", "flux_references")
        if os.path.isdir(flux_refs):
            shutil.rmtree(flux_refs, ignore_errors=True)
    if not keep.get("prompts"):
        removals.append("prompts")
    if not keep.get("notes") and not keep.get("prompts"):
        removals.append("storyboard")
    for name in removals:
        path = os.path.join(project_folder, name)
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)


def _copy_file_into_folder(source_path, target_folder, target_name=None):
    if not source_path:
        return ""
    source = os.path.abspath(str(source_path or "").strip().strip('"'))
    if not os.path.isfile(source):
        return ""
    os.makedirs(target_folder, exist_ok=True)
    name = target_name or os.path.basename(source)
    safe_stem = _safe_project_name(os.path.splitext(name)[0])
    ext = os.path.splitext(name)[1] or os.path.splitext(source)[1]
    target = os.path.join(target_folder, f"{safe_stem}{ext}")
    if os.path.abspath(source) != os.path.abspath(target):
        shutil.copy2(source, target)
    return target


def _convert_audio_to_wav(source_path, target_path):
    source = _resolve_existing_file(source_path, "Audio file")
    target = os.path.abspath(str(target_path or "").strip().strip('"'))
    os.makedirs(os.path.dirname(target), exist_ok=True)
    command = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel",
        "error",
        "-y",
        "-i",
        source,
        "-vn",
        "-acodec",
        "pcm_s16le",
        "-ar",
        "44100",
        "-ac",
        "2",
        target,
    ]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if result.returncode != 0:
        error_text = result.stderr.decode("utf-8", errors="replace").strip()
        raise ValueError(f"Could not convert audio to WAV: {error_text or f'ffmpeg exited with code {result.returncode}'}")
    if not os.path.isfile(target) or os.path.getsize(target) <= 0:
        raise ValueError("Audio conversion finished, but the WAV file was not created.")
    return target


def _copy_or_convert_project_audio(source_path, target_folder, target_name=None):
    source = _resolve_existing_file(source_path, "Audio file")
    name = target_name or os.path.basename(source)
    if os.path.splitext(source)[1].lower() == ".m4a":
        safe_stem = _safe_project_name(os.path.splitext(name)[0])
        return _convert_audio_to_wav(source, os.path.join(target_folder, f"{safe_stem}.wav"))
    return _copy_file_into_folder(source, target_folder, name)


def _project_rebased_path(project_folder, old_project_folder, raw_path):
    text = str(raw_path or "").strip().strip('"')
    if not text or not old_project_folder:
        return ""
    try:
        old_abs = os.path.abspath(old_project_folder)
        raw_abs = os.path.abspath(text)
        if _is_inside_folder(raw_abs, old_abs):
            return os.path.abspath(os.path.join(project_folder, os.path.relpath(raw_abs, old_abs)))
    except Exception:
        return ""
    return ""


def _snapshot_project_assets(project_folder, session, audio_path, old_project_folder=""):
    project_folder = os.path.abspath(project_folder)
    if audio_path and os.path.isfile(audio_path):
        copied_audio = _copy_or_convert_project_audio(
            audio_path,
            os.path.join(project_folder, "project_audio"),
            "project_audio" + os.path.splitext(audio_path)[1],
        )
        if copied_audio:
            audio_path = copied_audio
    elif old_project_folder:
        rebased_audio = _project_rebased_path(project_folder, old_project_folder, audio_path)
        if rebased_audio:
            audio_path = rebased_audio

    context_map = {
        "prompt_json_path": "ConceptPrompts.txt",
        "theme_style_path": "themestyle.txt",
        "story_idea_path": "storyconcept.txt",
        "subject_scene_path": "subjectsandscenes.txt",
    }
    for key, filename in context_map.items():
        raw_path = str(session.get(key, "") or "").strip()
        if raw_path and os.path.isfile(raw_path):
            copied_path = _copy_file_into_folder(raw_path, _context_folder(project_folder), filename)
            if copied_path:
                session[key] = copied_path
        else:
            rebased_path = _project_rebased_path(project_folder, old_project_folder, raw_path)
            if rebased_path:
                session[key] = rebased_path

    return audio_path, session


def _copy_file_if_exists(source_path, target_path):
    source = str(source_path or "").strip().strip('"')
    if not source or not os.path.isfile(source):
        return ""
    source = os.path.abspath(source)
    target = os.path.abspath(target_path)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    if os.path.normcase(source) == os.path.normcase(target):
        return target
    shutil.copy2(source, target)
    return target


def _open_local_file(path):
    target = os.path.abspath(str(path or "").strip().strip('"'))
    if not target or not os.path.isfile(target):
        raise ValueError("Video file was not found.")
    if os.name == "nt":
        os.startfile(target)  # pylint: disable=no-member
    elif sys.platform == "darwin":
        subprocess.Popen(["open", target])
    else:
        subprocess.Popen(["xdg-open", target])
    return target


def _copy_reference_asset(project_folder, scene_number, key, source_path):
    source = str(source_path or "").strip().strip('"')
    if not source or not os.path.isfile(source):
        return ""
    ext = os.path.splitext(source)[1].lower() or ".png"
    if ext not in {".png", ".jpg", ".jpeg", ".webp", ".wav", ".mp3", ".flac", ".m4a", ".ogg"}:
        ext = ".bin"
    safe_key = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(key or "asset")).strip("_") or "asset"
    folder = os.path.join(_context_folder(project_folder), f"scene_{max(1, int(scene_number or 1)):04d}")
    return _copy_file_if_exists(source, os.path.join(folder, f"{safe_key}{ext}"))


def _copy_session_assets_to_project(project_folder, session):
    project_folder = os.path.abspath(project_folder)
    if isinstance(session.get("flux_global_image_ingredients"), list):
        global_folder = os.path.join(_context_folder(project_folder), "flux_global")
        for ingredient_index, ingredient in enumerate(session["flux_global_image_ingredients"], start=1):
            if not isinstance(ingredient, dict):
                continue
            source = str(ingredient.get("path", "") or "").strip().strip('"')
            if not source or not os.path.isfile(source):
                continue
            ext = os.path.splitext(source)[1].lower() or ".png"
            copied = _copy_file_if_exists(source, os.path.join(global_folder, f"global_ingredient_{ingredient_index}{ext}"))
            if copied:
                ingredient["path"] = copied
    segments = session.get("segments", [])
    if not isinstance(segments, list):
        session["segments"] = []
        return session

    for scene_number, segment in enumerate(segments, start=1):
        if not isinstance(segment, dict):
            continue

        approved = str(segment.get("approved_image_path", "") or "").strip()
        if approved and os.path.isfile(approved):
            ext = os.path.splitext(approved)[1] or ".png"
            segment["approved_image_path"] = _copy_file_if_exists(
                approved,
                _scene_image_path(project_folder, scene_number, ext),
            )

        history = segment.get("image_history", [])
        new_history = []
        if isinstance(history, list):
            for item in history:
                item_path = str(item or "").strip()
                if not item_path or not os.path.isfile(item_path):
                    continue
                if item_path == approved or _is_internal_approved_image_path(item_path):
                    continue
                ext = os.path.splitext(item_path)[1] or ".png"
                copied = _copy_file_if_exists(item_path, _unique_preview_path(project_folder, scene_number, ext))
                if copied and copied not in new_history:
                    new_history.append(copied)
        segment["image_history"] = new_history
        if new_history:
            try:
                current_index = int(segment.get("image_history_index", len(new_history) - 1) or 0)
            except (TypeError, ValueError):
                current_index = len(new_history) - 1
            segment["image_history_index"] = max(0, min(len(new_history) - 1, current_index))
        else:
            segment["image_history_index"] = -1

        video_path = str(segment.get("video_path", "") or "").strip()
        if video_path and os.path.isfile(video_path):
            target_video = os.path.join(project_folder, "rendered_scene_videos", f"video_{scene_number:04d}-audio.mp4")
            segment["video_path"] = _copy_file_if_exists(video_path, target_video)
            segment["video_folder"] = os.path.dirname(segment["video_path"])
            segment["video_status"] = "done"

        custom_audio = str(segment.get("custom_audio_path", "") or "").strip()
        if custom_audio and os.path.isfile(custom_audio):
            ext = os.path.splitext(custom_audio)[1] or ".wav"
            segment["custom_audio_path"] = _copy_file_if_exists(
                custom_audio,
                _scene_audio_path(project_folder, scene_number, ext),
            )

        for key in (
            "custom_image_path",
            "ref_image_path",
            "flux_subject_image_path",
            "flux_location_image_path",
        ):
            copied = _copy_reference_asset(project_folder, scene_number, key, segment.get(key, ""))
            if copied:
                segment[key] = copied
        if isinstance(segment.get("flux_image_ingredients"), list):
            for ingredient_index, ingredient in enumerate(segment["flux_image_ingredients"], start=1):
                if not isinstance(ingredient, dict):
                    continue
                copied = _copy_reference_asset(
                    project_folder,
                    scene_number,
                    f"flux_ingredient_{ingredient_index}",
                    ingredient.get("path", ""),
                )
                if copied:
                    ingredient["path"] = copied

    overlay_segments = session.get("overlay_segments", [])
    if isinstance(overlay_segments, list):
        overlay_segments = _assign_overlay_scene_numbers(overlay_segments)
        for overlay_index, segment in enumerate(overlay_segments, start=1):
            if not isinstance(segment, dict):
                continue
            scene_number = _overlay_scene_number(segment, overlay_index)
            segment["track"] = "overlay"
            approved = str(segment.get("approved_image_path", "") or "").strip()
            if approved and os.path.isfile(approved):
                ext = os.path.splitext(approved)[1] or ".png"
                segment["approved_image_path"] = _copy_file_if_exists(
                    approved,
                    _scene_image_path(project_folder, scene_number, ext),
                )
            video_path = str(segment.get("video_path", "") or "").strip()
            if video_path and os.path.isfile(video_path):
                target_video = os.path.join(project_folder, "rendered_scene_videos", f"video_{scene_number:04d}-audio.mp4")
                segment["video_path"] = _copy_file_if_exists(video_path, target_video)
                segment["video_folder"] = os.path.dirname(segment["video_path"])
                segment["video_status"] = "done"
            for key in (
                "custom_image_path",
                "ref_image_path",
                "flux_subject_image_path",
                "flux_location_image_path",
            ):
                copied = _copy_reference_asset(project_folder, scene_number, key, segment.get(key, ""))
                if copied:
                    segment[key] = copied

    return session


def _rebase_project_owned_paths(project_folder, old_project_folder, session):
    if not old_project_folder:
        return session
    session = _rewrite_project_paths(session, old_project_folder, project_folder)
    session = _clear_remaining_source_paths(session, old_project_folder)
    _rewrite_project_sidecar_json(project_folder, old_project_folder)
    return session


def _project_path_candidates(project_folder, old_project_folder, raw_path, scene_number=None):
    text = str(raw_path or "").strip().strip('"')
    if not text:
        return []
    abs_text = os.path.abspath(text)
    candidates = [text, abs_text]
    if old_project_folder:
        try:
            old_abs = os.path.abspath(old_project_folder)
            if _is_inside_folder(abs_text, old_abs):
                candidates.append(os.path.join(project_folder, os.path.relpath(abs_text, old_abs)))
        except Exception:
            pass
    base = os.path.basename(text)
    if base:
        candidates.extend([
            os.path.join(project_folder, base),
            os.path.join(_images_folder(project_folder), base),
            os.path.join(_context_folder(project_folder), base),
            os.path.join(project_folder, "project_audio", base),
            os.path.join(_scene_audio_folder(project_folder), base),
            os.path.join(project_folder, "rendered_scene_videos", base),
        ])
    if scene_number:
        scene = int(scene_number)
        candidates.extend([
            _scene_image_path(project_folder, scene, ".png"),
            _scene_image_path(project_folder, scene, ".jpg"),
            _scene_image_path(project_folder, scene, ".jpeg"),
            _scene_image_path(project_folder, scene, ".webp"),
            _scene_audio_path(project_folder, scene, ".wav"),
            _scene_audio_path(project_folder, scene, ".mp3"),
            _scene_audio_path(project_folder, scene, ".m4a"),
            os.path.join(project_folder, "rendered_scene_videos", f"video_{scene:04d}-audio.mp4"),
        ])
    return candidates


def _overlay_scene_number(segment, fallback_index):
    if isinstance(segment, dict):
        for key in ("overlay_slot_number", "scene_slot_number", "slot_number"):
            try:
                value = int(segment.get(key, 0) or 0)
            except (TypeError, ValueError):
                value = 0
            if value >= 10001:
                return value
    return 10000 + int(fallback_index or 1)


def _assign_overlay_scene_numbers(overlay_segments):
    if not isinstance(overlay_segments, list):
        return overlay_segments
    used = set()
    existing = []
    for segment in overlay_segments:
        if isinstance(segment, dict):
            value = _overlay_scene_number(segment, 0)
            if value >= 10001:
                existing.append(value)
    next_slot = max([10000] + existing) + 1
    for index, segment in enumerate(overlay_segments, start=1):
        if not isinstance(segment, dict):
            continue
        slot = _overlay_scene_number(segment, index)
        if slot in used:
            slot = max(next_slot, 10000 + index)
            while slot in used:
                slot += 1
            next_slot = slot + 1
        segment["overlay_slot_number"] = slot
        used.add(slot)
    return overlay_segments


def _resolve_project_asset_path(project_folder, old_project_folder, raw_path, scene_number=None):
    for candidate in _project_path_candidates(project_folder, old_project_folder, raw_path, scene_number):
        if candidate and os.path.isfile(candidate):
            return os.path.abspath(candidate)
    return str(raw_path or "")


def _scene_numbers_from_folder(folder, pattern):
    numbers = set()
    if not os.path.isdir(folder):
        return numbers
    regex = re.compile(pattern, re.IGNORECASE)
    for name in os.listdir(folder):
        match = regex.match(name)
        if match and os.path.isfile(os.path.join(folder, name)):
            numbers.add(int(match.group(1)))
    return numbers


def _project_scene_numbers(project_folder):
    numbers = set()
    numbers.update(_scene_numbers_from_folder(_images_folder(project_folder), r"^image_(\d+)\.(?:png|jpe?g|webp)$"))
    numbers.update(_scene_numbers_from_folder(os.path.join(project_folder, "rendered_scene_videos"), r"^video_(\d+)-audio\.mp4$"))
    preview_root = os.path.join(project_folder, "scene_image_previews")
    if os.path.isdir(preview_root):
        for name in os.listdir(preview_root):
            match = re.match(r"^scene_(\d+)$", name, re.IGNORECASE)
            if match and os.path.isdir(os.path.join(preview_root, name)):
                numbers.add(int(match.group(1)))
    return numbers


def _scene_preview_paths(project_folder, scene_number):
    folder = _scene_preview_folder(project_folder, scene_number)
    if not os.path.isdir(folder):
        return []
    paths = []
    for name in os.listdir(folder):
        path = os.path.join(folder, name)
        if os.path.isfile(path) and os.path.splitext(name)[1].lower() in {".png", ".jpg", ".jpeg", ".webp"}:
            paths.append(os.path.abspath(path))
    paths.sort(key=lambda item: os.path.getmtime(item))
    return paths


def _backup_session_file(project_folder):
    path = _session_path(project_folder)
    if not os.path.isfile(path):
        return ""
    backup_folder = os.path.join(project_folder, "session_backups")
    os.makedirs(backup_folder, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    target = os.path.join(backup_folder, f"vrgdg_builder_session_{stamp}.json")
    index = 2
    while os.path.exists(target):
        target = os.path.join(backup_folder, f"vrgdg_builder_session_{stamp}_{index:02d}.json")
        index += 1
    shutil.copy2(path, target)
    return target


def _rehydrate_builder_session(project_folder, session):
    old_project_folder = str(session.get("project_folder", "") or "")
    project_folder = os.path.abspath(project_folder)

    # Portable imports can contain paths in deeply nested reference-builder,
    # FLF, history, LUT, grain, and adjustment structures. Rebase every path
    # owned by the exported project before the field-specific recovery below.
    def rebase_nested_project_paths(value):
        if isinstance(value, dict):
            return {key: rebase_nested_project_paths(item) for key, item in value.items()}
        if isinstance(value, list):
            return [rebase_nested_project_paths(item) for item in value]
        if not isinstance(value, str) or not old_project_folder or not os.path.isabs(value):
            return value
        rebased = _project_rebased_path(project_folder, old_project_folder, value)
        return rebased if rebased and os.path.exists(rebased) else value

    session = rebase_nested_project_paths(session)
    session["project_folder"] = project_folder
    manifest_path = os.path.join(project_folder, "subject_location", "reference_descriptions.json")
    if not isinstance(session.get("flux_reference_builder"), dict) and os.path.isfile(manifest_path):
        try:
            with open(manifest_path, "r", encoding="utf-8-sig") as handle:
                manifest = json.load(handle)
            if isinstance(manifest, dict) and isinstance(manifest.get("subjects"), list) and isinstance(manifest.get("locations"), list):
                session["flux_reference_builder"] = manifest
        except Exception as exc:
            print(f"[VRGDG Music Builder] Reference-builder manifest restore skipped: {exc}")
    context = _context_folder(project_folder)
    session.setdefault("theme_style_path", os.path.join(context, "themestyle.txt"))
    session.setdefault("story_idea_path", os.path.join(context, "storyconcept.txt"))
    session.setdefault("subject_scene_path", os.path.join(context, "subjectsandscenes.txt"))
    session["audio_path"] = _resolve_project_asset_path(project_folder, old_project_folder, session.get("audio_path", ""))
    for key in ("prompt_json_path", "theme_style_path", "story_idea_path", "subject_scene_path"):
        session[key] = _resolve_project_asset_path(project_folder, old_project_folder, session.get(key, ""))
    if isinstance(session.get("flux_global_image_ingredients"), list):
        for ingredient in session["flux_global_image_ingredients"]:
            if not isinstance(ingredient, dict):
                continue
            ingredient["path"] = _resolve_project_asset_path(
                project_folder,
                old_project_folder,
                ingredient.get("path", ""),
            )

    segments = session.get("segments", [])
    if not isinstance(segments, list):
        session["segments"] = []
        segments = session["segments"]
    overlay_segments = session.get("overlay_segments", [])
    if not isinstance(overlay_segments, list):
        session["overlay_segments"] = []
        overlay_segments = session["overlay_segments"]
    overlay_segments = _assign_overlay_scene_numbers(overlay_segments)

    # Only rebuild timeline scenes from loose media files when the session has no
    # saved scene list. Otherwise deleted scenes can come back from old files.
    existing_count = len(segments)
    if existing_count == 0:
        asset_numbers = _project_scene_numbers(project_folder)
        base_asset_numbers = [number for number in asset_numbers if number < 10000]
        target_count = max(base_asset_numbers) if base_asset_numbers else 0
        for index in range(1, target_count + 1):
            start = float((index - 1) * 4)
            segments.append({
                "id": f"recovered_scene_{index}",
                "label": f"Scene {index}",
                "start": start,
                "end": start + 4,
                "source": "recovered",
            })

    cleaned_segments = []
    for segment in segments:
        if not isinstance(segment, dict):
            continue
        is_recovered = str(segment.get("source", "") or "").lower() == "recovered" or str(segment.get("id", "") or "").startswith("recovered_scene_")
        if is_recovered:
            start = float(segment.get("start", 0) or 0)
            end = float(segment.get("end", start) or start)
            overlaps_real = False
            for other in segments:
                if other is segment or not isinstance(other, dict):
                    continue
                other_recovered = str(other.get("source", "") or "").lower() == "recovered" or str(other.get("id", "") or "").startswith("recovered_scene_")
                if other_recovered:
                    continue
                other_start = float(other.get("start", 0) or 0)
                other_end = float(other.get("end", other_start) or other_start)
                if min(end, other_end) - max(start, other_start) > 0.05:
                    overlaps_real = True
                    break
            if overlaps_real:
                continue
        cleaned_segments.append(segment)
    session["segments"] = cleaned_segments
    segments = cleaned_segments

    for index, segment in enumerate(segments, start=1):
        if not isinstance(segment, dict):
            continue
        if not str(segment.get("label", "") or "").strip() or str(segment.get("label", "")).lower() == "new scene":
            segment["label"] = f"Scene {index}"
        for key in (
            "approved_image_path",
            "custom_image_path",
            "ref_image_path",
            "flux_subject_image_path",
            "flux_location_image_path",
            "video_path",
            "custom_audio_path",
        ):
            segment[key] = _resolve_project_asset_path(project_folder, old_project_folder, segment.get(key, ""), index)
        if isinstance(segment.get("image_history"), list):
            segment["image_history"] = [
                _resolve_project_asset_path(project_folder, old_project_folder, item, index)
                for item in segment["image_history"]
            ]
            segment["image_history"] = [item for item in segment["image_history"] if item]
        else:
            segment["image_history"] = []
        if isinstance(segment.get("flux_image_ingredients"), list):
            for ingredient in segment["flux_image_ingredients"]:
                if not isinstance(ingredient, dict):
                    continue
                ingredient["path"] = _resolve_project_asset_path(
                    project_folder,
                    old_project_folder,
                    ingredient.get("path", ""),
                    index,
                )
        approved = _resolve_project_asset_path(project_folder, old_project_folder, segment.get("approved_image_path", ""), index)
        image_assignment_cleared = bool(segment.get("image_assignment_cleared", False))
        if not approved and not image_assignment_cleared:
            for ext in (".png", ".jpg", ".jpeg", ".webp"):
                candidate = _scene_image_path(project_folder, index, ext)
                if os.path.isfile(candidate):
                    approved = os.path.abspath(candidate)
                    break
        if approved and os.path.isfile(approved):
            segment["approved_image_path"] = approved
            segment["image_history"] = [
                item for item in segment["image_history"]
                if item != approved and not _is_internal_approved_image_path(item)
            ]
        if not image_assignment_cleared:
            for preview_path in _scene_preview_paths(project_folder, index):
                if preview_path not in segment["image_history"]:
                    segment["image_history"].append(preview_path)
        if segment["image_history"] and not isinstance(segment.get("image_history_index"), int):
            segment["image_history_index"] = len(segment["image_history"]) - 1
        video_path = os.path.join(project_folder, "rendered_scene_videos", f"video_{index:04d}-audio.mp4")
        if os.path.isfile(video_path):
            segment["video_path"] = os.path.abspath(video_path)
            segment["video_folder"] = os.path.dirname(os.path.abspath(video_path))
            segment["video_status"] = "done"
    for index, segment in enumerate(overlay_segments, start=1):
        if not isinstance(segment, dict):
            continue
        scene_number = _overlay_scene_number(segment, index)
        if not str(segment.get("label", "") or "").strip() or str(segment.get("label", "")).lower() == "new scene":
            segment["label"] = f"Insert {index}"
        segment["track"] = "overlay"
        for key in (
            "approved_image_path",
            "custom_image_path",
            "ref_image_path",
            "flux_subject_image_path",
            "flux_location_image_path",
            "video_path",
            "custom_audio_path",
        ):
            segment[key] = _resolve_project_asset_path(project_folder, old_project_folder, segment.get(key, ""), scene_number)
        if isinstance(segment.get("image_history"), list):
            segment["image_history"] = [
                _resolve_project_asset_path(project_folder, old_project_folder, item, scene_number)
                for item in segment["image_history"]
            ]
            segment["image_history"] = [item for item in segment["image_history"] if item]
        else:
            segment["image_history"] = []
        for preview_path in _scene_preview_paths(project_folder, scene_number):
            if preview_path not in segment["image_history"]:
                segment["image_history"].append(preview_path)
        video_path = os.path.join(project_folder, "rendered_scene_videos", f"video_{scene_number:04d}-audio.mp4")
        if os.path.isfile(video_path):
            segment["video_path"] = os.path.abspath(video_path)
            segment["video_folder"] = os.path.dirname(os.path.abspath(video_path))
            segment["video_status"] = "done"
    return session


def _format_srt_time(seconds):
    total_ms = max(0, int(round(float(seconds or 0) * 1000)))
    hours = total_ms // 3600000
    total_ms %= 3600000
    minutes = total_ms // 60000
    total_ms %= 60000
    secs = total_ms // 1000
    millis = total_ms % 1000
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


def _parse_srt_time(text):
    match = re.match(r"^\s*(\d+):(\d+):(\d+)[,.](\d+)\s*$", str(text or ""))
    if not match:
        raise ValueError(f"Invalid SRT time: {text}")
    hours, minutes, seconds, millis = [int(part) for part in match.groups()]
    return hours * 3600 + minutes * 60 + seconds + millis / 1000.0


def _parse_srt_segments(srt_text):
    blocks = re.split(r"\n\s*\n", str(srt_text or "").strip(), flags=re.MULTILINE)
    segments = []
    for block in blocks:
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        if not lines:
            continue
        timing_index = next((idx for idx, line in enumerate(lines) if "-->" in line), -1)
        if timing_index < 0:
            continue
        left, right = [part.strip() for part in lines[timing_index].split("-->", 1)]
        start = _parse_srt_time(left)
        end = max(start + 0.1, _parse_srt_time(right))
        label = " ".join(lines[timing_index + 1:]).strip() or f"Scene {len(segments) + 1}"
        segments.append(
            {
                "id": f"srt_{len(segments) + 1}_{int(start * 1000)}",
                "start": round(start, 3),
                "end": round(end, 3),
                "label": label[:80] or f"Scene {len(segments) + 1}",
                "notes": label,
                "t2i_prompt": "",
                "i2v_prompt": "",
                "ref_image_path": "",
                "use_vision_reference": False,
                "image": None,
                "source": "srt",
            }
        )
    return segments


def _load_srt_segments(path):
    srt_path = _resolve_existing_file(path, "SRT file")
    with open(srt_path, "r", encoding="utf-8-sig") as handle:
        segments = _parse_srt_segments(handle.read())
    if not segments:
        raise ValueError("No SRT timing blocks were found.")
    return {"srt_path": srt_path, "segments": segments}


def _prompt_key_number(key):
    match = re.search(r"(\d+)", str(key or ""))
    return int(match.group(1)) if match else 999999


def _load_prompt_json(path):
    json_path = _resolve_existing_file(path, "Prompt JSON")
    with open(json_path, "r", encoding="utf-8-sig") as handle:
        data = json.load(handle)
    prompts = []
    if isinstance(data, dict):
        for key in sorted(data.keys(), key=_prompt_key_number):
            prompts.append(str(data.get(key, "") or "").strip())
    elif isinstance(data, list):
        for item in data:
            if isinstance(item, str):
                prompts.append(item.strip())
            elif isinstance(item, dict):
                for key in sorted(item.keys(), key=_prompt_key_number):
                    prompts.append(str(item.get(key, "") or "").strip())
    else:
        raise ValueError("Prompt JSON must be an object or list.")
    if not prompts:
        raise ValueError("Prompt JSON did not contain any prompt text.")
    return {"prompt_json_path": json_path, "prompts": prompts}


def _extract_json_object_from_text(text):
    cleaned = str(text or "").strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start >= 0 and end > start:
        cleaned = cleaned[start:end + 1]
    candidates = [cleaned, _repair_builder_json_like_text(cleaned)]
    last_error = None
    for candidate in candidates:
        if not str(candidate or "").strip():
            continue
        try:
            return json.loads(candidate)
        except Exception as error:
            last_error = error
    if last_error:
        raise last_error
    raise ValueError("Gemma did not return a JSON object.")


def _repair_builder_json_like_text(text):
    repaired = str(text or "").strip()
    repaired = repaired.replace("\u201c", '"').replace("\u201d", '"').replace("\u2018", "'").replace("\u2019", "'")
    repaired = re.sub(r"//.*?$", "", repaired, flags=re.MULTILINE)
    repaired = re.sub(r",\s*([}\]])", r"\1", repaired)
    json_keys = (
        "locations|scene_map|name|description|id|label|prompt|runner|used_model|"
        "title|premise|scenes|character_id|subject_id|speaker_id|location_id|"
        "dialogue|line|lyrics|story_beat|beat|visual_direction|summary|image_prompt|visual_prompt|"
        "shot_type|camera_motion|facial_performance|facial_performance_custom|emotion|delivery|"
        "motion_summary|video_notes|setting|location_name|character_name|speaker"
    )
    repaired = re.sub(
        rf'([{{\[,]\s*)({json_keys})\s*:',
        r'\1"\2":',
        repaired,
        flags=re.IGNORECASE,
    )
    repaired = re.sub(r'([{\[,]\s*)(Scene\s*\d+|Scene\d+)\s*:', lambda m: f'{m.group(1)}"{m.group(2).replace(" ", "")}":', repaired, flags=re.IGNORECASE)
    repaired = re.sub(
        rf'(^\s*)({json_keys})\s*:',
        r'\1"\2":',
        repaired,
        flags=re.IGNORECASE | re.MULTILINE,
    )
    repaired = re.sub(r'(^\s*)(Scene\s*\d+|Scene\d+)\s*:', lambda m: f'{m.group(1)}"{m.group(2).replace(" ", "")}":', repaired, flags=re.IGNORECASE | re.MULTILINE)
    # Gemma sometimes omits commas between array objects or object properties.
    repaired = re.sub(r'(["}\]])\s*\n\s*(")', r'\1,\n\2', repaired)
    repaired = re.sub(r'(})\s*\n\s*({)', r'\1,\n\2', repaired)
    repaired = re.sub(r'(})\s*({)', r'\1,\2', repaired)
    repaired = re.sub(r'(\])\s*("scene_map"\s*:)', r'\1,\2', repaired, flags=re.IGNORECASE)
    return repaired


def _parse_flux_location_map_fallback(text, cleaned_scenes, existing_locations=None):
    cleaned = _clean_visual_gemma_text(text)
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start >= 0 and end > start:
        cleaned = cleaned[start:end + 1]

    locations = []
    seen_names = set()
    location_block_match = re.search(
        r'"?locations"?\s*:\s*\[(.*?)]\s*,?\s*"?scene_map"?\s*:',
        cleaned,
        flags=re.IGNORECASE | re.DOTALL,
    )
    location_block = location_block_match.group(1) if location_block_match else ""
    for object_text in re.findall(r"\{(.*?)\}", location_block, flags=re.DOTALL):
        name_match = re.search(r'"?name"?\s*:\s*"([^"]+)"', object_text, flags=re.IGNORECASE | re.DOTALL)
        description_match = re.search(r'"?description"?\s*:\s*"([^"]*)"', object_text, flags=re.IGNORECASE | re.DOTALL)
        name = re.sub(r"\s+", " ", (name_match.group(1) if name_match else "").strip())
        description = re.sub(r"\s+", " ", (description_match.group(1) if description_match else "").strip())
        if not name or name.lower() in seen_names:
            continue
        seen_names.add(name.lower())
        locations.append({"name": name, "description": description})

    if not locations and isinstance(existing_locations, list):
        for item in existing_locations:
            if not isinstance(item, dict):
                continue
            name = re.sub(r"\s+", " ", str(item.get("name", "") or "").strip())
            description = re.sub(r"\s+", " ", str(item.get("description", "") or "").strip())
            if not name or name.lower() in seen_names:
                continue
            seen_names.add(name.lower())
            locations.append({"name": name, "description": description})

    scene_lookup = {}
    for index, scene in enumerate(cleaned_scenes, start=1):
        scene_lookup[str(scene["id"]).strip().lower()] = scene["id"]
        scene_lookup[str(scene["label"]).strip().lower()] = scene["id"]
        scene_lookup[f"scene {index}"] = scene["id"]
        scene_lookup[f"scene{index}"] = scene["id"]
        scene_lookup[str(index)] = scene["id"]

    scene_map = {}
    scene_block_match = re.search(r'"?scene_map"?\s*:\s*\{(.*?)\}\s*$', cleaned, flags=re.IGNORECASE | re.DOTALL)
    scene_block = scene_block_match.group(1) if scene_block_match else ""
    for raw_key, raw_location in re.findall(r'"([^"]+)"\s*:\s*"([^"]+)"', scene_block, flags=re.DOTALL):
        lookup_key = re.sub(r"\s+", " ", raw_key.strip().lower())
        scene_id = scene_lookup.get(lookup_key) or scene_lookup.get(lookup_key.replace(" ", ""))
        location_name = re.sub(r"\s+", " ", raw_location.strip())
        if scene_id and location_name:
            scene_map[scene_id] = location_name

    if locations:
        if not scene_map:
            scene_map = _fallback_location_map_by_overlap(cleaned_scenes, locations)
        else:
            valid_location_names = {item["name"].lower(): item["name"] for item in locations}
            for scene in cleaned_scenes:
                raw_name = re.sub(r"\s+", " ", str(scene_map.get(scene["id"], "") or "").strip())
                if raw_name.lower() not in valid_location_names:
                    scene_map[scene["id"]] = _best_location_for_scene(scene, locations)["name"]
        return {"locations": locations, "scene_map": scene_map}

    raise ValueError("Gemma location map could not be parsed as JSON or recovered from text.")


def _fallback_location_map_by_overlap(cleaned_scenes, locations):
    mapped = {}
    for scene in cleaned_scenes:
        mapped[scene["id"]] = _best_location_for_scene(scene, locations)["name"]
    return mapped


def _best_location_for_scene(scene, locations):
    if not locations:
        return {"name": "Location 1", "description": ""}
    scene_text = f"{scene.get('concept', '')} {scene.get('notes', '')}"
    best_location = locations[0]
    best_score = -1
    for location in locations:
        score = _location_text_overlap_score(
            scene_text,
            f"{location.get('name', '')} {location.get('description', '')}",
        )
        if score > best_score:
            best_location = location
            best_score = score
    return best_location


def _canonical_location_name(name, locations):
    raw = re.sub(r"\s+", " ", str(name or "").strip()).lower()
    for location in locations or []:
        loc_name = re.sub(r"\s+", " ", str(location.get("name", "") or "").strip())
        if loc_name.lower() == raw:
            return loc_name
    return ""


def _location_usage_counts_from_payload(payload, locations):
    names = [re.sub(r"\s+", " ", str(item.get("name", "") or "").strip()) for item in locations or []]
    counts = {name: 0 for name in names if name}
    raw_counts = payload.get("used_location_counts")
    if isinstance(raw_counts, dict):
        for raw_name, raw_count in raw_counts.items():
            name = _canonical_location_name(raw_name, locations)
            if name:
                try:
                    counts[name] = max(0, int(raw_count or 0))
                except Exception:
                    counts[name] = counts.get(name, 0)
    raw_assignments = payload.get("previous_assignments")
    if isinstance(raw_assignments, list):
        for item in raw_assignments:
            if isinstance(item, dict):
                name = _canonical_location_name(item.get("location") or item.get("location_name"), locations)
            else:
                name = _canonical_location_name(item, locations)
            if name:
                counts[name] = counts.get(name, 0) + 1
    return counts


def _balance_location_map_by_usage(scene_map, cleaned_scenes, locations, previous_counts=None):
    if not scene_map or not cleaned_scenes or not locations:
        return scene_map
    location_by_name = {}
    for item in locations:
        name = re.sub(r"\s+", " ", str(item.get("name", "") or "").strip())
        if name:
            location_by_name[name] = item
    location_names = list(location_by_name.keys())
    if len(location_names) <= 1:
        return scene_map
    balanced = {}
    fallback = _fallback_location_map_by_overlap(cleaned_scenes, locations)
    for scene in cleaned_scenes:
        name = _canonical_location_name(scene_map.get(scene["id"], ""), locations) or fallback.get(scene["id"], "")
        balanced[scene["id"]] = name

    previous_counts = previous_counts or {}
    current_counts = {name: 0 for name in location_names}
    for name in balanced.values():
        if name in current_counts:
            current_counts[name] += 1

    target_count = min(len(cleaned_scenes), len(location_names))
    desired_locations = sorted(
        location_names,
        key=lambda name: (int(previous_counts.get(name, 0) or 0), current_counts.get(name, 0), location_names.index(name)),
    )[:target_count]

    for desired_name in desired_locations:
        if current_counts.get(desired_name, 0) > 0:
            continue
        desired_location = location_by_name.get(desired_name) or {"name": desired_name, "description": ""}
        best_scene = None
        best_score = None
        for scene in cleaned_scenes:
            current_name = balanced.get(scene["id"], "")
            if current_name == desired_name:
                continue
            if current_counts.get(current_name, 0) <= 1 and any(current_counts.get(name, 0) == 0 for name in desired_locations if name != desired_name):
                continue
            scene_text = f"{scene.get('concept', '')} {scene.get('notes', '')}"
            desired_score = _location_text_overlap_score(scene_text, f"{desired_location.get('name', '')} {desired_location.get('description', '')}")
            current_location = location_by_name.get(current_name, {"name": current_name, "description": ""})
            current_score = _location_text_overlap_score(scene_text, f"{current_location.get('name', '')} {current_location.get('description', '')}")
            repeat_penalty = current_counts.get(current_name, 0) + int(previous_counts.get(current_name, 0) or 0)
            score = (desired_score - current_score) + repeat_penalty
            if best_score is None or score > best_score:
                best_score = score
                best_scene = scene
        if best_scene:
            old_name = balanced.get(best_scene["id"], "")
            if old_name in current_counts:
                current_counts[old_name] = max(0, current_counts[old_name] - 1)
            balanced[best_scene["id"]] = desired_name
            current_counts[desired_name] = current_counts.get(desired_name, 0) + 1
    return balanced


def _location_text_overlap_score(scene_text, location_text):
    stop_words = {
        "a", "an", "and", "are", "as", "at", "by", "for", "from", "in", "into", "is", "it",
        "of", "on", "or", "the", "to", "with", "scene", "shot", "cinematic", "woman", "man",
        "girl", "boy", "subject", "character", "wearing", "light", "lighting",
    }
    scene_tokens = {
        token for token in re.findall(r"[a-z0-9]+", str(scene_text or "").lower())
        if len(token) > 2 and token not in stop_words
    }
    location_tokens = [
        token for token in re.findall(r"[a-z0-9]+", str(location_text or "").lower())
        if len(token) > 2 and token not in stop_words
    ]
    if not scene_tokens or not location_tokens:
        return 0
    score = 0
    for token in location_tokens:
        if token in scene_tokens:
            score += 3
        elif any(scene_token.startswith(token) or token.startswith(scene_token) for scene_token in scene_tokens if len(scene_token) > 4):
            score += 1
    return score


def _parse_location_lines(text):
    locations = []
    seen_names = set()
    for raw_line in str(text or "").splitlines():
        line = raw_line.strip().strip("-").strip()
        if not line or line in {"{", "}", "[", "]"}:
            continue
        match = re.match(r"^\s*(?:Location\s*)?(\d+)\s*(?:[|:=\).-])\s*(.+?)\s*$", line, flags=re.IGNORECASE)
        if not match:
            continue
        rest = match.group(2).strip().strip('"').rstrip(",")
        parts = [part.strip().strip('"') for part in rest.split("|")]
        if len(parts) >= 2:
            name = parts[0]
            description = " | ".join(parts[1:])
        else:
            name = rest
            description = rest
        name = re.sub(r"^\s*name\s*[:=]\s*", "", name, flags=re.IGNORECASE)
        description = re.sub(r"^\s*description\s*[:=]\s*", "", description, flags=re.IGNORECASE)
        raw_name = name
        name, description = _clean_location_card(name, description, raw_name)
        if not name or _looks_like_location_meta_text(name) or _looks_like_location_meta_text(description) or not _valid_location_card(name, description) or name.lower() in seen_names:
            continue
        seen_names.add(name.lower())
        locations.append({"name": name, "description": description})
    return locations


def _looks_like_location_meta_text(value):
    text = re.sub(r"\s+", " ", str(value or "").strip()).lower()
    if not text:
        return True
    if len(text) > 140 and not re.search(r"\b(?:room|hall|hallway|corridor|street|road|forest|temple|pool|motel|stage|club|warehouse|desert|beach|shore|city|rooftop|alley|kitchen|bedroom|bathroom|church|chapel|station|train|car|bus|field|garden|vault|cave|lake|river|bridge|tunnel|apartment|house|mansion|hotel|bar|lounge|studio|parking|garage)\b", text):
        return True
    meta_patterns = (
        r"\bsince the provided\b",
        r"\bprovided .*content was not visible\b",
        r"\bprovided .*prompt\b",
        r"\bsubjectsandscenes\.txt\b",
        r"\bhere is (?:a|the)\b",
        r"\breusable location list\b",
        r"\bbased on the structural context\b",
        r"\bscene descriptions imply\b",
        r"\bcohesive project\b",
        r"\bi can(?:not|'t)\b",
        r"\bi(?:'|’)m sorry\b",
        r"\bas an ai\b",
        r"\boutput format\b",
        r"\buser input\b",
    )
    return any(re.search(pattern, text, flags=re.IGNORECASE) for pattern in meta_patterns)


_LOCATION_PLACE_WORDS = {
    "alley", "apartment", "arena", "attic", "ballroom", "bar", "barn", "bathroom", "beach", "bedroom",
    "bridge", "building", "cabin", "cafe", "casino", "cathedral", "cave", "chapel", "church", "city",
    "club", "corridor", "courtyard", "desert", "diner", "dock", "factory", "field", "forest", "foyer",
    "garage", "garden", "greenhouse", "hall", "hallway", "harbor", "hotel", "house", "kitchen", "lab",
    "lake", "lounge", "mansion", "market", "motel", "museum", "office", "palace", "parking", "pier",
    "pool", "quarry", "railway", "road", "rooftop", "room", "school", "set", "shore", "stage", "station",
    "street", "studio", "subway", "temple", "theater", "tower", "train", "tunnel", "vault", "warehouse",
    "workshop",
}

_NON_LOCATION_OBJECT_WORDS = {
    "bottle", "bowl", "bracelet", "camera", "candle", "chair", "collar", "comb", "crown", "dress",
    "frame", "glass", "kit", "knife", "locket", "mirror", "necklace", "perfume", "phone", "pocket",
    "razor", "rice", "ring", "shaving", "shoe", "sink", "sugar", "table", "tooth", "vanity", "veil", "window",
}

_LOCATION_SURFACE_WORDS = {
    "ceiling", "corner", "floor", "partition", "partitions", "wall", "walls",
}

_CHARACTER_WORDS = {
    "bride", "character", "face", "ghost", "girl", "hand", "human", "man", "person", "silhouette",
    "subject", "woman",
}


def _location_place_pattern():
    return r"(?:%s)" % "|".join(sorted((re.escape(word) for word in _LOCATION_PLACE_WORDS), key=len, reverse=True))


def _nice_location_name(value):
    text = re.sub(r"\s+", " ", str(value or "").strip(" ,.-"))
    if not text:
        return ""
    return text[:1].upper() + text[1:]


def _location_text_has_non_place_focus(value):
    tokens = set(re.findall(r"[a-z0-9]+", str(value or "").lower()))
    return bool(tokens & (_NON_LOCATION_OBJECT_WORDS | _LOCATION_SURFACE_WORDS | _CHARACTER_WORDS))


def _normalize_location_name(name):
    text = re.sub(r"\s+", " ", str(name or "").strip(" ,.-"))
    if not text:
        return ""
    lowered = text.lower()
    place_re = _location_place_pattern()
    tokens = set(re.findall(r"[a-z0-9]+", lowered))

    if re.search(r"\b(?:a|an|the|with|without|under|beneath|behind|beside|inside|outside|near|through|over|heavy|long|thick|deep|wide|large|small|empty|covered)\s*$", lowered):
        place_match = re.search(rf"^(.{{3,80}}?\b{place_re}\b)", text, flags=re.IGNORECASE)
        if place_match:
            return _nice_location_name(place_match.group(1))

    if tokens & (_NON_LOCATION_OBJECT_WORDS | _LOCATION_SURFACE_WORDS | _CHARACTER_WORDS):
        prep_match = re.search(
            rf"\b(?:in|inside|within|at|on|near|beside|behind|beneath|under)\s+(?:a|an|the)?\s*([^,.;]*?\b{place_re}\b(?:\s+\w+)?)",
            text,
            flags=re.IGNORECASE,
        )
        if prep_match:
            return _nice_location_name(prep_match.group(1))

        surface_match = re.search(
            rf"^(.{{3,80}}?\b{place_re}\b)\s+(?:{'|'.join(sorted(_LOCATION_SURFACE_WORDS | _NON_LOCATION_OBJECT_WORDS, key=len, reverse=True))})\b",
            text,
            flags=re.IGNORECASE,
        )
        if surface_match:
            return _nice_location_name(surface_match.group(1))

        trailing_object_match = re.search(
            rf"\b({place_re})\s+(?:{'|'.join(sorted(_LOCATION_SURFACE_WORDS | _NON_LOCATION_OBJECT_WORDS, key=len, reverse=True))})\b",
            text,
            flags=re.IGNORECASE,
        )
        if trailing_object_match:
            before = text[:trailing_object_match.end(1)].strip()
            return _nice_location_name(before)

    return _nice_location_name(text)


def _clean_location_card(name, description, raw_name=None):
    normalized_name = _normalize_location_name(name)
    cleaned_description = _clean_location_description(normalized_name, description)
    raw_text = str(raw_name if raw_name is not None else name or "")
    if normalized_name.lower() != re.sub(r"\s+", " ", raw_text.strip(" ,.-")).lower() and _location_text_has_non_place_focus(raw_text):
        cleaned_description = normalized_name
    return normalized_name, cleaned_description


def _location_name_fragment_is_complete(fragment):
    text = re.sub(r"\s+", " ", str(fragment or "").strip().lower())
    if not text:
        return False
    if re.search(r"\b(?:a|an|the|with|without|under|beneath|behind|beside|inside|outside|near|through|over|heavy|long|thick|deep|wide|large|small|empty|covered)\s*$", text):
        return False
    return bool(re.search(rf"\b{_location_place_pattern()}\b", text, flags=re.IGNORECASE))


def _location_name_is_place(name):
    text = re.sub(r"\s+", " ", str(name or "").strip().lower())
    if not text:
        return False
    tokens = set(re.findall(r"[a-z0-9]+", text))
    if tokens & _LOCATION_PLACE_WORDS:
        if tokens & (_NON_LOCATION_OBJECT_WORDS | _LOCATION_SURFACE_WORDS | _CHARACTER_WORDS):
            normalized = _normalize_location_name(name).lower()
            normalized_tokens = set(re.findall(r"[a-z0-9]+", normalized))
            if normalized_tokens & (_NON_LOCATION_OBJECT_WORDS | _LOCATION_SURFACE_WORDS | _CHARACTER_WORDS):
                return False
        return True
    if tokens & (_NON_LOCATION_OBJECT_WORDS | _LOCATION_SURFACE_WORDS | _CHARACTER_WORDS):
        return False
    if re.search(r"\b(?:inside|outside|interior|exterior|room|space|area|zone)\b", text):
        return True
    return False


def _clean_location_description(name, description):
    name_text = re.sub(r"\s+", " ", str(name or "").strip())
    desc = re.sub(r"\s+", " ", str(description or "").strip())
    if not desc:
        return name_text
    fragments = [part.strip(" .") for part in re.split(r"\s*,\s*", desc) if part.strip(" .")]
    kept = []
    for index, fragment in enumerate(fragments):
        fragment_lower = fragment.lower()
        if index > 0 and re.search(
            r"\b(?:bride|woman|man|girl|boy|face|hand|human|silhouette|wearing|watching|pressed|resting|trailing|caught|hidden|dissolving|reflecting|smelling)\b",
            fragment_lower,
        ):
            continue
        if index > 0 and re.search(r"\b(?:razor|tooth|dress|veil|bottle|locket|collar|frame|kit|rice|sugar bowl)\b", fragment_lower):
            continue
        kept.append(fragment)
    cleaned = ", ".join(kept).strip()
    if not cleaned:
        cleaned = name_text
    if name_text and not cleaned.lower().startswith(name_text.lower()):
        cleaned = f"{name_text}, {cleaned}"
    return cleaned


def _valid_location_card(name, description):
    if not _location_name_is_place(name):
        return False
    combined = f"{name} {description}".lower()
    if re.search(r"\b(?:character|subject|woman|man|girl|boy|bride|ghostly face|human tooth|hand pressed)\b", combined):
        desc_without_name = str(description or "").lower().replace(str(name or "").lower(), "")
        if not re.search(r"\b(?:room|hall|hallway|corridor|street|road|forest|garden|stage|kitchen|bathroom|bedroom|ballroom|pool|motel|warehouse|studio|city)\b", desc_without_name):
            return False
    return True


def _clean_location_context_text(value):
    text = str(value or "").strip()
    if not text:
        return ""
    lines = []
    for raw_line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        line = raw_line.strip()
        if not line:
            continue
        if re.search(r"\bsubjectsandscenes\.txt\b", line, flags=re.IGNORECASE):
            continue
        if re.search(r"\.(?:txt|json|srt)\b", line, flags=re.IGNORECASE) and re.search(r"[A-Za-z]:\\|/|\\", line):
            continue
        if _looks_like_location_meta_text(line):
            continue
        lines.append(line)
    cleaned = "\n".join(lines).strip()
    if _looks_like_location_meta_text(cleaned):
        return ""
    return cleaned


def _parse_location_idea_lines(text):
    locations = []
    seen_names = set()
    for raw_line in str(text or "").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if re.match(r"^\s*music\s+video\s+locations\s*:?\s*$", line, flags=re.IGNORECASE):
            continue
        line = re.sub(r"^\s*(?:[-*\u2022]+|\d+[\).:-])\s*", "", line).strip()
        line = line.strip('"').strip()
        if not line or line in {"{", "}", "[", "]"} or line.startswith("{") or line.startswith("["):
            continue
        if re.match(r"^(?:location ideas?|output|user input)\s*:?\s*$", line, flags=re.IGNORECASE):
            continue
        name = line
        description = line
        split_match = re.match(r"^(.{4,80}?)(?:\s+-\s+|\s+--\s+|:\s+)(.{4,})$", line)
        if split_match:
            name = split_match.group(1).strip()
            description = split_match.group(2).strip()
        else:
            comma_parts = line.split(",", 1)
            if len(comma_parts) == 2 and 4 <= len(comma_parts[0].strip()) <= 60 and _location_name_fragment_is_complete(comma_parts[0]):
                name = comma_parts[0].strip()
        raw_name = name
        name, description = _clean_location_card(name, description, raw_name)
        if _looks_like_location_meta_text(name) or _looks_like_location_meta_text(description) or not _valid_location_card(name, description) or name.lower() in seen_names:
            continue
        seen_names.add(name.lower())
        locations.append({"name": name, "description": description})
    return locations


def _parse_location_ideas_flexible(text):
    locations = _parse_location_idea_lines(text)
    if locations:
        return locations
    cleaned = _clean_visual_gemma_text(text)
    try:
        data = _extract_json_object_from_text(cleaned)
        if isinstance(data, dict):
            raw_locations = data.get("locations") or data.get("location_ideas") or data.get("music_video_locations")
        else:
            raw_locations = data
        if isinstance(raw_locations, list):
            parsed = []
            for item in raw_locations:
                if isinstance(item, dict):
                    raw_name = item.get("name") or item.get("location") or item.get("idea") or ""
                    name = _normalize_location_name(raw_name)
                    description = re.sub(r"\s+", " ", str(item.get("description") or item.get("detail") or item.get("visual_detail") or name).strip())
                else:
                    raw_name = item
                    name = _normalize_location_name(raw_name)
                    description = name
                name, description = _clean_location_card(name, description or name, raw_name)
                if name and not _looks_like_location_meta_text(name) and not _looks_like_location_meta_text(description) and _valid_location_card(name, description):
                    parsed.append({"name": name, "description": description or name})
            if parsed:
                return parsed
    except Exception:
        pass
    bulletish = re.split(r"(?:\n+|(?<=\.)\s+(?=[A-Z][A-Za-z ]{4,70}(?:\s+-|:)))", cleaned)
    parsed = _parse_location_idea_lines("\n".join(part.strip() for part in bulletish if part.strip()))
    if parsed:
        return parsed
    candidates = []
    for part in re.split(r";|\n", cleaned):
        part = re.sub(r"^\s*(?:Music Video Locations|Locations|Location ideas)\s*:?\s*", "", part.strip(), flags=re.I)
        if 4 <= len(part) <= 180 and not _looks_like_location_meta_text(part) and not re.search(r"\b(?:sorry|cannot|unable|lyrics|song meaning|summary)\b", part, flags=re.I):
            candidates.append(part)
    return _parse_location_idea_lines("\n".join(f"- {item}" for item in candidates))


def _parse_subject_lines(text):
    subjects = []
    for raw_line in str(text or "").splitlines():
      line = raw_line.strip().strip("-* ")
      if not line:
          continue
      match = re.match(r"^\s*(?:\d+[\).:\-|]\s*)?([^|:]+?)\s*\|\s*(.+)$", line)
      if match:
          name = re.sub(r"\s+", " ", match.group(1).strip())
          description = re.sub(r"\s+", " ", match.group(2).strip())
      else:
          match = re.match(r"^\s*(?:\d+[\).:\-|]\s*)?([^:]+?)\s*:\s*(.+)$", line)
          if not match:
              continue
          name = re.sub(r"\s+", " ", match.group(1).strip())
          description = re.sub(r"\s+", " ", match.group(2).strip())
      if name and description:
          subjects.append({"name": name, "description": description})
    return subjects


def _parse_scene_location_number_map(text, cleaned_scenes, locations):
    scene_map = {}
    scene_by_number = {str(index): scene["id"] for index, scene in enumerate(cleaned_scenes, start=1)}
    scene_by_label = {}
    for index, scene in enumerate(cleaned_scenes, start=1):
        scene_by_label[scene["id"].lower()] = scene["id"]
        scene_by_label[scene["label"].lower()] = scene["id"]
        scene_by_label[f"scene {index}"] = scene["id"]
        scene_by_label[f"scene{index}"] = scene["id"]
    location_by_number = {str(index): item["name"] for index, item in enumerate(locations, start=1)}
    location_by_name = {item["name"].lower(): item["name"] for item in locations}
    for raw_line in str(text or "").splitlines():
        line = raw_line.strip().strip(",")
        if not line:
            continue
        match = re.match(
            r'^\s*(?:Scene\s*)?("?[^"=:\|]+"?)\s*(?:=|:|\|)\s*(?:Location\s*)?("?[^",\s]+"?)',
            line,
            flags=re.IGNORECASE,
        )
        if not match:
            continue
        raw_scene = match.group(1).strip().strip('"').lower()
        raw_location = match.group(2).strip().strip('"').lower()
        scene_id = scene_by_number.get(raw_scene) or scene_by_label.get(raw_scene) or scene_by_label.get(raw_scene.replace(" ", ""))
        location_name = location_by_number.get(raw_location) or location_by_name.get(raw_location)
        if scene_id and location_name:
            scene_map[scene_id] = location_name
    return scene_map


def _read_text_file(path, label):
    if not str(path or "").strip():
        return ""
    text_path = _resolve_existing_file(path, label)
    with open(text_path, "r", encoding="utf-8-sig") as handle:
        return handle.read().strip()


def _resolve_editable_text_file(path):
    raw_path = str(path or "").strip().strip('"')
    if not raw_path:
        raise ValueError("Text file path is empty.")
    file_path = os.path.normpath(os.path.abspath(raw_path))
    if os.path.splitext(file_path)[1].lower() not in {".txt", ".json"}:
        raise ValueError("Only .txt or .json files can be edited here.")
    return file_path


def _load_editable_text_file(payload):
    file_path = _resolve_editable_text_file(payload.get("path", ""))
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"Text file was not found: {file_path}")
    with open(file_path, "r", encoding="utf-8-sig", errors="replace") as handle:
        return {"path": file_path, "content": handle.read()}


def _save_editable_text_file(payload):
    file_path = _resolve_editable_text_file(payload.get("path", ""))
    parent = os.path.dirname(file_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    content = str(payload.get("content", "") or "")
    with open(file_path, "w", encoding="utf-8", newline="") as handle:
        handle.write(content)
    return {"path": file_path}


def _segments_to_srt(segments, text_field="label"):
    lines = []
    ordered = sorted(segments, key=lambda item: float(item.get("start", 0) or 0))
    for index, segment in enumerate(ordered, start=1):
        start = float(segment.get("start", 0) or 0)
        end = max(start + 0.1, float(segment.get("end", start + 4) or start + 4))
        text = str(segment.get(text_field) or segment.get("label") or segment.get("t2i_prompt") or f"Scene {index}").strip()
        lines.extend([str(index), f"{_format_srt_time(start)} --> {_format_srt_time(end)}", text, ""])
    return "\n".join(lines).strip() + "\n"


def _read_audio_peaks_with_torchaudio(audio_path, target_peaks=1600):
    import torch
    import torchaudio

    waveform, sample_rate = torchaudio.load(audio_path)
    if waveform.numel() == 0:
        return {"duration": 0, "sample_rate": sample_rate, "channels": 0, "peaks": []}
    channels = int(waveform.shape[0])
    mono = waveform.mean(dim=0).abs()
    total_samples = int(mono.numel())
    duration = total_samples / float(sample_rate or 1)
    peak_count = max(1, min(int(target_peaks or 1600), total_samples))
    samples_per_peak = max(1, math.ceil(total_samples / peak_count))
    padded = peak_count * samples_per_peak - total_samples
    if padded > 0:
        mono = torch.nn.functional.pad(mono, (0, padded))
    chunks = mono.reshape(peak_count, samples_per_peak)
    peaks_tensor = torch.sqrt(torch.mean(chunks * chunks, dim=1)).clamp(0, 1)
    return {
        "duration": duration,
        "sample_rate": int(sample_rate or 0),
        "channels": channels,
        "peaks": [float(value) for value in peaks_tensor.cpu().tolist()],
    }


def _read_audio_peaks_with_wave(audio_path, target_peaks=1600):
    with wave.open(audio_path, "rb") as handle:
        channels = handle.getnchannels()
        sample_width = handle.getsampwidth()
        sample_rate = handle.getframerate()
        frames = handle.getnframes()
        duration = frames / float(sample_rate or 1)
        if sample_width not in (1, 2, 4):
            raise ValueError("Only 8-bit, 16-bit, and 32-bit WAV files are supported by the fallback reader.")
        raw = handle.readframes(frames)

    if not raw:
        return {"duration": duration, "sample_rate": sample_rate, "channels": channels, "peaks": []}

    import audioop

    mono = raw
    if channels > 1:
        mono = audioop.tomono(raw, sample_width, 0.5, 0.5)
    total_samples = len(mono) // sample_width
    peak_count = max(1, min(int(target_peaks or 1600), total_samples))
    samples_per_peak = max(1, math.ceil(total_samples / peak_count))
    peaks = []
    for offset in range(0, len(mono), samples_per_peak * sample_width):
        chunk = mono[offset: offset + samples_per_peak * sample_width]
        if not chunk:
            continue
        rms = audioop.rms(chunk, sample_width)
        maximum = float((1 << ((sample_width * 8) - 1)) - 1)
        peaks.append(min(1.0, rms / maximum if maximum else 0.0))

    return {
        "duration": duration,
        "sample_rate": sample_rate,
        "channels": channels,
        "peaks": peaks,
    }


def _read_audio_peaks_with_ffmpeg(audio_path, target_peaks=1600):
    sample_rate = 16000
    command = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel",
        "error",
        "-i",
        audio_path,
        "-vn",
        "-ac",
        "1",
        "-ar",
        str(sample_rate),
        "-f",
        "f32le",
        "pipe:1",
    ]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if result.returncode != 0:
        error_text = result.stderr.decode("utf-8", errors="replace").strip()
        raise ValueError(error_text or f"ffmpeg exited with code {result.returncode}")
    samples = array.array("f")
    samples.frombytes(result.stdout)
    if sys.byteorder != "little":
        samples.byteswap()
    total_samples = len(samples)
    duration = total_samples / float(sample_rate)
    if total_samples <= 0:
        return {"duration": 0, "sample_rate": sample_rate, "channels": 1, "peaks": []}
    peak_count = max(1, min(int(target_peaks or 1600), total_samples))
    samples_per_peak = max(1, math.ceil(total_samples / peak_count))
    peaks = []
    for start in range(0, total_samples, samples_per_peak):
        chunk = samples[start: start + samples_per_peak]
        if not chunk:
            continue
        total = 0.0
        for value in chunk:
            total += float(value) * float(value)
        peaks.append(min(1.0, math.sqrt(total / len(chunk))))
    return {
        "duration": duration,
        "sample_rate": sample_rate,
        "channels": 1,
        "peaks": peaks,
    }


def _read_audio_peaks(audio_path, target_peaks=1600):
    try:
        return _read_audio_peaks_with_torchaudio(audio_path, target_peaks)
    except Exception as torch_exc:
        try:
            return _read_audio_peaks_with_wave(audio_path, target_peaks)
        except Exception as wave_exc:
            try:
                return _read_audio_peaks_with_ffmpeg(audio_path, target_peaks)
            except Exception as ffmpeg_exc:
                raise ValueError(
                    "Could not read audio for waveform. Try a standard WAV, MP3, FLAC, or M4A file. "
                    f"torchaudio error: {torch_exc}; wav fallback error: {wave_exc}; ffmpeg fallback error: {ffmpeg_exc}"
                )


def _estimate_beats_from_peaks(peaks, duration):
    values = [float(value or 0) for value in peaks or []]
    total_duration = float(duration or 0)
    if len(values) < 8 or total_duration <= 0:
        return []
    step = total_duration / len(values)
    mean = sum(values) / len(values)
    variance = sum((value - mean) ** 2 for value in values) / len(values)
    std = math.sqrt(max(0.0, variance))
    threshold = mean + (std * 0.65)
    min_gap = max(0.22, min(0.55, total_duration / 500))
    beats = []
    beat_values = []
    last_time = -999.0
    for index in range(1, len(values) - 1):
        value = values[index]
        if value < threshold:
            continue
        if value < values[index - 1] or value < values[index + 1]:
            continue
        beat_time = index * step
        if beat_time - last_time < min_gap:
            # Keep the strongest peak in the minimum-gap window. Do not turn a
            # rounded timestamp back into an array index: floating-point
            # truncation can select the preceding bin and incorrectly replace
            # a stronger, correctly timed peak with a later weaker one.
            if beats and value > beat_values[-1]:
                beats[-1] = round(beat_time, 3)
                beat_values[-1] = value
                last_time = beat_time
            continue
        beats.append(round(beat_time, 3))
        beat_values.append(value)
        last_time = beat_time
    return beats


def _coerce_tempo_bpm(value):
    try:
        if hasattr(value, "reshape"):
            value = value.reshape(-1)[0]
        elif isinstance(value, (list, tuple)):
            value = value[0] if value else 0
        bpm = float(value or 0)
    except (TypeError, ValueError, IndexError):
        return 0.0
    return round(bpm, 6) if math.isfinite(bpm) and bpm > 0 else 0.0


def _tempo_from_beat_times(beats):
    values = sorted(float(value) for value in beats or [] if math.isfinite(float(value)))
    intervals = [
        values[index] - values[index - 1]
        for index in range(1, len(values))
        if values[index] - values[index - 1] > 0.05
    ]
    if not intervals:
        return 0.0
    intervals.sort()
    middle = len(intervals) // 2
    median = intervals[middle] if len(intervals) % 2 else (intervals[middle - 1] + intervals[middle]) / 2.0
    return round(60.0 / median, 6) if median > 0 else 0.0


def _estimate_beats_from_audio(audio_path, peaks, duration, include_tempo=False):
    """Return musical beat positions, falling back to RMS peaks when needed."""
    try:
        import librosa

        waveform, sample_rate = librosa.load(audio_path, sr=22050, mono=True)
        if waveform is None or len(waveform) < 2:
            raise ValueError("Audio contains no samples.")
        onset_envelope = librosa.onset.onset_strength(y=waveform, sr=sample_rate)
        if onset_envelope is None or len(onset_envelope) < 2:
            raise ValueError("Audio contains no detectable onset envelope.")
        tempo_bpm, beat_frames = librosa.beat.beat_track(
            onset_envelope=onset_envelope,
            sr=sample_rate,
            trim=False,
        )
        # Put each grid beat on the transient's leading edge instead of the
        # later energy maximum, matching what the waveform shows visually.
        beat_frames = librosa.onset.onset_backtrack(beat_frames, onset_envelope)
        beat_times = librosa.frames_to_time(beat_frames, sr=sample_rate)
        maximum = max(0.0, float(duration or (len(waveform) / float(sample_rate or 1))))
        result = []
        for value in beat_times:
            beat_time = round(float(value), 3)
            if beat_time < 0 or (maximum > 0 and beat_time > maximum + 0.001):
                continue
            if not result or beat_time > result[-1]:
                result.append(beat_time)
        if result:
            bpm = _coerce_tempo_bpm(tempo_bpm) or _tempo_from_beat_times(result)
            return (result, bpm) if include_tempo else result
    except Exception:
        # librosa is optional in some ComfyUI installations. The corrected RMS
        # detector remains available so audio loading never depends on it.
        pass
    result = _estimate_beats_from_peaks(peaks, duration)
    bpm = _tempo_from_beat_times(result)
    return (result, bpm) if include_tempo else result


def _load_json_file(path):
    with open(path, "r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def _extract_capcut_project_beats(draft, draft_path=""):
    if not isinstance(draft, dict):
        return None
    materials = draft.get("materials") if isinstance(draft.get("materials"), dict) else {}
    audio_materials = {
        str(item.get("id") or ""): item
        for item in materials.get("audios", []) or []
        if isinstance(item, dict) and str(item.get("id") or "")
    }
    audio_segments = []
    for track in draft.get("tracks", []) or []:
        if not isinstance(track, dict) or str(track.get("type") or "").lower() != "audio":
            continue
        audio_segments.extend(item for item in track.get("segments", []) or [] if isinstance(item, dict))
    audio_segment = audio_segments[0] if audio_segments else {}
    audio_material = audio_materials.get(str(audio_segment.get("material_id") or ""), {})
    referenced_ids = {str(value) for value in audio_segment.get("extra_material_refs", []) or [] if str(value)}

    time_marks = [item for item in materials.get("time_marks", []) or [] if isinstance(item, dict)]
    linked_time_marks = [item for item in time_marks if str(item.get("id") or "") in referenced_ids]
    marker_times = []
    for collection in linked_time_marks or time_marks:
        for marker in collection.get("mark_items", []) or []:
            if not isinstance(marker, dict):
                continue
            time_range = marker.get("time_range") if isinstance(marker.get("time_range"), dict) else {}
            try:
                marker_time = float(time_range.get("start") or 0) / 1_000_000.0
            except (TypeError, ValueError):
                continue
            if marker_time >= 0:
                marker_times.append(round(marker_time, 6))
    marker_times = sorted(set(marker_times))

    beat_materials = [item for item in materials.get("beats", []) or [] if isinstance(item, dict)]
    linked_beats = [item for item in beat_materials if str(item.get("id") or "") in referenced_ids]
    beat_material = (linked_beats or beat_materials or [{}])[0]
    ai_beats = beat_material.get("ai_beats") if isinstance(beat_material.get("ai_beats"), dict) else {}
    beat_cache_path = os.path.normpath(str(ai_beats.get("beats_path") or "").strip())
    cache_times = []
    beat_values = []
    if beat_cache_path and os.path.isfile(beat_cache_path):
        try:
            cache_data = _load_json_file(beat_cache_path)
            if isinstance(cache_data, dict):
                for value in cache_data.get("time", []) or []:
                    try:
                        cache_time = float(value) / 1000.0
                    except (TypeError, ValueError):
                        continue
                    if cache_time >= 0:
                        cache_times.append(round(cache_time, 6))
                beat_values = list(cache_data.get("value", []) or [])
        except Exception:
            cache_times = []
            beat_values = []

    # CapCut's visible project markers are frame-aligned. Prefer them when they
    # correspond one-for-one with the AI cache; otherwise use the raw AI times.
    if marker_times and (not cache_times or abs(len(marker_times) - len(cache_times)) <= 1):
        beats = marker_times
        beat_source = "timeline_markers"
    else:
        beats = sorted(set(cache_times))
        beat_source = "ai_beat_cache"
    if len(beats) < 2:
        return None
    duration = float(draft.get("duration") or 0) / 1_000_000.0
    return {
        "project_name": str(draft.get("name") or "").strip() or os.path.basename(os.path.dirname(draft_path)),
        "draft_path": os.path.abspath(draft_path) if draft_path else "",
        "project_fps": float(draft.get("fps") or 0),
        "project_duration": duration,
        "audio_name": str(audio_material.get("name") or "").strip(),
        "audio_path": str(audio_material.get("path") or "").strip(),
        "beat_cache_path": beat_cache_path,
        "beat_source": beat_source,
        "beats": beats,
        "raw_ai_beats": cache_times,
        "beat_values": beat_values,
    }


def _find_latest_capcut_beats(audio_duration=0):
    local_app_data = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Local")
    index_path = os.path.join(
        local_app_data,
        "CapCut",
        "User Data",
        "Projects",
        "com.lveditor.draft",
        "root_meta_info.json",
    )
    if not os.path.isfile(index_path):
        raise FileNotFoundError(f"CapCut project index was not found: {index_path}")
    index_data = _load_json_file(index_path)
    entries = index_data.get("all_draft_store", []) if isinstance(index_data, dict) else []
    entries = sorted(
        (item for item in entries if isinstance(item, dict) and not item.get("tm_draft_removed")),
        key=lambda item: float(item.get("tm_draft_modified") or 0),
        reverse=True,
    )
    requested_duration = max(0.0, float(audio_duration or 0))
    latest_with_beats = None
    for entry in entries[:150]:
        draft_path = os.path.normpath(str(entry.get("draft_json_file") or "").strip())
        if not draft_path or not os.path.isfile(draft_path):
            continue
        try:
            result = _extract_capcut_project_beats(_load_json_file(draft_path), draft_path)
        except Exception:
            continue
        if not result:
            continue
        result["project_name"] = str(entry.get("draft_name") or result.get("project_name") or "").strip()
        result["project_modified"] = float(entry.get("tm_draft_modified") or 0)
        latest_with_beats = latest_with_beats or result
        if requested_duration <= 0 or abs(float(result.get("project_duration") or 0) - requested_duration) <= 0.75:
            return result
    if latest_with_beats and requested_duration <= 0:
        return latest_with_beats
    if latest_with_beats:
        raise ValueError(
            "CapCut projects with beat data were found, but none matched the loaded audio duration within 0.75 seconds."
        )
    raise ValueError("No CapCut project containing beat data was found.")


def _looks_like_gemma_repeat_failure(text):
    sample = re.sub(r"\s+", " ", str(text or "").lower()).strip()
    if not sample:
        return False

    compact = re.sub(r"[^a-z0-9_<>\-|]+", "", sample)
    for marker in (
        "completion-completion-completion",
        "thought-thought-thought",
        "de-facto-de-facto-de-facto",
        "de-fleshed",
        "cast-cast-cast",
        "prompt-cast-cast",
        "thoughtthoughtthought",
        "ownnessownnessownness",
        "nessnessnessness",
        "model_model_model",
        "modelmodelmodel",
        "end_anow",
        "thought_turn",
        "turn_turn",
        "<|channel>",
        "<channel|>",
    ):
        if marker in compact or marker in sample:
            return True

    if re.search(r"([a-z]{2,16})\1{5,}", compact):
        return True

    if re.search(r"(?:^|_)([a-z]{2,24})(?:_\1){5,}(?:_|$)", compact):
        return True

    if re.search(r"\b([a-zA-Z_]{3,})(?:[-\s]+\1){5,}\b", sample):
        return True

    unicode_tokens = re.findall(r"[\w']+", sample, flags=re.UNICODE)
    unicode_tokens = [token.strip("_'") for token in unicode_tokens if token.strip("_'")]
    if len(unicode_tokens) >= 16:
        token_counts = {}
        for token in unicode_tokens:
            token_counts[token] = token_counts.get(token, 0) + 1
        if token_counts and max(token_counts.values()) >= 10 and max(token_counts.values()) / float(len(unicode_tokens)) >= 0.20:
            return True
        for size in (2, 3, 4):
            if len(unicode_tokens) < size * 4:
                continue
            phrase_counts = {}
            for index in range(len(unicode_tokens) - size + 1):
                phrase = " ".join(unicode_tokens[index:index + size])
                phrase_counts[phrase] = phrase_counts.get(phrase, 0) + 1
            if phrase_counts and max(phrase_counts.values()) >= 8:
                return True

    words = re.findall(r"[a-zA-Z_][a-zA-Z_']{2,}", sample)
    if len(words) < 18:
        return False

    counts = {}
    for word in words:
        counts[word] = counts.get(word, 0) + 1
    common_words = {"the", "and", "with", "that", "this", "from", "into", "while", "during"}
    repeated_words = [
        count
        for word, count in counts.items()
        if word not in common_words
    ]
    if repeated_words and max(repeated_words) >= 10 and max(repeated_words) / float(len(words)) >= 0.25:
        return True

    phrases = [" ".join(words[index:index + 2]) for index in range(len(words) - 1)]
    if len(phrases) >= 12:
        phrase_counts = {}
        for phrase in phrases:
            phrase_counts[phrase] = phrase_counts.get(phrase, 0) + 1
        if max(phrase_counts.values()) >= 6:
            return True

    return False


def _looks_like_unfilled_prompt_template(text):
    sample = str(text or "").strip()
    if not sample:
        return False
    bracketed = re.findall(r"\[([^\]]{2,80})\]", sample)
    if len(bracketed) >= 2:
        return True
    placeholder_terms = (
        "subject",
        "setting",
        "environment",
        "time",
        "weather",
        "camera motion",
        "dynamic performance",
        "subject visibility",
        "framing",
        "reacts dynamically",
        "clothing",
        "hair",
    )
    lowered = sample.lower()
    if any(f"[{term}]" in lowered for term in placeholder_terms):
        return True
    if re.search(r"\[[^\]]*(?:subject|setting|environment|camera|motion|weather|lighting|dynamic|framing)[^\]]*\]", lowered):
        return True
    return False


def _looks_like_bad_reference_description(text):
    sample = re.sub(r"\s+", " ", str(text or "").strip())
    if not sample:
        return True
    if _looks_like_gemma_repeat_failure(sample) or _looks_like_unfilled_prompt_template(sample):
        return True
    tokens = re.findall(r"[\w']+", sample.lower(), flags=re.UNICODE)
    tokens = [token.strip("_'") for token in tokens if token.strip("_'")]
    if not tokens:
        return True
    if len(tokens) < 6 and len(set(tokens)) <= 2:
        return True
    counts = {}
    for token in tokens:
        counts[token] = counts.get(token, 0) + 1
    if counts:
        max_count = max(counts.values())
        if max_count >= 3 and max_count / float(len(tokens)) >= 0.45:
            return True
    for size in (1, 2, 3):
        if len(tokens) < size * 3:
            continue
        for index in range(0, len(tokens) - (size * 3) + 1):
            chunk = tokens[index:index + size]
            if all(tokens[index + offset:index + offset + size] == chunk for offset in range(size, size * 3, size)):
                return True
    alpha_chars = re.findall(r"[a-zA-Z]", sample)
    if len(alpha_chars) < 18:
        return True
    return False


def _looks_like_id_lora_script_prompt(text):
    sample = str(text or "").strip().lower()
    return all(label in sample for label in ("[visual]", "[speech]", "[sounds]"))


def _normalized_prompt_similarity_text(text):
    return " ".join(re.findall(r"[\w']+", str(text or "").lower(), flags=re.UNICODE))


def _looks_like_source_lyric_echo(text, payload):
    source = str((payload or {}).get("lyric_text") or (payload or {}).get("lyrics") or "").strip()
    candidate = str(text or "").strip()
    if not source or not candidate:
        return False
    source_norm = _normalized_prompt_similarity_text(source)
    candidate_norm = _normalized_prompt_similarity_text(candidate)
    if not source_norm or not candidate_norm:
        return False
    if candidate_norm == source_norm:
        return True
    source_tokens = source_norm.split()
    candidate_tokens = candidate_norm.split()
    if len(source_tokens) < 4 or len(candidate_tokens) < 4:
        return False
    source_set = set(source_tokens)
    candidate_set = set(candidate_tokens)
    overlap = len(source_set & candidate_set) / float(max(1, len(candidate_set)))
    length_ratio = min(len(source_tokens), len(candidate_tokens)) / float(max(len(source_tokens), len(candidate_tokens)))
    visual_terms = {
        "cinematic", "shot", "still", "frame", "portrait", "wide", "closeup", "close", "medium",
        "camera", "lens", "lighting", "background", "foreground", "composition", "scene",
        "environment", "location", "color", "palette", "texture", "detail", "reference",
    }
    has_visual_terms = bool(candidate_set & visual_terms)
    return overlap >= 0.90 and length_ratio >= 0.75 and not has_visual_terms


def _validate_reference_description(text, label):
    if _looks_like_bad_reference_description(text):
        raise ValueError(
            f"Gemma returned unusable repeated text for the {label} description. "
            "Try again, or use a clearer reference image."
        )


def _validate_builder_gemma_prompt(text, label, payload=None):
    if not str(text or "").strip():
        raise ValueError(f"Gemma returned an empty {label} prompt.")
    if _looks_like_source_lyric_echo(text, payload):
        raise ValueError(
            f"Gemma returned the scene lyrics instead of a usable {label} image prompt. "
            "Try again, add a short visual scene beat, or reduce Lyric Story Strength."
        )
    if _looks_like_gemma_repeat_failure(text):
        hint = "Try again or shorten the notes."
        if str(label or "").lower() != "flux/klein":
            hint = "Try again, shorten the notes, or turn off image reference."
        raise ValueError(
            f"Gemma returned repeated/thought text for the {label} prompt. "
            f"{hint}"
        )
    label_key = str(label or "").strip().lower().replace(" ", "_")
    if _looks_like_unfilled_prompt_template(text) and not (label_key in {"id-lora", "id_lora", "id-lora_i2v"} and _looks_like_id_lora_script_prompt(text)):
        raise ValueError(
            f"Gemma returned an unfilled template for the {label} prompt. "
            "Try again or add more specific scene/motion notes."
        )


def _llm_runner_from_payload(payload):
    runner = str(payload.get("text_runner") or payload.get("text_gemma_runner") or payload.get("gemma_runner") or "builtin").strip().lower()
    if runner in {"lmstudio", "lm-studio", "lm_studio"}:
        runner = "lm_studio"
    if runner in {"llmapi", "llm-api", "llm_api", "api", "outside_api", "outside_llm_api"}:
        runner = "llm_api"
    if runner in {"ownserver", "own-server", "own_server", "custom_openai", "openai_compatible", "custom_server", "my_server"}:
        runner = "own_server"
    if runner in {"qwen", "qwen_local", "qwen-local", "qwen_gguf", "qwen_gguf_local"}:
        runner = "qwen_local"
    if runner not in {"builtin", "qwen_local", "lm_studio", "llm_api", "own_server"}:
        runner = "builtin"
    return runner


def _llm_runner_display_name(payload, vision=False):
    runner = _llm_runner_from_payload(payload)
    names = {
        "builtin": "Gemma Local",
        "qwen_local": "Qwen Local",
        "lm_studio": "LM Studio",
        "llm_api": "LLM API",
        "own_server": "Custom Server",
    }
    name = names.get(runner, "Gemma Local")
    return f"{name} vision" if vision else name


def _builder_local_llm(payload):
    from .LLM import VRGDG_QwenGGUF, VRGDG_SuperGemmaGGUFChat
    if _llm_runner_from_payload(payload) == "qwen_local":
        llm = VRGDG_QwenGGUF()
    else:
        llm = VRGDG_SuperGemmaGGUFChat()
    # Builder prompt jobs need direct structured output, not a reasoning
    # preamble. Set this explicitly for both local runners because model chat
    # templates can default to thinking mode when the flag is omitted.
    llm._qwen_chat_template_kwargs = {"enable_thinking": False}
    return llm


def _builder_local_model_file(payload, current=""):
    if _llm_runner_from_payload(payload) == "qwen_local":
        return str(payload.get("qwen_model_file") or current or "").strip()
    if _llm_runner_from_payload(payload) == "builtin" and payload.get("gemma_model_file"):
        return str(payload.get("gemma_model_file") or current or "").strip()
    return str(current or "").strip()


def _builder_local_mmproj_file(payload, current=""):
    if _llm_runner_from_payload(payload) == "qwen_local":
        return str(payload.get("qwen_mmproj_file") or current or "").strip()
    return str(current or "").strip()

def _own_server_v1_root(raw_url):
    url = str(raw_url or "").strip()
    if not url:
        raise ValueError("Own server URL is empty. Open LLM Runner and paste your server URL.")
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("Own server URL must start with http:// or https://.")
    if not parsed.netloc:
        raise ValueError("Own server URL is missing a host.")
    path = (parsed.path or "").rstrip("/")
    lowered = path.lower()
    for suffix in ("/chat/completions", "/completions", "/models"):
        if lowered.endswith(suffix):
            path = path[: -len(suffix)]
            lowered = path.lower()
            break
    if lowered.endswith("/v1"):
        v1_path = path
    elif path:
        v1_path = f"{path}/v1"
    else:
        v1_path = "/v1"
    return urllib.parse.urlunparse((parsed.scheme, parsed.netloc, v1_path, "", "", ""))


def _own_server_api_key(payload):
    payload = payload if isinstance(payload, dict) else {}
    return str(
        payload.get("own_server_api_key")
        or payload.get("own_server_key")
        or payload.get("api_key")
        or ""
    ).strip()


def _own_server_model_name(payload):
    payload = payload if isinstance(payload, dict) else {}
    return str(
        payload.get("own_server_model")
        or payload.get("model")
        or payload.get("model_file")
        or ""
    ).strip()


def _own_server_timeout(payload, default=360):
    payload = payload if isinstance(payload, dict) else {}
    try:
        timeout = float(payload.get("own_server_timeout") or default)
    except (TypeError, ValueError):
        timeout = float(default)
    return max(15.0, min(600.0, timeout))


def _own_server_headers(payload):
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "User-Agent": "VRGDG-OwnServer/1.0 (+ComfyUI)",
    }
    api_key = _own_server_api_key(payload)
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    return headers


def _own_server_ssl_context(url):
    if not str(url or "").lower().startswith("https://"):
        return None
    return ssl.create_default_context()


def _own_server_request_json(url, payload, method="POST", body=None, timeout=180):
    headers = _own_server_headers(payload)
    if str(method or "POST").upper() == "GET":
        headers.pop("Content-Type", None)
    data = None if body is None else json.dumps(body).encode("utf-8")
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    ssl_context = _own_server_ssl_context(url)

    def _open(context):
        with urllib.request.urlopen(request, timeout=float(timeout), context=context) as response:
            raw = response.read().decode("utf-8", errors="replace")
            if not raw.strip():
                return {}
            return json.loads(raw)

    try:
        return _open(ssl_context)
    except ssl.SSLError as exc:
        raise RuntimeError(
            f"TLS certificate validation failed for own server at {url}. "
            "Install a trusted certificate or use HTTP only for a server on a trusted local network."
        ) from exc
    except urllib.error.HTTPError as exc:
        details = exc.read().decode("utf-8", errors="replace") if hasattr(exc, "read") else ""
        raise RuntimeError(f"Own server request failed ({exc.code}): {details or exc.reason}") from exc
    except urllib.error.URLError as exc:
        if isinstance(getattr(exc, "reason", None), ssl.SSLError):
            raise RuntimeError(
                f"TLS certificate validation failed for own server at {url}. "
                "Install a trusted certificate or use HTTP only for a server on a trusted local network."
            ) from exc
        raise RuntimeError(
            f"Could not connect to own server at {url}. Check the URL, local bind address, or Cloudflare tunnel."
        ) from exc


def _own_server_message_text(data):
    if not isinstance(data, dict):
        return ""
    choices = data.get("choices")
    if isinstance(choices, list) and choices:
        message = choices[0].get("message", {}) if isinstance(choices[0], dict) else {}
        content = message.get("content") if isinstance(message, dict) else ""
        if isinstance(content, list):
            parts = []
            for item in content:
                if isinstance(item, str):
                    parts.append(item)
                elif isinstance(item, dict):
                    item_type = str(item.get("type") or "").lower()
                    if item_type in {"text", "output_text"}:
                        parts.append(str(item.get("text") or ""))
                    elif isinstance(item.get("text"), str):
                        parts.append(item.get("text"))
                    elif isinstance(item.get("content"), str):
                        parts.append(item.get("content"))
            content = "".join(parts)
        text = str(content or "").strip()
        if text:
            return text
        for key in ("reasoning_content", "refusal"):
            extra = message.get(key) if isinstance(message, dict) else None
            if extra:
                return str(extra).strip()
        choice_text = choices[0].get("text") if isinstance(choices[0], dict) else None
        if choice_text:
            return str(choice_text).strip()
    for key in ("output_text", "response", "text", "content"):
        value = data.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _own_server_chat_messages(instruction_text, pil_images=None):
    images = [image for image in list(pil_images or []) if image is not None]
    if not images:
        return [{"role": "user", "content": str(instruction_text or "")}]
    content = [{"type": "text", "text": str(instruction_text or "")}]
    for image in images[:4]:
        content.append({
            "type": "image_url",
            "image_url": {
                "url": _pil_image_to_data_url(image, max_height=1024, quality=90),
            },
        })
    return [{"role": "user", "content": content}]


def _run_own_server_chat(payload, instruction_text, pil_images=None, temperature=0.6, top_p=0.95, max_new_tokens=1200):
    v1_root = _own_server_v1_root(
        payload.get("own_server_url") or payload.get("base_url") or _OWN_SERVER_DEFAULT_BASE_URL
    )
    model = _own_server_model_name(payload)
    if not model:
        raise ValueError("Own server model name is missing. Open LLM Runner and enter the served model id.")
    body = {
        "model": model,
        "messages": _own_server_chat_messages(instruction_text, pil_images),
        "temperature": float(temperature),
        "top_p": float(top_p),
        "stream": False,
        "max_tokens": int(_runner_output_token_limit(payload, max_new_tokens)),
    }
    url = f"{v1_root}/chat/completions"
    try:
        data = _own_server_request_json(url, payload, body=body, timeout=_own_server_timeout(payload))
    except RuntimeError as exc:
        message = str(exc).lower()
        if "max_tokens" in message and ("unknown" in message or "unsupported" in message or "400" in message):
            retry_body = dict(body)
            retry_body["max_completion_tokens"] = retry_body.pop("max_tokens")
            data = _own_server_request_json(url, payload, body=retry_body, timeout=_own_server_timeout(payload))
        else:
            raise
    text = _own_server_message_text(data)
    if not text:
        raise ValueError("Own server returned empty text.")
    return text, {
        "runner": "own_server_vision" if pil_images else "own_server",
        "used_provider": "own_server",
        "used_model": model,
        "unloaded": False,
        "base_url": v1_root,
    }


def _run_own_server_text(payload, instruction_text, temperature=0.6, top_p=0.95, max_new_tokens=1200):
    return _run_own_server_chat(
        payload,
        instruction_text,
        temperature=temperature,
        top_p=top_p,
        max_new_tokens=max_new_tokens,
    )


def _run_own_server_vision(payload, instruction_text, pil_images, temperature=0.25, top_p=0.95, max_new_tokens=1200):
    images = list(pil_images or [])
    if not images:
        raise ValueError("Own server vision needs at least one image reference.")
    return _run_own_server_chat(
        payload,
        instruction_text,
        pil_images=images,
        temperature=temperature,
        top_p=top_p,
        max_new_tokens=max_new_tokens,
    )


def _try_run_remote_vision(payload, instruction_text, pil_images, temperature=0.25, top_p=0.95, max_new_tokens=1200):
    runner = _llm_runner_from_payload(payload)
    if runner == "llm_api":
        return _run_llm_api_vision(payload, instruction_text, pil_images)
    if runner == "own_server":
        return _run_own_server_vision(
            payload,
            instruction_text,
            pil_images,
            temperature=temperature,
            top_p=top_p,
            max_new_tokens=max_new_tokens,
        )
    if runner == "lm_studio":
        text = _run_lm_studio_vision(
            payload,
            instruction_text,
            pil_images,
            temperature=temperature,
            top_p=top_p,
            max_new_tokens=max_new_tokens,
        )
        return text, {
            "runner": "lm_studio_vision",
            "used_model": str(payload.get("lmstudio_model") or "").strip(),
            "unloaded": False,
        }
    return None


def _list_own_server_models(payload):
    v1_root = _own_server_v1_root(
        payload.get("own_server_url") or payload.get("base_url") or _OWN_SERVER_DEFAULT_BASE_URL
    )
    data = _own_server_request_json(
        f"{v1_root}/models",
        payload,
        method="GET",
        timeout=min(45.0, _own_server_timeout(payload, 45)),
    )
    models = []
    raw_models = data.get("data") if isinstance(data, dict) else None
    if isinstance(raw_models, list):
        for item in raw_models:
            if isinstance(item, str) and item.strip():
                models.append(item.strip())
            elif isinstance(item, dict):
                model_id = str(item.get("id") or item.get("name") or "").strip()
                if model_id:
                    models.append(model_id)
    return {"models": models, "base_url": v1_root}


def _test_own_server(payload):
    prompt = str(payload.get("prompt") or "Reply with OK only.").strip() or "Reply with OK only."
    text, info = _run_own_server_text(payload, prompt, temperature=0.1, top_p=0.9, max_new_tokens=64)
    return {
        "text": text,
        "used_provider": "own_server",
        "used_model": info.get("used_model", ""),
        "base_url": info.get("base_url", ""),
    }



def _normalized_token_limit(value, default, minimum=64, maximum=262144):
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        parsed = int(default)
    return max(int(minimum), min(int(maximum), parsed))


def _runner_output_token_limit(payload, requested=1200):
    payload = payload if isinstance(payload, dict) else {}
    runner = _llm_runner_from_payload(payload)
    if runner == "lm_studio":
        configured = payload.get("lmstudio_output_token_limit")
        if configured in (None, ""):
            configured = payload.get("lm_studio_output_token_limit")
    elif runner == "own_server":
        configured = payload.get("own_server_output_token_limit")
    elif runner == "builtin":
        configured = payload.get("gemma_output_token_limit")
    else:
        configured = None
    if runner in {"builtin", "lm_studio", "own_server"} and configured in (None, ""):
        configured = payload.get("llm_max_tokens")
    if configured not in (None, ""):
        return _normalized_token_limit(configured, requested)
    return _normalized_token_limit(requested, 1200)


def _lm_studio_context_limit(payload):
    payload = payload if isinstance(payload, dict) else {}
    configured = payload.get("lmstudio_context_limit")
    if configured in (None, ""):
        configured = payload.get("lm_studio_context_limit")
    return _normalized_token_limit(configured, 32768, minimum=512)


def _lm_studio_reasoning_mode(payload, default=""):
    payload = payload if isinstance(payload, dict) else {}
    configured = payload.get("lmstudio_reasoning")
    if configured in (None, ""):
        configured = payload.get("lm_studio_reasoning")
    normalized = str(configured or "").strip().lower()
    allowed = {"off", "low", "medium", "high", "on"}
    if normalized in allowed:
        return normalized
    fallback = str(default or "").strip().lower()
    return fallback if fallback in allowed else ""


def _lm_studio_api_root(payload):
    base_url = str(payload.get("lmstudio_base_url") or _LM_STUDIO_DEFAULT_BASE_URL).strip().rstrip("/")
    if base_url.lower().endswith("/v1"):
        return base_url[:-3].rstrip("/")
    return base_url


def _lm_studio_native_output_text(data):
    output = data.get("output") if isinstance(data, dict) else None
    if not isinstance(output, list):
        return ""
    parts = []
    for item in output:
        if not isinstance(item, dict) or str(item.get("type") or "").lower() != "message":
            continue
        content = item.get("content")
        if isinstance(content, str):
            parts.append(content)
        elif isinstance(content, list):
            for block in content:
                if isinstance(block, str):
                    parts.append(block)
                elif isinstance(block, dict):
                    text = block.get("text") or block.get("content")
                    if text:
                        parts.append(str(text))
    return "\n".join(part.strip() for part in parts if str(part or "").strip()).strip()


def _run_lm_studio_native_chat(payload, input_value, temperature, top_p, max_new_tokens, timeout, label, reasoning_default=""):
    api_root = _lm_studio_api_root(payload)
    model = str(payload.get("lmstudio_model") or payload.get("model_file") or "").strip()
    api_key = str(payload.get("lmstudio_api_key") or "").strip()
    if not api_root:
        raise ValueError("LM Studio base URL is empty.")
    if not model:
        raise ValueError(f"Enter the LM Studio {label}model name shown in LM Studio.")
    body = {
        "model": model,
        "input": input_value,
        "temperature": float(temperature),
        "top_p": float(top_p),
        "context_length": _lm_studio_context_limit(payload),
        "max_output_tokens": _runner_output_token_limit(payload, max_new_tokens),
        "store": False,
        "stream": False,
    }
    reasoning_mode = _lm_studio_reasoning_mode(payload, reasoning_default)
    if reasoning_mode:
        body["reasoning"] = reasoning_mode
    if payload.get("seed") is not None:
        body["seed"] = int(payload.get("seed"))
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    def _post(request_body):
        request = urllib.request.Request(
            f"{api_root}/api/v1/chat",
            data=json.dumps(request_body).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=float(timeout)) as response:
            return json.loads(response.read().decode("utf-8", errors="replace"))

    try:
        data = _post(body)
    except urllib.error.HTTPError as exc:
        details = exc.read().decode("utf-8", errors="replace") if hasattr(exc, "read") else ""
        if exc.code in {404, 405}:
            raise RuntimeError(
                "LM Studio's native /api/v1/chat endpoint is required to apply per-request context and output limits. "
                "Update LM Studio and make sure its Local Server is running."
            ) from exc
        if "seed" in body and "unrecognized_keys" in details.lower() and "seed" in details.lower():
            retry_body = {key: value for key, value in body.items() if key != "seed"}
            try:
                data = _post(retry_body)
            except urllib.error.HTTPError as retry_exc:
                retry_details = retry_exc.read().decode("utf-8", errors="replace") if hasattr(retry_exc, "read") else ""
                raise RuntimeError(f"LM Studio {label}request failed ({retry_exc.code}): {retry_details or retry_exc.reason}") from retry_exc
            except urllib.error.URLError as retry_exc:
                raise RuntimeError(f"Could not connect to LM Studio at {api_root}. Make sure LM Studio's local server is running.") from retry_exc
        else:
            raise RuntimeError(f"LM Studio {label}request failed ({exc.code}): {details or exc.reason}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Could not connect to LM Studio at {api_root}. Make sure LM Studio's local server is running.") from exc
    text = _lm_studio_native_output_text(data)
    if not text:
        raise ValueError(f"LM Studio {label}returned empty text.")
    return text


def _resolve_mmproj_dropdown_path(llm, mmproj_file):
    selected = str(mmproj_file or "").strip()
    try:
        if selected:
            return llm._resolve_dropdown_path(selected, llm.MISSING_MMPROJ_OPTION)
    except Exception:
        pass
    try:
        choices = [
            choice for choice in llm._list_local_mmproj_choices()
            if choice and choice != llm.MISSING_MMPROJ_OPTION
        ]
    except Exception:
        choices = []
    if len(choices) == 1:
        return llm._resolve_dropdown_path(choices[0], llm.MISSING_MMPROJ_OPTION)
    if selected:
        return llm._resolve_dropdown_path(selected, llm.MISSING_MMPROJ_OPTION)
    raise ValueError("Choose an mmproj file for the vision model.")


def _run_lm_studio_text(payload, instruction_text, temperature=0.6, top_p=0.95, max_new_tokens=1200):
    return _run_lm_studio_native_chat(
        payload,
        str(instruction_text or ""),
        temperature,
        top_p,
        max_new_tokens,
        payload.get("lmstudio_timeout") or 180,
        "",
    )


def _run_llm_api_text(payload, instruction_text):
    try:
        from .LLM import VRGDG_LLM_Multi
    except Exception as exc:
        raise RuntimeError(f"Could not load LLM API runner: {exc}") from exc
    provider = str(payload.get("llm_api_provider") or payload.get("provider") or "openai").strip().lower()
    if provider == "xai":
        provider = "grok"
    model = str(payload.get("llm_api_model") or payload.get("model") or "").strip()
    api_key = str(payload.get("llm_api_key") or payload.get("api_key") or "").strip()
    custom_model = str(payload.get("llm_api_custom_model") or payload.get("custom_model") or "").strip()
    if not api_key:
        raise ValueError("LLM API key is missing. Open LLM Runner and paste your API key.")
    if not provider:
        raise ValueError("LLM API provider is missing.")
    runner = VRGDG_LLM_Multi()
    text, used_provider, used_model, status, _image = runner.generate_text(
        api_key=api_key,
        provider=provider,
        model=model,
        prompt=str(instruction_text or ""),
        custom_model=custom_model,
    )
    status = str(status or "").strip()
    if status.lower().startswith("error"):
        raise RuntimeError(status)
    text = str(text or "").strip()
    if not text:
        raise ValueError("LLM API returned empty text.")
    return text, {
        "runner": "llm_api",
        "used_provider": used_provider or provider,
        "used_model": used_model or model,
        "unloaded": False,
    }


def _run_llm_api_vision(payload, instruction_text, pil_images):
    try:
        from .LLM import VRGDG_LLM_Multi
    except Exception as exc:
        raise RuntimeError(f"Could not load LLM API runner: {exc}") from exc
    provider = str(payload.get("llm_api_provider") or payload.get("provider") or "openai").strip().lower()
    if provider == "xai":
        provider = "grok"
    model = str(payload.get("llm_api_model") or payload.get("model") or "").strip()
    api_key = str(payload.get("llm_api_key") or payload.get("api_key") or "").strip()
    custom_model = str(payload.get("llm_api_custom_model") or payload.get("custom_model") or "").strip()
    if not api_key:
        raise ValueError("LLM API key is missing. Open LLM Runner and paste your API key.")
    if not provider:
        raise ValueError("LLM API provider is missing.")
    if not (model or custom_model):
        raise ValueError("LLM API vision model is missing. Open LLM Runner and select a vision-capable API model before running Video All with image reference.")
    if provider in {"deepseek", "apifreellm"}:
        raise ValueError(f"{provider} is not configured for image/vision input here. Choose a vision-capable LLM API provider/model, or use LM Studio/Gemma Local vision.")
    images = list(pil_images or [])
    if not images:
        raise ValueError("LLM API vision needs at least one image reference.")
    runner = VRGDG_LLM_Multi()
    image_tensors = [runner._pil_to_tensor(image.convert("RGB")) for image in images[:4]]
    kwargs = {
        "api_key": api_key,
        "provider": provider,
        "model": model,
        "prompt": str(instruction_text or ""),
        "custom_model": custom_model,
    }
    for index, tensor in enumerate(image_tensors, start=1):
        kwargs[f"image{index}"] = tensor
    text, used_provider, used_model, status, _image = runner.generate_text(**kwargs)
    status = str(status or "").strip()
    if status.lower().startswith("error"):
        raise RuntimeError(status)
    text = str(text or "").strip()
    if not text:
        raise ValueError("LLM API vision returned empty text.")
    return text, {
        "runner": "llm_api_vision",
        "used_provider": used_provider or provider,
        "used_model": used_model or model or custom_model,
        "unloaded": False,
    }


def _pil_image_to_data_url(image, max_height=512, quality=88):
    if image is None:
        raise ValueError("LM Studio vision image is missing.")
    image = image.convert("RGB")
    if image.height > max_height:
        resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC)
        width = max(1, int(image.width * (float(max_height) / max(1, image.height))))
        image = image.resize((width, int(max_height)), resample)
    import io
    buffer = io.BytesIO()
    image.save(buffer, format="JPEG", quality=int(quality), optimize=True)
    encoded = base64.b64encode(buffer.getvalue()).decode("ascii")
    return f"data:image/jpeg;base64,{encoded}"


def _run_lm_studio_vision(payload, instruction_text, pil_images, temperature=0.25, top_p=0.95, max_new_tokens=1200):
    images = list(pil_images or [])
    if not images:
        raise ValueError("LM Studio vision needs at least one image.")
    # Native LM Studio chat accepts multimodal input blocks directly. Do not
    # wrap the text in an OpenAI-style message object inside `input`.
    content = [{"type": "text", "content": str(instruction_text or "")}]
    for image in images:
        content.append({
            "type": "image",
            "data_url": _pil_image_to_data_url(image),
        })
    return _run_lm_studio_native_chat(
        payload,
        content,
        temperature,
        top_p,
        max_new_tokens,
        payload.get("lmstudio_timeout") or 300,
        "vision ",
        reasoning_default="off",
    )


def _list_lm_studio_models(payload):
    base_url = str(payload.get("lmstudio_base_url") or _LM_STUDIO_DEFAULT_BASE_URL).strip().rstrip("/")
    api_key = str(payload.get("lmstudio_api_key") or "").strip()
    if not base_url:
        raise ValueError("LM Studio base URL is empty.")
    headers = {"Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    request = urllib.request.Request(f"{base_url}/models", headers=headers, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=float(payload.get("lmstudio_timeout") or 30)) as response:
            data = json.loads(response.read().decode("utf-8", errors="replace"))
    except urllib.error.HTTPError as exc:
        details = exc.read().decode("utf-8", errors="replace") if hasattr(exc, "read") else ""
        raise RuntimeError(f"LM Studio models request failed ({exc.code}): {details or exc.reason}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Could not connect to LM Studio at {base_url}. Make sure LM Studio's local server is running.") from exc
    items = data.get("data") if isinstance(data, dict) else []
    models = []
    if isinstance(items, list):
        for item in items:
            if isinstance(item, dict):
                model_id = str(item.get("id") or "").strip()
                if model_id:
                    models.append(model_id)
    return {"models": models, "raw": data}


def _strip_builder_thinking_text(text):
    """Remove reasoning/control-channel text that models may emit despite disabled thinking."""
    cleaned = str(text or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    # Qwen and a few OpenAI-compatible servers can emit an unclosed block. In
    # that case the useful answer starts after the closing marker.
    cleaned = re.sub(r"<(?:think|thought)>.*?</(?:think|thought)>", "", cleaned, flags=re.IGNORECASE | re.DOTALL)
    closing = re.search(r"</(?:think|thought)>", cleaned, flags=re.IGNORECASE)
    if closing:
        cleaned = cleaned[closing.end():].strip()

    # When a model labels a reasoning preamble and then supplies a final
    # answer, discard the whole preamble rather than only its heading.
    thought_prefix = re.match(
        r"^\s*(?:<\|channel\|>\s*)?(?:<\|(?:thought|thinking|analysis|reasoning)\|>\s*)?"
        r"(?:thought(?: process)?|thinking(?: process)?|analysis|reasoning)\s*:\s*",
        cleaned,
        flags=re.IGNORECASE,
    )
    final_marker = re.search(r"\n\s*(?:final(?: answer| response)?|answer|response)\s*:\s*", cleaned, flags=re.IGNORECASE)
    if thought_prefix and final_marker and final_marker.start() >= thought_prefix.end():
        cleaned = cleaned[final_marker.end():].strip()
    else:
        # Strip a leading label/control token while preserving the answer text.
        cleaned = re.sub(
            r"^\s*(?:<\|channel\|>\s*)?(?:<\|(?:thought|thinking|analysis|reasoning)\|>\s*)?"
            r"(?:thought(?: process)?|thinking(?: process)?|analysis|reasoning)\s*:\s*",
            "",
            cleaned,
            count=1,
            flags=re.IGNORECASE,
        ).strip()
    return cleaned


def _clean_lm_studio_plain_text(text):
    cleaned = _strip_builder_thinking_text(text)
    cleaned = re.sub(r"^\s*```(?:text|json)?\s*", "", cleaned, flags=re.IGNORECASE).strip()
    cleaned = re.sub(r"\s*```\s*$", "", cleaned).strip()
    cleaned = re.sub(r"^(?:Assistant|Answer|Final answer)\s*:\s*", "", cleaned, flags=re.IGNORECASE).strip()
    return cleaned


def _format_minimax_h3_prompt(text, payload=None, instruction_key=""):
    """Keep H3 prompts readable and enforce the selected MiniMax audio contract."""
    payload = payload if isinstance(payload, dict) else {}
    cleaned = _clean_lm_studio_plain_text(text).replace("\r\n", "\n").replace("\r", "\n")
    cleaned = re.sub(r"<\s*Picture\s+(\d+)\s*>", r"Image \1", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"<\s*Video\s+(\d+)\s*>", r"Video \1", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"<\s*Audio\s+1\s*>", "Audio 1", cleaned, flags=re.IGNORECASE)

    raw_audio_mode = str(payload.get("audio_mode") or payload.get("minimax_h3_audio_mode") or "input_audio").strip().lower().replace("-", "_").replace(" ", "_")
    native_audio = raw_audio_mode in {"built_in_audio", "native_audio", "generated_audio"}
    speaker_assignments_raw = payload.get("speaker_assignments") or payload.get("minimax_speaker_assignments") or payload.get("dialogue_cues") or []
    if isinstance(speaker_assignments_raw, str):
        try:
            speaker_assignments_raw = json.loads(speaker_assignments_raw)
        except Exception:
            speaker_assignments_raw = []
    speaker_assignments = []
    if isinstance(speaker_assignments_raw, list):
        for item in speaker_assignments_raw:
            if not isinstance(item, dict):
                continue
            speaker_name = str(item.get("speaker_name") or item.get("speaker") or item.get("name") or "").strip()
            cue_text = str(item.get("text") or item.get("dialogue") or item.get("line") or "").strip()
            if cue_text:
                speaker_assignments.append({"speaker_name": speaker_name or "The assigned speaker", "text": cue_text})

    timestamp_pattern = r"\[\s*\d+(?:\.\d+)?s?\s*[-\u2013\u2014]\s*\d+(?:\.\d+)?s?\s*\]"
    section_pattern = rf"(?:Image\s+\d+|Video\s+\d+|Audio\s+1|Native\s+audio|Audio|Continuity)\s*:|{timestamp_pattern}"
    cleaned = re.sub(rf"[ \t]*(?={section_pattern})", "\n\n", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(rf"({timestamp_pattern})[ \t]*(?:\n[ \t]*)?", r"\1\n", cleaned)
    cleaned = re.sub(r"\n[ \t]+", "\n", cleaned)
    cleaned = re.sub(r"[ \t]+\n", "\n", cleaned)
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned).strip()

    lyric_text = re.sub(r"\s+", " ", str(payload.get("lyric_text") or "")).strip().strip('"\'\u201c\u201d\u2018\u2019')
    performance_mode = str(payload.get("performance_mode") or "singing").strip().lower().replace("-", "_").replace(" ", "_")
    no_visible_character = bool(payload.get("no_character_present"))
    no_lip_sync = no_visible_character or performance_mode in {"no_lip_sync", "nolipsync", "no_lipsync", "visual_only", "instrumental"}
    singers_raw = payload.get("singers") or []
    if isinstance(singers_raw, str):
        singer_names = [item.strip() for item in re.split(r"[,;\n]+", singers_raw) if item.strip()]
    elif isinstance(singers_raw, list):
        singer_names = [str(item or "").strip() for item in singers_raw if str(item or "").strip()]
    else:
        singer_names = []
    performer = " and ".join(singer_names[:2]) if singer_names else "the visible performer"
    ordered_native_dialogue = bool(native_audio and performance_mode == "speaking" and speaker_assignments)

    def insert_before_first_timeline(block):
        nonlocal cleaned
        match = re.search(timestamp_pattern, cleaned)
        if match:
            cleaned = f"{cleaned[:match.start()].rstrip()}\n\n{block}\n\n{cleaned[match.start():].lstrip()}"
        else:
            cleaned = f"{cleaned.rstrip()}\n\n{block}"

    def insert_before_continuity(block):
        nonlocal cleaned
        match = re.search(r"(?im)^Continuity\s*:", cleaned)
        if match:
            cleaned = f"{cleaned[:match.start()].rstrip()}\n\n{block}\n\n{cleaned[match.start():].lstrip()}"
        else:
            cleaned = f"{cleaned.rstrip()}\n\n{block}"

    def enforce_visual_only_timeline():
        """Remove lyric-synchronised vocal actions from H3 timestamps and add a final B-roll contract."""
        nonlocal cleaned
        positive_vocal = re.compile(
            r"\b(?:sing(?:s|ing)?|sang|sung|rap(?:s|ping)?|lip[ -]?sync(?:s|ing)?|"
            r"speak(?:s|ing)?|say(?:s|ing)?|said|mouth(?:s|ed|ing)?|whisper(?:s|ing)?|"
            r"perform(?:s|ing)?\s+(?:the\s+)?(?:saved\s+|exact\s+)?(?:lyric|dialogue|words?))\b",
            flags=re.IGNORECASE,
        )
        negative_safety = re.compile(
            r"\b(?:no|not|never|without|does\s+not|do\s+not|must\s+not|cannot|can['’]t|don['’]t)\b",
            flags=re.IGNORECASE,
        )
        timeline_block_pattern = re.compile(
            rf"({timestamp_pattern}\n)(.*?)(?=\n\n(?:{timestamp_pattern}|Audio\s*:|Continuity\s*:)|$)",
            flags=re.IGNORECASE | re.DOTALL,
        )

        def clean_timeline_block(match):
            parts = [
                part.strip()
                for part in re.split(r"(?<=[.!?])\s+|\n+", match.group(2).strip())
                if part.strip()
            ]
            kept = [
                part for part in parts
                if not (positive_vocal.search(part) and not negative_safety.search(part))
            ]
            if not kept:
                kept.append("Continue the requested visual action, camera movement, and environmental motion naturally.")
            kept.append(
                "No visible subject sings, raps, mouths the saved lyric, or lip-syncs; any visible conversation remains natural and unsynchronised to the saved song."
            )
            return f"{match.group(1)}{' '.join(kept)}"

        cleaned = timeline_block_pattern.sub(clean_timeline_block, cleaned)
        safety_block = (
            "VISUAL-ONLY B-ROLL / NO-LIP-SYNC SAFETY — MANDATORY AND FINAL:\n"
            "This scene is explicitly B-roll / no-lip-sync. This safety block overrides any conflicting lyric, singer, "
            "song-performance, or lyric-sync instruction elsewhere in the prompt. It does not remove visible characters "
            "or prohibit natural non-lyric interaction.\n"
            "No visible subject sings, raps, lip-syncs, or mouths the saved lyric. Characters may appear, act, interact, "
            "and have natural unsynchronised conversation—for example, band members backstage talking—but no visible mouth "
            "may synchronise to the saved song.\n"
            + (
                "Built-in MiniMax Audio: generate only requested environmental ambience and sound effects. Do not "
                "generate speech, singing, dialogue, lyrics, narration, voices, or vocal layers."
                if native_audio else
                "Input Audio: preserve Audio 1 completely unchanged as the soundtrack and timing reference, including "
                "any audible vocals, but treat those vocals as off-screen soundtrack only. No visible subject may synchronize to them."
            )
            + "\nTreat the saved lyric only as hidden mood/story context; never quote it as dialogue or describe anyone performing it."
        )
        insert_before_first_timeline(safety_block)

    if instruction_key.endswith("image_to_video") and not re.search(r"(?im)^Image\s+1\s*:", cleaned):
        image_assignment = (
            "Image 1: use as the exact start frame, character appearance and clothing reference, "
            "environment reference, lighting reference, and composition reference."
        )
        first_audio = re.search(r"(?im)^Audio\s+1\s*:", cleaned)
        if first_audio:
            cleaned = f"{cleaned[:first_audio.start()].rstrip()}\n\n{image_assignment}\n\n{cleaned[first_audio.start():].lstrip()}"
        else:
            insert_before_first_timeline(image_assignment)

    if native_audio:
        native_assignment_pattern = re.compile(
            rf"(?ims)^(?:Audio\s+1|Native\s+audio)\s*:.*?(?=\n\n(?:{timestamp_pattern}|Image\s+\d+\s*:|Video\s+\d+\s*:|Audio\s*:|Continuity\s*:)|\Z)"
        )
        cleaned = native_assignment_pattern.sub("", cleaned).strip()
        if ordered_native_dialogue:
            ordered_cues = "; ".join(
                f'{cue["speaker_name"]} says exactly “{cue["text"]}”'
                for cue in speaker_assignments
            )
            native_assignment = (
                f"Native audio: Generate spoken dialogue in this exact order: {ordered_cues}. "
                "Only the assigned speaker speaks during each cue. Every other visible character remains silent with their mouth closed and reacts naturally. "
                "Synchronize each assigned speaker’s lips, mouth shapes, jaw movement, facial muscles, and breathing precisely to that speaker’s generated words. "
                "Speak only in the same language used by the exact supplied dialogue; do not translate or switch languages. "
                "Pronounce every supplied word clearly at a natural measured pace. Do not generate gibberish, babble, invented syllables, filler, phonetic substitutions, repeated phrases, or extra vocalizations. "
                "Begin the first cue within the first 0.15 seconds, pace the exact words naturally across the available clip, and land the final word approximately 0.15-0.30 seconds before the clip ends. Never finish early and fill time with invented speech. "
                "Do not merge speakers, overlap or reorder cues, transfer words, rewrite, restart, repeat, improvise, omit, or add dialogue."
            )
        elif lyric_text and not no_lip_sync:
            action = "speaking" if performance_mode == "speaking" else "singing"
            native_assignment = (
                f"Native audio: Generate {performer} {action} the exact line “{lyric_text}”. "
                "Synchronize the visible performance precisely to the generated words and preserve the exact wording without additions, repetition, or replacement."
            )
        elif no_lip_sync:
            native_assignment = (
                "Native audio: Generate only the requested environmental ambience and sound effects. "
                "Do not generate speech, singing, lyrics, dialogue, voices, or visible mouth synchronization."
            )
        else:
            native_assignment = (
                "Native audio: Generate only appropriate environmental ambience and requested sound effects. "
                "Do not invent speech, singing, lyrics, dialogue, or voices."
            )
        insert_before_first_timeline(native_assignment)
    else:
        if lyric_text and not no_lip_sync:
            action = "says" if performance_mode == "speaking" else "is singing"
            vocal_kind = "spoken" if performance_mode == "speaking" else "sung"
            audio_assignment = (
                "Audio 1: use unchanged as the primary and only audio track. Preserve its exact music, vocals, timing, "
                f"rhythm, phrasing, tone, and duration, and use it as the exact vocal, timing, and lip-sync reference. "
                f"{performer} {action} the exact line "
                f"“{lyric_text}”. Synchronize lips, mouth shapes, jaw movement, facial muscles, and breathing precisely "
                f"to that {vocal_kind} line in Audio 1. Do not generate, add, replace, remix, or extend any music, "
                "ambience, dialogue, vocals, or sound effects."
            )
        elif no_lip_sync:
            audio_assignment = (
                "Audio 1: use unchanged as the primary and only audio track. Preserve its exact music, vocals, timing, "
                "rhythm, phrasing, tone, and duration. This portion contains no vocal line for the visible character, "
                "so the character does not sing, speak, or lip-sync; keep the mouth naturally relaxed or closed. "
                "Do not generate, add, replace, remix, or extend any music, ambience, dialogue, vocals, or sound effects."
            )
        else:
            audio_assignment = (
                "Audio 1: use unchanged as the primary and only audio track. Preserve its exact music, vocals, timing, "
                "rhythm, phrasing, tone, and duration. Use it as the exact performance and movement reference. "
                "Do not generate, add, replace, remix, or extend any music, ambience, dialogue, vocals, or sound effects."
            )
        input_audio_assignment_pattern = re.compile(
            rf"(?ims)^Audio\s+1\s*:.*?(?=\n\n(?:{timestamp_pattern}|Image\s+\d+\s*:|Video\s+\d+\s*:|Audio\s*:|Continuity\s*:|REFERENCE\s+SUBJECT\s+COUNT\b)|\Z)"
        )
        cleaned = input_audio_assignment_pattern.sub("", cleaned).strip()
        insert_before_first_timeline(audio_assignment)

    if no_lip_sync:
        enforce_visual_only_timeline()

    if lyric_text and not no_lip_sync and not ordered_native_dialogue:
        lines = cleaned.split("\n")
        exact_line_lower = lyric_text.casefold()
        for index, line in enumerate(lines):
            if re.match(r"^Audio\s+1\s*:", line, flags=re.IGNORECASE):
                if exact_line_lower not in line.casefold() or "lip" not in line.casefold():
                    action = "spoken" if performance_mode == "speaking" else "sung"
                    lines[index] = (
                        f"{line.rstrip()} Preserve the exact {action} line “{lyric_text}” and synchronize lips, mouth shapes, "
                        "jaw movement, facial muscles, and breathing precisely to Audio 1."
                    )
                break
        cleaned = "\n".join(lines)

        vocal_verb = "says" if performance_mode == "speaking" else "visibly sings"
        sync_kind = "spoken dialogue" if performance_mode == "speaking" else "sung lyric"
        timeline_block_pattern = re.compile(
            rf"({timestamp_pattern}\n)(.*?)(?=\n\n(?:{timestamp_pattern}|Audio\s*:|Continuity\s*:)|$)",
            flags=re.IGNORECASE | re.DOTALL,
        )

        def ensure_vocal_in_timeline(match):
            header = match.group(1)
            body = match.group(2).strip()
            body_lower = body.casefold()
            visibly_performed = (
                lyric_text.casefold() in body_lower
                and bool(re.search(r"\b(?:sing|sings|singing|sung|lip[ -]?sync|say|says|speaking|spoken)\b", body_lower))
            )
            if visibly_performed:
                return f"{header}{body}"
            required_action = (
                f"During only the portion of this interval where the {sync_kind} is audible in Audio 1, {performer} "
                f"{vocal_verb} “{lyric_text}” with precise lip, mouth-shape, jaw, facial-muscle, and breathing synchronization. "
                "When the supplied vocal ends, the mouth closes or relaxes naturally; never stretch, restart, or repeat the line to fill the interval."
            )
            return f"{header}{body.rstrip()} {required_action}".strip()

        cleaned = timeline_block_pattern.sub(ensure_vocal_in_timeline, cleaned)

    if native_audio:
        native_summary_pattern = re.compile(
            r"(?ims)^Audio\s*:.*?(?=\n\n(?:Continuity\s*:|MINIMAX\s+NATIVE\s+VOICE\s+IDENTITY\b)|\Z)"
        )
        cleaned = native_summary_pattern.sub("", cleaned).strip()
        if ordered_native_dialogue:
            audio_summary = (
                "Audio: Generate the ordered spoken dialogue as the primary audio track using each character’s assigned voice. "
                "Preserve every word and speaker turn exactly, keep the visible speaker’s lip sync precise, and keep all non-speaking characters silent. "
                "Add only subtle low-level requested ambience and sound effects underneath. Do not add narration, extra dialogue, music, or vocal layers."
            )
        elif lyric_text and not no_lip_sync:
            vocal_kind = "spoken line" if performance_mode == "speaking" else "sung lyric"
            audio_summary = (
                f"Audio: Generate the exact {vocal_kind} “{lyric_text}” as the primary audio track and synchronize the visible performance precisely to it. "
                "Add only subtle low-level requested ambience and sound effects underneath. Do not add replacement words, extra dialogue, or vocal layers."
            )
        else:
            audio_summary = (
                "Audio: Generate only the requested environmental ambience and sound effects. "
                "Do not add speech, singing, dialogue, lyrics, narration, or vocal layers."
            )
        insert_before_continuity(audio_summary)
    else:
        if lyric_text and not no_lip_sync:
            audio_summary = (
                "Audio: Audio 1 remains unchanged as the primary and only audio track. Preserve its exact music, vocals, "
                f"timing, rhythm, phrasing, tone, and duration, and keep the lip sync exact to “{lyric_text}”. "
                "Do not generate, add, replace, remix, or extend any music, ambience, dialogue, vocals, or sound effects."
            )
        elif no_lip_sync:
            audio_summary = (
                "Audio: Audio 1 remains unchanged as the primary and only audio track. Preserve its exact music, vocals, "
                "timing, rhythm, phrasing, tone, and duration. The visible character does not sing, speak, or lip-sync "
                "during this non-vocal portion and keeps the mouth naturally relaxed or closed. Do not generate, add, "
                "replace, remix, or extend any music, ambience, dialogue, vocals, or sound effects."
            )
        else:
            audio_summary = (
                "Audio: Audio 1 remains unchanged as the primary and only audio track. Preserve its exact music, vocals, "
                "timing, rhythm, phrasing, tone, and duration. Do not generate, add, replace, remix, or extend any music, "
                "ambience, dialogue, vocals, or sound effects."
            )
        input_audio_summary_pattern = re.compile(
            r"(?ims)^Audio\s*:.*?(?=\n\n(?:Audio\s+1\s*:|Continuity\s*:|REFERENCE\s+SUBJECT\s+COUNT\b)|\Z)"
        )
        cleaned = input_audio_summary_pattern.sub("", cleaned).strip()
        insert_before_continuity(audio_summary)

    if not re.search(r"(?im)^Continuity\s*:", cleaned):
        continuity = (
            "Continuity: Preserve the same visible character identity, appearance, clothing, environment, lighting, and spatial "
            "relationships throughout. Do not introduce new characters, objects, text, logos, captions, or scene changes unless explicitly requested."
        )
        cleaned = f"{cleaned.rstrip()}\n\n{continuity}"

    if native_audio:
        cleaned = re.sub(r"\bAudio\s+1\b", "the generated native audio", cleaned, flags=re.IGNORECASE)

    if ordered_native_dialogue:
        # Keep the exact dialogue script in one authoritative place. Repeating a full
        # quoted cue in timeline/summary sections can make H3 restart or repeat it.
        native_block = re.search(
            rf"(?ims)^Native\s+audio\s*:.*?(?=\n\n{timestamp_pattern}|\Z)",
            cleaned,
        )
        if native_block:
            prefix = cleaned[:native_block.end()]
            suffix = cleaned[native_block.end():]
            for cue in speaker_assignments:
                cue_text = str(cue.get("text") or "").strip()
                if not cue_text:
                    continue
                escaped = re.escape(cue_text)
                suffix = re.sub(
                    rf"[\u201c\"]\s*{escaped}\s*[\u201d\"]",
                    "the assigned cue",
                    suffix,
                    flags=re.IGNORECASE,
                )
                suffix = re.sub(escaped, "the assigned cue", suffix, flags=re.IGNORECASE)
            cleaned = prefix + suffix

    try:
        camera_speed = max(0.0, min(10.0, float(payload.get("camera_motion_speed", 4))))
    except Exception:
        camera_speed = 4.0
    try:
        character_speed = max(0.0, min(10.0, float(payload.get("character_motion_speed", 4))))
    except Exception:
        character_speed = 4.0

    if camera_speed >= 7:
        camera_replacements = [
            (r"\bslow cinematic drift\b", "energetic cinematic tracking drift"),
            (r"\bslow orbit\b", "energetic orbit"),
            (r"\bslow (left|right) orbit\b", r"energetic \1 orbit"),
            (r"\bslow zoom out\b", "brisk pull-back reveal"),
            (r"\bslow (left|right|side|lateral) drift\b", r"brisk \1 tracking drift"),
            (r"\bslow (pan|tilt|track|tracking|pull[ -]?back|drift)\b", r"brisk \1"),
            (r"\bgentle lateral drift\b", "energetic lateral tracking"),
            (r"\bgentle pan reveal\b", "brisk pan reveal"),
            (r"\bgentle (pan|tilt|orbit|drift|camera movement)\b", r"brisk \1"),
            (r"\bsubtle handheld movement\b", "active handheld tracking"),
            (r"\bsubtle handheld camera\b", "active handheld camera"),
            (r"\bsubtle handheld follow\b", "energetic handheld follow"),
            (r"\bsubtle rack focus\b", "quick rack focus"),
            (r"\bsubtle energetic orbit\b", "energetic orbit"),
            (r"\bsubtle settling pause\b", "active reframing beat"),
            (r"\bsubtle orbit movement\b", "energetic orbit movement"),
            (r"\b(?:quiet handheld hold|locked-off reaction hold|locked-off shot)\b", "active handheld reaction tracking"),
            (r"\brestrained pan\b", "brisk pan"),
        ]
        for pattern, replacement in camera_replacements:
            cleaned = re.sub(pattern, replacement, cleaned, flags=re.IGNORECASE)
        if not re.search(r"\b(?:tracking|orbit|whip pan|pan|tilt|crane|pullback|pull-back|push|dolly|handheld|reveal)\b", cleaned, flags=re.IGNORECASE):
            first_timeline = re.search(rf"(?ims)({timestamp_pattern}\n)(.*?)(?=\n\n(?:{timestamp_pattern}|Audio\s*:|Continuity\s*:)|$)", cleaned)
            if first_timeline:
                body = first_timeline.group(2).rstrip()
                replacement = f"{first_timeline.group(1)}{body} The camera uses energetic tracking throughout this interval and never settles into a static hold."
                cleaned = cleaned[:first_timeline.start()] + replacement + cleaned[first_timeline.end():]

    if character_speed >= 4 and not no_visible_character:
        physical_action_pattern = r"\b(?:walks?|steps?|strides?|runs?|sprints?|dances?|crosses?|lunges?|reaches?|pushes?|pulls?|climbs?|fights?|brushes?|sweeps?|gestures?|interacts?|grabs?|lifts?|paces?)\b"
        timeline_text = "\n".join(
            match.group(2)
            for match in re.finditer(
                rf"(?ims)({timestamp_pattern}\n)(.*?)(?=\n\n(?:{timestamp_pattern}|Audio\s*:|Continuity\s*:)|$)",
                cleaned,
            )
        )
        if not re.search(physical_action_pattern, timeline_text, flags=re.IGNORECASE):
            first_timeline = re.search(rf"(?ims)({timestamp_pattern}\n)(.*?)(?=\n\n(?:{timestamp_pattern}|Audio\s*:|Continuity\s*:)|$)", cleaned)
            if first_timeline:
                body = first_timeline.group(2).rstrip()
                replacement = (
                    f"{first_timeline.group(1)}{body} The visible subject performs a clear physical action with the body, hands, "
                    "or surrounding set instead of relying on facial movement alone."
                )
                cleaned = cleaned[:first_timeline.start()] + replacement + cleaned[first_timeline.end():]

    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned).strip()
    return cleaned


def _run_builder_text_llm(payload, instruction_text, temperature=0.6, top_p=0.95, max_new_tokens=1200, label="Gemma", preserve_paragraphs=False):
    max_new_tokens = _runner_output_token_limit(payload, max_new_tokens)
    if _llm_runner_from_payload(payload) == "lm_studio":
        text = _run_lm_studio_text(
            payload,
            instruction_text,
            temperature=temperature,
            top_p=top_p,
            max_new_tokens=max_new_tokens,
        )
        cleaned = _clean_lm_studio_plain_text(text) if preserve_paragraphs else _clean_visual_gemma_text(text)
        return cleaned, {
            "runner": "lm_studio",
            "used_model": str(payload.get("lmstudio_model") or "").strip(),
            "unloaded": False,
        }

    if _llm_runner_from_payload(payload) == "llm_api":
        text, info = _run_llm_api_text(payload, instruction_text)
        cleaned = _clean_lm_studio_plain_text(text) if preserve_paragraphs else _clean_visual_gemma_text(text)
        return cleaned, info

    if _llm_runner_from_payload(payload) == "own_server":
        text, info = _run_own_server_text(
            payload,
            instruction_text,
            temperature=temperature,
            top_p=top_p,
            max_new_tokens=max_new_tokens,
        )
        cleaned = _clean_lm_studio_plain_text(text) if preserve_paragraphs else _clean_visual_gemma_text(text)
        return cleaned, info

    from .LLM import VRGDG_SuperGemmaGGUFChat, _clear_vrgdg_llm_caches

    model_file = str(payload.get("model_file", "") or "").strip()
    if not model_file:
        raise ValueError(f"Choose a {label} model first.")
    llm = _builder_local_llm(payload)
    model_file = _builder_local_model_file(payload, model_file)
    model_path = llm._resolve_dropdown_path(model_file, llm.MISSING_MODEL_OPTION)
    print(
        f"[VRGDG LLM] runner={_llm_runner_display_name(payload)} "
        f"model={os.path.basename(str(model_path)) or str(model_path)}"
    )
    n_ctx = int(payload.get("n_ctx") or 8000)
    n_gpu_layers = int(payload.get("n_gpu_layers") or 99)
    n_threads = int(payload.get("n_threads") or 8)
    chat_format = str(payload.get("chat_format", "") or "").strip()
    unload_after = bool(payload.get("unload_after", True))
    seed = payload.get("seed")
    try:
        model = llm._load_gguf_model(
            model_path=model_path,
            n_ctx=n_ctx,
            n_gpu_layers=n_gpu_layers,
            n_threads=n_threads,
            chat_format=chat_format,
        )
        text = llm._run_gguf_text_pipeline(
            model=model,
            instruction_text=instruction_text,
            temperature=float(temperature),
            top_p=float(top_p),
            max_new_tokens=int(max_new_tokens),
            seed=int(seed) if seed is not None else None,
        )
        cleaned = _clean_lm_studio_plain_text(text) if preserve_paragraphs else _clean_visual_gemma_text(text)
        return cleaned, {
            "runner": _llm_runner_from_payload(payload),
            "used_model": model_path,
            "unloaded": unload_after,
        }
    finally:
        if unload_after:
            llm._unload_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path="",
            )
            _clear_vrgdg_llm_caches(clear_cuda_cache=True, clear_hf_pipeline_cache=False)


def _repair_builder_gemma_prompt(payload, text, label):
    original = str(text or "").strip()
    label_key = str(label or "").strip().lower().replace(" ", "_")
    if label_key in {"id-lora", "id_lora", "id-lora_i2v"} and _looks_like_id_lora_script_prompt(original):
        return original
    lyric_echo = _looks_like_source_lyric_echo(original, payload)
    needs_repair = _looks_like_gemma_repeat_failure(original) or _looks_like_unfilled_prompt_template(original) or lyric_echo
    if not original or not needs_repair:
        return original

    repair_payload = dict(payload or {})
    repair_model = str(
        repair_payload.get("repair_model_file")
        or repair_payload.get("text_model_file")
        or repair_payload.get("model_file")
        or ""
    ).strip()
    if repair_model:
        repair_payload["model_file"] = repair_model
    repair_payload["mmproj_file"] = ""
    repair_payload["use_vision"] = False
    broken = original[:5000]
    label_text = str(label or "").strip()
    video_repair = label_text.lower() in {"i2v", "t2v"}
    if video_repair:
        concept_prompt = str(repair_payload.get("t2i_prompt") or "").strip()[:3000]
        motion_notes = str(repair_payload.get("user_notes") or "").strip()[:2000]
        instruction = (
            f"Clean this broken {label_text} video prompt into one usable final video prompt.\n\n"
            "The broken text may contain internal thoughts, repeated tokens, markdown, or unfilled square-bracket placeholders.\n"
            "Use only the concept prompt and motion notes below as context. Do not use project story, lyrics, agent chat, or any other context.\n"
            "Replace placeholders like [Subject], [setting/environment], [time/weather], and [Camera Motion] with concrete details from the concept prompt and motion notes.\n"
            "Do not continue the broken text. Do not explain the repair. Do not mention that it was repaired.\n"
            "Return exactly one normal video prompt paragraph with no square brackets, labels, markdown, or placeholders.\n"
            "Keep it under 120 words.\n\n"
            f"Concept/T2I prompt:\n{concept_prompt or '[none provided]'}\n\n"
            f"I2V/T2V motion notes:\n{motion_notes or '[none provided]'}\n\n"
            f"Broken video prompt:\n{broken}"
        )
    else:
        user_notes = str(repair_payload.get("user_notes") or "").strip()[:3000]
        lyric_text = str(repair_payload.get("lyric_text") or repair_payload.get("lyrics") or "").strip()[:1200]
        instruction = (
            f"Clean this broken {label_text} image prompt into one usable final prompt.\n\n"
            "The broken text may contain internal thoughts, analysis, channel tags, repeated tokens, markdown, unfilled square-bracket placeholders, junk, or the raw scene lyric copied by mistake.\n"
            "Do not continue the broken text. Do not explain the repair. Do not mention that it was repaired.\n"
            "Return exactly one normal image prompt paragraph.\n"
            "Remove all thought, analysis, channel, role, markdown, labels, square brackets, placeholder words, and repeated junk.\n"
            "If the broken text is just the scene lyric, do not quote the lyric; create a visual still-image prompt from the user notes and lyric mood.\n"
            "Replace placeholders like [Subject], [setting/environment], [time/weather], and [Camera Motion] with concrete details inferred from the broken text and user notes.\n"
            "Keep only usable visual image-generation content. If usable details are scarce, create a concise cinematic prompt from the usable fragments.\n"
            "Keep it under 120 words.\n\n"
            f"User notes/context:\n{user_notes or '[none provided]'}\n\n"
            f"Scene lyric, for mood only:\n{lyric_text or '[none provided]'}\n\n"
            f"Broken text:\n{broken}"
        )
    try:
        repaired, _run_info = _run_builder_text_llm(
            repair_payload,
            instruction,
            temperature=0.25,
            top_p=0.85,
            max_new_tokens=350,
            label=f"{label_text} repair Gemma",
        )
        repaired = _clean_visual_gemma_text(repaired)
        if repaired and not _looks_like_gemma_repeat_failure(repaired) and not _looks_like_unfilled_prompt_template(repaired):
            return repaired
    except Exception:
        pass
    return original

def _repair_and_validate_builder_gemma_prompt(payload, text, label):
    repaired = _repair_builder_gemma_prompt(payload, text, label)
    performance_mode = str(
        payload.get("performance_mode")
        or payload.get("performanceMode")
        or payload.get("video_type")
        or payload.get("videoType")
        or ""
    ).strip().lower().replace("-", "_").replace(" ", "_")
    if performance_mode in {"no_lip_sync", "nolipsync", "no_lipsync", "no_sync", "silent", "visual_only"}:
        repaired = _clean_visual_only_positive_prompt(repaired)
    _validate_builder_gemma_prompt(repaired, label, payload)
    return repaired


def _clean_visual_only_positive_prompt(text):
    """Keep visual-only LTX prompts affirmative and free of vocal/mouth concepts."""
    forbidden = re.compile(
        r"\b(?:lip[ -]?sync(?:ing|s)?|sing(?:s|ing)?|sang|sung|rap(?:s|ping)?|"
        r"vocal(?:s|ization)?|lyric(?:s)?|speak(?:s|ing)?|say(?:s|ing)?|said|"
        r"dialogue|mouth(?:s|ed|ing)?|lips?)\b",
        re.IGNORECASE,
    )
    negative = re.compile(
        r"\b(?:no|not|never|without|avoid|omit|exclude|prevent|don['’]t|"
        r"doesn['’]t|isn['’]t|aren['’]t|cannot|can['’]t|do\s+not|does\s+not)\b",
        re.IGNORECASE,
    )
    parts = re.split(r"(?<=[.!?])\s+|\s*;\s*", str(text or ""))
    kept = [part.strip() for part in parts if part.strip() and not forbidden.search(part) and not negative.search(part)]
    return re.sub(r"\s{2,}", " ", " ".join(kept)).strip()


def _generate_builder_agent_reply(payload):
    context = payload.get("context") or {}
    if not isinstance(context, dict):
        context = {}
    auto_apply = bool(payload.get("auto_apply"))
    agent_purpose = str(payload.get("agent_purpose") or "scene_work").strip().lower()
    if agent_purpose not in {"walkthrough", "scene_work", "story_builder", "troubleshoot"}:
        agent_purpose = "scene_work"
    messages = payload.get("messages") or []
    if not isinstance(messages, list):
        messages = []
    cleaned_messages = []
    for item in messages[-10:]:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role") or "").strip().lower()
        if role not in {"user", "assistant"}:
            continue
        content = str(item.get("content") or "").strip()
        if content:
            cleaned_messages.append({"role": role, "content": content[:3000]})
    latest_user = str(payload.get("message") or "").strip()
    if latest_user:
        cleaned_messages.append({"role": "user", "content": latest_user[:3000]})
    if not cleaned_messages:
        raise ValueError("Type a message for the Builder Agent first.")

    context_text = json.dumps(context, ensure_ascii=False, indent=2)[:9000]
    conversation_text = "\n\n".join(
        f"{item['role'].title()}:\n{item['content']}"
        for item in cleaned_messages
    )
    instruction = (
        "You are the VRGDG Music Video Builder Agent, a local assistant inside a scene-by-scene music video workflow.\n"
        "Help the user think through lyrics, scene concepts, image prompts, video prompts, shot choices, continuity, and troubleshooting.\n"
        "Be practical, concise, and specific to the provided active scene context.\n"
        "Keep the user-facing reply short: usually 1-5 sentences. Do not write strategy essays, option menus, or long explanations unless the user asks.\n"
        "When suggesting prompt text, provide copy-ready text clearly, but keep normal chat friendly.\n"
        "If the context is missing something, say what is missing and make a reasonable suggestion from what is available.\n\n"
        f"Agent purpose: {agent_purpose}.\n"
        "Read project_status and scene_directory first. If project_status.scene_count is greater than 0, scenes already exist; do not say no scenes have been created and do not ask to create initial scenes from timeline markers unless the user explicitly asks for that.\n"
        "If purpose is walkthrough, act like intake plus step-by-step onboarding. First identify what the user is making: music video, short film, ad/social clip, visualizer, or something else. Use project_status before choosing the next step. If project_status.has_audio is false, ask whether they plan to use custom audio and point them to Choose Audio if yes; do not ask for lyrics/SRT before resolving the audio plan. If audio exists, ask how they want scenes created: import Prompt Creator outputs, load SRT/lyrics, manually create scenes, or plan scenes with the agent. Only ask about lyrics when the user is making a music video or lyric-driven project. For short films/ads, ask for script, scene beats, product/message, or visual outline instead. Tell them one small UI step at a time and why. Do not generate prompts or run models unless the user explicitly asks. Prefer one next step over a full tutorial.\n"
        "If purpose is troubleshoot, focus on diagnosing the user's stated problem from project_status, active scene context, and available get actions.\n"
        "If purpose is scene_work, help create/update scene notes, prompts, images, and videos using the supported actions.\n\n"
        "If purpose is story_builder, act like a scene planner for complex multi-character projects. This workflow may not use Prompt Creator, SRT, or existing lyric segments. First check project_status.has_audio and story_source.has_source. For music videos/songs, if no audio exists, ask for global/timeline audio before asking for lyrics. If no story source exists, ask the user to paste lyrics/script/story source and use save_story_source in Auto Apply mode when they provide it. Use get_story_source when you need the saved lyrics/script instead of keeping it in chat memory. Help define characters, assign which character(s) appear in each scene, match the lyrics/story beat, and create compact per-scene planning notes. Prefer structured scene plans over long prose. When Auto Apply is enabled, use create_story_scenes_from_source if the user asks to create starter scenes from saved lyrics/script, then use set_scene_plan for requested scenes. Do not generate final image/video prompts unless the user explicitly asks; write planning notes that the existing prompt generators can use.\n\n"
        "Return only valid JSON with this shape:\n"
        "{\n"
        "  \"reply\": \"short message to show the user\",\n"
        "  \"actions\": []\n"
        "}\n\n"
        "Supported actions are:\n"
        "- {\"type\":\"select_scene\",\"scene_id\":\"...\"} or {\"type\":\"select_scene\",\"scene_number\":2}\n"
        "- {\"type\":\"get_scene_lyrics\",\"scene_id\":\"...\"} or {\"type\":\"get_scene_lyrics\",\"scene_number\":2}\n"
        "- {\"type\":\"get_scene_context\",\"scene_id\":\"...\"} or {\"type\":\"get_scene_context\",\"scene_number\":2}\n"
        "- {\"type\":\"get_story_source\"}\n"
        "- {\"type\":\"get_context_prompts\",\"context_type\":\"all|theme_style|story_idea|subject_scene\"}\n"
        "- {\"type\":\"get_selected_timeline_range\"}\n"
        "- {\"type\":\"save_story_source\",\"text\":\"lyrics/script/story source text\"}\n"
        "- {\"type\":\"set_context_prompt\",\"context_type\":\"theme_style|story_idea|subject_scene\",\"text\":\"...\",\"mode\":\"replace|append\"}\n"
        "- {\"type\":\"create_story_scenes_from_source\",\"scene_count\":12}\n"
        "- {\"type\":\"create_concept_prompts\",\"source_mode\":\"all|director|scene|timeline|director_scene\",\"scope\":\"all|selected|range\",\"batch_size\":5,\"use_story\":true,\"use_theme\":true}\n"
        "- {\"type\":\"create_motion_notes\",\"source_mode\":\"concept|concept_director|concept_timeline|all\",\"scope\":\"all|selected|range\",\"batch_size\":5,\"use_story\":true,\"use_theme\":true}\n"
        "- {\"type\":\"set_active_scene_to_selected_range\",\"scene_id\":\"optional target scene\"}\n"
        "- {\"type\":\"create_scene_from_selected_range\",\"label\":\"...\",\"director_note\":\"...\",\"scene_notes\":\"...\",\"flux_notes\":\"...\",\"nb_notes\":\"...\",\"video_notes\":\"...\"}\n"
        "- {\"type\":\"split_selected_range_into_scenes\",\"scene_count\":3,\"label_prefix\":\"Scene\",\"director_notes\":[\"...\"],\"scene_notes\":[\"...\"]}\n"
        "- {\"type\":\"split_scene_into_subscenes\",\"scene_id\":\"...\",\"scene_number\":4,\"scene_count\":3,\"label_prefix\":\"Scene 4\"}\n"
        "- {\"type\":\"merge_scenes\",\"scene_numbers\":[2,3,4],\"label\":\"Scene 2\"}\n"
        "- {\"type\":\"renumber_scene_labels\"}\n"
        "- {\"type\":\"normalize_dual_vocal_director_notes\",\"replacement\":\"male and female\"}\n"
        "- {\"type\":\"replace_director_note_text\",\"find\":\"male singer and female singer\",\"replace\":\"female and male\"}\n"
        "- {\"type\":\"assign_selected_range_note\",\"label\":\"Female vocal\",\"marker_type\":\"female vocal|male vocal|chorus|verse|beat|note\",\"note\":\"...\"}\n"
        "- {\"type\":\"sync_existing_scenes_to_timeline_markers\",\"create_missing\":true}\n"
        "- {\"type\":\"set_scene_notes\",\"scene_number\":2,\"text\":\"...\"}\n"
        "- {\"type\":\"set_flux_notes\",\"scene_number\":2,\"text\":\"...\"}\n"
        "- {\"type\":\"set_nb_notes\",\"scene_number\":2,\"text\":\"...\"}\n"
        "- {\"type\":\"set_video_notes\",\"scene_number\":2,\"text\":\"...\"}\n"
        "- {\"type\":\"set_scene_plan\",\"scene_number\":2,\"director_note\":\"...\",\"scene_notes\":\"...\",\"flux_notes\":\"...\",\"nb_notes\":\"...\",\"video_notes\":\"...\"}\n"
        "- {\"type\":\"set_image_model_mode\",\"image_mode\":\"zimage|flux_klein|nano_banana|ernie_image\"}\n"
        "- {\"type\":\"set_video_model_mode\",\"video_mode\":\"i2v|id_lora|t2v|rtv|ingredients\"}\n"
        "- {\"type\":\"request_reference_images\",\"scene_id\":\"...\",\"image_mode\":\"nano_banana|flux_klein\"}\n"
        "- {\"type\":\"generate_image_prompt_for_current_mode\",\"scene_id\":\"...\",\"image_mode\":\"optional zimage|flux_klein|nano_banana|ernie_image\"}\n"
        "- {\"type\":\"run_image_for_current_mode\",\"scene_id\":\"...\",\"image_mode\":\"optional zimage|flux_klein|nano_banana|ernie_image\"}\n"
        "- {\"type\":\"generate_video_prompt_for_current_mode\",\"scene_id\":\"...\",\"video_mode\":\"optional i2v|id_lora|t2v|rtv|ingredients\"}\n\n"
        "- {\"type\":\"run_video_for_current_mode\",\"scene_id\":\"...\",\"video_mode\":\"optional i2v|id_lora|t2v|rtv|ingredients\"}\n\n"
        "Use note actions to capture the creative direction you discuss with the user. Use set_scene_plan when planning character assignments, story beats, scene concepts, and motion notes for one or more scenes. Keep each set_scene_plan field short and direct.\n"
        "Use create_concept_prompts when the user asks to create, generate, build, or update concept prompts from director notes, scene notes, timeline notes, story idea, or theme/style. This writes generated concept prompts into scene notes in batches.\n"
        "Use create_motion_notes when the user asks to create, generate, build, or update I2V/T2V motion notes from concept prompts, director notes, timeline notes, story idea, or theme/style. This writes generated motion notes into the I2V motion notes fields/file in batches.\n"
        "Use get_context_prompts to read the global Theme/style, Story idea, and Subject/scene context prompts. Use set_context_prompt when the user asks to update those global context prompt files. Choose context_type theme_style for style/mood/look, story_idea for plot/concept/narrative, and subject_scene for characters, subjects, locations, and recurring scene details.\n"
        "Use selected_timeline_range and timeline_markers when the user is timing vocals, choruses, dialogue, or music sections. If they say this selected range is where someone sings, use assign_selected_range_note. If they ask to make a scene cover it, use set_active_scene_to_selected_range. Only use create_scene_from_selected_range or split_selected_range_into_scenes when selected_timeline_range is not null and the user explicitly asks to create/split the selected in/out range. If the user asks to split one existing scene, such as 'split scene 4 into 3', use split_scene_into_subscenes with that scene number and count. If the user asks to combine, merge, join, or consolidate scenes, use merge_scenes with the scene numbers. If the user asks to update/reword/fix director notes, do note actions only; do not sync or change timings. If they ask to replace director note text, such as 'when a director note says X change it to Y', use replace_director_note_text. If they ask that all both-character or dual-vocal director notes say a specific phrase such as 'male and female' or 'female and male', use normalize_dual_vocal_director_notes with that replacement phrase. If timeline markers already exist and the user asks to update, align, match, sync, or split existing scene segments from those markers, or answers yes after you suggest updating scenes from markers, use sync_existing_scenes_to_timeline_markers. If the user asks to fix missing/skipped/duplicate scene numbers or renumber labels, use renumber_scene_labels. Do not use split_selected_range_into_scenes for marker-based timing, one-scene splits, or merge/combine requests.\n"
        "Use generate actions when the user asks you to make/create/update the actual image or video prompt. Use run_image_for_current_mode only when the user asks to run/create/generate the actual image, not just the text prompt.\n"
        "If the user asks for multiple steps, include all requested actions in order. Example: prompt, then image, then video means generate_image_prompt_for_current_mode, run_image_for_current_mode, generate_video_prompt_for_current_mode, run_video_for_current_mode.\n"
        "Nano B and Flux/Klein can run with or without reference images. If no references exist, use the normal generate/run actions anyway and the app will use text-only prompting. Only request reference images when the user specifically asks to use references or the scene concept requires matching an exact character/location.\n"
        "Do not write final image/video prompts yourself as actions. Do not use unsupported set_image_prompt, set_flux_prompt, set_nb_prompt, or set_video_prompt actions.\n"
        "Never put JSON, action arrays, code fences, or internal notes inside the reply string. The reply must be a short user-facing sentence; all work must be in the actions array.\n"
        "Do not claim which image/video generator ran. The app will report the actual mode after it runs the action.\n"
        f"Agent mode: {'AUTO APPLY. If the user asks you to do/apply/update/fill/write prompts or notes, include supported note/generate actions for the requested scene fields.' if auto_apply else 'MANUAL. Never include actions. Do not say you applied or updated the project; only suggest copy-ready text.'}\n"
        "Prefer scene_number for scene-targeted actions. Use scene_id only when copying an exact internal id from the context JSON. If the target scene is unclear, ask one short clarifying question and return no actions.\n"
        "In Auto Apply mode, the application will apply actions after your response. In Manual mode, actions must always be an empty list.\n\n"
        "Active context JSON:\n"
        f"{context_text}\n\n"
        "Conversation:\n"
        f"{conversation_text}\n\n"
        "Return the JSON now."
    )
    text, info = _run_builder_text_llm(
        payload,
        instruction,
        temperature=float(payload.get("temperature") or 0.55),
        top_p=float(payload.get("top_p") or 0.95),
        max_new_tokens=int(payload.get("max_new_tokens") or 500),
        label="Builder Agent",
        preserve_paragraphs=True,
    )
    raw = _clean_lm_studio_plain_text(text)
    try:
        parsed = _extract_json_object_from_text(raw)
    except Exception:
        parsed = {"reply": raw, "actions": []}
    reply = _clean_lm_studio_plain_text(str(parsed.get("reply") or "")).strip()
    actions = parsed.get("actions") if isinstance(parsed, dict) else []
    if not isinstance(actions, list) or not auto_apply:
        actions = []
    cleaned_actions = []
    allowed_types = {
        "set_scene_notes",
        "set_scene_plan",
        "select_scene",
        "get_scene_lyrics",
        "get_scene_context",
        "get_story_source",
        "get_context_prompts",
        "get_selected_timeline_range",
        "save_story_source",
        "set_context_prompt",
        "create_story_scenes_from_source",
        "create_concept_prompts",
        "create_motion_notes",
        "set_active_scene_to_selected_range",
        "create_scene_from_selected_range",
        "split_selected_range_into_scenes",
        "split_scene_into_subscenes",
        "merge_scenes",
        "renumber_scene_labels",
        "normalize_dual_vocal_director_notes",
        "replace_director_note_text",
        "assign_selected_range_note",
        "sync_existing_scenes_to_timeline_markers",
        "set_flux_notes",
        "set_nb_notes",
        "set_video_notes",
        "set_image_model_mode",
        "set_video_model_mode",
        "request_reference_images",
        "generate_image_prompt_for_current_mode",
        "run_image_for_current_mode",
        "generate_video_prompt_for_current_mode",
        "run_video_for_current_mode",
    }
    allowed_image_modes = {"zimage", "flux_klein", "nano_banana", "ernie_image"}
    allowed_video_modes = {"i2v", "id_lora", "t2v", "rtv", "ingredients"}
    max_actions = 60 if agent_purpose == "story_builder" else 12
    plan_fields = {"director_note", "scene_notes", "flux_notes", "nb_notes", "video_notes"}
    for action in actions[:max_actions]:
        if not isinstance(action, dict):
            continue
        action_type = str(action.get("type") or "").strip()
        scene_id = str(action.get("scene_id") or "").strip()
        action_text_raw = str(action.get("text") or "").strip()
        image_mode = str(action.get("image_mode") or "").strip()
        video_mode = str(action.get("video_mode") or "").strip()
        context_type = str(action.get("context_type") or "").strip().lower()
        context_mode = str(action.get("mode") or "").strip().lower()
        scene_count = action.get("scene_count")
        try:
            scene_count = int(scene_count) if scene_count is not None else None
        except Exception:
            scene_count = None
        plan_values = {
            field: str(action.get(field) or "").strip()[:5000]
            for field in plan_fields
            if str(action.get(field) or "").strip()
        }
        scene_number = action.get("scene_number")
        if scene_number is None:
            scene_target_text = " ".join(
                str(action.get(field) or "")
                for field in (
                    "scene_id",
                    "scene",
                    "scene_label",
                    "scene_name",
                    "target_scene",
                    "target",
                    "label",
                    "name",
                    "title",
                )
            )
            scene_match = re.search(r"\bscene\s*(\d+)(?:\b|\s|\.|:|-)", scene_target_text, re.I)
            if scene_match:
                scene_number = scene_match.group(1)
        try:
            scene_number = int(scene_number) if scene_number is not None else None
        except Exception:
            scene_number = None
        no_scene_actions = {
            "set_image_model_mode",
            "set_video_model_mode",
            "get_story_source",
            "get_context_prompts",
            "save_story_source",
            "set_context_prompt",
            "create_story_scenes_from_source",
            "create_concept_prompts",
            "create_motion_notes",
            "get_selected_timeline_range",
            "create_scene_from_selected_range",
            "split_selected_range_into_scenes",
            "merge_scenes",
            "renumber_scene_labels",
            "normalize_dual_vocal_director_notes",
            "replace_director_note_text",
            "assign_selected_range_note",
            "sync_existing_scenes_to_timeline_markers",
        }
        if action_type in allowed_types and (scene_id or scene_number is not None or action_type in no_scene_actions):
            if action_type == "request_reference_images" and not scene_id:
                continue
            cleaned_action = {
                "type": action_type,
            }
            if scene_id:
                cleaned_action["scene_id"] = scene_id[:160]
            if scene_number is not None:
                cleaned_action["scene_number"] = scene_number
            if action_text_raw:
                cleaned_action["text"] = action_text_raw[:50000 if action_type == "save_story_source" else 5000]
            if image_mode in allowed_image_modes:
                cleaned_action["image_mode"] = image_mode
            if video_mode in allowed_video_modes:
                cleaned_action["video_mode"] = video_mode
            if scene_count is not None:
                cleaned_action["scene_count"] = max(1, min(120, scene_count))
            if action_type == "get_context_prompts":
                if context_type not in {"all", "theme_style", "story_idea", "subject_scene"}:
                    context_type = "all"
                cleaned_action["context_type"] = context_type
                cleaned_actions.append(cleaned_action)
                continue
            if action_type == "set_context_prompt":
                if context_type not in {"theme_style", "story_idea", "subject_scene"}:
                    continue
                if not action_text_raw:
                    continue
                cleaned_action["context_type"] = context_type
                cleaned_action["text"] = action_text_raw[:50000]
                cleaned_action["mode"] = context_mode if context_mode in {"replace", "append"} else "replace"
                cleaned_actions.append(cleaned_action)
                continue
            if action_type == "assign_selected_range_note":
                for field in ("label", "marker_type", "note"):
                    value = str(action.get(field) or "").strip()
                    if value:
                        cleaned_action[field] = value[:1000]
                cleaned_actions.append(cleaned_action)
                continue
            if action_type == "create_scene_from_selected_range":
                for field in ("label", "director_note", "scene_notes", "flux_notes", "nb_notes", "video_notes", "note"):
                    value = str(action.get(field) or "").strip()
                    if value:
                        cleaned_action[field] = value[:5000]
                cleaned_actions.append(cleaned_action)
                continue
            if action_type == "split_selected_range_into_scenes":
                label_prefix = str(action.get("label_prefix") or "").strip()
                if label_prefix:
                    cleaned_action["label_prefix"] = label_prefix[:160]
                for field in ("director_notes", "scene_notes"):
                    values = action.get(field)
                    if isinstance(values, list):
                        cleaned_action[field] = [str(value or "").strip()[:5000] for value in values[:120]]
                cleaned_actions.append(cleaned_action)
                continue
            if action_type == "split_scene_into_subscenes":
                label_prefix = str(action.get("label_prefix") or "").strip()
                if label_prefix:
                    cleaned_action["label_prefix"] = label_prefix[:160]
                for field in ("director_notes", "scene_notes"):
                    values = action.get(field)
                    if isinstance(values, list):
                        cleaned_action[field] = [str(value or "").strip()[:5000] for value in values[:120]]
                if scene_count is None or scene_count < 2:
                    continue
                cleaned_actions.append(cleaned_action)
                continue
            if action_type == "merge_scenes":
                numbers = action.get("scene_numbers") or action.get("scenes") or []
                cleaned_numbers = []
                if isinstance(numbers, list):
                    for value in numbers[:120]:
                        try:
                            number = int(value)
                        except Exception:
                            continue
                        if number > 0 and number not in cleaned_numbers:
                            cleaned_numbers.append(number)
                for src, dst in (("start_scene_number", "start_scene_number"), ("end_scene_number", "end_scene_number")):
                    try:
                        value = int(action.get(src))
                    except Exception:
                        value = None
                    if value is not None and value > 0:
                        cleaned_action[dst] = value
                label = str(action.get("label") or "").strip()
                if label:
                    cleaned_action["label"] = label[:160]
                if cleaned_numbers:
                    cleaned_action["scene_numbers"] = cleaned_numbers
                if len(cleaned_numbers) < 2 and not (cleaned_action.get("start_scene_number") and cleaned_action.get("end_scene_number")):
                    continue
                cleaned_actions.append(cleaned_action)
                continue
            if action_type == "renumber_scene_labels":
                cleaned_actions.append(cleaned_action)
                continue
            if action_type == "normalize_dual_vocal_director_notes":
                replacement = str(action.get("replacement") or "male and female").strip()
                cleaned_action["replacement"] = (replacement or "male and female")[:160]
                cleaned_actions.append(cleaned_action)
                continue
            if action_type == "replace_director_note_text":
                find_text = str(action.get("find") or action.get("from") or "").strip()
                replace_text = str(action.get("replace") or action.get("to") or "").strip()
                if not find_text or not replace_text:
                    continue
                cleaned_action["find"] = find_text[:500]
                cleaned_action["replace"] = replace_text[:500]
                cleaned_actions.append(cleaned_action)
                continue
            if action_type == "get_story_source":
                cleaned_actions.append(cleaned_action)
                continue
            if action_type in {"save_story_source", "create_story_scenes_from_source"} and action_type == "save_story_source" and not action_text_raw:
                continue
            if action_type == "save_story_source":
                cleaned_actions.append(cleaned_action)
                continue
            if action_type == "create_story_scenes_from_source":
                cleaned_actions.append(cleaned_action)
                continue
            if action_type == "create_concept_prompts":
                source_mode = str(action.get("source_mode") or action.get("source") or "all").strip().lower()
                scope = str(action.get("scope") or "all").strip().lower()
                if source_mode not in {"all", "director", "scene", "timeline", "director_scene"}:
                    source_mode = "all"
                if scope not in {"all", "selected", "range"}:
                    scope = "all"
                try:
                    batch_size = int(action.get("batch_size") or action.get("batch") or 5)
                except Exception:
                    batch_size = 5
                cleaned_action["source_mode"] = source_mode
                cleaned_action["scope"] = scope
                cleaned_action["batch_size"] = max(1, min(10, batch_size))
                cleaned_action["use_story"] = action.get("use_story") is not False
                cleaned_action["use_theme"] = action.get("use_theme") is not False
                cleaned_actions.append(cleaned_action)
                continue
            if action_type == "create_motion_notes":
                source_mode = str(action.get("source_mode") or action.get("source") or "concept").strip().lower()
                scope = str(action.get("scope") or "all").strip().lower()
                if source_mode not in {"concept", "concept_director", "concept_timeline", "all"}:
                    source_mode = "concept"
                if scope not in {"all", "selected", "range"}:
                    scope = "all"
                try:
                    batch_size = int(action.get("batch_size") or action.get("batch") or 5)
                except Exception:
                    batch_size = 5
                cleaned_action["source_mode"] = source_mode
                cleaned_action["scope"] = scope
                cleaned_action["batch_size"] = max(1, min(10, batch_size))
                cleaned_action["use_story"] = action.get("use_story") is not False
                cleaned_action["use_theme"] = action.get("use_theme") is not False
                cleaned_actions.append(cleaned_action)
                continue
            if action_type == "sync_existing_scenes_to_timeline_markers":
                cleaned_action["create_missing"] = action.get("create_missing") is not False
                cleaned_actions.append(cleaned_action)
                continue
            if action_type == "set_scene_plan":
                for field, value in plan_values.items():
                    cleaned_action[field] = value
                if not plan_values and not action_text_raw:
                    continue
                cleaned_actions.append(cleaned_action)
                continue
            if action_type in {"set_scene_notes", "set_flux_notes", "set_nb_notes", "set_video_notes"} and not cleaned_action.get("text"):
                alias_fields = {
                    "set_scene_notes": ("scene_notes", "notes", "concept", "concept_prompt", "prompt"),
                    "set_flux_notes": ("flux_notes", "notes", "prompt"),
                    "set_nb_notes": ("nb_notes", "nano_banana_notes", "notes", "prompt"),
                    "set_video_notes": ("video_notes", "i2v_notes", "motion_notes", "notes", "prompt"),
                }[action_type]
                for field in alias_fields:
                    value = str(action.get(field) or "").strip()
                    if value:
                        cleaned_action["text"] = value[:5000]
                        break
            if action_type.startswith("set_") and not action_text_raw:
                if action_type == "set_image_model_mode" and cleaned_action.get("image_mode"):
                    cleaned_actions.append(cleaned_action)
                    continue
                if action_type == "set_video_model_mode" and cleaned_action.get("video_mode"):
                    cleaned_actions.append(cleaned_action)
                    continue
                if action_type in {"set_scene_notes", "set_flux_notes", "set_nb_notes", "set_video_notes"} and cleaned_action.get("text"):
                    cleaned_actions.append(cleaned_action)
                    continue
                continue
            cleaned_actions.append(cleaned_action)
    action_hint_text = "\n\n".join(
        [item.get("content", "") for item in cleaned_messages[-6:]]
        + ([reply] if reply else [])
    )
    latest_user_text = str(latest_user or cleaned_messages[-1].get("content", "") if cleaned_messages else "").strip()
    latest_merge_intent = re.search(r"\b(combine|merge|join|consolidate)\b", latest_user_text, re.I)
    latest_split_intent = re.search(r"\b(split|break|divide|sub[-\s]?scenes?|sub[-\s]?segments?)\b", latest_user_text, re.I)
    latest_director_note_text_intent = re.search(r"\b(director\s+notes?|notes?|reword|rename|text)\b", latest_user_text, re.I)
    latest_dual_vocal_note_intent = (
        latest_director_note_text_intent and
        re.search(r"\b(male\s+and\s+female|both\s+(?:characters|singers|vocals?)|dual[-\s]?vocal)\b", latest_user_text, re.I)
    )
    if auto_apply and latest_director_note_text_intent:
        cleaned_actions = [
            action for action in cleaned_actions
            if action.get("type") not in {
                "sync_existing_scenes_to_timeline_markers",
                "split_selected_range_into_scenes",
                "split_scene_into_subscenes",
                "merge_scenes",
            }
        ]
    if auto_apply and latest_dual_vocal_note_intent and not any(action.get("type") == "normalize_dual_vocal_director_notes" for action in cleaned_actions):
        exact_replace_match = re.search(r"\b(?:director\s+notes?|director\s+note|note)\s+says?\s+[\"']([^\"']+)[\"'].*?\b(?:changed?\s+to|to|instead)\s+[\"']([^\"']+)[\"']", latest_user_text, re.I)
        if exact_replace_match and not any(action.get("type") == "replace_director_note_text" for action in cleaned_actions):
            cleaned_actions.append(
                {
                    "type": "replace_director_note_text",
                    "find": exact_replace_match.group(1).strip(),
                    "replace": exact_replace_match.group(2).strip(),
                }
            )
        replacement_match = re.search(r"\b(?:says?|to|instead|changed?\s+to)\s+[\"']?((?:fe)?male\s+and\s+(?:fe)?male)[\"']?", latest_user_text, re.I)
        replacement = replacement_match.group(1).strip().lower() if replacement_match else "male and female"
        cleaned_actions.append({"type": "normalize_dual_vocal_director_notes", "replacement": replacement})
    if auto_apply and latest_split_intent:
        cleaned_actions = [
            action for action in cleaned_actions
            if action.get("type") != "merge_scenes"
        ]
    if auto_apply and latest_merge_intent:
        cleaned_actions = [
            action for action in cleaned_actions
            if action.get("type") not in {"split_scene_into_subscenes", "split_selected_range_into_scenes"}
        ]
    merge_intent = latest_merge_intent or (
        not latest_split_intent and
        re.fullmatch(r"\s*(yes|yep|yeah|ok|okay|please do it|do it|go ahead|sure)\.?\s*", latest_user_text, re.I) and
        re.search(r"\b(combine|merge|join|consolidate)\b", action_hint_text, re.I)
    )
    if auto_apply and merge_intent:
        cleaned_actions = [
            action for action in cleaned_actions
            if action.get("type") not in {"split_scene_into_subscenes", "split_selected_range_into_scenes"}
        ]
        has_merge_action = any(action.get("type") == "merge_scenes" for action in cleaned_actions)
        if not has_merge_action:
            range_match = re.search(r"\bscenes?\s+(\d+)\s*(?:-|to|through)\s*(\d+)\b", action_hint_text, re.I)
            scene_numbers = []
            if range_match:
                start_num = int(range_match.group(1))
                end_num = int(range_match.group(2))
                if start_num <= end_num:
                    scene_numbers = list(range(start_num, end_num + 1))
            if not scene_numbers:
                sequence_match = re.search(r"\bscenes?\s+((?:\d+\s*(?:,|and)?\s*){2,})", action_hint_text, re.I)
                if sequence_match:
                    scene_numbers = [int(value) for value in re.findall(r"\d+", sequence_match.group(1))]
            if len(scene_numbers) >= 2:
                scene_numbers = list(dict.fromkeys(scene_numbers))
                cleaned_actions.append(
                    {
                        "type": "merge_scenes",
                        "scene_numbers": scene_numbers,
                        "label": f"Scene {scene_numbers[0]}",
                    }
                )
                if not reply:
                    reply = f"Merging scenes {', '.join(str(value) for value in scene_numbers)}."
    if auto_apply and not cleaned_actions:
        split_hint_text = latest_user_text if latest_split_intent else action_hint_text
        if not merge_intent and re.search(r"\b(split|break|divide|sub[-\s]?scenes?|sub[-\s]?segments?)\b", split_hint_text, re.I):
            scene_matches = re.findall(r"\bscene\s+(\d+)\b", split_hint_text, re.I)
            count_matches = []
            count_matches.extend(
                int(match)
                for match in re.findall(r"\b(?:into|in|to)\s+(\d+)\s*(?:sub[-\s]?scenes?|scenes?|segments?)\b", split_hint_text, re.I)
                if str(match).isdigit()
            )
            count_matches.extend(
                int(match)
                for match in re.findall(r"\b(\d+)\s*(?:sub[-\s]?scenes?|sub[-\s]?segments?)\b", split_hint_text, re.I)
                if str(match).isdigit()
            )
            latest_user_number = re.fullmatch(r"\s*(\d{1,2})\s*", latest_user or "")
            if latest_user_number:
                count_matches.append(int(latest_user_number.group(1)))
            if scene_matches and count_matches:
                inferred_scene = int(scene_matches[-1])
                inferred_count = max(2, min(24, int(count_matches[-1])))
                cleaned_actions.append(
                    {
                        "type": "split_scene_into_subscenes",
                        "scene_number": inferred_scene,
                        "scene_count": inferred_count,
                        "label_prefix": f"Scene {inferred_scene}",
                    }
                )
                if not reply:
                    reply = f"Splitting Scene {inferred_scene} into {inferred_count} sub-scenes."
    if not reply:
        reply = "Done." if cleaned_actions else "I can help with that."
    return {"reply": reply, "actions": cleaned_actions, **info}


def _generate_builder_concept_prompts(payload):
    source_mode = str(payload.get("source_mode") or "all").strip().lower()
    story_idea = str(payload.get("story_idea") or "").strip()
    theme_style = str(payload.get("theme_style") or "").strip()
    previous_summary = str(payload.get("previous_summary") or "").strip()
    scenes = payload.get("scenes") or []
    if not isinstance(scenes, list) or not scenes:
        raise ValueError("No scenes were provided for concept prompt creation.")

    cleaned_scenes = []
    for scene in scenes[:20]:
        if not isinstance(scene, dict):
            continue
        try:
            number = int(scene.get("scene_number") or scene.get("number") or len(cleaned_scenes) + 1)
        except Exception:
            number = len(cleaned_scenes) + 1
        timeline_notes = scene.get("timeline_notes") or []
        if not isinstance(timeline_notes, list):
            timeline_notes = []
        cleaned_scenes.append({
            "scene_number": max(1, number),
            "label": str(scene.get("label") or f"Scene {number}").strip()[:160],
            "lyric_text": str(scene.get("lyric_text") or "").strip()[:1200],
            "lyric_singers": [
                str(item or "").strip()[:160]
                for item in (scene.get("lyric_singers") if isinstance(scene.get("lyric_singers"), list) else [])
                if str(item or "").strip()
            ][:8],
            "lyric_instrumental": bool(scene.get("lyric_instrumental")),
            "lyric_no_lip_sync": bool(scene.get("lyric_no_lip_sync")),
            "no_character_present": bool(scene.get("no_character_present") or scene.get("no_subject") or scene.get("no_visible_subject")),
            "mapped_subjects": str(scene.get("mapped_subjects") or "").strip()[:1600],
            "director_note": str(scene.get("director_note") or "").strip()[:1200],
            "scene_note": str(scene.get("scene_note") or "").strip()[:1200],
            "timeline_notes": [
                {
                    "label": str(item.get("label") or item.get("type") or "note").strip()[:160],
                    "note": str(item.get("note") or "").strip()[:800],
                    "start": item.get("start"),
                    "end": item.get("end"),
                }
                for item in timeline_notes[:8]
                if isinstance(item, dict)
            ],
            "subject_reference_mode": str(scene.get("subject_reference_mode") or "none").strip()[:80],
            "location_reference_mode": str(scene.get("location_reference_mode") or "none").strip()[:80],
        })
    if not cleaned_scenes:
        raise ValueError("No valid scenes were provided for concept prompt creation.")

    source_note = {
        "director": "Use director notes as the main scene notes.",
        "scene": "Use raw scene notes as the main scene notes.",
        "timeline": "Use overlapping timeline notes as the main scene notes.",
        "lyrics": "Use lyric notes as the main scene notes.",
        "subjects": "Use subject and singer mapping as the main scene notes.",
        "lyrics_subjects": "Use lyric notes plus subject and singer mapping as the main scene notes.",
        "director_scene": "Use director notes and raw scene notes as the main scene notes.",
        "all": "Use all available notes: director notes, raw scene notes, lyric notes, subject/singer mapping, and overlapping timeline notes.",
    }.get(source_mode, "Use all available notes: director notes, raw scene notes, lyric notes, subject/singer mapping, and overlapping timeline notes.")

    instruction = (
        "You will create concept prompts from scene notes and/or director notes, timeline notes, story idea, and style/theme.\n"
        "Return only valid JSON in this exact flat format:\n"
        "{\n"
        "  \"Scene1\": \"\",\n"
        "  \"Scene2\": \"\"\n"
        "}\n\n"
        f"Source mode: {source_mode}. {source_note}\n\n"
        "The story idea explains the overall music video concept, emotional arc, setting, and visual direction. Use it to make the prompts feel connected and to make each scene flow naturally like a music video.\n"
        "The style/theme explains the visual language, mood, palette, texture, and production design. Use it for consistency.\n"
        "Character descriptions or character reference images may be provided separately. Do not describe characters' hair, face, clothing, makeup, or exact appearance in the concept prompts.\n\n"
        "Create one prompt for each provided scene.\n"
        "Each concept prompt must include who is in the scene, shot type, Location:, and scene details that fit the story world.\n\n"
        "Subject rules:\n"
        "- If lyric_singers contains names, those are the subjects/performers for that scene.\n"
        "- If mapped_subjects contains character reference names, use those as the visible subjects for that scene.\n"
        "- If no_character_present is true, write only the location/background, environment, architecture, props, objects, weather, lighting, atmosphere, environmental motion, and camera. Do not include, mention, imply, describe, silhouette, reflect, or refer to any person, character, subject, singer, performer, band member, crowd, body part, face, voice, or character reference.\n"
        "- If lyric_no_lip_sync is true or lyric_instrumental is true, the scene should not be treated as a singing/lip-sync performance scene.\n"
        "- If the scene note says female, start with \"Female only\".\n"
        "- If the scene note says male, start with \"Male only\".\n"
        "- If the scene note says female and male, start with \"Female and male together in frame\".\n"
        "- If the scene note is instrumental only or has no clear subject, start with \"No main subject\".\n\n"
        "Music video flow rules:\n"
        "- Make the prompts feel like connected shots from the same music video.\n"
        "- Let locations and details progress with the story instead of feeling random.\n"
        "- Instrumental scenes can be establishing shots, transitions, symbolic visuals, or world-building.\n"
        "- Character scenes should feel like performance, duet, reaction, memory, confrontation, longing, or story moments.\n"
        "- Keep the visual world consistent across all prompts.\n\n"
        "Shot rules:\n"
        "- Instrumental scenes should usually be wide establishing shots or wide environment shots.\n"
        "- Female-only or male-only scenes should usually be close-up, upper body, or medium shot.\n"
        "- Female and male together should usually be full body, two-shot, medium-wide, or wide shot.\n"
        "- Make the shot type fit the scene note and story moment.\n\n"
        "Location rules:\n"
        "- Include \"Location:\" in every prompt.\n"
        "- Pick locations that fit the story idea, mood, and style/theme.\n"
        "- If a location reference is available for that scene, use it as the location identity instead of inventing an unrelated location.\n"
        "- If no location reference is available, create the location from the story idea, style/theme, and notes.\n"
        "- Keep locations visually connected so the scenes feel like one continuous music video world.\n\n"
        "Style rules:\n"
        "- Do not write full text-to-image prompts.\n"
        "- Do not include character descriptions.\n"
        "- Do not include camera settings, aspect ratio, render style, or quality tags.\n"
        "- Keep each prompt as one clear sentence or short paragraph.\n"
        "- Make prompts detailed enough for another LLM to expand into image prompts.\n"
        "- Return only the JSON object.\n\n"
        f"Story idea:\n{story_idea or '[none provided]'}\n\n"
        f"Style/theme:\n{theme_style or '[none provided]'}\n\n"
        f"Previous batch visual progression summary:\n{previous_summary or '[none yet]'}\n\n"
        "Scenes:\n"
        f"{json.dumps(cleaned_scenes, ensure_ascii=False, indent=2)}"
    )
    text, info = _run_builder_text_llm(
        payload,
        instruction,
        temperature=float(payload.get("temperature") or 0.45),
        top_p=float(payload.get("top_p") or 0.95),
        max_new_tokens=int(payload.get("max_new_tokens") or 1200),
        label="Concept Prompt Creator",
        preserve_paragraphs=True,
    )
    raw = _clean_lm_studio_plain_text(text)
    prompts = {}
    try:
        parsed = _extract_json_object_from_text(raw)
        if isinstance(parsed, dict):
            for key, value in parsed.items():
                match = re.search(r"scene\s*(\d+)", str(key), re.I)
                if not match:
                    continue
                prompt_text = str(value or "").strip()
                if prompt_text:
                    prompts[f"Scene{int(match.group(1))}"] = prompt_text
    except Exception:
        prompts = {}
    if not prompts:
        for match in re.finditer(r'"?\bScene\s*(\d+)"?\s*:\s*"([^"]+)"', raw, re.I | re.S):
            prompt_text = match.group(2).strip()
            if prompt_text:
                prompts[f"Scene{int(match.group(1))}"] = prompt_text
    if not prompts:
        raise ValueError("Gemma did not return any SceneN concept prompts.")
    summary_lines = []
    for key in sorted(prompts.keys(), key=lambda item: int(re.search(r"\d+", item).group(0))):
        text_value = prompts[key]
        summary_lines.append(f"{key}: {text_value[:180]}")
    return {
        "prompts": prompts,
        "raw": raw,
        "summary": "\n".join(summary_lines)[:1200],
        "run_info": info,
    }


def _generate_builder_motion_notes(payload):
    source_mode = str(payload.get("source_mode") or "concept").strip().lower()
    story_idea = str(payload.get("story_idea") or "").strip()
    theme_style = str(payload.get("theme_style") or "").strip()
    previous_summary = str(payload.get("previous_summary") or "").strip()
    video_mode = str(payload.get("video_mode") or "i2v").strip().lower()
    scenes = payload.get("scenes") or []
    if not isinstance(scenes, list) or not scenes:
        raise ValueError("No scenes were provided for motion note creation.")

    cleaned_scenes = []
    for scene in scenes[:20]:
        if not isinstance(scene, dict):
            continue
        try:
            number = int(scene.get("scene_number") or scene.get("number") or len(cleaned_scenes) + 1)
        except Exception:
            number = len(cleaned_scenes) + 1
        timeline_notes = scene.get("timeline_notes") or []
        if not isinstance(timeline_notes, list):
            timeline_notes = []
        cleaned_scenes.append({
            "scene_number": max(1, number),
            "label": str(scene.get("label") or f"Scene {number}").strip()[:160],
            "concept_prompt": str(scene.get("concept_prompt") or "").strip()[:1600],
            "director_note": str(scene.get("director_note") or "").strip()[:1200],
            "timeline_notes": [
                {
                    "label": str(item.get("label") or item.get("type") or "note").strip()[:160],
                    "note": str(item.get("note") or "").strip()[:800],
                    "start": item.get("start"),
                    "end": item.get("end"),
                }
                for item in timeline_notes[:8]
                if isinstance(item, dict)
            ],
        })
    if not cleaned_scenes:
        raise ValueError("No valid scenes were provided for motion note creation.")

    source_note = {
        "concept": "Use only concept prompts.",
        "concept_director": "Use concept prompts and director notes.",
        "concept_timeline": "Use concept prompts and overlapping timeline notes.",
        "all": "Use concept prompts, director notes, and overlapping timeline notes.",
    }.get(source_mode, "Use concept prompts.")

    instruction = (
        "You will create concise I2V/T2V motion notes for scene-by-scene music video generation.\n"
        "Return only valid JSON in this exact flat format:\n"
        "{\n"
        "  \"Motion1\": \"\",\n"
        "  \"Motion2\": \"\"\n"
        "}\n\n"
        f"Source mode: {source_mode}. {source_note}\n"
        f"Target video mode: {video_mode.upper()}.\n\n"
        "Write one motion note for each provided scene.\n"
        "Each motion note should describe camera motion, subject movement or interaction, environmental motion, and emotional pacing.\n"
        "Use the concept prompt as the main visual action source. Use director notes and timeline notes only when provided by the source mode.\n\n"
        "Rules:\n"
        "- Keep each motion note one sentence or one short paragraph.\n"
        "- Do not write a full video prompt.\n"
        "- Do not repeat character appearance details.\n"
        "- Do not include camera settings, frame rate, aspect ratio, render quality, or model tags.\n"
        "- For instrumental/no-subject scenes, focus on environmental movement, transitions, symbolic motion, light, particles, atmosphere, or camera drift.\n"
        "- For solo character scenes, include performance/reaction movement, facial/emotional energy, body motion, and camera movement.\n"
        "- For two-character scenes, include interaction, blocking, distance, reaction, duet/confrontation energy, and camera movement.\n"
        "- Keep motion connected across the batch like shots from the same music video.\n"
        "- Return only the JSON object.\n\n"
        f"Story idea:\n{story_idea or '[none provided]'}\n\n"
        f"Style/theme:\n{theme_style or '[none provided]'}\n\n"
        f"Previous batch motion summary:\n{previous_summary or '[none yet]'}\n\n"
        "Scenes:\n"
        f"{json.dumps(cleaned_scenes, ensure_ascii=False, indent=2)}"
    )
    text, info = _run_builder_text_llm(
        payload,
        instruction,
        temperature=float(payload.get("temperature") or 0.45),
        top_p=float(payload.get("top_p") or 0.95),
        max_new_tokens=int(payload.get("max_new_tokens") or 1200),
        label="Motion Note Creator",
        preserve_paragraphs=True,
    )
    raw = _clean_lm_studio_plain_text(text)
    notes = {}
    try:
        parsed = _extract_json_object_from_text(raw)
        if isinstance(parsed, dict):
            for key, value in parsed.items():
                match = re.search(r"(?:motion|scene)\s*(\d+)", str(key), re.I)
                if not match:
                    continue
                note_text = str(value or "").strip()
                if note_text:
                    notes[f"Motion{int(match.group(1))}"] = note_text
    except Exception:
        notes = {}
    if not notes:
        for match in re.finditer(r'"?\b(?:Motion|Scene)\s*(\d+)"?\s*:\s*"([^"]+)"', raw, re.I | re.S):
            note_text = match.group(2).strip()
            if note_text:
                notes[f"Motion{int(match.group(1))}"] = note_text
    if not notes:
        raise ValueError("Gemma did not return any MotionN notes.")
    summary_lines = []
    for key in sorted(notes.keys(), key=lambda item: int(re.search(r"\d+", item).group(0))):
        text_value = notes[key]
        summary_lines.append(f"{key}: {text_value[:180]}")
    return {
        "notes": notes,
        "raw": raw,
        "summary": "\n".join(summary_lines)[:1200],
        "run_info": info,
    }


def _generate_builder_t2i_prompt(payload):
    from .LLM import VRGDG_SuperGemmaGGUFChat, _clear_vrgdg_llm_caches

    model_file = str(payload.get("model_file", "") or "").strip()
    mmproj_file = str(payload.get("mmproj_file", "") or "").strip()
    ref_image_path = str(payload.get("ref_image_path", "") or "").strip().strip('"')
    ref_image_data = str(payload.get("ref_image_data", "") or "").strip()
    user_notes = str(payload.get("user_notes", "") or "").strip()
    prompt_mode = str(payload.get("prompt_mode", "") or "").strip().lower()
    builder_instruction_key = str(payload.get("builder_instruction_key") or payload.get("instruction_key") or "").strip()
    reference_context = payload.get("reference_context") or {}
    if not isinstance(reference_context, dict):
        reference_context = {}
    theme_style = _read_text_file(payload.get("theme_style_path", ""), "Theme/style file")
    story_idea = _read_text_file(payload.get("story_idea_path", ""), "Story idea file")
    subject_scene = _read_text_file(payload.get("subject_scene_path", ""), "Subject/scene file")
    context_parts = []
    if subject_scene:
        context_parts.append(f"Subject/scene:\n{subject_scene}")
    if theme_style:
        context_parts.append(f"Theme/style:\n{theme_style}")
    if story_idea:
        context_parts.append(f"Story idea:\n{story_idea}")
    if context_parts:
        user_notes = "\n\n".join(context_parts + ([f"Segment notes:\n{user_notes}"] if user_notes else []))
    use_vision = bool(payload.get("use_vision"))
    has_ref_image = bool(use_vision and ((ref_image_path and os.path.isfile(ref_image_path)) or ref_image_data))
    text_runner = _llm_runner_from_payload(payload)
    if not model_file and text_runner not in _EXTERNAL_LLM_RUNNERS:
        raise ValueError("Choose a Gemma model first.")
    if use_vision and not has_ref_image:
        raise ValueError("Choose a valid reference image path/data or turn off vision reference.")
    if not has_ref_image and not user_notes:
        raise ValueError("Enter scene notes or provide a reference image.")

    llm = _builder_local_llm(payload) if has_ref_image and text_runner not in _EXTERNAL_LLM_RUNNERS else None
    model_file = _builder_local_model_file(payload, model_file)
    model_path = llm._resolve_dropdown_path(model_file, llm.MISSING_MODEL_OPTION) if llm else ""
    mmproj_file = _builder_local_mmproj_file(payload, mmproj_file)
    mmproj_path = _resolve_mmproj_dropdown_path(llm, mmproj_file) if llm else ""
    image = None
    if has_ref_image:
        image = _image_from_data_url(ref_image_data).convert("RGB") if ref_image_data else Image.open(ref_image_path).convert("RGB")
    if has_ref_image:
        prompt = _VISUAL_T2I_INSTRUCTIONS
        prompt += f"\n\nUser notes:\n{user_notes or 'Use the reference image as the guide.'}"
    elif prompt_mode == "flux_klein":
        subject_description = str(reference_context.get("subject_description", "") or "").strip()
        location_name = str(reference_context.get("location_name", "") or "").strip()
        location_description = str(reference_context.get("location_description", "") or "").strip()
        reference_rules = []
        if subject_description:
            reference_rules.append(
                "Use the subject description for the main subject identity, face/body details, outfit, and visible character consistency. "
                f"Subject description: {subject_description}"
            )
        if location_name or location_description:
            location_details = "; ".join(part for part in (location_name, location_description) if part)
            reference_rules.append(
                "Use the mapped location as the required setting/background. Do not replace it with a different location from the concept or notes. "
                f"Mapped location: {location_details}"
            )
        reference_text = ""
        if reference_rules:
            reference_text = (
                "\nReference Builder priorities:\n"
                + "\n".join(f"- {rule}" for rule in reference_rules)
                + "\n- Use the user's notes/concept for action, pose, mood, lighting, story beat, and details after respecting the reference priorities.\n"
            )
        base_instructions = _FLUX_KLEIN_T2I_INSTRUCTIONS
        if builder_instruction_key:
            base_instructions = _effective_builder_instruction(payload, builder_instruction_key, _FLUX_KLEIN_T2I_INSTRUCTIONS)
        prompt = (
            f"{base_instructions}\n"
            f"{reference_text}\n"
            "\n"
            f"User notes:\n{user_notes or 'Create a cinematic image using the available scene notes.'}"
        )
    elif prompt_mode == "nano_banana":
        subject_description = str(reference_context.get("subject_description", "") or "").strip()
        location_name = str(reference_context.get("location_name", "") or "").strip()
        location_description = str(reference_context.get("location_description", "") or "").strip()
        has_subject_reference = bool(reference_context.get("has_subject_reference") or subject_description)
        has_location_reference = bool(reference_context.get("has_location_reference") or location_name or location_description)
        context_parts = []
        if subject_description:
            context_parts.append(f"Character reference description:\n{subject_description}")
        if location_name or location_description:
            context_parts.append(f"Location reference description:\n{location_name}\n{location_description}".strip())
        if user_notes:
            context_parts.append(f"User input:\n{user_notes}")
        start_rules = [
            "- Start with: Using the provided character reference and location reference, create...",
            "- If only a character reference description is available, start with: Using the provided character reference, create...",
            "- If only a location reference description is available, start with: Using the provided location reference, create...",
        ]
        if not has_subject_reference and not has_location_reference:
            start_rules = ["- Start directly with the shot and subject; do not claim a provided reference exists."]
        base_instructions = _NANO_B_T2I_INSTRUCTIONS
        if builder_instruction_key:
            base_instructions = _effective_builder_instruction(payload, builder_instruction_key, _NANO_B_T2I_INSTRUCTIONS)
        prompt = (
            f"{base_instructions}\n\n"
            "Reference wording rules:\n"
            + "\n".join(start_rules)
            + "\n"
            "- Preserve the character identity from the character reference description: face, hair, outfit, makeup, and overall identity.\n"
            "- Preserve the location identity from the location reference description: environment, architecture, layout, atmosphere, and major visible setting details.\n"
            "\n"
            f"{chr(10).join(context_parts) if context_parts else 'User input: Create a cinematic image using the available scene notes.'}"
        )
    else:
        base_instructions = _TEXT_ONLY_T2I_INSTRUCTIONS
        if builder_instruction_key:
            base_instructions = _effective_builder_instruction(payload, builder_instruction_key, _TEXT_ONLY_T2I_INSTRUCTIONS)
        prompt = f"{base_instructions}\n\nUser notes:\n{user_notes}"

    n_ctx = int(payload.get("n_ctx") or 8000)
    n_gpu_layers = int(payload.get("n_gpu_layers") or 99)
    n_threads = int(payload.get("n_threads") or 8)
    chat_format = str(payload.get("chat_format", "") or "").strip()
    temperature = float(payload.get("temperature") or (0.25 if has_ref_image else 0.6))
    top_p = float(payload.get("top_p") or 0.95)
    max_new_tokens = _runner_output_token_limit(payload, int(payload.get("max_new_tokens") or (1000 if has_ref_image else 1200)))
    unload_after = bool(payload.get("unload_after", True))
    seed = payload.get("seed")

    try:
        if has_ref_image and text_runner in _EXTERNAL_LLM_RUNNERS:
            text, run_info = _try_run_remote_vision(
                payload,
                prompt,
                [image],
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
            )
        elif has_ref_image:
            model = llm._load_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            text = llm._run_gguf_vision_pipeline(
                model=model,
                pil_images=[image],
                instruction_text=prompt,
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
            )
        else:
            text, run_info = _run_builder_text_llm(
                payload,
                prompt,
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
                label="Gemma",
            )
        text = _clean_visual_gemma_text(text)
        text = extract_prompt_text_from_gemma_output(text, payload.get("scene_number"))
        label = "Flux/Klein" if prompt_mode == "flux_klein" else "NanoBanana" if prompt_mode == "nano_banana" else "Flow/GPT" if prompt_mode == "flow_gpt" else "T2I"
        text = _repair_and_validate_builder_gemma_prompt(payload, text, label)
        return {
            "prompt": text,
            "used_reference_image": has_ref_image,
            "used_model": run_info.get("used_model", model_path) if has_ref_image and text_runner in _EXTERNAL_LLM_RUNNERS else model_path if has_ref_image else run_info.get("used_model", ""),
            "used_mmproj": mmproj_path,
            "runner": run_info.get("runner", "builtin") if has_ref_image and text_runner in _EXTERNAL_LLM_RUNNERS else "builtin" if has_ref_image else run_info.get("runner", "builtin"),
            "unloaded": run_info.get("unloaded", unload_after) if has_ref_image and text_runner in _EXTERNAL_LLM_RUNNERS else unload_after if has_ref_image else run_info.get("unloaded", unload_after),
        }
    finally:
        if llm and has_ref_image and unload_after:
            llm._unload_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            _clear_vrgdg_llm_caches(clear_cuda_cache=True, clear_hf_pipeline_cache=False)


def _generate_builder_i2v_prompt(payload):
    from .LLM import VRGDG_SuperGemmaGGUFChat, _clear_vrgdg_llm_caches

    model_file = str(payload.get("model_file", "") or "").strip()
    mmproj_file = str(payload.get("mmproj_file", "") or "").strip()
    t2i_prompt = str(payload.get("t2i_prompt", "") or "").strip()
    image_reference_path = str(payload.get("image_reference_path", "") or "").strip().strip('"')
    image_reference_data = str(payload.get("image_reference_data", "") or "").strip()
    user_notes = str(payload.get("user_notes", "") or "").strip()
    subject_context = str(payload.get("subject_context", "") or "").strip()
    location_context = str(payload.get("location_context", "") or "").strip()
    no_character_present = bool(payload.get("no_character_present") or payload.get("no_subject") or payload.get("no_visible_subject"))
    performance_mode = str(
        payload.get("performance_mode")
        or payload.get("performanceMode")
        or payload.get("video_type")
        or payload.get("videoType")
        or ""
    ).strip().lower().replace("-", "_").replace(" ", "_")
    if performance_mode in {"speaking", "short_film", "dialogue", "dialog"}:
        performance_mode = "speaking"
    elif performance_mode in {"no_lip_sync", "nolipsync", "no_lipsync", "no_sync", "silent", "visual_only"}:
        performance_mode = "no_lip_sync"
    else:
        performance_mode = "singing"
    if performance_mode == "speaking":
        mode_note = (
            "Video Type / performance mode:\nspeaking / short film. "
            "If a line is present, the visible speaker says it naturally. Do not use singing, rapping, vocals, lyric, lip-sync, or music-performance wording."
        )
    elif performance_mode == "no_lip_sync":
        mode_note = (
            "Video Type / performance mode:\nno lip sync / visual-only. "
            "Do not quote lyric text. Do not mention saying, speaking, dialogue, singing, rapping, vocals, lyric, lip-sync, mouth movement, or no-vocal status. "
            "Use visible action, camera motion, environmental motion, mood, and physical movement instead."
        )
    else:
        mode_note = (
            "Video Type / performance mode:\nsinging / music video. "
            "Use singing behavior only when the scene notes or lyric context call for a vocal performance."
        )
    text_runner = _llm_runner_from_payload(payload)
    if not model_file and text_runner not in _EXTERNAL_LLM_RUNNERS:
        raise ValueError("Choose an I2V Gemma model first.")
    if model_file and text_runner not in _EXTERNAL_LLM_RUNNERS and not model_file.lower().endswith(".gguf"):
        raise ValueError("The I2V model field is not a GGUF model.")

    image = None
    has_image_reference = False
    if image_reference_data:
        image = _image_from_data_url(image_reference_data).convert("RGB")
        has_image_reference = True
    elif image_reference_path:
        image_path = _resolve_existing_file(image_reference_path, "I2V image reference")
        image = Image.open(image_path).convert("RGB")
        has_image_reference = True

    if has_image_reference and text_runner not in _EXTERNAL_LLM_RUNNERS and not model_file:
        raise ValueError("Choose an I2V vision Gemma model first.")
    if not has_image_reference and not t2i_prompt:
        raise ValueError("Create or paste a T2I prompt first, or save/load an image reference.")
    if not has_image_reference:
        theme_style = _read_text_file(payload.get("theme_style_path", ""), "Theme/style file")
        story_idea = _read_text_file(payload.get("story_idea_path", ""), "Story idea file")
        subject_scene = _read_text_file(payload.get("subject_scene_path", ""), "Subject/scene file")
        context_parts = []
        if no_character_present:
            context_parts.append("Subject visibility:\nNo main character, singer, performer, person, mapped subject, or character reference is present in this scene. Use location, props, objects, atmosphere, and camera motion instead.")
        elif subject_scene:
            context_parts.append(f"Subject/scene:\n{subject_scene}")
        if subject_context and not no_character_present:
            context_parts.append(f"Mapped scene character(s):\n{subject_context}")
        if location_context:
            context_parts.append(f"Mapped scene location:\n{location_context}")
        if theme_style:
            context_parts.append(f"Theme/style:\n{theme_style}")
        if story_idea:
            context_parts.append(f"Story idea:\n{story_idea}")
        if context_parts:
            user_notes = "\n\n".join(context_parts + ([f"Segment motion notes:\n{user_notes}"] if user_notes else []))

    user_notes = "\n\n".join([mode_note, user_notes]).strip()

    llm = _builder_local_llm(payload) if text_runner not in _EXTERNAL_LLM_RUNNERS else None
    model_file = _builder_local_model_file(payload, model_file)
    model_path = llm._resolve_dropdown_path(model_file, llm.MISSING_MODEL_OPTION) if llm else ""
    mmproj_file = _builder_local_mmproj_file(payload, mmproj_file)
    mmproj_path = _resolve_mmproj_dropdown_path(llm, mmproj_file) if has_image_reference and llm else ""
    i2v_instructions = _effective_builder_instruction(payload, "i2v", _I2V_INSTRUCTIONS)
    if has_image_reference:
        prompt = (
            f"{i2v_instructions}\n\n"
            "Use the provided image as the primary visual reference. Preserve the visible subject, setting, clothing, mood, and scene identity from the image. "
            "Use the text-to-image prompt only as extra scene context. "
            "Use only the provided image, the text-to-image prompt, and the user motion/camera notes. Do not use concept prompts, global story text, theme files, or subject files. "
            "Use the user motion/camera notes as the highest priority when deciding motion, performance, camera movement, and energy.\n\n"
            f"Text-to-image prompt:\n{t2i_prompt or 'Use the image as the main visual reference.'}\n\n"
        )
    else:
        prompt = f"{i2v_instructions}\n\nText-to-image prompt:\n{t2i_prompt}\n\n"
    prompt += f"User motion/camera notes:\n{user_notes or 'Create fast cinematic performance motion that fits the scene.'}"

    n_ctx = int(payload.get("n_ctx") or 8000)
    n_gpu_layers = int(payload.get("n_gpu_layers") or 99)
    n_threads = int(payload.get("n_threads") or 8)
    chat_format = str(payload.get("chat_format", "") or "").strip()
    temperature = float(payload.get("temperature") or (0.25 if has_image_reference else 0.7))
    top_p = float(payload.get("top_p") or 0.95)
    max_new_tokens = _runner_output_token_limit(payload, int(payload.get("max_new_tokens") or 4000))
    unload_after = bool(payload.get("unload_after", True))
    seed = payload.get("seed")

    try:
        if has_image_reference and text_runner in _EXTERNAL_LLM_RUNNERS:
            text, run_info = _try_run_remote_vision(
                payload,
                prompt,
                [image],
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
            )
        elif text_runner in _EXTERNAL_LLM_RUNNERS:
            text, run_info = _run_builder_text_llm(
                payload,
                prompt,
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
                label="I2V LLM",
            )
        else:
            model = llm._load_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            if has_image_reference:
                text = llm._run_gguf_vision_pipeline(
                    model=model,
                    pil_images=[image],
                    instruction_text=prompt,
                    temperature=temperature,
                    top_p=top_p,
                    max_new_tokens=max_new_tokens,
                    seed=int(seed) if seed is not None else None,
                )
                run_info = {"runner": "builtin", "used_model": model_path, "unloaded": unload_after}
            else:
                text = llm._run_gguf_text_pipeline(
                    model=model,
                    instruction_text=prompt,
                    temperature=temperature,
                    top_p=top_p,
                    max_new_tokens=max_new_tokens,
                    seed=int(seed) if seed is not None else None,
                )
                run_info = {"runner": "builtin", "used_model": model_path, "unloaded": unload_after}
        text = _clean_gemma_prompt_text(text)
        text = _repair_and_validate_builder_gemma_prompt(payload, text, "I2V")
        return {"prompt": text, "used_model": run_info.get("used_model", model_path), "used_mmproj": mmproj_path, "used_image_reference": has_image_reference, "runner": run_info.get("runner", "builtin"), "unloaded": run_info.get("unloaded", unload_after)}
    finally:
        if llm and unload_after:
            llm._unload_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            _clear_vrgdg_llm_caches(clear_cuda_cache=True, clear_hf_pipeline_cache=False)


def _chained_i2v_meta_language_error(text):
    forbidden_patterns = [
        r"\bcurrent\s+(?:frame|image|picture|photo)\b",
        r"\bprovided\s+(?:frame|image|picture|photo)\b",
        r"\bprevious\s+(?:frame|image|picture|photo|scene|video)\b",
        r"\blast\s+(?:frame|image|picture|photo)\b",
        r"\bfirst\s+(?:frame|image|picture|photo)\b",
        r"\bstart(?:ing)?\s+(?:frame|image|picture|photo)\b",
        r"\b(?:this|the)\s+(?:frame|image|picture|photo)\b",
        r"\bfrom\s+(?:the\s+)?(?:frame|image|picture|photo)\b",
    ]
    for pattern in forbidden_patterns:
        if re.search(pattern, text or "", flags=re.I):
            return pattern
    return ""


def _validate_chained_i2v_prompt(text):
    if _chained_i2v_meta_language_error(text):
        raise ValueError(
            "Gemma returned a chained I2V prompt with frame/image meta language. "
            "Try again or simplify the chain direction."
        )


def _repair_chained_i2v_meta_prompt(payload, text, transition_lora_prompt=False, transition_lora_trigger="zhuanchang"):
    original = str(text or "").strip()
    if not original or not _chained_i2v_meta_language_error(original):
        return original
    repair_payload = dict(payload or {})
    repair_model = str(
        repair_payload.get("repair_model_file")
        or repair_payload.get("text_model_file")
        or repair_payload.get("model_file")
        or ""
    ).strip()
    if repair_model:
        repair_payload["model_file"] = repair_model
    repair_payload["mmproj_file"] = ""
    repair_payload["use_vision"] = False
    trigger = str(transition_lora_trigger or "zhuanchang").strip() or "zhuanchang"
    trigger_rule = (
        f"\n- End the prompt with exactly one trigger phrase: {trigger}"
        if transition_lora_prompt else ""
    )
    instruction = (
        "Rewrite this chained LTX image-to-video prompt into one normal final video prompt paragraph.\n\n"
        "The prompt is already conceptually useful, but it contains forbidden meta language about frames/images/references/sources. "
        "Remove that meta language while preserving the visible starting subject, setting, action, camera motion, transformation, lyrics/performance intent, and ending state.\n\n"
        "Rules:\n"
        "- Do not mention frames, images, pictures, photos, references, sources, current visuals, provided visuals, previous scenes, or previous videos.\n"
        "- Do not say use/using/based on/from the image or frame.\n"
        "- Keep it as a normal cinematic image-to-video prompt only.\n"
        "- No markdown, labels, quotes around the whole prompt, JSON, or bullet points."
        f"{trigger_rule}\n\n"
        f"Prompt to rewrite:\n{original[:5000]}"
    )
    try:
        repaired, _run_info = _run_builder_text_llm(
            repair_payload,
            instruction,
            temperature=0.2,
            top_p=0.85,
            max_new_tokens=900,
            label="Chained I2V repair Gemma",
        )
        repaired = _clean_gemma_prompt_text(repaired)
        if transition_lora_prompt and trigger:
            repaired = re.sub(rf"(?:,\s*)?{re.escape(trigger)}\s*$", "", repaired, flags=re.I).strip().rstrip(".,;")
            repaired = f"{repaired}, {trigger}"
        if repaired and not _chained_i2v_meta_language_error(repaired):
            return repaired
    except Exception:
        pass
    return original


def _fallback_chained_i2v_prompt(
    scene_context="",
    user_notes="",
    story_context="",
    chain_style="continuous",
    transition_lora_prompt=False,
    transition_lora_trigger="zhuanchang",
):
    context = " ".join(
        part
        for part in (
            str(scene_context or "").strip(),
            str(user_notes or "").strip(),
            str(story_context or "").strip(),
        )
        if part
    )
    context = re.sub(r"\s+", " ", context).strip()
    if len(context) > 700:
        context = context[:700].rsplit(" ", 1)[0].strip()
    style = str(chain_style or "continuous").strip().lower().replace("-", "_").replace(" ", "_")
    if style in {"transformation", "surreal"} or transition_lora_prompt:
        prompt = (
            "A cinematic shot begins from the visible subject and setting, preserving the existing pose, lighting, colors, and composition. "
            "As the camera moves smoothly, the subject's outfit, hair, materials, and silhouette begin to transform with fluid detail, while the surrounding environment shifts into a new expressive location shaped by the scene's story and mood. "
            "Lighting changes across the subject's face and clothing, textures ripple and reform, and the background evolves into a more dramatic visual world while the motion remains continuous and natural."
        )
    elif style == "environment_shift":
        prompt = (
            "A cinematic shot begins from the visible subject and setting, preserving the existing pose, lighting, colors, and composition. "
            "As the camera moves smoothly, the surrounding environment transforms with changing atmosphere, architecture, weather, and light, while the visible subject remains grounded in the scene. "
            "The location gradually becomes a new expressive space shaped by the story and mood, with continuous motion and natural visual flow."
        )
    else:
        prompt = (
            "A cinematic shot begins from the visible subject and setting, preserving the existing pose, lighting, colors, and composition. "
            "The camera moves smoothly as the subject continues with natural performance energy, subtle expression changes, and environmental motion. "
            "The scene develops toward the next story beat while maintaining continuous visual flow."
        )
    if context:
        prompt += f" The transformation direction follows this scene context: {context}"
    trigger = str(transition_lora_trigger or "zhuanchang").strip() or "zhuanchang"
    if transition_lora_prompt:
        prompt = re.sub(rf"(?:,\s*)?{re.escape(trigger)}\s*$", "", prompt, flags=re.I).strip().rstrip(".,;")
        prompt = f"{prompt}, {trigger}"
    return prompt


def _chained_i2v_style_note(chain_style, chain_direction):
    style = str(chain_style or "continuous").strip().lower().replace("-", "_").replace(" ", "_")
    if style not in {"continuous", "surreal", "transformation", "environment_shift"}:
        style = "continuous"
    direction = str(chain_direction or "").strip()
    if style == "surreal":
        note = "Style mode: surreal continuity. Keep the opening visual state recognizable, then introduce dreamlike impossible motion, altered light, strange materials, or poetic environmental behavior."
    elif style == "transformation":
        note = (
            "Style mode: subject and environment transformation. Start from the visible subject, clothing, pose, lighting, and place exactly as they appear, "
            "then visibly change them during the shot. Include at least one clear wardrobe/material/body-silhouette transformation and one clear environment, lighting, weather, architecture, or location transformation when a character is visible. "
            "Do not leave the subject in the same outfit and same location with only posing or wind; the shot must evolve into something else while remaining continuous."
        )
    elif style == "environment_shift":
        note = "Style mode: environment shift. Keep the opening visual state recognizable, then gradually change the surrounding place, weather, architecture, lighting, or atmosphere while maintaining one continuous shot."
    else:
        note = "Style mode: continuous video. Keep the opening visual state recognizable and extend it with natural action, camera motion, lighting changes, and environmental motion."
    if direction:
        note += f"\nUser chain direction: {direction}"
    return note


def _generate_builder_chained_i2v_prompt(payload):
    from .LLM import VRGDG_SuperGemmaGGUFChat, _clear_vrgdg_llm_caches

    model_file = str(payload.get("model_file", "") or "").strip()
    mmproj_file = str(payload.get("mmproj_file", "") or "").strip()
    image_reference_path = str(payload.get("image_reference_path", "") or payload.get("source_image_path", "") or "").strip().strip('"')
    image_reference_data = str(payload.get("image_reference_data", "") or "").strip()
    scene_context = str(payload.get("scene_context", "") or payload.get("t2i_prompt", "") or "").strip()
    user_notes = str(payload.get("user_notes", "") or "").strip()
    scene_notes = str(payload.get("scene_notes", "") or "").strip()
    director_note = str(payload.get("director_note", "") or "").strip()
    story_beat = str(payload.get("story_beat", "") or "").strip()
    lyric_text = str(payload.get("lyric_text", "") or payload.get("lyrics", "") or "").strip()
    lyric_section = str(payload.get("lyric_section", "") or "").strip()
    subject_context = str(payload.get("subject_context", "") or "").strip()
    location_context = str(payload.get("location_context", "") or "").strip()
    no_character_present = bool(payload.get("no_character_present", False))
    reference_context = payload.get("reference_context") or {}
    chain_style = str(payload.get("chain_style", "") or payload.get("continuity_style", "") or "continuous").strip()
    chain_direction = str(payload.get("chain_direction", "") or payload.get("continuity_direction", "") or "").strip()
    transition_lora_prompt = bool(payload.get("transition_lora_prompt") or payload.get("use_transition_lora_prompt") or False)
    transition_lora_trigger = str(payload.get("transition_lora_trigger", "") or "zhuanchang").strip() or "zhuanchang"
    performance_mode = str(payload.get("performance_mode") or payload.get("video_type") or "").strip()
    text_runner = _llm_runner_from_payload(payload)

    if not image_reference_data and not image_reference_path:
        raise ValueError("Chained I2V needs an extracted final-frame image.")
    if not model_file and text_runner not in _EXTERNAL_LLM_RUNNERS:
        raise ValueError("Choose an I2V vision Gemma model first.")
    if model_file and text_runner not in _EXTERNAL_LLM_RUNNERS and not model_file.lower().endswith(".gguf"):
        raise ValueError("The I2V vision model field is not a GGUF model.")

    if image_reference_data:
        image = _image_from_data_url(image_reference_data).convert("RGB")
    else:
        image_path = _resolve_existing_file(image_reference_path, "Chained I2V image reference")
        image = Image.open(image_path).convert("RGB")

    style_note = _chained_i2v_style_note(chain_style, chain_direction)
    reference_subject_context = ""
    reference_location_context = ""
    if isinstance(reference_context, dict):
        reference_subject_context = str(reference_context.get("subject_context", "") or "").strip()
        reference_location_context = str(reference_context.get("location_context", "") or "").strip()
        if not reference_subject_context:
            subject_refs = reference_context.get("subject_refs") or []
            if isinstance(subject_refs, list):
                subject_lines = []
                for subject in subject_refs:
                    if not isinstance(subject, dict):
                        continue
                    name = str(subject.get("name", "") or "").strip()
                    description = str(subject.get("description", "") or "").strip()
                    trigger = str(subject.get("trigger_phrase", "") or "").strip()
                    line = " - ".join(part for part in (name, description, f"trigger: {trigger}" if trigger else "") if part)
                    if line:
                        subject_lines.append(line)
                reference_subject_context = "\n".join(subject_lines)
        if not reference_location_context:
            location_ref = reference_context.get("location_ref")
            if isinstance(location_ref, dict):
                name = str(location_ref.get("name", "") or "").strip()
                description = str(location_ref.get("description", "") or "").strip()
                trigger = str(location_ref.get("trigger_phrase", "") or "").strip()
                reference_location_context = " - ".join(part for part in (name, description, f"trigger: {trigger}" if trigger else "") if part)
    elif reference_context:
        reference_subject_context = str(reference_context).strip()

    subject_context = subject_context or reference_subject_context
    location_context = location_context or reference_location_context
    story_parts = [
        ("Scene concept", scene_context),
        ("Scene notes", scene_notes),
        ("Director note", director_note),
        ("Story beat", story_beat),
        ("Lyric section", lyric_section),
        ("Lyrics/dialogue", lyric_text),
        ("Reference Builder subject", subject_context if not no_character_present else ""),
        ("Reference Builder location", location_context),
    ]
    story_context = "\n".join(f"{label}: {value}" for label, value in story_parts if value)
    no_character_rule = (
        "\n- The next shot is marked as no-character-present. Do not add the mapped subject unless the visible scene already clearly contains them."
        if no_character_present else ""
    )
    transition_lora_rules = ""
    if transition_lora_prompt:
        transition_lora_rules = (
            "\nTransition LoRA prompt style is active.\n"
            f"- Write in a transition-LoRA style: visible starting shot, detailed transformation process, changed ending state, lighting/material/environment details, and strong continuous camera movement.\n"
            "- Make the transformation explicit and temporal with phrases such as gradually, as the camera moves, the clothing shifts into, the environment morphs into, the lighting changes from/to, or the scene reveals.\n"
            "- For a visible character, include a clear outfit/material/hair/silhouette change and a clear environment/location/lighting/style change unless the user direction forbids one of them.\n"
            "- For an environment-only shot, transform the place, weather, architecture, terrain, lighting, or style into a different readable destination.\n"
            "- End the prompt with the transition trigger phrase exactly once.\n"
            f"- Trigger phrase: {transition_lora_trigger}\n"
        )
    i2v_instructions = _effective_builder_instruction(payload, "i2v", _I2V_INSTRUCTIONS)
    instruction = (
        f"{i2v_instructions}\n\n"
        "Write one normal image-to-video prompt for LTX. The video model will receive a visual source separately, "
        "but your output must read like an ordinary video prompt only.\n\n"
        "Rules for the output:\n"
        "- Begin with a concrete description of only what is actually visible: subject, clothing, pose, lighting, camera angle, colors, and setting. Do not invent a different location, outfit, pose, shot angle, or material from the story context in the opening description.\n"
        "- Treat the story, lyrics, subject, and location context as the direction the shot may evolve toward, not as permission to replace the visible starting facts.\n"
        "- Continue with motion and changes that naturally develop from the visible state while moving toward the story context below.\n"
        "- If transformation style is active, the prompt must include visible change: clothing/materials/body silhouette should transform and the surrounding environment or lighting should transform. Avoid a boring continuation where the subject only poses, stares, walks, wind blows, or the camera moves while the outfit and place stay basically the same.\n"
        "- Silently assess the visible shot scale before choosing camera motion. If it is already a close-up or extreme close-up, do not zoom or push farther into the face; use a slow pullback, orbit, pan, rack focus, expression change, environmental motion, or transformation instead. If it is already a wide or distant shot, do not pull farther away; use a push-in toward the subject, orbiting push-in, tracking move, subject action, or environmental change instead. If it is a medium shot, choose motion that changes the composition without repeating what is already true.\n"
        "- Use the story context to make this shot meaningfully different from the last shot when it fits the requested chain style.\n"
        "- Do not mention frames, images, pictures, photos, references, sources, current visuals, provided visuals, previous scenes, or previous videos.\n"
        "- Do not write instructions to the model. Output only the final cinematic prompt paragraph.\n"
        f"- No markdown, labels, quotes, JSON, or bullet points.{no_character_rule}\n"
        f"{transition_lora_rules}\n"
        f"{style_note}\n\n"
        f"Story context for the next shot:\n{story_context or '(none)'}\n\n"
        f"Motion/performance notes:\n{user_notes or 'Create cinematic motion that fits the visible scene.'}\n\n"
        f"Performance mode:\n{performance_mode or 'Use the visible scene and notes. Do not force singing unless the notes call for it.'}"
    )

    llm = _builder_local_llm(payload) if text_runner not in _EXTERNAL_LLM_RUNNERS else None
    model_file = _builder_local_model_file(payload, model_file)
    model_path = llm._resolve_dropdown_path(model_file, llm.MISSING_MODEL_OPTION) if llm else ""
    mmproj_file = _builder_local_mmproj_file(payload, mmproj_file)
    mmproj_path = _resolve_mmproj_dropdown_path(llm, mmproj_file) if llm else ""
    n_ctx = int(payload.get("n_ctx") or 8000)
    n_gpu_layers = int(payload.get("n_gpu_layers") or 99)
    n_threads = int(payload.get("n_threads") or 8)
    chat_format = str(payload.get("chat_format", "") or "").strip()
    temperature = float(payload.get("temperature") or 0.25)
    top_p = float(payload.get("top_p") or 0.9)
    max_new_tokens = _runner_output_token_limit(payload, int(payload.get("max_new_tokens") or 1200))
    unload_after = bool(payload.get("unload_after", True))
    seed = payload.get("seed")

    try:
        model = None
        if text_runner in _EXTERNAL_LLM_RUNNERS:
            text, run_info = _try_run_remote_vision(
                payload,
                instruction,
                [image],
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
            )
        else:
            model = llm._load_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            text = llm._run_gguf_vision_pipeline(
                model=model,
                pil_images=[image],
                instruction_text=instruction,
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
                seed=int(seed) if seed is not None else None,
            )
            run_info = {"runner": "builtin", "used_model": model_path, "unloaded": unload_after}
        text = _clean_gemma_prompt_text(text)
        try:
            text = _repair_and_validate_builder_gemma_prompt(payload, text, "Chained I2V")
        except Exception:
            text = _fallback_chained_i2v_prompt(
                scene_context=scene_context,
                user_notes=user_notes,
                story_context=story_context,
                chain_style=chain_style,
                transition_lora_prompt=transition_lora_prompt,
                transition_lora_trigger=transition_lora_trigger,
            )
        if transition_lora_prompt and transition_lora_trigger:
            text = re.sub(rf"(?:,\s*)?{re.escape(transition_lora_trigger)}\s*$", "", text, flags=re.I).strip().rstrip(".,;")
            text = f"{text}, {transition_lora_trigger}"
        text = _repair_chained_i2v_meta_prompt(
            payload,
            text,
            transition_lora_prompt=transition_lora_prompt,
            transition_lora_trigger=transition_lora_trigger,
        )
        if _looks_like_gemma_repeat_failure(text) or _looks_like_unfilled_prompt_template(text):
            text = _fallback_chained_i2v_prompt(
                scene_context=scene_context,
                user_notes=user_notes,
                story_context=story_context,
                chain_style=chain_style,
                transition_lora_prompt=transition_lora_prompt,
                transition_lora_trigger=transition_lora_trigger,
            )
        meta_language_warning = bool(_chained_i2v_meta_language_error(text))
        return {
            "prompt": text,
            "used_model": run_info.get("used_model", model_path),
            "used_mmproj": mmproj_path,
            "used_image_reference": True,
            "runner": run_info.get("runner", "builtin"),
            "unloaded": run_info.get("unloaded", unload_after),
            "chain_style": chain_style or "continuous",
            "transition_lora_prompt": transition_lora_prompt,
            "transition_lora_trigger": transition_lora_trigger if transition_lora_prompt else "",
            "meta_language_warning": meta_language_warning,
        }
    finally:
        if llm and unload_after:
            llm._unload_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            _clear_vrgdg_llm_caches(clear_cuda_cache=True, clear_hf_pipeline_cache=False)


def _normalize_flf_vision_observation(text):
    """Return canonical START/END lines without discarding paragraph breaks."""
    cleaned = str(text or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    cleaned = re.sub(r"<think>.*?</think>", "", cleaned, flags=re.IGNORECASE | re.DOTALL).strip()
    cleaned = re.sub(r"^```(?:json|text|markdown)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```$", "", cleaned).strip()
    cleaned = re.sub(
        r"^(?:Assistant|Answer|Final answer|Final response|Observation)\s*:\s*",
        "",
        cleaned,
        flags=re.IGNORECASE,
    ).strip()

    descriptions = {}
    try:
        parsed = json.loads(cleaned)
    except Exception:
        parsed = None
    if isinstance(parsed, dict):
        for key, value in parsed.items():
            normalized_key = re.sub(r"[^a-z]", "", str(key or "").lower())
            if normalized_key.startswith("start") and str(value or "").strip():
                descriptions.setdefault("START", str(value).strip())
            elif normalized_key.startswith("end") and str(value or "").strip():
                descriptions.setdefault("END", str(value).strip())

    if len(descriptions) < 2:
        label_pattern = re.compile(
            r"(?im)^[ \t]*(?:[-+]\s+|\d+[.)]\s+|#{1,6}[ \t]+)?"
            r"[*_]{0,2}[ \t]*(START|END)\b"
            r"(?:[ \t]+(?:FRAME|IMAGE|DESCRIPTION|OBSERVATION|STATE))?"
            r"[ \t]*(?::|-)?[ \t]*[*_]{0,2}[ \t]*(?::|-)?[ \t]*"
        )
        matches = list(label_pattern.finditer(cleaned))
        for index, match in enumerate(matches):
            label = match.group(1).upper()
            end = matches[index + 1].start() if index + 1 < len(matches) else len(cleaned)
            body = re.sub(r"\s+", " ", cleaned[match.end():end]).strip(" \t\n-*_:;")
            if body:
                descriptions.setdefault(label, body)

    missing = [label for label in ("START", "END") if not descriptions.get(label)]
    normalized = "\n".join(
        f"{label}: {descriptions[label]}"
        for label in ("START", "END")
        if descriptions.get(label)
    )
    return normalized, missing


def _generate_builder_t2v_prompt(payload):
    from .LLM import VRGDG_SuperGemmaGGUFChat, _clear_vrgdg_llm_caches

    model_file = str(payload.get("model_file", "") or "").strip()
    mmproj_file = str(payload.get("mmproj_file", "") or "").strip()
    scene_prompt = str(payload.get("t2i_prompt", "") or payload.get("scene_prompt", "") or "").strip()
    image_reference_path = str(payload.get("image_reference_path", "") or "").strip().strip('"')
    image_reference_data = str(payload.get("image_reference_data", "") or "").strip()
    user_notes = str(payload.get("user_notes", "") or "").strip()
    lyric_cue_map = payload.get("lyric_cue_map")
    if isinstance(lyric_cue_map, list) and lyric_cue_map:
        # Keep the assignment in the actual LLM text context as well as in
        # the request metadata. This makes the singer/shot handoff auditable
        # and prevents generic scene context from replacing explicit cue rows.
        cue_lines = []
        for index, cue in enumerate(lyric_cue_map, start=1):
            if not isinstance(cue, dict):
                continue
            cue_type = "instrumental" if str(cue.get("type") or "").strip().lower() == "instrumental" else "vocal"
            singer = str(cue.get("singer_name") or cue.get("speaker_name") or "the assigned singer").strip()
            text = str(cue.get("text") or "").strip()
            start = cue.get("start")
            end = cue.get("end")
            timing = ""
            if start is not None and end is not None:
                timing = f" [{start}s-{end}s]"
            if cue_type == "instrumental":
                cue_lines.append(f"Cue {index}{timing}: INSTRUMENTAL — no subject sings, speaks, or lip-syncs.")
            else:
                cue_lines.append(f"Cue {index}{timing}: {singer} is the only singer for the exact words: {text!r}.")
        if cue_lines:
            user_notes = "\n\n".join(filter(None, [user_notes, "AUTHORITATIVE SINGER CUE MAP — follow exactly:\n" + "\n".join(cue_lines)]))
    subject_context = str(payload.get("subject_context", "") or "").strip()
    location_context = str(payload.get("location_context", "") or "").strip()
    no_character_present = bool(payload.get("no_character_present") or payload.get("no_subject") or payload.get("no_visible_subject"))
    instruction_key = _safe_builder_instruction_key(payload.get("builder_instruction_key") or payload.get("instruction_key") or "t2v")
    is_minimax_h3_prompt = instruction_key.startswith("minimax_h3_")
    is_minimax_h3_shot_json_task = is_minimax_h3_prompt and scene_prompt.lstrip().startswith("MiniMax H3 shot-description task.")
    prompt_only_scene_inspiration = bool(payload.get("prompt_only_scene_inspiration"))
    frame_continuity_prompt = bool(payload.get("frame_continuity_prompt")) or instruction_key == "minimax_h3_frame_continuity"
    text_runner = _llm_runner_from_payload(payload)
    if not model_file and text_runner not in _EXTERNAL_LLM_RUNNERS:
        raise ValueError("Choose a T2V Gemma model first.")
    if model_file and text_runner not in _EXTERNAL_LLM_RUNNERS and not model_file.lower().endswith(".gguf"):
        raise ValueError("The T2V model field is not a GGUF model.")
    vision_images = []
    has_image_reference = False
    image_references = payload.get("image_references") or []
    if isinstance(image_references, str):
        try:
            image_references = json.loads(image_references)
        except Exception:
            image_references = [{"path": line.strip()} for line in image_references.splitlines() if line.strip()]
    if isinstance(image_references, list):
        reference_limit = 10 if is_minimax_h3_prompt and (prompt_only_scene_inspiration or frame_continuity_prompt) else 9 if is_minimax_h3_prompt else 4
        for index, item in enumerate(image_references[:reference_limit], start=1):
            if isinstance(item, str):
                item = {"path": item}
            if not isinstance(item, dict):
                continue
            try:
                vision_images.append(_image_from_prompt_payload(item.get("path", ""), item.get("data", ""), f"T2V Gemma image reference {index}").convert("RGB"))
            except Exception as exc:
                raise ValueError(f"Could not load T2V Gemma image reference {index}: {exc}") from exc
    if not vision_images:
        if image_reference_data:
            vision_images.append(_image_from_data_url(image_reference_data).convert("RGB"))
        elif image_reference_path:
            image_path = _resolve_existing_file(image_reference_path, "T2V Gemma image reference")
            vision_images.append(Image.open(image_path).convert("RGB"))
    first_last_frame_mode = bool(payload.get("first_last_frame_mode") or payload.get("firstLastFrameMode"))
    transition_lora_active = bool(payload.get("transition_lora_active") or payload.get("transitionLoraActive"))
    flf_context_mode = str(payload.get("flf_context_mode") or "images_story").strip().lower()
    if flf_context_mode not in {"images_only", "images_story", "full"}:
        flf_context_mode = "images_story"
    flf_start_state = str(payload.get("flf_start_state") or "").strip()[:1800]
    flf_transformation = str(payload.get("flf_transformation") or "").strip()[:2400]
    flf_end_state = str(payload.get("flf_end_state") or "").strip()[:1800]
    flf_carry_forward = str(payload.get("flf_carry_forward") or "").strip()[:1800]
    if first_last_frame_mode and len(vision_images) < 2:
        raise ValueError(
            "First Last Frame Gemma requires two resolved image references, "
            f"but the backend received {len(vision_images)}. Reassign the scene's start and end images and try again."
        )
    if first_last_frame_mode and len(vision_images) >= 2:
        first_image, last_image = vision_images[0], vision_images[1]
        total_width = max(1, first_image.width + last_image.width)
        if total_width > 1920:
            scale = 1920.0 / total_width
            resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC)
            first_image = first_image.resize((max(1, int(round(first_image.width * scale))), max(1, int(round(first_image.height * scale)))), resample)
            last_image = last_image.resize((max(1, int(round(last_image.width * scale))), max(1, int(round(last_image.height * scale)))), resample)
        if first_image.width + last_image.width > 1920:
            last_image = last_image.crop((0, 0, max(1, 1920 - first_image.width), last_image.height))
        canvas_width = first_image.width + last_image.width
        canvas_height = max(first_image.height, last_image.height)
        combined = Image.new("RGB", (canvas_width, canvas_height), (0, 0, 0))
        combined.paste(first_image, (0, (canvas_height - first_image.height) // 2))
        combined.paste(last_image, (first_image.width, (canvas_height - last_image.height) // 2))
        vision_images = [combined]
    has_image_reference = bool(vision_images)
    if has_image_reference and text_runner not in _EXTERNAL_LLM_RUNNERS and not model_file:
        raise ValueError("Choose a T2V vision Gemma model first.")
    if has_image_reference:
        max_height = 512
        resized_images = []
        for image in vision_images:
            if image.height > max_height:
                resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC)
                width = max(1, int(image.width * (max_height / max(1, image.height))))
                image = image.resize((width, max_height), resample)
            resized_images.append(image)
        vision_images = resized_images

    theme_style = _read_text_file(payload.get("theme_style_path", ""), "Theme/style file")
    story_idea = _read_text_file(payload.get("story_idea_path", ""), "Story idea file")
    subject_scene = _read_text_file(payload.get("subject_scene_path", ""), "Subject/scene file")
    context_parts = []
    if no_character_present:
        context_parts.append("Subject visibility:\nNo main character, singer, performer, person, mapped subject, or character reference is present in this scene. Use location, props, objects, atmosphere, and camera motion instead.")
    elif subject_scene:
        context_parts.append(f"Subject/scene:\n{subject_scene}")
    if subject_context and not no_character_present:
        context_parts.append(f"Mapped scene character(s):\n{subject_context}")
    if location_context:
        context_parts.append(f"Mapped scene location:\n{location_context}")
    if theme_style:
        context_parts.append(f"Theme/style:\n{theme_style}")
    if story_idea:
        context_parts.append(f"Story idea:\n{story_idea}")
    if context_parts:
        user_notes = "\n\n".join(context_parts + ([f"Segment motion notes:\n{user_notes}"] if user_notes else []))
    if not scene_prompt:
        if user_notes or subject_context or location_context or theme_style or story_idea or subject_scene or no_character_present:
            scene_prompt = "Use the available scene notes, mapped references, lyrics/performance context, location details, and motion notes as the scene concept."
        else:
            raise ValueError("Create or paste scene notes, mapped references, motion notes, or a T2I/concept prompt first.")

    t2v_instructions = _effective_builder_instruction(payload, instruction_key, _T2V_INSTRUCTIONS)
    prompt_label = (
        _BUILDER_INSTRUCTION_LABELS.get(instruction_key, "MiniMax H3")
        if is_minimax_h3_prompt
        else "ID-LoRA I2V" if instruction_key == "id_lora"
        else "Reference to Video" if instruction_key == "rtv"
        else "T2V"
    )
    if has_image_reference and first_last_frame_mode:
        # Generic I2V instructions describe a single first-frame reference and
        # can conflict with FLF endpoint framing (for example, demanding that a
        # face remain visible). FLF uses its dedicated contract below instead.
        t2v_instructions = (
            "Write only one polished First Last Frame video prompt paragraph. "
            "Use the locked START and END facts, scene performance context, and transition direction exactly. "
            "Do not output analysis, labels, headings, or hidden reasoning."
        )
        transition_trigger_guidance = (
            "- The LTX 2.3 transition LoRA is active. End the final prompt with the trigger word 'zhuanchang' exactly once, and do not place it anywhere else.\n"
            if transition_lora_active
            else "- No transition LoRA is active. Do not include the trigger word 'zhuanchang'.\n"
        )
        image_guidance = (
            "First Last Frame guidance:\n"
            "- You receive one side-by-side image: the LEFT half is the opening visual state and the RIGHT half is the ending visual state.\n"
            "- Use both halves as the absolute visual truth for subject identity, wardrobe, setting, lighting, composition, body pose, subject position, camera endpoint, visible objects, and visible creatures. Lyrics, storyboard beats, transformation notes, and user text may explain how to travel between the endpoints, but they must never override, omit, or contradict what is visibly present in either half.\n"
            "- The final paragraph must explicitly account for every major endpoint difference: standing/sitting/lying posture, front/back/profile orientation, hand placement, subject location in frame, wardrobe state, foreground/background objects, creature type and color, and camera distance/crop. Do not substitute a related object or creature (for example moths for butterflies, birds for moths, or skin for a mirror) unless that exact change is visibly supported by the endpoints.\n"
            "- Write ONE compact, flowing paragraph in this exact motion structure; do not use headings, bullets, timestamps, numbered phases, or separate staged blocks.\n"
            "- Sentence 1 establishes the actual LEFT composition, subject, setting, and starting condition without inventing a wider establishing shot.\n"
            "- Sentence 2 begins with an explicit natural physical action by the subject (for example shoulders lift, the body rises, the head turns, or the subject steps/moves as supported by the endpoints) and joins all material/anatomical changes into ONE continuous progressive transformation. Do not merely change textures on a motionless subject. Describe a few precise visible changes with coordinated verbs such as softens, closes, separates, lengthens, opens, or forms. Do not schedule them as disconnected events.\n"
            "- Sentence 3 starts a continuous camera move at the same time as the transformation and follows it toward the exact RIGHT crop. Keep that camera motion active throughout instead of delaying it until late in the clip.\n"
            "- Sentence 4 describes the most distinctive RIGHT destination anatomy, object, material, color, pose, and focal detail forming gradually and coherently. Never replace an unusual endpoint with generic wording such as 'fleshy anatomy,' 'human visage,' or 'living form.'\n"
            "- Sentence 5 anchors shared environmental motion and explicitly keeps the setting, lighting, and spatial layout consistent.\n"
            "- Sentence 6 states that the transformation completes as the camera settles on the exact RIGHT destination, preserving continuous movement and coherent anatomy/structure throughout.\n"
            "- Both subject motion and camera travel begin immediately and proceed continuously. Do not hold one endpoint, introduce a second figure, overlay both compositions, or wait until the middle of the clip to reframe.\n"
            "- Never move, collapse, or recede facial features into another body region. Preserve coherent identity and anatomy while the camera moves away from any region excluded by the END crop.\n"
            "- When framing or camera angle differs, derive the camera direction strictly from the relative location of the RIGHT endpoint crop, then describe a precise continuous trajectory using direction and distance. If the LEFT shows a face and the RIGHT is centered lower on the neck, chest, shoulders, torso, or legs, the camera must tilt/pan DOWNWARD and must never say upward. If the RIGHT endpoint is physically above the LEFT focal region, only then may it say upward. The camera must end at the exact crop and focal region shown on the right. Explicitly name what remains visible at that endpoint and do not claim the face or full subject remains visible when the ending crop excludes it.\n"
            "- Preserve environmental elements that remain shared between the endpoints so the background does not reset unnecessarily.\n"
            "- Describe every change as progressive physical formation rather than a fade, crossfade, cut, overlay, double exposure, collage, split screen, or abrupt replacement.\n"
            "- Let the images decide the camera/character endpoints. Use motion/camera notes and speed/pacing guidance only to decide how quickly, smoothly, forcefully, or emotionally the subject and camera travel between those endpoints.\n"
            + transition_trigger_guidance
            +
            "- Do not include an aspect ratio, resolution, widescreen label, or phrases such as 'cinematic 16:9' in the final prompt. Width and height are controlled by the workflow settings.\n"
            "- Before answering, silently check that every camera-direction word moves toward the RIGHT crop and that no sentence contradicts the endpoint. Correct any upward/downward, closer/wider, or visible/out-of-frame contradiction.\n"
            "- Preserve any supplied singing, lyric, dialogue, emotional-performance, and selected facial-performance direction; integrate it naturally without disrupting the continuous visual motion.\n"
            "- Preserve the normal one-paragraph video prompt structure from the instructions. Do not mention images, frames, references, inputs, MSR, or LoRA in the final prompt.\n\n"
        )
        if flf_context_mode == "full" and any((flf_start_state, flf_transformation, flf_end_state, flf_carry_forward)):
            image_guidance += (
                "Storyboard FLF motion contract:\n"
                f"- Opening state: {flf_start_state or '[derive exactly from the LEFT image]'}\n"
                f"- Required continuous transformation: {flf_transformation or '[derive one continuous physical transition from both images]'}\n"
                f"- Required destination state: {flf_end_state or '[derive exactly from the RIGHT image]'}\n"
                f"- Carry-forward continuity: {flf_carry_forward or '[preserve all shared continuity]'}\n"
                "- The images remain the visual truth. The storyboard transformation is the primary motion plan and must be expressed as progressive physical action rather than replaced by generic morph language.\n"
                "- Begin the planned action and camera travel immediately, keep them continuous, and finish at the exact RIGHT destination.\n"
                "- Preserve all supplied singing, lyric, emotional-performance, and selected facial-performance directions while carrying out this transformation.\n"
                "- Do not output these labels or quote this contract in the final paragraph.\n\n"
            )
        elif flf_context_mode == "images_only":
            image_guidance += (
                "Gemma context mode: IMAGES ONLY.\n"
                "- Design the visual transition only from the locked LEFT and RIGHT observations.\n"
                "- Ignore lyrics, story arc, storyboard endpoint prose, mapped descriptions, scene notes, and camera presets when deciding visible action or camera travel.\n"
                "- The application adds any required exact vocal line and facial-performance direction after this visual prompt is returned.\n\n"
            )
        elif flf_context_mode == "images_story":
            image_guidance += (
                "Gemma context mode: IMAGES + STORY BEAT.\n"
                "- Use the locked LEFT and RIGHT observations as absolute endpoint truth.\n"
                "- Use only the supplied short scene story beat to choose a meaningful continuous bridge. Discard any beat detail that conflicts with either image.\n"
                "- Ignore lyrics, story arc, mapped descriptions, detailed endpoint prose, other scene notes, and camera presets when deciding visible action or camera travel.\n"
                "- The application adds any required exact vocal line and facial-performance direction after this visual prompt is returned.\n\n"
            )
    elif has_image_reference and frame_continuity_prompt:
        image_guidance = (
            "Vision attachment mapping:\n"
            "- Picture 1 is the previous render's final frame and the authoritative opening state. It is prompt-writing input, not a renderer Image N label.\n"
            "- Later pictures are the supporting inputs documented by the resolved Scene concept and cannot replace Picture 1's opening state.\n\n"
        )
    elif has_image_reference and is_minimax_h3_shot_json_task:
        image_guidance = (
            "MiniMax H3 JSON-shot visual-reference guidance:\n"
            "- Inspect the attached pictures only according to the exact assignments and limits in the Scene concept.\n"
            "- Use permitted visual facts inside the creative shot descriptions, but do not define pictures, subjects, audio, retention, continuity, or final prompt sections.\n"
            "- Return only the requested valid JSON object.\n\n"
        )
    elif has_image_reference and is_minimax_h3_prompt:
        image_guidance = (
            "MiniMax H3 prompt-only scene-inspiration guidance:\n"
            "- Attached <Picture 1> is vision input for prompt writing only. It is never supplied to the MiniMax renderer and must never appear as Image 1 or any Image N in the finished prompt.\n"
            "- Follow the scene context's exact environment-only or environment-plus-framing extraction limits for <Picture 1>. Always ignore all character identity, appearance, clothing, body, pose, placement, and activity visible in it.\n"
            "- Attached <Picture 2> corresponds to renderer Image 1, <Picture 3> to renderer Image 2, and so on. Inspect each renderer picture only for its assigned purpose.\n"
            "- In the finished prompt, use only renderer Image N labels. Convert permitted observations from <Picture 1> into direct scene prose without mentioning pictures, inspiration, analysis, or source imagery.\n"
            "- Do not merge a storyboard grid into a collage output; interpret its panels as ordered visual guidance.\n\n"
            if prompt_only_scene_inspiration
            else
            "MiniMax H3 ordered visual-reference guidance:\n"
            "- The attached pictures are in the exact <Picture 1>, <Picture 2>, and subsequent order stated in the scene context.\n"
            "- Inspect every attached picture and use it only for the purpose assigned to its matching tag.\n"
            "- Keep the exact <Picture N> tags in the final MiniMax prompt wherever the mode instructions require them.\n"
            "- Do not merge a storyboard grid into a collage output; interpret its panels as ordered visual guidance.\n\n"
        )
    elif has_image_reference and instruction_key == "id_lora":
        image_guidance = (
            "Use the provided image as the primary visual truth for the [VISUAL] section. "
            "Describe the visible subject, framing, setting, clothing/style, mood, and camera-ready action from the image, then adapt motion to the scene notes. "
            "Do not say 'reference image' in the final script.\n\n"
        )
    else:
        image_guidance = (
            "Use the provided reference image only to guide pose, framing, composition, mood, visible styling, or other user-requested visual details. "
            "Do not describe it as a reference image in the final prompt.\n\n"
            if has_image_reference else ""
        )
    prompt = (
        f"{t2v_instructions}\n\n"
        f"{image_guidance}"
        f"Scene concept:\n{scene_prompt}\n\n"
        f"User motion/camera notes:\n{user_notes or 'Create cinematic camera movement and natural subject/environment motion that fits the scene.'}"
    )

    llm_request_audit_path = ""
    llm_request_audit = None
    if is_minimax_h3_prompt:
        project_folder = os.path.abspath(str(payload.get("project_folder") or "").strip().strip('"')) if payload.get("project_folder") else ""
        if project_folder and os.path.isdir(project_folder):
            scene_id = _safe_project_name(str(payload.get("scene_id") or "scene"))
            audit_folder = os.path.join(project_folder, "llm_request_audits")
            llm_request_audit_path = os.path.join(audit_folder, f"last_minimax_h3_{scene_id}.json")
            llm_request_audit = {
                "saved_at": time.time(),
                "scene_id": str(payload.get("scene_id") or ""),
                "instruction_key": instruction_key,
                "performance_mode": str(payload.get("performance_mode") or ""),
                "audio_mode": str(payload.get("audio_mode") or ""),
                "singers": payload.get("singers") or [],
                "lyric_text": str(payload.get("lyric_text") or ""),
                "lyric_cue_map": payload.get("lyric_cue_map") or [],
                "performer_assignment": payload.get("performer_assignment") or {},
                "scene_concept": scene_prompt,
                "user_notes": user_notes,
                "actual_llm_instruction": prompt,
            }
            _atomic_write_json(llm_request_audit_path, llm_request_audit)

    llm = _builder_local_llm(payload) if has_image_reference and text_runner not in _EXTERNAL_LLM_RUNNERS else None
    model_file = _builder_local_model_file(payload, model_file)
    model_path = llm._resolve_dropdown_path(model_file, llm.MISSING_MODEL_OPTION) if llm else ""
    mmproj_path = _resolve_mmproj_dropdown_path(llm, mmproj_file) if llm else ""
    n_ctx = int(payload.get("n_ctx") or 8000)
    n_gpu_layers = int(payload.get("n_gpu_layers") or 99)
    n_threads = int(payload.get("n_threads") or 8)
    chat_format = str(payload.get("chat_format", "") or "").strip()
    temperature = float(payload.get("temperature") or 0.7)
    top_p = float(payload.get("top_p") or 0.95)
    max_new_tokens = _runner_output_token_limit(payload, int(payload.get("max_new_tokens") or 4000))
    unload_after = bool(payload.get("unload_after", True))

    try:
        model = None
        if has_image_reference and text_runner not in _EXTERNAL_LLM_RUNNERS:
            model = llm._load_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )

        def run_vision_instruction(instruction_text, token_limit):
            if text_runner in _EXTERNAL_LLM_RUNNERS:
                vision_payload = dict(payload)
                vision_payload["max_new_tokens"] = int(token_limit)
                return _try_run_remote_vision(
                    vision_payload,
                    instruction_text,
                    vision_images,
                    temperature=temperature,
                    top_p=top_p,
                    max_new_tokens=int(token_limit),
                )
            result_text = llm._run_gguf_vision_pipeline(
                model=model,
                pil_images=vision_images,
                instruction_text=instruction_text,
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=int(token_limit),
            )
            return result_text, {"runner": "builtin", "used_model": model_path, "unloaded": unload_after}

        if has_image_reference:
            if first_last_frame_mode:
                observation_prompt = (
                    "Inspect the side-by-side visual carefully. The LEFT half is START and the RIGHT half is END. "
                    "Do visual observation only; do not write a video prompt, story, transition, or camera direction. "
                    "Return exactly two dense labeled lines. Each line must literally inventory: subject identity; full-body posture (standing, sitting, kneeling, lying, leaning); front/back/profile orientation; head, torso, arm, and hand placement; location and scale within the frame; clothing and hair; all major props and surfaces; setting; lighting; exact crop; and every visible creature/object with its type and dominant color. "
                    "START: state all visible opening facts. END: state all visible destination facts and every major difference from START, including where the subject moved and which opening objects disappeared or remained. "
                    "Prioritize unusual anatomy, openings, cavities, translucent structures, distinctive materials, and which body regions are out of frame when present. "
                    "Do not merge the two halves, infer a story, rename one creature as another, or describe what ought to be present. State only what is visibly present."
                )
                locked_observation, _ = run_vision_instruction(observation_prompt, 900)
                locked_observation, missing_observations = _normalize_flf_vision_observation(locked_observation)
                if missing_observations:
                    retry_observation_prompt = (
                        observation_prompt
                        + "\n\nYour prior response did not provide two readable endpoint descriptions. Try again. "
                        "You MUST output both labeled lines, START: and END:. "
                        "Do not stop after START. Keep each line compact enough to fit."
                    )
                    locked_observation, _ = run_vision_instruction(retry_observation_prompt, 1200)
                    locked_observation, missing_observations = _normalize_flf_vision_observation(locked_observation)
                if missing_observations:
                    raise ValueError(
                        "FLF Gemma vision observation was incomplete after retry. "
                        "Missing readable description(s): "
                        + ", ".join(missing_observations)
                        + ". Both START and END descriptions are required."
                    )
                prompt += (
                    "\n\nLOCKED VISUAL OBSERVATION FROM THE REQUIRED FIRST PASS:\n"
                    f"{locked_observation}\n\n"
                    "Use these locked facts as literal visual truth. The final prompt must reach every distinctive END fact without replacing it with generic wording."
                    " If any lyric, storyboard transformation, motion note, or scene concept conflicts with the locked facts, discard the conflicting detail and write a continuous physical bridge that reaches the visible END instead."
                )
            text, run_info = run_vision_instruction(prompt, max_new_tokens)
        else:
            text, run_info = _run_builder_text_llm(
                payload,
                prompt,
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
                label=f"{prompt_label} Gemma",
                preserve_paragraphs=is_minimax_h3_prompt,
            )
        if llm_request_audit is not None:
            llm_request_audit["raw_llm_response"] = str(text or "")
            _atomic_write_json(llm_request_audit_path, llm_request_audit)
        text = _clean_lm_studio_plain_text(text) if is_minimax_h3_prompt else _clean_gemma_prompt_text(text)
        if is_minimax_h3_prompt and not is_minimax_h3_shot_json_task:
            text = _format_minimax_h3_prompt(text, payload, instruction_key)
        if first_last_frame_mode:
            text = re.sub(r"(?i)\b(?:cinematic\s+)?(?:aspect\s+ratio\s*[:=]?\s*)?(?:16\s*:\s*9|9\s*:\s*16|21\s*:\s*9|4\s*:\s*3|3\s*:\s*4|1\s*:\s*1)(?:\s+(?:aspect\s+ratio|widescreen|portrait|landscape))?\b[,]?\s*", "", text)
            text = re.sub(r"(?i)\b(?:widescreen|portrait|landscape)\s+aspect\s+ratio\b[,]?\s*", "", text)
            text = re.sub(r"(?i)\b(?:fades?|dissolves?|crossfades?|blends?)\s+(?:smoothly\s+|seamlessly\s+|gradually\s+)?into\b", "progressively transforms into", text)
            text = re.sub(r"(?i),?\s*(?:while\s+)?maintaining (?:her|his|their|the subject(?:'s)?) visibility throughout(?: the transformation)?", "", text)
            text = re.sub(r"\s{2,}", " ", text).strip(" ,")
        if is_minimax_h3_prompt:
            if not text:
                raise ValueError(f"{prompt_label} LLM returned an empty prompt.")
        else:
            text = _repair_and_validate_builder_gemma_prompt(payload, text, prompt_label)
        if first_last_frame_mode:
            text = re.sub(r"(?i)(?:\s*[,.;:-]?\s*)\bzhuanchang\b", "", text).strip(" ,.;:-")
            if transition_lora_active:
                text = f"{text}. zhuanchang"
        return {
            "prompt": text,
            "used_model": run_info.get("used_model", model_path if has_image_reference else ""),
            "used_mmproj": mmproj_path,
            "runner": run_info.get("runner", "builtin"),
            "used_image_reference": has_image_reference,
            "unloaded": run_info.get("unloaded", unload_after),
            "llm_request_audit_path": llm_request_audit_path,
        }
    finally:
        if llm and has_image_reference and unload_after:
            llm._unload_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            _clear_vrgdg_llm_caches(clear_cuda_cache=True, clear_hf_pipeline_cache=False)


def _video_prompt_enhancement_instructions(payload):
    mode_label = str(payload.get("mode_label") or "I2V").strip().upper()
    draft_prompt = str(payload.get("draft_prompt") or "").strip()
    scene_prompt = str(payload.get("t2i_prompt") or payload.get("scene_prompt") or "").strip()
    user_notes = str(payload.get("user_notes") or "").strip()
    lyric_text = str(payload.get("lyric_text") or "").strip()
    performance_mode = str(
        payload.get("performance_mode")
        or payload.get("performanceMode")
        or payload.get("video_type")
        or payload.get("videoType")
        or ""
    ).strip().lower().replace("-", "_").replace(" ", "_")
    if performance_mode in {"speaking", "short_film", "dialogue", "dialog"}:
        performance_mode = "speaking"
    elif performance_mode in {"no_lip_sync", "nolipsync", "no_lipsync", "no_sync", "silent", "visual_only"}:
        performance_mode = "no_lip_sync"
    else:
        performance_mode = "singing"
    singers_raw = payload.get("singers") or []
    if isinstance(singers_raw, str):
        singers = [item.strip() for item in singers_raw.split(",") if item.strip()]
    elif isinstance(singers_raw, list):
        singers = [str(item or "").strip() for item in singers_raw if str(item or "").strip()]
    else:
        singers = []
    no_vocal = bool(payload.get("no_vocal") or payload.get("instrumental") or payload.get("broll") or performance_mode == "no_lip_sync")
    no_character_present = bool(payload.get("no_character_present") or payload.get("no_subject") or payload.get("no_visible_subject"))
    has_multiple_singers = len(singers) > 1
    has_one_singer = len(singers) == 1
    singer_text = ", ".join(singers)

    if no_character_present:
        template = (
            "Use this final prompt shape:\n"
            "The [main visual focus: location, prop, object, environment, architecture, weather, light, or atmosphere] in [location/environment] during [time/weather/lighting]. "
            "[Main visual focus] [clear visible action or environmental motion]. [Objects, props, fabric, water, plants, particles, or lighting] move naturally if visible. "
            "The camera [camera motion] while keeping the location or main object clearly framed and visible. "
            "The environment [visible motion/reaction].\n\n"
            "No-character rule: do not include, mention, imply, show, or describe any main character, singer, performer, person, mapped subject, or character reference in the final prompt."
        )
    elif no_vocal:
        template = (
            "Use this final prompt shape:\n"
            "The [subject or main visual focus] in [location/environment] during [time/weather/lighting]. "
            "[Subject or main visual focus] [visible action only]. [Clothing, hair, objects, or props] move naturally if visible. "
            "The camera [camera motion] while keeping the main visual focus clearly framed and visible. "
            "The environment [visible motion/reaction].\n\n"
            "Visual-only rule: do not quote or mention the lyric line. Do not mention singing, speaking, saying, dialogue, lip-syncing, vocals, lyric, mouth movement, instrumental status, or no-vocal status in the final prompt."
        )
    elif performance_mode == "speaking" and has_multiple_singers:
        template = (
            "Use this final prompt shape:\n"
            f"The [speakers: {singer_text}] in [location/environment] during [time/weather/lighting]. "
            f"[Speakers] say the dialogue line \"{lyric_text}\" with expressive facial emotion, intentional gestures, and natural body movement. "
            "[Clothing/hair] moves naturally with their body motion. "
            "The camera [camera motion] while keeping all speakers clearly framed and visible. "
            "The environment [visible motion/reaction].\n\n"
            "Speaking-mode rule: use says/say wording only. Do not use singing, rapping, vocals, lyric, lip-sync, or music-performance wording."
        )
    elif performance_mode == "speaking" and has_one_singer:
        template = (
            "Use this final prompt shape:\n"
            f"The [speaker: {singer_text}] in [location/environment] during [time/weather/lighting]. "
            f"[Speaker] says the dialogue line \"{lyric_text}\" with expressive facial emotion, intentional gestures, and natural body movement. "
            "[Clothing/hair] moves naturally with their body motion. "
            "The camera [camera motion] while keeping the speaker clearly framed and visible. "
            "The environment [visible motion/reaction].\n\n"
            "Speaking-mode rule: use says wording only. Do not use singing, rapping, vocals, lyric, lip-sync, or music-performance wording."
        )
    elif performance_mode == "speaking" and lyric_text:
        template = (
            "Use this final prompt shape:\n"
            "The [visible speaker] in [location/environment] during [time/weather/lighting]. "
            f"The visible speaker says the dialogue line \"{lyric_text}\" with expressive facial emotion, intentional gestures, and natural body movement. "
            "[Clothing/hair] moves naturally with their body motion. "
            "The camera [camera motion] while keeping the speaker clearly framed and visible. "
            "The environment [visible motion/reaction].\n\n"
            "Speaking-mode rule: use says wording only. Do not use singing, rapping, vocals, lyric, lip-sync, or music-performance wording."
        )
    elif has_multiple_singers:
        template = (
            "Use this final prompt shape:\n"
            f"The [subjects: {singer_text}] in [location/environment] during [time/weather/lighting]. "
            f"[Subjects] are singing with passion, clearly moving their mouths in sync with the lyric \"{lyric_text}\", "
            "with expressive facial emotion, head movement, and strong visible performance gestures. "
            "[Clothing/hair] moves naturally with their body motion. "
            "The camera [camera motion] while keeping all singers clearly framed and visible. "
            "The environment [visible motion/reaction]."
        )
    elif has_one_singer:
        template = (
            "Use this final prompt shape:\n"
            f"The [subject: {singer_text}] in [location/environment] during [time/weather/lighting]. "
            f"[Subject] is singing with passion, clearly moving their mouth in sync with the lyric \"{lyric_text}\", "
            "with expressive facial emotion, head movement, and strong visible performance gestures. "
            "[Clothing/hair] moves naturally with their body motion. "
            "The camera [camera motion] while keeping the subject clearly framed and visible. "
            "The environment [visible motion/reaction]."
        )
    elif lyric_text:
        template = (
            "Use this final prompt shape:\n"
            f"The [visible subject] in [location/environment] during [time/weather/lighting]. "
            f"The visible subject is singing with passion, clearly moving their mouth in sync with the lyric \"{lyric_text}\", "
            "with expressive facial emotion, head movement, and strong visible performance gestures. "
            "[Clothing/hair] moves naturally with their body motion. "
            "The camera [camera motion] while keeping the subject clearly framed and visible. "
            "The environment [visible motion/reaction]."
        )
    else:
        template = (
            "Use this final prompt shape:\n"
            "The [subject or main visual focus] in [location/environment] during [time/weather/lighting]. "
            "[Subject or main visual focus] [clear visible action]. [Clothing, hair, objects, or props] move naturally if visible. "
            "The camera [camera motion] while keeping the main visual focus clearly framed and visible. "
            "The environment [visible motion/reaction]."
        )

    return (
        f"Rewrite this draft {mode_label} video prompt into one stronger LTX-ready paragraph.\n\n"
        "Use the requested sentence shape, but replace every bracketed phrase with concrete details. Never output brackets or placeholder words.\n"
        "Preserve the subject, location, outfit, scene identity, and any user-requested camera/motion notes from the inputs.\n"
        "If the no-character rule is present, ignore any subject/character/singer from the draft and preserve only location, props, objects, atmosphere, and camera/motion notes.\n"
        "Only describe visible physical actions or visible scene motion. Do not mention invisible sensations, internal thoughts, symbolism, breath, heartbeat, sound-only details, or audio instructions.\n"
        "Do not use the word lip-sync. Use singing language only in singing mode. Use saying/dialogue language only in speaking mode. Use neither in no-lip-sync mode.\n"
        "Do not add microphones unless they are visible or explicitly requested.\n"
        "Do not add captions, text overlays, dialogue explanations, unrelated characters, new locations, markdown, labels, or explanations.\n"
        "Output one polished paragraph only.\n\n"
        f"{template}\n\n"
        f"Video Type / performance mode:\n{performance_mode}\n\n"
        f"Draft prompt:\n{draft_prompt}\n\n"
        f"Scene/T2I context:\n{scene_prompt or '(none)'}\n\n"
        f"User/video notes:\n{user_notes or '(none)'}\n\n"
        f"Lyric text:\n{lyric_text or '(none)'}\n\n"
        f"Singer(s):\n{singer_text or '(none)'}"
    )


def _enhance_builder_video_prompt(payload):
    draft_prompt = str(payload.get("draft_prompt") or "").strip()
    if not draft_prompt:
        raise ValueError("Draft video prompt is empty.")
    model_file = str(payload.get("model_file") or payload.get("repair_model_file") or "").strip()
    if model_file:
        payload = dict(payload)
        payload["model_file"] = model_file
    instruction = _video_prompt_enhancement_instructions(payload)
    text, run_info = _run_builder_text_llm(
        payload,
        instruction,
        temperature=float(payload.get("enhance_temperature") or 0.25),
        top_p=float(payload.get("enhance_top_p") or 0.9),
        max_new_tokens=int(payload.get("enhance_max_new_tokens") or 1200),
        label="I2V prompt enhancement",
    )
    text = _clean_gemma_prompt_text(text)
    text = _repair_and_validate_builder_gemma_prompt(payload, text, str(payload.get("mode_label") or "I2V"))
    return {
        "prompt": text,
        "runner": run_info.get("runner", "builtin"),
        "used_model": run_info.get("used_model", ""),
        "unloaded": run_info.get("unloaded", bool(payload.get("unload_after", True))),
    }


def _video_prompt_edit_instructions(payload):
    current_prompt = str(payload.get("current_prompt") or "").strip()
    edit_request = str(payload.get("edit_request") or "").strip()
    mode_label = str(payload.get("mode_label") or "video").strip() or "video"
    performance_mode = str(
        payload.get("performance_mode")
        or payload.get("performanceMode")
        or payload.get("video_type")
        or payload.get("videoType")
        or ""
    ).strip().lower().replace("-", "_").replace(" ", "_")
    if performance_mode in {"speaking", "short_film", "dialogue", "dialog"}:
        performance_mode = "speaking"
    elif performance_mode in {"no_lip_sync", "nolipsync", "no_lipsync", "no_sync", "silent", "visual_only"}:
        performance_mode = "no_lip_sync"
    else:
        performance_mode = "singing"
    if performance_mode == "speaking":
        performance_rule = (
            "Video Type is speaking / short film. Preserve speaking/dialogue behavior. "
            "Use says/say wording for dialogue and do not introduce singing, rapping, vocals, lyric, lip-sync, or music-performance wording."
        )
    elif performance_mode == "no_lip_sync":
        performance_rule = (
            "Video Type is no lip sync / visual-only. Do not quote lyric text. "
            "Do not introduce saying, speaking, dialogue, singing, rapping, vocals, lyric, lip-sync, mouth movement, or no-vocal status. "
            "Keep the edit focused on visible action, camera motion, environment, mood, and physical movement."
        )
    else:
        performance_rule = (
            "Video Type is singing / music video. Preserve singing behavior only when the current prompt or edit request calls for a vocal performance."
        )
    use_full_scene_context = bool(payload.get("use_full_scene_context"))
    use_vision_reference = bool(payload.get("use_vision_reference"))
    scene_context = payload.get("scene_context") if isinstance(payload.get("scene_context"), dict) else {}
    if not current_prompt:
        raise ValueError("Current video prompt is empty.")
    if not edit_request:
        raise ValueError("Edit request is empty.")
    context_text = ""
    if use_full_scene_context:
        singers = scene_context.get("singers")
        if isinstance(singers, list):
            singers_text = ", ".join(str(item or "").strip() for item in singers if str(item or "").strip())
        else:
            singers_text = str(singers or "").strip()
        context_text = (
            "\n\nFull scene context is enabled. Use this context only when it helps satisfy the requested edit. "
            "Do not rewrite unrelated parts just because context is present.\n"
            f"Scene label: {str(scene_context.get('label') or '').strip() or '(none)'}\n"
            f"Image/concept prompt: {str(scene_context.get('image_prompt') or '').strip() or '(none)'}\n"
            f"Scene notes: {str(scene_context.get('scene_notes') or '').strip() or '(none)'}\n"
            f"Director note: {str(scene_context.get('director_note') or '').strip() or '(none)'}\n"
            f"Motion notes: {str(scene_context.get('motion_notes') or '').strip() or '(none)'}\n"
            f"Lyric section: {str(scene_context.get('lyric_section') or '').strip() or '(none)'}\n"
            f"Lyric text: {str(scene_context.get('lyric_text') or '').strip() or '(none)'}\n"
            f"Performance mode: {str(scene_context.get('performance_mode') or performance_mode).strip() or performance_mode}\n"
            f"Singer(s): {singers_text or '(none)'}\n"
            f"Subject context: {str(scene_context.get('subject_context') or '').strip() or '(none)'}\n"
            f"Location context: {str(scene_context.get('location_context') or '').strip() or '(none)'}\n"
            f"No character present: {bool(scene_context.get('no_character_present'))}"
        )
    return (
        f"You are editing an existing {mode_label} generation prompt.\n"
        "Make the smallest useful edit that satisfies the user's request.\n"
        "Preserve the subject, setting, style, lighting, wardrobe, identity, mood, and continuity unless the user explicitly asks to change them.\n"
        "If a starting image is provided, use it only as visual reference for subject, setting, framing, and visible motion/camera feasibility.\n"
        "If the user asks for a camera or motion change, replace conflicting camera/motion language instead of stacking contradictions.\n"
        "When full scene context is disabled, use only the current prompt and user requested change.\n"
        "When full scene context is enabled, you may use the supplied scene context for a larger but still controlled rewrite.\n"
        f"{performance_rule}\n"
        "Do not add new characters, new locations, unrelated actions, captions, text overlays, markdown, labels, or explanations.\n"
        "Do not mention this edit request. Do not describe what changed.\n"
        "Return only one clean revised prompt paragraph.\n\n"
        f"Current prompt:\n{current_prompt}\n\n"
        f"User requested change:\n{edit_request}\n\n"
        f"Starting image provided: {use_vision_reference}"
        f"{context_text}"
    )


def _edit_builder_video_prompt(payload):
    from .LLM import VRGDG_SuperGemmaGGUFChat, _clear_vrgdg_llm_caches

    current_prompt = str(payload.get("current_prompt") or "").strip()
    if not current_prompt:
        raise ValueError("Current video prompt is empty.")
    model_file = str(payload.get("model_file") or payload.get("repair_model_file") or "").strip()
    mmproj_file = str(payload.get("mmproj_file") or "").strip()
    image_reference_path = str(payload.get("image_reference_path") or "").strip().strip('"')
    image_reference_data = str(payload.get("image_reference_data") or "").strip()
    use_vision_reference = bool(payload.get("use_vision_reference"))
    text_runner = _llm_runner_from_payload(payload)
    if model_file:
        payload = dict(payload)
        payload["model_file"] = model_file
    instruction = _video_prompt_edit_instructions(payload)
    image = None
    if use_vision_reference:
        if image_reference_data:
            image = _image_from_data_url(image_reference_data).convert("RGB")
        elif image_reference_path:
            image_path = _resolve_existing_file(image_reference_path, "Prompt edit starting image")
            image = Image.open(image_path).convert("RGB")
        else:
            raise ValueError("Prompt edit requested the starting image, but no image reference was provided.")

    temperature = float(payload.get("temperature") or 0.25)
    top_p = float(payload.get("top_p") or 0.9)
    max_new_tokens = _runner_output_token_limit(payload, int(payload.get("max_new_tokens") or 1200))
    unload_after = bool(payload.get("unload_after", True))
    n_ctx = int(payload.get("n_ctx") or 8000)
    n_gpu_layers = int(payload.get("n_gpu_layers") or 99)
    n_threads = int(payload.get("n_threads") or 8)
    chat_format = str(payload.get("chat_format") or "").strip()
    seed = payload.get("seed")
    llm = None
    model_path = ""
    mmproj_path = ""
    try:
        if use_vision_reference and text_runner in _EXTERNAL_LLM_RUNNERS:
            text, run_info = _try_run_remote_vision(
                payload,
                instruction,
                [image],
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
            )
        elif use_vision_reference:
            if not model_file:
                raise ValueError("Choose an I2V vision Gemma model first.")
            if not model_file.lower().endswith(".gguf"):
                raise ValueError("The I2V model field is not a GGUF model.")
            llm = _builder_local_llm(payload)
            model_file = _builder_local_model_file(payload, model_file)
            model_path = llm._resolve_dropdown_path(model_file, llm.MISSING_MODEL_OPTION)
            mmproj_file = _builder_local_mmproj_file(payload, mmproj_file)
            mmproj_path = _resolve_mmproj_dropdown_path(llm, mmproj_file)
            model = llm._load_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            text = llm._run_gguf_vision_pipeline(
                model=model,
                pil_images=[image],
                instruction_text=instruction,
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
                seed=int(seed) if seed is not None else None,
            )
            run_info = {"runner": "builtin", "used_model": model_path, "unloaded": unload_after}
        else:
            text, run_info = _run_builder_text_llm(
                payload,
                instruction,
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
                label="video prompt edit",
            )
        text = _clean_gemma_prompt_text(text)
        text = _repair_and_validate_builder_gemma_prompt(payload, text, str(payload.get("mode_label") or "Video"))
        return {
            "prompt": text,
            "runner": run_info.get("runner", "builtin"),
            "used_model": run_info.get("used_model", model_path),
            "used_mmproj": mmproj_path,
            "used_image_reference": use_vision_reference,
            "unloaded": run_info.get("unloaded", unload_after),
        }
    finally:
        if llm and unload_after:
            llm._unload_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            _clear_vrgdg_llm_caches(clear_cuda_cache=True, clear_hf_pipeline_cache=False)


def _image_prompt_edit_instructions(payload):
    current_prompt = str(payload.get("current_prompt") or "").strip()
    edit_request = str(payload.get("edit_request") or "").strip()
    mode_label = str(payload.get("mode_label") or "image").strip() or "image"
    prompt_mode = str(payload.get("prompt_mode") or "").strip().lower()
    use_full_scene_context = bool(payload.get("use_full_scene_context"))
    use_vision_reference = bool(payload.get("use_vision_reference"))
    scene_context = payload.get("scene_context") if isinstance(payload.get("scene_context"), dict) else {}
    reference_context = payload.get("reference_context") if isinstance(payload.get("reference_context"), dict) else {}
    if not current_prompt:
        raise ValueError("Current image prompt is empty.")
    if not edit_request:
        raise ValueError("Edit request is empty.")
    has_subject_reference = bool(reference_context.get("has_subject_reference"))
    has_location_reference = bool(reference_context.get("has_location_reference"))
    try:
        subject_reference_count = int(float(reference_context.get("subject_reference_count") or 1)) if has_subject_reference else 0
    except (TypeError, ValueError):
        subject_reference_count = 1 if has_subject_reference else 0
    subject_reference_count = max(0, min(99, subject_reference_count))
    character_reference_phrase = "character reference images" if subject_reference_count > 1 else "character reference image"
    reference_opening = ""
    if prompt_mode in {"nano_banana", "flow_gpt"}:
        if has_subject_reference and has_location_reference:
            reference_opening = f"Using the provided {character_reference_phrase} and location reference image"
        elif has_subject_reference:
            reference_opening = f"Using the provided {character_reference_phrase}"
        elif has_location_reference:
            reference_opening = "Using the provided location reference image"
    mode_rules = ""
    if prompt_mode in {"nano_banana", "flow_gpt"}:
        mode_rules = (
            f"This is a {'Flow/GPT browser image' if prompt_mode == 'flow_gpt' else 'NanoBanana'} prompt. Preserve any required wording about provided character or location reference images unless the user explicitly asks to change reference usage. "
            "Use advanced Krea 2-style image prompting: concrete subject identity, wardrobe, hair, makeup, pose, camera framing, lens feel, lighting setup, environment, materials, atmosphere, color palette, texture, and cinematic finish. "
            "Keep it practical as one image-generation prompt paragraph."
        )
        if reference_opening:
            mode_rules += f" The revised prompt must start with exactly this reference opening before the rest of the prompt: \"{reference_opening}, create\"."
    elif prompt_mode == "flux_klein":
        mode_rules = (
            "This is a Flux/Klein image prompt. Preserve mapped subject and location identity from the prompt/reference context unless the user explicitly asks to change them. "
            "Do not mention image indexes or internal reference labels."
        )
    elif prompt_mode == "krea2_2pass":
        mode_rules = "This is a Krea 2 image prompt. Keep enough concrete detail for pose, wardrobe, lighting, camera framing, environment, materials, and atmosphere."
    else:
        mode_rules = "This is a text-to-image prompt. Keep it visually specific and usable directly by an image generation model."

    context_text = ""
    if use_full_scene_context:
        context_text = (
            "\n\nFull scene context is enabled. Use this context only when it helps satisfy the requested edit. "
            "Do not rewrite unrelated parts just because context is present.\n"
            f"Scene label: {str(scene_context.get('label') or '').strip() or '(none)'}\n"
            f"Scene notes: {str(scene_context.get('scene_notes') or '').strip() or '(none)'}\n"
            f"Director note: {str(scene_context.get('director_note') or '').strip() or '(none)'}\n"
            f"Lyric section: {str(scene_context.get('lyric_section') or '').strip() or '(none)'}\n"
            f"Lyric text: {str(scene_context.get('lyric_text') or '').strip() or '(none)'}\n"
            f"Subject context: {str(scene_context.get('subject_context') or '').strip() or '(none)'}\n"
            f"Location context: {str(scene_context.get('location_context') or '').strip() or '(none)'}\n"
            f"No character present: {bool(scene_context.get('no_character_present'))}"
        )
    ref_bits = []
    for label, key in (
        ("Reference subject description", "subject_description"),
        ("Reference location name", "location_name"),
        ("Reference location description", "location_description"),
    ):
        value = str(reference_context.get(key) or "").strip()
        if value:
            ref_bits.append(f"{label}: {value}")
    reference_text = f"\n\nReference Builder context:\n{chr(10).join(ref_bits)}" if ref_bits else ""
    return (
        f"You are editing an existing {mode_label} image generation prompt.\n"
        "Make the smallest useful edit that satisfies the user's request.\n"
        "Preserve the subject, setting, identity, style, lighting, wardrobe, camera framing, mood, and continuity unless the user explicitly asks to change them.\n"
        "If a reference image is provided, use it only as visual reference for subject, setting, composition, color, and concrete visible details.\n"
        "When full scene context is disabled, use only the current prompt and user requested change.\n"
        "When full scene context is enabled, you may use the supplied scene context for a larger but still controlled rewrite.\n"
        f"{mode_rules}\n"
        "Do not add captions, text overlays, markdown, labels, bullet points, explanations, or commentary.\n"
        "Do not mention this edit request. Do not describe what changed.\n"
        "Return only one clean revised image prompt paragraph.\n\n"
        f"Current prompt:\n{current_prompt}\n\n"
        f"User requested change:\n{edit_request}\n\n"
        f"Reference image provided: {use_vision_reference}"
        f"{context_text}"
        f"{reference_text}"
    )


def _ensure_reference_opening_for_image_edit(prompt, payload):
    text = str(prompt or "").strip()
    prompt_mode = str(payload.get("prompt_mode") or "").strip().lower()
    if prompt_mode not in {"nano_banana", "flow_gpt"} or not text:
        return text
    reference_context = payload.get("reference_context") if isinstance(payload.get("reference_context"), dict) else {}
    has_subject_reference = bool(reference_context.get("has_subject_reference"))
    has_location_reference = bool(reference_context.get("has_location_reference"))
    try:
        subject_reference_count = int(float(reference_context.get("subject_reference_count") or 1)) if has_subject_reference else 0
    except (TypeError, ValueError):
        subject_reference_count = 1 if has_subject_reference else 0
    subject_reference_count = max(0, min(99, subject_reference_count))
    if not has_subject_reference and not has_location_reference:
        return text
    character_reference_phrase = "character reference images" if subject_reference_count > 1 else "character reference image"
    if has_subject_reference and has_location_reference:
        opening = f"Using the provided {character_reference_phrase} and location reference image"
    elif has_subject_reference:
        opening = f"Using the provided {character_reference_phrase}"
    else:
        opening = "Using the provided location reference image"
    text = re.sub(
        r"^Using the provided\s+(?:(?:character|location|scene|reference)\s+)+(?:images?|references?)\s*,?\s*(?:create\s+)?",
        "",
        text,
        count=1,
        flags=re.IGNORECASE,
    ).strip()
    if re.match(r"^(?:create|make|generate)\b", text, flags=re.IGNORECASE):
        text = re.sub(r"^(?:create|make|generate)\b\s*", "", text, count=1, flags=re.IGNORECASE).strip()
    if not text:
        return f"{opening}, create a cinematic still image."
    return f"{opening}, create {text[:1].lower()}{text[1:] if len(text) > 1 else ''}".strip()


def _edit_builder_image_prompt(payload):
    from .LLM import VRGDG_SuperGemmaGGUFChat, _clear_vrgdg_llm_caches

    current_prompt = str(payload.get("current_prompt") or "").strip()
    if not current_prompt:
        raise ValueError("Current image prompt is empty.")
    model_file = str(payload.get("model_file") or payload.get("repair_model_file") or "").strip()
    mmproj_file = str(payload.get("mmproj_file") or "").strip()
    ref_image_path = str(payload.get("ref_image_path") or payload.get("image_reference_path") or "").strip().strip('"')
    ref_image_data = str(payload.get("ref_image_data") or payload.get("image_reference_data") or "").strip()
    use_vision_reference = bool(payload.get("use_vision_reference"))
    text_runner = _llm_runner_from_payload(payload)
    if model_file:
        payload = dict(payload)
        payload["model_file"] = model_file
    instruction = _image_prompt_edit_instructions(payload)
    image = None
    if use_vision_reference:
        if ref_image_data:
            image = _image_from_data_url(ref_image_data).convert("RGB")
        elif ref_image_path:
            image_path = _resolve_existing_file(ref_image_path, "Image prompt edit reference image")
            image = Image.open(image_path).convert("RGB")
        else:
            raise ValueError("Prompt edit requested a reference image, but no image reference was provided.")

    temperature = float(payload.get("temperature") or 0.25)
    top_p = float(payload.get("top_p") or 0.9)
    max_new_tokens = _runner_output_token_limit(payload, int(payload.get("max_new_tokens") or 1200))
    unload_after = bool(payload.get("unload_after", True))
    n_ctx = int(payload.get("n_ctx") or 8000)
    n_gpu_layers = int(payload.get("n_gpu_layers") or 99)
    n_threads = int(payload.get("n_threads") or 8)
    chat_format = str(payload.get("chat_format") or "").strip()
    seed = payload.get("seed")
    llm = None
    model_path = ""
    mmproj_path = ""
    try:
        if use_vision_reference and text_runner in _EXTERNAL_LLM_RUNNERS:
            text, run_info = _try_run_remote_vision(
                payload,
                instruction,
                [image],
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
            )
        elif use_vision_reference:
            if not model_file:
                raise ValueError("Choose a vision Gemma model first.")
            if not model_file.lower().endswith(".gguf"):
                raise ValueError("The vision Gemma model field is not a GGUF model.")
            llm = _builder_local_llm(payload)
            model_file = _builder_local_model_file(payload, model_file)
            model_path = llm._resolve_dropdown_path(model_file, llm.MISSING_MODEL_OPTION)
            mmproj_file = _builder_local_mmproj_file(payload, mmproj_file)
            mmproj_path = _resolve_mmproj_dropdown_path(llm, mmproj_file)
            model = llm._load_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            text = llm._run_gguf_vision_pipeline(
                model=model,
                pil_images=[image],
                instruction_text=instruction,
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
                seed=int(seed) if seed is not None else None,
            )
            run_info = {"runner": "builtin", "used_model": model_path, "unloaded": unload_after}
        else:
            text, run_info = _run_builder_text_llm(
                payload,
                instruction,
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
                label="image prompt edit",
            )
        text = _clean_visual_gemma_text(text)
        text = extract_prompt_text_from_gemma_output(text, payload.get("scene_number"))
        text = _repair_and_validate_builder_gemma_prompt(payload, text, str(payload.get("mode_label") or "Image"))
        text = _ensure_reference_opening_for_image_edit(text, payload)
        return {
            "prompt": text,
            "runner": run_info.get("runner", "builtin"),
            "used_model": run_info.get("used_model", model_path),
            "used_mmproj": mmproj_path,
            "used_image_reference": use_vision_reference,
            "unloaded": run_info.get("unloaded", unload_after),
        }
    finally:
        if llm and unload_after:
            llm._unload_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            _clear_vrgdg_llm_caches(clear_cuda_cache=True, clear_hf_pipeline_cache=False)


def _image_from_prompt_payload(path, data, label):
    raw_data = str(data or "").strip()
    raw_path = str(path or "").strip().strip('"')
    if raw_data:
        return _image_from_data_url(raw_data).convert("RGB")
    if raw_path:
        image_path = _resolve_existing_file(raw_path, label)
        return Image.open(image_path).convert("RGB")
    raise ValueError(f"{label} is required.")


def _combine_subject_location_images(subject_image, location_image):
    max_height = 640
    resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC)
    resized = []
    for image in (subject_image, location_image):
        scale = min(1.0, max_height / max(1, image.height))
        width = max(1, int(image.width * scale))
        height = max(1, int(image.height * scale))
        resized.append(image.resize((width, height), resample))
    gap = 24
    canvas_width = resized[0].width + resized[1].width + gap
    canvas_height = max(resized[0].height, resized[1].height)
    canvas = Image.new("RGB", (canvas_width, canvas_height), (20, 20, 20))
    canvas.paste(resized[0], (0, (canvas_height - resized[0].height) // 2))
    canvas.paste(resized[1], (resized[0].width + gap, (canvas_height - resized[1].height) // 2))
    return canvas


def _combine_flux_ingredient_images(images):
    if not images:
        raise ValueError("At least one image ingredient is required.")
    cell_size = 384 if len(images) <= 4 else 256
    gap = 24
    columns = 1 if len(images) == 1 else int(math.ceil(math.sqrt(len(images))))
    rows = int(math.ceil(len(images) / columns))
    resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC)

    canvas_width = (columns * cell_size) + (gap * (columns - 1))
    canvas_height = (rows * cell_size) + (gap * (rows - 1))
    canvas = Image.new("RGB", (canvas_width, canvas_height), (20, 20, 20))

    resized = []
    for image in images:
        scale = min(1.0, cell_size / max(1, image.width), cell_size / max(1, image.height))
        width = max(1, int(image.width * scale))
        height = max(1, int(image.height * scale))
        resized.append(image.resize((width, height), resample))

    for index, image in enumerate(resized):
        column = index % columns
        row = index // columns
        cell_x = column * (cell_size + gap)
        cell_y = row * (cell_size + gap)
        x = cell_x + ((cell_size - image.width) // 2)
        y = cell_y + ((cell_size - image.height) // 2)
        canvas.paste(image, (x, y))
    return canvas


def _combine_story_reference_batch(images, cell_size=512):
    if not images:
        raise ValueError("At least one Story reference image is required.")
    batch = list(images[:4])
    gap = 16
    columns = 1 if len(batch) == 1 else 2
    rows = int(math.ceil(len(batch) / columns))
    resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC)
    canvas = Image.new("RGB", ((columns * cell_size) + (gap * (columns - 1)), (rows * cell_size) + (gap * (rows - 1))), (20, 20, 20))
    for index, image in enumerate(batch):
        image = image.convert("RGB")
        scale = min(cell_size / max(1, image.width), cell_size / max(1, image.height))
        width = max(1, int(image.width * scale))
        height = max(1, int(image.height * scale))
        resized = image.resize((width, height), resample)
        column = index % columns
        row = index // columns
        cell_x = column * (cell_size + gap)
        cell_y = row * (cell_size + gap)
        canvas.paste(resized, (cell_x + ((cell_size - width) // 2), cell_y + ((cell_size - height) // 2)))
    return canvas


def _clear_comfy_model_memory():
    result = {
        "comfy_loaded_before": None,
        "comfy_loaded_after": None,
        "comfy_cleanup_calls": [],
        "comfy_cleanup_errors": [],
        "torch_cuda_cache_cleared": False,
    }
    try:
        import comfy.model_management as model_management
        import torch

        loaded_models = getattr(model_management, "loaded_models", None)
        if callable(loaded_models):
            try:
                result["comfy_loaded_before"] = len(loaded_models())
            except Exception as exc:
                result["comfy_cleanup_errors"].append(f"loaded_models before: {exc}")

        unload_all_models = getattr(model_management, "unload_all_models", None)
        if callable(unload_all_models):
            unload_all_models()
            result["comfy_cleanup_calls"].append("unload_all_models")

        cleanup_models_gc = getattr(model_management, "cleanup_models_gc", None)
        if callable(cleanup_models_gc):
            cleanup_models_gc()
            result["comfy_cleanup_calls"].append("cleanup_models_gc")

        cleanup_models = getattr(model_management, "cleanup_models", None)
        if callable(cleanup_models):
            cleanup_models()
            result["comfy_cleanup_calls"].append("cleanup_models")

        soft_empty_cache = getattr(model_management, "soft_empty_cache", None)
        if callable(soft_empty_cache):
            try:
                soft_empty_cache(force=True)
            except TypeError:
                soft_empty_cache()
            result["comfy_cleanup_calls"].append("soft_empty_cache")

        if torch.cuda.is_available():
            torch.cuda.synchronize()
            torch.cuda.empty_cache()
            ipc_collect = getattr(torch.cuda, "ipc_collect", None)
            if callable(ipc_collect):
                ipc_collect()
            result["torch_cuda_cache_cleared"] = True

        gc.collect()
        if callable(loaded_models):
            try:
                result["comfy_loaded_after"] = len(loaded_models())
            except Exception as exc:
                result["comfy_cleanup_errors"].append(f"loaded_models after: {exc}")
    except Exception as exc:
        result["comfy_cleanup_errors"].append(str(exc))
    return result


def _clear_builder_memory_direct():
    from .LLM import _clear_vrgdg_llm_caches

    comfy_result = _clear_comfy_model_memory()
    llm_result = _clear_vrgdg_llm_caches(clear_cuda_cache=True, clear_hf_pipeline_cache=False)
    gc.collect()
    cleanup_calls = ", ".join(comfy_result.get("comfy_cleanup_calls") or []) or "none"
    cleanup_errors = "; ".join(comfy_result.get("comfy_cleanup_errors") or [])
    return {
        "message": (
            "Memory cleanup finished.\n"
            f"Comfy cleanup calls: {cleanup_calls}\n"
            f"Comfy loaded models: {comfy_result.get('comfy_loaded_before')} -> {comfy_result.get('comfy_loaded_after')}\n"
            f"GGUF models unloaded: {llm_result.get('gguf_models_unloaded', 0)}\n"
            f"HF pipelines unloaded: {llm_result.get('hf_pipelines_unloaded', 0)}\n"
            f"CUDA cache cleared: {bool(llm_result.get('cuda_cache_cleared') or comfy_result.get('torch_cuda_cache_cleared'))}"
            + (f"\nCleanup warnings: {cleanup_errors}" if cleanup_errors else "")
        ),
        **comfy_result,
        **llm_result,
    }


def _generate_builder_reference_description(payload):
    from .LLM import VRGDG_SuperGemmaGGUFChat, _clear_vrgdg_llm_caches

    model_file = str(payload.get("model_file", "") or "").strip()
    mmproj_file = str(payload.get("mmproj_file", "") or "").strip()
    text_runner = _llm_runner_from_payload(payload)
    reference_type = str(payload.get("reference_type") or "subject").strip().lower()
    name_hint = str(payload.get("name") or "").strip()
    subject_label = re.sub(r"\s+", " ", name_hint).strip()
    if subject_label.lower().startswith("the "):
        subject_label = subject_label.lower()
    object_reference_types = {"prop", "object", "vehicle", "creature", "animal", "outfit", "style", "environment", "other"}
    if reference_type not in {"subject", "character", "face", "location", "extra", *object_reference_types}:
        reference_type = "subject"
    if text_runner not in _EXTERNAL_LLM_RUNNERS and not model_file:
        raise ValueError("Choose a Gemma vision model first.")
    image = _image_from_prompt_payload(payload.get("image_path", ""), payload.get("image_data", ""), "Reference image")

    if reference_type == "face":
        instruction = (
            "Study the visible person's face and write one precise face-identity description for an image enhancement prompt.\n"
            "Return only one plain-text paragraph. It must begin exactly with: a photo of\n"
            "Describe stable facial identity details only: apparent age range, face shape, eyes, eyebrows, nose, lips, jawline, cheeks, distinctive facial features, hair color, hairline, and face-framing hair.\n"
            "Include makeup or facial accessories only when clearly visible and useful for preserving identity.\n"
            "Do not mention the background, location, clothing, body, pose, camera angle, action, mood, or facial expression.\n"
            "Do not describe smiling, frowning, an open mouth, gaze direction, or head direction.\n"
            "Do not add markdown, a label, quotation marks, instructions, or commentary.\n"
            "Do not invent details that are not visible. Keep it under 100 words."
        )
    elif reference_type in {"subject", "character"}:
        instruction = (
            "Look at the image and write one concise character appearance description.\n"
            "Output only the description, one paragraph, no markdown, no label, no bullet points.\n"
            "Describe only the character's full visible appearance: hair, makeup, accessories, jewelry, clothing, outfit materials, colors, shoes, and distinctive visual identity details.\n"
            "Do not mention skin color, skin tone, ethnicity, race, or complexion.\n"
            "Do not describe the background, location, pose, camera angle, facial expression, mood, action, or what the character is doing.\n"
            "Do not invent hidden or unseen details.\n"
            "Keep it under 100 words."
        )
        if subject_label:
            instruction += (
                f"\nRefer to the subject as {subject_label}. "
                f"Do not call them the character or the subject in the final description."
            )
    elif reference_type == "extra":
        try:
            count = max(1, min(100, int(round(float(payload.get("count") or 1)))))
        except (TypeError, ValueError, OverflowError):
            count = 1
        style_hint = re.sub(r"\s+", " ", str(payload.get("style") or "")).strip()
        group_hint = f"one of a group of {count} background performers"
        if style_hint:
            group_hint += f" in a {style_hint}-appropriate wardrobe"
        instruction = (
            "Look at the image and write one very short background-performer identity description.\n"
            "Output only the description, one paragraph, no markdown, no label, no bullet points.\n"
            "Include apparent gender presentation, hair color and hairstyle, a concise outfit description with its main colors, and at most one clearly visible distinguishing trait when available, such as build, face shape, facial hair, or one prominent accessory.\n"
            "Use one complete grammatical sentence of no more than 35 words.\n"
            "Do not mention skin color, skin tone, ethnicity, race, or complexion.\n"
            "Do not describe the background, location, pose, camera angle, facial expression, mood, action, or what the performer is doing.\n"
            "Do not list minor jewelry, every accessory, fabric micro-details, or unseen details.\n"
            f"Treat the pictured person as {group_hint}."
        )
        if subject_label:
            instruction += f"\nUse this label only as the performer name if needed: {subject_label}"
    elif reference_type == "location":
        instruction = (
            "Look at the image and write one concise location/environment description.\n"
            "Output only the description, one paragraph, no markdown, no label, no bullet points.\n"
            "Describe the place itself: environment, architecture, layout, major objects, materials, colors, lighting, atmosphere, and visible setting details.\n"
            "Do not describe a main character, pose, performance, camera angle, or story action.\n"
            "Do not invent hidden or unseen details.\n"
            "Keep it under 100 words."
        )
        if name_hint:
            instruction += f"\nUse this label only as the location name if needed: {name_hint}"
    else:
        label = reference_type.replace("_", " ")
        instruction = (
            f"Look at the image and write one concise {label} reference description.\n"
            "Output only the description, one paragraph, no markdown, no label, no bullet points.\n"
            "Describe only the visible reference item: shape, form, materials, colors, markings, texture, scale cues, construction, accessories, and distinctive visual identity details.\n"
            "Do not describe the background, location, pose, camera angle, facial expression, mood, action, story meaning, or a person unless the reference item itself is a person.\n"
            "Do not invent hidden or unseen details.\n"
            "Keep it under 100 words."
        )
        if name_hint:
            instruction += f"\nUse this label only as the reference name if needed: {name_hint}"

    llm = _builder_local_llm(payload) if text_runner not in _EXTERNAL_LLM_RUNNERS else None
    model_file = _builder_local_model_file(payload, model_file)
    model_path = llm._resolve_dropdown_path(model_file, llm.MISSING_MODEL_OPTION) if llm else str(payload.get("lmstudio_model") or "").strip()
    mmproj_file = _builder_local_mmproj_file(payload, mmproj_file)
    mmproj_path = _resolve_mmproj_dropdown_path(llm, mmproj_file) if llm else ""
    n_ctx = int(payload.get("n_ctx") or 2048)
    n_gpu_layers = int(payload.get("n_gpu_layers") or 99)
    n_threads = int(payload.get("n_threads") or 8)
    chat_format = str(payload.get("chat_format", "") or "").strip()
    temperature = float(payload.get("temperature") or 0.2)
    top_p = float(payload.get("top_p") or 0.9)
    max_new_tokens = _runner_output_token_limit(payload, int(payload.get("max_new_tokens") or 180))
    seed = payload.get("seed")
    clear_before_load = bool(payload.get("clear_before_load", False))
    unload_after = bool(payload.get("unload_after", True))

    try:
        if clear_before_load and llm:
            _clear_comfy_model_memory()
            _clear_vrgdg_llm_caches(clear_cuda_cache=True, clear_hf_pipeline_cache=False)
        model = None
        if llm:
            model = llm._load_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
        def clean_reference_description(raw_text):
            text = _clean_visual_gemma_text(raw_text)
            text = re.sub(r"^\s*(character|subject|location|description)\s*:\s*", "", text, flags=re.I).strip()
            if reference_type == "face":
                text = text.strip().strip('"').strip("'").strip()
                # Vision models occasionally leak a short thought and then emit the
                # requested prompt, e.g. "a photo of me thoughta photo of a woman...".
                # The final occurrence is the actual answer, even when the leaked
                # text omitted whitespace before it.
                markers = list(re.finditer(r"a\s+photo\s+of", text, flags=re.I))
                if markers:
                    text = text[markers[-1].start():]
                else:
                    text = re.sub(r"^\s*(?:face prompt|prompt|face description)\s*:\s*", "", text, flags=re.I)
                    text = f"a photo of {text.lstrip(' ,.-')}"
                text = re.sub(r"^a\s+photo\s+of\b", "a photo of", text, count=1, flags=re.I)
                text = re.sub(r"\s+", " ", text).strip()
                if len(re.findall(r"a\s+photo\s+of", text, flags=re.I)) != 1:
                    raise ValueError("The face description repeated its required opening phrase.")
                if re.search(r"\b(?:assistant|analysis|reasoning|let me|i think|i thought|my thought)\b", text, flags=re.I):
                    raise ValueError("The face description leaked model reasoning.")
            elif reference_type in {"subject", "character"}:
                if subject_label:
                    text = re.sub(r"\bthe character\b", subject_label, text, flags=re.I)
                    text = re.sub(r"\bthe subject\b", subject_label, text, flags=re.I)
                    text = re.sub(r"\ba character\b", subject_label, text, flags=re.I)
                    text = re.sub(r"\ba subject\b", subject_label, text, flags=re.I)
                text = re.sub(
                    r"\b(?:with|has|having|featuring)?\s*(?:very\s+|pale\s+|fair\s+|light\s+|medium\s+|tan\s+|tanned\s+|olive\s+|brown\s+|dark\s+|deep\s+|warm\s+|cool\s+|golden\s+|porcelain\s+|dusky\s+|caramel\s+|bronze\s+|dark-skinned\s+|light-skinned\s+)+(?:skin|skin tone|complexion)\b,?\s*(?:and\s+)?",
                    "",
                    text,
                    flags=re.I,
                )
                text = re.sub(r"\b(?:skin|skin tone|complexion)\s*(?:is|appears|looks)\s+[^,.]+,?\s*(?:and\s+)?", "", text, flags=re.I)
                text = re.sub(r"\s+,", ",", text)
                text = re.sub(r"(?:^|\.\s*)and\s+", "", text, flags=re.I).strip()
                text = re.sub(r"\s{2,}", " ", text).strip(" ,")
            words = text.split()
            if len(words) > 100:
                text = " ".join(words[:100]).rstrip(" ,.;:") + "."
            if not text:
                raise ValueError("Gemma returned an empty reference description.")
            _validate_reference_description(text, reference_type)
            return text

        last_error = None
        text = ""
        for attempt in range(2):
            attempt_instruction = instruction
            if attempt:
                attempt_instruction += (
                    "\n\nPrevious output was rejected because it repeated words or was not a usable description. "
                    "Write a normal visual description with varied concrete nouns. Do not repeat any word more than twice."
                )
            if text_runner in _EXTERNAL_LLM_RUNNERS:
                raw_text, _run_info = _try_run_remote_vision(
                    payload,
                    attempt_instruction,
                    [image],
                    temperature=0.05 if attempt else temperature,
                    top_p=0.75 if attempt else top_p,
                    max_new_tokens=max_new_tokens,
                )
            else:
                raw_text = llm._run_gguf_vision_pipeline(
                    model=model,
                    pil_images=[image],
                    instruction_text=attempt_instruction,
                    temperature=0.05 if attempt else temperature,
                    top_p=0.75 if attempt else top_p,
                    max_new_tokens=max_new_tokens,
                    seed=int(seed) if seed is not None else None,
                )
            try:
                text = clean_reference_description(raw_text)
                last_error = None
                break
            except ValueError as exc:
                last_error = exc
        if last_error:
            raise last_error
        return {"description": text, "used_model": model_path, "used_mmproj": mmproj_path, "runner": "llm_api_vision" if text_runner == "llm_api" else "own_server_vision" if text_runner == "own_server" else "lm_studio_vision" if text_runner == "lm_studio" else "builtin", "unloaded": False if text_runner in _EXTERNAL_LLM_RUNNERS else unload_after}
    finally:
        if llm and unload_after:
            llm._unload_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            _clear_vrgdg_llm_caches(clear_cuda_cache=True, clear_hf_pipeline_cache=False)


def _generate_flux_klein_prompt(payload):
    from .LLM import VRGDG_SuperGemmaGGUFChat, _clear_vrgdg_llm_caches

    model_file = str(payload.get("model_file", "") or "").strip()
    mmproj_file = str(payload.get("mmproj_file", "") or "").strip()
    user_notes = str(payload.get("user_notes", "") or "").strip()
    builder_instruction_key = str(payload.get("builder_instruction_key") or payload.get("instruction_key") or "flux_klein_t2i").strip()
    text_runner = _llm_runner_from_payload(payload)
    if text_runner not in _EXTERNAL_LLM_RUNNERS and not model_file:
        raise ValueError("Choose a Gemma vision model first.")

    ingredients = payload.get("image_ingredients") or []
    if isinstance(ingredients, str):
        try:
            ingredients = json.loads(ingredients)
        except Exception:
            ingredients = [{"path": line.strip()} for line in ingredients.splitlines() if line.strip()]
    if not isinstance(ingredients, list):
        raise ValueError("Image ingredients must be a list.")
    reference_context = payload.get("reference_context") or {}
    if not isinstance(reference_context, dict):
        reference_context = {}
    has_subject_reference = bool(reference_context.get("has_subject_reference"))
    has_location_reference = bool(reference_context.get("has_location_reference"))
    subject_description = str(reference_context.get("subject_description", "") or "").strip()
    location_name = str(reference_context.get("location_name", "") or "").strip()
    location_description = str(reference_context.get("location_description", "") or "").strip()
    images = []
    for index, item in enumerate(ingredients, start=1):
        if isinstance(item, str):
            item = {"path": item}
        if not isinstance(item, dict):
            continue
        images.append(_image_from_prompt_payload(item.get("path", ""), item.get("data", ""), f"Image ingredient {index}"))
    combined_image = _combine_flux_ingredient_images(images)
    reference_rules = []
    if has_subject_reference:
        subject_line = "Use the subject reference for the main subject identity, face/body details, outfit, and visible character consistency."
        if subject_description:
            subject_line += f" Subject description: {subject_description}"
        reference_rules.append(subject_line)
    if has_location_reference:
        location_line = "Use the mapped location reference as the required setting/background. Do not replace it with a different location from the concept or notes."
        location_details = "; ".join(part for part in (location_name, location_description) if part)
        if location_details:
            location_line += f" Mapped location: {location_details}"
        reference_rules.append(location_line)
    reference_text = ""
    if reference_rules:
        reference_text = (
            "\nReference Builder priorities:\n"
            + "\n".join(f"- {rule}" for rule in reference_rules)
            + "\n- Use the user's notes/concept for action, pose, mood, lighting, story beat, and details after respecting the reference priorities.\n"
        )
    base_instructions = _effective_builder_instruction(payload, builder_instruction_key, _FLUX_KLEIN_T2I_INSTRUCTIONS)
    instruction = (
        f"{base_instructions}\n\n"
        "The image input contains the available reference images/visual ingredients. These may include a character, background, props, style references, or other visual ingredients.\n"
        f"{reference_text}"
        "\n"
        f"User input:\n{user_notes or 'Create a new image using the available reference images.'}"
    )

    llm = _builder_local_llm(payload) if text_runner not in _EXTERNAL_LLM_RUNNERS else None
    model_file = _builder_local_model_file(payload, model_file)
    model_path = llm._resolve_dropdown_path(model_file, llm.MISSING_MODEL_OPTION) if llm else str(payload.get("lmstudio_model") or "").strip()
    mmproj_file = _builder_local_mmproj_file(payload, mmproj_file)
    mmproj_path = _resolve_mmproj_dropdown_path(llm, mmproj_file) if llm else ""
    # Flux/Klein only needs one short prompt, and vision GGUF context is expensive.
    # Keep this lower than the broader Gemma prompt tools to reduce crash risk.
    n_ctx = int(payload.get("n_ctx") or 2048)
    n_gpu_layers = int(payload.get("n_gpu_layers") or 99)
    n_threads = int(payload.get("n_threads") or 8)
    chat_format = str(payload.get("chat_format", "") or "").strip()
    temperature = float(payload.get("temperature") or 0.25)
    top_p = float(payload.get("top_p") or 0.95)
    max_new_tokens = _runner_output_token_limit(payload, int(payload.get("max_new_tokens") or 350))
    seed = payload.get("seed")
    clear_before_load = bool(payload.get("clear_before_load", True))
    unload_after = bool(payload.get("unload_after", True))

    try:
        if clear_before_load and llm:
            _clear_comfy_model_memory()
            _clear_vrgdg_llm_caches(clear_cuda_cache=True, clear_hf_pipeline_cache=False)
        if text_runner in _EXTERNAL_LLM_RUNNERS:
            text, run_info = _try_run_remote_vision(
                payload,
                instruction,
                [combined_image],
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
            )
        else:
            run_info = {}
            model = llm._load_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            text = llm._run_gguf_vision_pipeline(
                model=model,
                pil_images=[combined_image],
                instruction_text=instruction,
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
                seed=int(seed) if seed is not None else None,
            )
        text = _clean_visual_gemma_text(text)
        text = _repair_and_validate_builder_gemma_prompt(payload, text, "Flux/Klein")
        return {"prompt": text, "used_model": run_info.get("used_model", model_path) if text_runner in _EXTERNAL_LLM_RUNNERS else model_path, "used_mmproj": mmproj_path, "runner": "llm_api_vision" if text_runner == "llm_api" else "own_server_vision" if text_runner == "own_server" else "lm_studio_vision" if text_runner == "lm_studio" else "builtin", "unloaded": False if text_runner in _EXTERNAL_LLM_RUNNERS else unload_after}
    finally:
        if llm and unload_after:
            llm._unload_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            _clear_vrgdg_llm_caches(clear_cuda_cache=True, clear_hf_pipeline_cache=False)
            _clear_comfy_model_memory()


def _analyze_builder_story_references(payload):
    from .LLM import VRGDG_SuperGemmaGGUFChat, _clear_vrgdg_llm_caches

    model_file = str(payload.get("model_file", "") or "").strip()
    mmproj_file = str(payload.get("mmproj_file", "") or "").strip()
    user_notes = str(payload.get("user_notes", "") or "").strip()
    builder_instruction_key = str(payload.get("builder_instruction_key") or payload.get("instruction_key") or "nano_b_t2i").strip()
    text_runner = _llm_runner_from_payload(payload)
    if text_runner not in _EXTERNAL_LLM_RUNNERS and not model_file:
        raise ValueError("Choose a Gemma vision model first.")
    ingredients = payload.get("image_ingredients") or []
    if isinstance(ingredients, str):
        try:
            ingredients = json.loads(ingredients)
        except Exception:
            ingredients = [{"path": line.strip()} for line in ingredients.splitlines() if line.strip()]
    if not isinstance(ingredients, list):
        raise ValueError("Story reference images must be a list.")
    images = []
    for index, item in enumerate(ingredients, start=1):
        if isinstance(item, str):
            item = {"path": item}
        if not isinstance(item, dict):
            continue
        images.append(_image_from_prompt_payload(item.get("path", ""), item.get("data", ""), f"Story reference image {index}"))
    if not images:
        raise ValueError("Add at least one Story Builder reference image first.")
    batches = [images[index:index + 4] for index in range(0, len(images), 4)]
    llm = _builder_local_llm(payload) if text_runner not in _EXTERNAL_LLM_RUNNERS else None
    model_file = _builder_local_model_file(payload, model_file)
    model_path = llm._resolve_dropdown_path(model_file, llm.MISSING_MODEL_OPTION) if llm else str(payload.get("lmstudio_model") or "").strip()
    mmproj_path = _resolve_mmproj_dropdown_path(llm, mmproj_file) if llm else ""
    n_ctx = int(payload.get("n_ctx") or 4096)
    n_gpu_layers = int(payload.get("n_gpu_layers") or 99)
    n_threads = int(payload.get("n_threads") or 8)
    chat_format = str(payload.get("chat_format", "") or "").strip()
    temperature = float(payload.get("temperature") or 0.25)
    top_p = float(payload.get("top_p") or 0.95)
    max_new_tokens = _runner_output_token_limit(payload, int(payload.get("max_new_tokens") or 500))
    unload_after = bool(payload.get("unload_after", True))
    used_model = model_path
    try:
        model = None
        if llm:
            _clear_comfy_model_memory()
            _clear_vrgdg_llm_caches(clear_cuda_cache=True, clear_hf_pipeline_cache=False)
            model = llm._load_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
        batch_notes = []
        for batch_index, batch in enumerate(batches, start=1):
            combined_image = _combine_story_reference_batch(batch, cell_size=512)
            instruction = (
                "Analyze these reference images for a music video Story Builder. "
                "Each image has been resized into a 512px tile; this batch contains at most four images. "
                "Write compact reusable planning notes for a text-only agent. "
                "Identify likely singers/characters, clothing, faces/hair/body details, location ideas, props, color palette, lighting, mood, genre, and overall aesthetic. "
                "Do not write an image generation prompt. Do not mention image grids or panels. "
                "Use short labeled lines. Keep it under 180 words.\n\n"
                f"Batch {batch_index} of {len(batches)}.\n"
                f"User notes:\n{user_notes or 'Summarize the characters, locations, style, and aesthetic shown in the images.'}"
            )
            if text_runner in _EXTERNAL_LLM_RUNNERS:
                text, _run_info = _try_run_remote_vision(
                    payload,
                    instruction,
                    [combined_image],
                    temperature=temperature,
                    top_p=top_p,
                    max_new_tokens=max_new_tokens,
                )
                used_model = _run_info.get("used_model", used_model)
            else:
                text = llm._run_gguf_vision_pipeline(
                    model=model,
                    pil_images=[combined_image],
                    instruction_text=instruction,
                    temperature=temperature,
                    top_p=top_p,
                    max_new_tokens=max_new_tokens,
                )
            text = _clean_visual_gemma_text(text)
            if _looks_like_gemma_repeat_failure(text):
                raise ValueError(f"Gemma returned repeated/thought junk instead of usable Story reference notes for batch {batch_index}.")
            if text.strip():
                prefix = f"Reference batch {batch_index}: " if len(batches) > 1 else ""
                batch_notes.append(prefix + text.strip())
        return {"notes": "\n\n".join(batch_notes).strip(), "used_model": used_model, "used_mmproj": mmproj_path, "runner": "llm_api_vision" if text_runner == "llm_api" else "own_server_vision" if text_runner == "own_server" else "lm_studio_vision" if text_runner == "lm_studio" else "builtin", "unloaded": False if text_runner in _EXTERNAL_LLM_RUNNERS else unload_after, "batches": len(batches)}
    finally:
        if llm and unload_after:
            llm._unload_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            _clear_vrgdg_llm_caches(clear_cuda_cache=True, clear_hf_pipeline_cache=False)
            _clear_comfy_model_memory()


def _generate_nb_image_prompt(payload):
    from .LLM import VRGDG_SuperGemmaGGUFChat, _clear_vrgdg_llm_caches

    model_file = str(payload.get("model_file", "") or "").strip()
    mmproj_file = str(payload.get("mmproj_file", "") or "").strip()
    user_notes = str(payload.get("user_notes", "") or "").strip()
    prompt_mode = str(payload.get("prompt_mode", "nano_banana") or "nano_banana").strip().lower()
    is_flow_gpt = prompt_mode == "flow_gpt"
    default_instruction_key = "flow_gpt_t2i" if is_flow_gpt else "nano_b_t2i"
    default_instruction_text = _FLOW_GPT_T2I_INSTRUCTIONS if is_flow_gpt else _NANO_B_T2I_INSTRUCTIONS
    prompt_label = "Flow/GPT" if is_flow_gpt else "NanoBanana"
    builder_instruction_key = str(payload.get("builder_instruction_key") or payload.get("instruction_key") or default_instruction_key).strip()
    text_runner = _llm_runner_from_payload(payload)
    if text_runner not in _EXTERNAL_LLM_RUNNERS and not model_file:
        raise ValueError(f"Choose a {prompt_label} Gemma vision model first.")

    ingredients = payload.get("image_ingredients") or []
    if isinstance(ingredients, str):
        try:
            ingredients = json.loads(ingredients)
        except Exception:
            ingredients = [{"path": line.strip()} for line in ingredients.splitlines() if line.strip()]
    if not isinstance(ingredients, list):
        raise ValueError(f"{prompt_label} reference images must be a list.")
    images = []
    for index, item in enumerate(ingredients, start=1):
        if isinstance(item, str):
            item = {"path": item}
        if not isinstance(item, dict):
            continue
        images.append(_image_from_prompt_payload(item.get("path", ""), item.get("data", ""), f"{prompt_label} reference image {index}"))
    reference_context = payload.get("reference_context") or {}
    if not isinstance(reference_context, dict):
        reference_context = {}

    context_parts = []
    subject_description = str(reference_context.get("subject_description", "") or "").strip()
    location_name = str(reference_context.get("location_name", "") or "").strip()
    location_description = str(reference_context.get("location_description", "") or "").strip()
    has_subject_reference = bool(reference_context.get("has_subject_reference"))
    has_location_reference = bool(reference_context.get("has_location_reference"))
    try:
        subject_reference_count = int(float(reference_context.get("subject_reference_count") or 1)) if has_subject_reference else 0
    except (TypeError, ValueError):
        subject_reference_count = 1 if has_subject_reference else 0
    subject_reference_count = max(0, min(99, subject_reference_count))
    character_reference_phrase = "character reference images" if subject_reference_count > 1 else "character reference image"
    character_identity_phrase = "character identities from the character references" if subject_reference_count > 1 else "character identity from the character reference"

    if subject_description:
        context_parts.append(f"Subject description:\n{subject_description}")
    if location_name or location_description:
        context_parts.append(f"Location reference:\n{location_name}\n{location_description}".strip())
    if user_notes:
        context_parts.append(f"User input:\n{user_notes}")

    reference_flags = []
    if has_subject_reference:
        reference_flags.append(f"{subject_reference_count or 1} character reference image{'s are' if (subject_reference_count or 1) != 1 else ' is'} available.")
    if has_location_reference:
        reference_flags.append("A scene/location reference image is available.")
    if reference_flags:
        context_parts.append("\n".join(reference_flags))

    has_images = bool(images)
    has_unmapped_reference_images = has_images and not has_subject_reference and not has_location_reference

    def _cleanup_nb_reference_claims(text):
        text = str(text or "")
        fallback_reference = "Using the provided reference image" if has_images else "Create"
        if not has_subject_reference and not has_location_reference:
            text = re.sub(
                r"\bUsing the provided character reference and location reference\b",
                fallback_reference,
                text,
                flags=re.IGNORECASE,
            )
            text = re.sub(
                r"\bUsing the provided location reference and character reference\b",
                fallback_reference,
                text,
                flags=re.IGNORECASE,
            )
            text = re.sub(
                r"\bUsing the provided (?:character|location|scene) reference\b",
                fallback_reference,
                text,
                flags=re.IGNORECASE,
            )
        elif not has_location_reference:
            text = re.sub(
                r"\bUsing the provided character reference and location reference\b",
                f"Using the provided {character_reference_phrase}",
                text,
                flags=re.IGNORECASE,
            )
            text = re.sub(
                r"\bUsing the provided location reference and character reference\b",
                f"Using the provided {character_reference_phrase}",
                text,
                flags=re.IGNORECASE,
            )
            text = re.sub(r"\s+and (?:the\s+)?(?:provided\s+)?(?:location|scene) reference(?: image)?\b", "", text, flags=re.IGNORECASE)
        elif not has_subject_reference:
            text = re.sub(
                r"\bUsing the provided character reference and location reference\b",
                "Using the provided location reference",
                text,
                flags=re.IGNORECASE,
            )
            text = re.sub(
                r"\bUsing the provided location reference and character reference\b",
                "Using the provided location reference",
                text,
                flags=re.IGNORECASE,
            )
            text = re.sub(r"\s+and (?:the\s+)?(?:provided\s+)?character reference(?: image)?\b", "", text, flags=re.IGNORECASE)
            text = re.sub(r"\bcharacter reference(?: image)?\s+and\s+", "", text, flags=re.IGNORECASE)
        text = re.sub(r"\s+,", ",", text)
        text = re.sub(r"\s{2,}", " ", text)
        return text.strip()

    def _ensure_nb_reference_opening(text):
        text = str(text or "").strip()
        if not text:
            return text
        if has_subject_reference and has_location_reference:
            opening = f"Using the provided {character_reference_phrase} and location reference image"
        elif has_subject_reference:
            opening = f"Using the provided {character_reference_phrase}"
        elif has_location_reference:
            opening = "Using the provided location reference image"
        else:
            return text
        if re.search(r"\bUsing the provided (?:character|location|scene|reference image)", text, flags=re.IGNORECASE):
            return text
        if re.match(r"^(?:create|make|generate)\b", text, flags=re.IGNORECASE):
            text = re.sub(r"^(?:create|make|generate)\b\s*", "", text, count=1, flags=re.IGNORECASE)
        return f"{opening}, create {text[:1].lower()}{text[1:] if len(text) > 1 else ''}".strip()

    if has_subject_reference and has_location_reference:
        reference_prompt_rules = (
            f"- Start by mentioning both the provided {character_reference_phrase} and location reference image.\n"
            f"- Preserve the {character_identity_phrase}: face, hair, outfit, makeup, and overall identity.\n"
            "- Preserve the location identity from the location reference: environment, architecture, layout, atmosphere, and major visible setting details.\n"
            "- Use the user's scene/concept notes for action, pose, camera, mood, and story beat.\n"
            "- Do not paste the character into the location image.\n"
            "- Do not copy the exact pose, crop, camera angle, perspective, or composition from either reference.\n"
        )
        example_text = (
            f"Using the provided {character_reference_phrase} and location reference image, create a close-up profile shot of the woman in the misty forest. "
            f"Preserve {'the subjects identities, hair, outfits, makeup, and overall identity details from the character references' if subject_reference_count > 1 else 'her identity, hair, outfit, and crown from the character reference'} while using the forest reference for the white fibrous trees, mist, and eerie atmosphere. "
            "Use a new pose, new camera angle, soft bokeh, atmospheric haze, and dramatic rim lighting."
        )
    elif has_subject_reference:
        reference_prompt_rules = (
            f"- Start by mentioning only the provided {character_reference_phrase}. Do not mention a location reference image.\n"
            f"- Preserve the {character_identity_phrase}: face, hair, outfit, makeup, and overall identity.\n"
            "- Create the setting, background, atmosphere, and location from the user's scene/concept notes.\n"
            f"- Do not copy the {'character reference poses, studio backgrounds, crops, camera angles, or lens distances' if subject_reference_count > 1 else 'character reference pose, studio background, crop, camera angle, or lens distance'}.\n"
        )
        example_text = (
            f"Using the provided {character_reference_phrase}, create an intimate upper body shot of the woman in a misty white forest built from the scene concept. "
            f"Preserve {'the subjects identities, hair, outfits, and facial details' if subject_reference_count > 1 else 'her identity, blonde hair, lace outfit, and delicate facial details'} while placing the scene among pale gnarled trees, soft fog, shallow depth of field, and ethereal rim lighting."
        )
    elif has_location_reference:
        reference_prompt_rules = (
            "- Start by mentioning only the provided location reference. Do not mention a character reference.\n"
            "- Use the location reference for environment, architecture, layout, atmosphere, and major visible setting details.\n"
            "- Create any subject, pose, outfit, camera, and story details from the user's scene/concept notes.\n"
            "- Do not copy the exact location reference camera angle, framing, perspective, or composition.\n"
        )
        example_text = (
            "Using the provided location reference, create a cinematic medium shot of the scene's subject moving through the misty forest. "
            "Preserve the pale fibrous trees, narrow fog-covered path, and eerie atmosphere from the location reference while creating a new camera angle, new subject pose, soft bokeh, and dramatic haze."
        )
    elif has_unmapped_reference_images:
        reference_prompt_rules = (
            "- You may use the provided reference image or images only as loose visual guidance.\n"
            "- Do not call them character references or location references unless the context explicitly says that.\n"
            "- Use the user's scene/concept notes as the main source of subject, setting, action, pose, and mood.\n"
            "- Create a new camera angle, new pose, and new composition.\n"
        )
        example_text = (
            "Create a cinematic medium close-up from the scene concept, using the provided visual reference only as loose style guidance. "
            "Build the subject, setting, lighting, and atmosphere from the notes, with soft bokeh, layered haze, a new composition, and high cinematic detail."
        )
    else:
        reference_prompt_rules = (
            "- Do not mention provided references or reference images.\n"
            "- Treat this as normal text-to-image prompt writing from the user's scene/concept notes.\n"
            "- Create the subject, setting, action, pose, camera, lighting, and atmosphere from the notes.\n"
        )
        example_text = (
            "Create a cinematic medium close-up in a vast cosmic void filled with drifting pearlescent particles and soft ethereal light. "
            "Use a new composition, shallow depth of field, gentle atmospheric haze, luminous highlights, and a quiet dreamlike mood."
        )
    base_instructions = _effective_builder_instruction(payload, builder_instruction_key, default_instruction_text)
    instruction = (
        f"{base_instructions}\n\n"
        "Reference wording rules:\n"
        f"{reference_prompt_rules}"
        "\n"
        f"Good output example:\n{example_text}\n\n"
        f"{chr(10).join(context_parts) if context_parts else 'User input: Create a new image from the notes.'}"
    )

    n_ctx = int(payload.get("n_ctx") or 8000)
    n_gpu_layers = int(payload.get("n_gpu_layers") or 99)
    n_threads = int(payload.get("n_threads") or 8)
    chat_format = str(payload.get("chat_format", "") or "").strip()
    temperature = float(payload.get("temperature") or 0.25)
    top_p = float(payload.get("top_p") or 0.95)
    max_new_tokens = _runner_output_token_limit(payload, int(payload.get("max_new_tokens") or 900))
    seed = payload.get("seed")
    clear_before_load = bool(payload.get("clear_before_load", True))
    unload_after = bool(payload.get("unload_after", True))
    if not has_images:
        text, info = _run_builder_text_llm(
            payload,
            instruction,
            temperature=temperature,
            top_p=top_p,
            max_new_tokens=max_new_tokens,
            label=f"{prompt_label} text Gemma",
            preserve_paragraphs=False,
        )
        text = _clean_lm_studio_plain_text(text)
        if not text:
            raise ValueError(f"{prompt_label} Gemma returned an empty prompt.")
        text = _cleanup_nb_reference_claims(text)
        text = _ensure_nb_reference_opening(text)
        text = _repair_and_validate_builder_gemma_prompt(payload, text, prompt_label)
        return {"prompt": text, **info}

    combined_image = _combine_flux_ingredient_images(images)
    llm = _builder_local_llm(payload) if text_runner not in _EXTERNAL_LLM_RUNNERS else None
    model_file = _builder_local_model_file(payload, model_file)
    model_path = llm._resolve_dropdown_path(model_file, llm.MISSING_MODEL_OPTION) if llm else str(payload.get("lmstudio_model") or "").strip()
    mmproj_path = _resolve_mmproj_dropdown_path(llm, mmproj_file) if llm else ""
    try:
        if text_runner in _EXTERNAL_LLM_RUNNERS:
            text, info = _try_run_remote_vision(
                payload,
                instruction,
                [combined_image],
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
            )
        else:
            if clear_before_load:
                _clear_comfy_model_memory()
                _clear_vrgdg_llm_caches(clear_cuda_cache=True, clear_hf_pipeline_cache=False)
            model = llm._load_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            text = llm._run_gguf_vision_pipeline(
                model=model,
                pil_images=[combined_image],
                instruction_text=instruction,
                temperature=temperature,
                top_p=top_p,
                max_new_tokens=max_new_tokens,
                seed=int(seed) if seed is not None else None,
            )
            info = {
                "runner": "builtin",
                "used_model": model_path,
                "used_mmproj": mmproj_path,
                "unloaded": unload_after,
            }
    finally:
        if llm and unload_after:
            llm._unload_gguf_model(
                model_path=model_path,
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads,
                chat_format=chat_format,
                mmproj_path=mmproj_path,
            )
            _clear_vrgdg_llm_caches(clear_cuda_cache=True, clear_hf_pipeline_cache=False)
            _clear_comfy_model_memory()
    text = _clean_lm_studio_plain_text(text)
    text = re.sub(r"(?im)^CAMERA\s+COMPOSI+TION\s*\(PRIORITY\)", "CAMERA COMPOSITION (PRIORITY)", text)
    text = re.sub(r"(?im)^CHARACTER\s+REFEREN[CC]E\b", "CHARACTER REFERENCE", text)
    text = re.sub(r"(?im)^SCE+NE\s+REFEREN[CC]E\b", "SCENE REFERENCE", text)
    text = re.sub(r"\breference\s+imagae\b", "reference image", text, flags=re.IGNORECASE)
    text = re.sub(r"\breference\s+imagaes\b", "reference images", text, flags=re.IGNORECASE)
    text = _cleanup_nb_reference_claims(text)
    text = _ensure_nb_reference_opening(text)
    if not text:
        raise ValueError(f"{prompt_label} Gemma returned an empty prompt.")
    text = _repair_and_validate_builder_gemma_prompt(payload, text, prompt_label)
    return {"prompt": text, **info}


def _generate_flux_reference_location_map(payload):
    model_file = str(payload.get("model_file", "") or "").strip()
    if not model_file and _llm_runner_from_payload(payload) not in _EXTERNAL_LLM_RUNNERS:
        raise ValueError("Choose a non-vision Gemma model first.")

    scenes = payload.get("scenes") or []
    if not isinstance(scenes, list) or not scenes:
        raise ValueError("No scenes were provided for location mapping.")

    cleaned_scenes = []
    for index, scene in enumerate(scenes, start=1):
        if not isinstance(scene, dict):
            continue
        scene_id = str(scene.get("id", "") or f"scene_{index}").strip()
        label = str(scene.get("label", "") or f"Scene {index}").strip()
        concept = str(scene.get("concept", "") or "").strip()
        notes = str(scene.get("notes", "") or "").strip()
        if concept or notes:
            cleaned_scenes.append({
                "id": scene_id,
                "label": label,
                "concept": concept,
                "notes": notes,
            })
    if not cleaned_scenes:
        raise ValueError("Scenes need lyrics, scene notes, concept prompts, or timeline notes before Gemma can map locations.")

    subject_scene = _clean_location_context_text(payload.get("subject_scene_text", ""))
    style_theme = _clean_location_context_text(payload.get("style_theme", ""))
    subject_context = _clean_location_context_text(payload.get("subject_context", ""))
    existing_locations = payload.get("existing_locations") or []
    if not isinstance(existing_locations, list):
        existing_locations = []
    normalized_existing_locations = []
    seen_existing = set()
    existing_location_lines = []
    for item in existing_locations:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name", "") or "").strip()
        description = str(item.get("description", "") or "").strip()
        if name:
            key = name.lower()
            if key not in seen_existing:
                seen_existing.add(key)
                normalized_existing_locations.append({"name": re.sub(r"\s+", " ", name), "description": re.sub(r"\s+", " ", description)})
            existing_location_lines.append(f"- {name}" + (f": {description}" if description else ""))
    if not normalized_existing_locations:
        raise ValueError("Auto Map needs locations first. Click Extract Locations or add locations manually, then run Auto Map.")

    scene_lines = []
    for index, scene in enumerate(cleaned_scenes, start=1):
        scene_lines.append(
            f"Scene {index}\n"
            f"id: {scene['id']}\n"
            f"label: {scene['label']}\n"
            f"concept: {scene['concept']}\n"
            f"notes: {scene['notes']}"
        )

    numbered_locations = "\n".join(
        f"{index}={item['name']}" + (f" | {item['description']}" if item.get("description") else "")
        for index, item in enumerate(normalized_existing_locations, start=1)
    )
    previous_counts = _location_usage_counts_from_payload(payload, normalized_existing_locations)
    usage_lines = "\n".join(
        f"- {name}: already used {int(previous_counts.get(name, 0) or 0)} time(s)"
        for name in sorted(previous_counts, key=lambda item: (int(previous_counts.get(item, 0) or 0), item.lower()))
    )
    instruction = (
        "You are mapping music-video scenes to an existing location list.\n\n"
        "Choose the best existing location number for each scene using the scene lyric line, concept text, notes, visual mood, objects, and environment. "
        "First use a location clearly named or implied by the scene text. "
        "If the scene has no clear location, choose the closest fit from the location list based on emotional tone and visual atmosphere. "
        "Use locations that have not been used yet before repeating locations that were already used. "
        "Avoid repeating the same location across too many neighboring scenes when another listed location fits equally well.\n\n"
        "Output only simple lines in this exact format:\n"
        "Scene1=1\n"
        "Scene2=3\n"
        "Scene3=3\n\n"
        "Rules:\n"
        "- Every scene must get one line.\n"
        "- Use only location numbers from the list.\n"
        "- Prefer the least-used matching location when multiple locations fit.\n"
        "- If there are enough scenes, use every listed location at least once before heavy repeats.\n"
        "- Do not output JSON, markdown, bullets, explanations, names, or descriptions.\n"
        "- Do not invent new locations.\n\n"
        f"Optional extra context, if any:\n{subject_scene or '(none)'}\n\n"
        f"Already used locations before these scenes:\n{usage_lines or '(none)'}\n\n"
        f"Locations:\n{numbered_locations}\n\n"
        f"Scenes:\n\n{chr(10).join(scene_lines)}"
    )

    temperature = float(payload.get("temperature") or 0.25)
    top_p = float(payload.get("top_p") or 0.8)
    max_new_tokens = _runner_output_token_limit(payload, int(payload.get("max_new_tokens") or 5000))
    text, run_info = _run_builder_text_llm(
        payload,
        instruction,
        temperature=temperature,
        top_p=top_p,
        max_new_tokens=max_new_tokens,
        label="Gemma",
    )
    normalized_locations = normalized_existing_locations
    normalized_map = _parse_scene_location_number_map(text, cleaned_scenes, normalized_locations)
    if not normalized_map:
        normalized_map = _fallback_location_map_by_overlap(cleaned_scenes, normalized_locations)
    else:
        fallback_map = _fallback_location_map_by_overlap(cleaned_scenes, normalized_locations)
        for scene in cleaned_scenes:
            normalized_map.setdefault(scene["id"], fallback_map[scene["id"]])
    normalized_map = _balance_location_map_by_usage(normalized_map, cleaned_scenes, normalized_locations, previous_counts)
    return {
        "locations": normalized_locations,
        "scene_map": normalized_map,
        "raw_text": text,
        "used_model": run_info.get("used_model", ""),
        "runner": run_info.get("runner", "builtin"),
        "unloaded": run_info.get("unloaded", True),
    }


def _generate_flux_reference_locations(payload):
    model_file = str(payload.get("model_file", "") or "").strip()
    if not model_file and _llm_runner_from_payload(payload) not in _EXTERNAL_LLM_RUNNERS:
        raise ValueError("Choose a non-vision Gemma model first.")
    scenes = payload.get("scenes") or []
    if not isinstance(scenes, list) or not scenes:
        raise ValueError("No scenes were provided for location extraction.")
    cleaned_scenes = []
    for index, scene in enumerate(scenes, start=1):
        if not isinstance(scene, dict):
            continue
        concept = str(scene.get("concept", "") or "").strip()
        notes = str(scene.get("notes", "") or "").strip()
        if concept or notes:
            cleaned_scenes.append({
                "id": str(scene.get("id", "") or f"scene_{index}").strip(),
                "label": str(scene.get("label", "") or f"Scene {index}").strip(),
                "concept": concept,
                "notes": notes,
            })
    if not cleaned_scenes:
        raise ValueError("Scenes need lyrics, scene notes, concept prompts, or timeline notes before Gemma can extract locations.")

    subject_scene = _clean_location_context_text(payload.get("subject_scene_text", ""))
    style_theme = _clean_location_context_text(payload.get("style_theme", ""))
    subject_context = _clean_location_context_text(payload.get("subject_context", ""))
    existing_locations = payload.get("existing_locations") or []
    max_locations = max(1, min(50, int(payload.get("max_locations") or 8)))
    existing_lines = []
    if isinstance(existing_locations, list):
        for item in existing_locations:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name", "") or "").strip()
            description = str(item.get("description", "") or "").strip()
            if name:
                existing_lines.append(f"- {name}" + (f": {description}" if description else ""))

    scene_lines = []
    for index, scene in enumerate(cleaned_scenes, start=1):
        scene_lines.append(
            f"Scene {index}: {scene['label']}\n"
            f"concept: {scene['concept']}\n"
            f"notes: {scene['notes']}"
        )

    instruction = (
        "Extract a short reusable location list for Flux/Klein or Nano B reference images.\n\n"
        "Use the scene concept prompts and scene notes as the source of truth. "
        "Optional extra context may be empty; if it is empty or missing, ignore it completely. "
        "Use character/reference descriptions and style/theme only to understand the visual world, era, mood, genre, and design language. "
        "Do not turn characters, clothing, props, accessories, or body details into location names. "
        "Find concrete physical places, sets, rooms, buildings, landscapes, or backgrounds that repeat or are useful as references. "
        "If the extra context includes locations not directly named in a concept prompt, include them when they fit the project.\n\n"
        "Output only simple lines in this exact format:\n"
        "1|location name|short visual description for a reference image\n"
        "2|location name|short visual description for a reference image\n\n"
        "Rules:\n"
        "- Do not output JSON, markdown, bullets, headings, or explanations.\n"
        "- Keep names short, like bedroom, foggy white forest, salt-flat desert, ruined opera house.\n"
        "- Every name must be an actual place where the subject could stand, walk, sit, perform, or be filmed.\n"
        "- Do not output props, objects, clothing, accessories, body parts, people, characters, creatures, or symbolic items as locations.\n"
        "- Descriptions must describe only the place/background: architecture, layout, surfaces, lighting, weather, atmosphere, era, and color.\n"
        "- Do not include characters or actions in descriptions. No bride, woman, man, face, hand, tooth, dress, razor, locket, veil, or similar subject/object details.\n"
        "- Reuse broad locations instead of creating one unique location for every scene.\n"
        f"- Return no more than {max_locations} locations. Reuse broad locations instead of exceeding this maximum.\n\n"
        f"Optional style/theme guidance:\n{style_theme or '(none)'}\n\n"
        f"Character/reference descriptions for style guidance only:\n{subject_context or '(none)'}\n\n"
        f"Optional extra context:\n{subject_scene or '(none)'}\n\n"
        f"Existing user locations:\n{chr(10).join(existing_lines) if existing_lines else '(none)'}\n\n"
        f"Scenes:\n\n{chr(10).join(scene_lines)}"
    )
    text, run_info = _run_builder_text_llm(
        payload,
        instruction,
        temperature=float(payload.get("temperature") or 0.2),
        top_p=float(payload.get("top_p") or 0.8),
        max_new_tokens=int(payload.get("max_new_tokens") or 2200),
        label="Gemma",
    )
    locations = _parse_location_lines(text)
    if not locations:
        locations = _parse_location_ideas_flexible(text)
    if not locations:
        try:
            data = _extract_json_object_from_text(_clean_visual_gemma_text(text))
            raw_locations = data.get("locations") if isinstance(data, dict) else data
            if isinstance(raw_locations, list):
                for item in raw_locations:
                    if isinstance(item, dict):
                        raw_name = item.get("name", "")
                        name = _normalize_location_name(raw_name)
                        description = re.sub(r"\s+", " ", str(item.get("description", "") or "").strip())
                        if name:
                            name, description = _clean_location_card(name, description, raw_name)
                            if _valid_location_card(name, description):
                                locations.append({"name": name, "description": description})
        except Exception:
            pass
    if not locations:
        retry_instruction = (
            "Return only reusable music video filming locations from the scene text below.\n"
            "Do not explain anything.\n"
            "Do not summarize the scenes.\n"
            f"Write no more than {max_locations} locations.\n"
            "Write one location per line as a short bullet.\n"
            "Each bullet must be a concrete visual place/background where the subject could stand or move.\n"
            "Reject props, objects, clothing, accessories, people, body parts, symbolic items, and actions.\n"
            "Describe only the environment, not characters or objects from the lyrics.\n"
            "If any optional context is missing, invisible, empty, or unavailable, ignore that and use only the scene text.\n"
            "Never mention missing files, missing context, subjectsandscenes.txt, prompts, or instructions.\n"
            "Example format:\n"
            "- Abandoned motel pool, turquoise water under buzzing neon signs\n"
            "- Foggy pine road, wet asphalt and fading headlights\n\n"
            f"Optional style/theme guidance:\n{style_theme or '(none)'}\n\n"
            f"Character/reference descriptions for style guidance only:\n{subject_context or '(none)'}\n\n"
            f"Optional extra context:\n{subject_scene or '(none)'}\n\n"
            f"Existing user locations:\n{chr(10).join(existing_lines) if existing_lines else '(none)'}\n\n"
            f"Scenes:\n\n{chr(10).join(scene_lines)}"
        )
        retry_text, retry_info = _run_builder_text_llm(
            payload,
            retry_instruction,
            temperature=float(payload.get("temperature") or 0.35),
            top_p=float(payload.get("top_p") or 0.9),
            max_new_tokens=int(payload.get("max_new_tokens") or 2200),
            label="Gemma",
        )
        retry_locations = _parse_location_lines(retry_text) or _parse_location_ideas_flexible(retry_text)
        if retry_locations:
            text = retry_text
            run_info = retry_info
            locations = retry_locations
    if not locations:
        try:
            scout_payload = {
                **payload,
                "subject_scene_text": "",
                "style_theme": style_theme,
                "subject_context": subject_context,
                "lyrics_text": "\n\n".join(scene_lines),
                "user_input": "Create reusable location ideas from these music-video scene lines.",
                "temperature": float(payload.get("temperature") or 0.45),
                "top_p": float(payload.get("top_p") or 0.9),
                "max_new_tokens": int(payload.get("max_new_tokens") or 2200),
            }
            scout_result = _generate_wizard_locations_from_lyrics(scout_payload)
            locations = scout_result.get("locations") or []
            if locations:
                text = scout_result.get("raw_text", text)
                run_info = {
                    **run_info,
                    "used_model": scout_result.get("used_model", run_info.get("used_model", "")),
                    "runner": scout_result.get("runner", run_info.get("runner", "builtin")),
                    "unloaded": scout_result.get("unloaded", run_info.get("unloaded", True)),
                }
        except Exception:
            pass
    if not locations:
        preview = re.sub(r"\s+", " ", str(text or "")).strip()
        if len(preview) > 700:
            preview = preview[:697].rstrip() + "..."
        raise ValueError(f"Gemma did not return any usable locations. Raw response preview: {preview or '(empty)'}")
    deduped = []
    seen = set()
    for item in locations:
        raw_name = item.get("name", "")
        name, description = _clean_location_card(raw_name, item.get("description", ""), raw_name)
        if not _valid_location_card(name, description):
            continue
        key = name.lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append({"name": name, "description": description})
    if not deduped:
        preview = re.sub(r"\s+", " ", str(text or "")).strip()
        if len(preview) > 700:
            preview = preview[:697].rstrip() + "..."
        raise ValueError(f"Gemma returned only non-location items. Raw response preview: {preview or '(empty)'}")
    return {
        "locations": deduped[:max_locations],
        "raw_text": text,
        "used_model": run_info.get("used_model", ""),
        "runner": run_info.get("runner", "builtin"),
        "unloaded": run_info.get("unloaded", True),
    }


def _generate_wizard_locations_from_lyrics(payload):
    model_file = str(payload.get("model_file", "") or "").strip()
    if not model_file and _llm_runner_from_payload(payload) not in _EXTERNAL_LLM_RUNNERS:
        raise ValueError("Choose a non-vision Gemma model first.")
    lyrics_text = str(payload.get("lyrics_text", "") or payload.get("lyrics", "") or "").strip()
    user_input = str(payload.get("user_input", "") or payload.get("notes", "") or "").strip()
    style_theme = _clean_location_context_text(payload.get("style_theme", ""))
    subject_context = _clean_location_context_text(payload.get("subject_context", ""))
    max_locations = max(1, min(50, int(payload.get("max_locations") or 8)))
    if not lyrics_text:
        raise ValueError("Paste or create lyrics before creating locations from lyrics.")

    existing_locations = payload.get("existing_locations") or []
    existing_lines = []
    if isinstance(existing_locations, list):
        for item in existing_locations:
            if not isinstance(item, dict):
                continue
            name = re.sub(r"\s+", " ", str(item.get("name", "") or "").strip())
            description = re.sub(r"\s+", " ", str(item.get("description", "") or "").strip())
            if name:
                existing_lines.append(f"- {name}" + (f": {description}" if description else ""))

    instruction = (
        "You are a music video location scout.\n\n"
        "The user will provide song lyrics.\n\n"
        "Your task is to analyze the mood, imagery, setting clues, themes, and emotional tone of the lyrics, "
        "then generate a list of reusable filming locations where the main subject or character could be placed.\n\n"
        "Return only actual locations, sets, rooms, buildings, outdoor areas, roads, stages, landscapes, or environments.\n\n"
        "Use character/reference descriptions and style/theme only to understand the visual world, era, mood, genre, and design language. "
        "Do not turn characters, clothing, props, accessories, or body details into location names.\n\n"
        "Rules:\n\n"
        "Do not summarize the lyrics.\n"
        "Do not explain the song meaning.\n"
        "Do not quote long lyric sections.\n"
        "Focus on visual places that could realistically appear in a music video and hold the subject.\n"
        "Include literal locations from the lyrics and cinematic locations inspired by the mood, but they must still be real places.\n"
        "Do not output props, objects, clothing, accessories, body parts, people, characters, creatures, or symbolic items as locations.\n"
        "Bad location names: Vintage shaving kit, Ornate sugar bowl, Lace veil, Silver frame, Human tooth, Ghostly face, Tattered dress.\n"
        "Good location names: Grand ballroom, Dark wood study, Steamy bathroom, Overgrown garden, Dimly lit hallway, Empty stage.\n"
        "Descriptions must describe only the place: architecture, layout, surfaces, lighting, weather, atmosphere, era, and color.\n"
        "Do not include characters or actions in descriptions. No bride, woman, man, face, hand, tooth, dress, razor, locket, veil, or similar subject/object details.\n"
        "Test every idea: could the selected subject stand, walk, sit, perform, or be filmed inside this place? If no, reject it.\n"
        "Make the locations specific and cinematic.\n"
        f"Output no more than {max_locations} locations. Prefer reusable locations rather than one location per scene.\n"
        "Use short bullet points.\n"
        "Each bullet should be a place only, with a brief visual detail if helpful.\n\n"
        "Output format:\n\n"
        "Music Video Locations:\n\n"
        "- [location idea]\n"
        "- [location idea]\n"
        "- [location idea]\n\n"
        f"Existing user locations to avoid duplicating exactly:\n{chr(10).join(existing_lines) if existing_lines else '(none)'}\n\n"
        f"Optional style/theme guidance:\n{style_theme or '(none)'}\n\n"
        f"Character/reference descriptions for style guidance only:\n{subject_context or '(none)'}\n\n"
        f"Optional user input:\n{user_input or '(none)'}\n\n"
        f"User lyrics:\n{lyrics_text}"
    )
    text, run_info = _run_builder_text_llm(
        payload,
        instruction,
        temperature=float(payload.get("temperature") or 0.45),
        top_p=float(payload.get("top_p") or 0.9),
        max_new_tokens=int(payload.get("max_new_tokens") or 2200),
        label="Gemma",
    )
    locations = _parse_location_ideas_flexible(text)
    if not locations:
        retry_instruction = (
            f"Return no more than {max_locations} reusable music video filming locations for the lyrics below.\n"
            "Do not write a heading.\n"
            "Do not explain anything.\n"
            "Do not summarize the lyrics.\n"
            "Write one location per line as a short bullet.\n"
            "Each bullet must be a specific cinematic place where the subject could stand, walk, sit, perform, or be filmed.\n"
            "Reject props, objects, clothing, accessories, body parts, people, characters, creatures, symbolic items, and actions.\n"
            "Descriptions must describe only the place/background, not characters or objects from the lyrics.\n"
            "Example format:\n"
            "- Abandoned motel pool, turquoise water under buzzing neon signs\n"
            "- Foggy pine road, wet asphalt and fading headlights\n\n"
            f"Optional style/theme guidance:\n{style_theme or '(none)'}\n\n"
            f"Character/reference descriptions for style guidance only:\n{subject_context or '(none)'}\n\n"
            f"Optional user input:\n{user_input or '(none)'}\n\n"
            f"Lyrics:\n{lyrics_text}"
        )
        retry_text, retry_info = _run_builder_text_llm(
            payload,
            retry_instruction,
            temperature=float(payload.get("temperature") or 0.55),
            top_p=float(payload.get("top_p") or 0.9),
            max_new_tokens=int(payload.get("max_new_tokens") or 2200),
            label="Gemma",
        )
        retry_locations = _parse_location_ideas_flexible(retry_text)
        if retry_locations:
            text = retry_text
            run_info = retry_info
            locations = retry_locations
    if not locations:
        locations = _parse_location_lines(text)
    if not locations:
        preview = re.sub(r"\s+", " ", str(text or "")).strip()
        if len(preview) > 700:
            preview = preview[:697].rstrip() + "..."
        raise ValueError(f"Gemma did not return any usable location ideas. Raw response preview: {preview or '(empty)'}")
    deduped = []
    seen = set()
    for item in locations:
        raw_name = item.get("name", "")
        name, description = _clean_location_card(raw_name, item.get("description", ""), raw_name)
        if not _valid_location_card(name, description):
            continue
        key = name.lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append({"name": name, "description": description})
    if not deduped:
        preview = re.sub(r"\s+", " ", str(text or "")).strip()
        if len(preview) > 700:
            preview = preview[:697].rstrip() + "..."
        raise ValueError(f"Gemma returned only non-location items. Raw response preview: {preview or '(empty)'}")
    return {
        "locations": deduped[:max_locations],
        "raw_text": text,
        "used_model": run_info.get("used_model", ""),
        "runner": run_info.get("runner", "builtin"),
        "unloaded": run_info.get("unloaded", True),
    }


def _generate_flux_reference_subjects(payload):
    model_file = str(payload.get("model_file", "") or "").strip()
    if not model_file and _llm_runner_from_payload(payload) not in _EXTERNAL_LLM_RUNNERS:
        raise ValueError("Choose a non-vision Gemma model first.")
    scenes = payload.get("scenes") or []
    if not isinstance(scenes, list) or not scenes:
        raise ValueError("No scenes were provided for subject extraction.")
    cleaned_scenes = []
    scene_note_fallbacks = _load_scene_notes_json(payload.get("project_folder", ""))
    for index, scene in enumerate(scenes, start=1):
        if not isinstance(scene, dict):
            continue
        concept = str(scene.get("concept", "") or "").strip()
        notes = str(scene.get("notes", "") or "").strip()
        director_note = str(scene.get("director_note", "") or "").strip() or scene_note_fallbacks.get(index, "")
        if concept or notes or director_note:
            cleaned_scenes.append({
                "id": str(scene.get("id", "") or f"scene_{index}").strip(),
                "label": str(scene.get("label", "") or f"Scene {index}").strip(),
                "concept": concept,
                "notes": notes,
                "director_note": director_note,
            })
    if not cleaned_scenes:
        raise ValueError("Scenes need concept prompt text, notes, or Director Notes before Gemma can extract subjects.")

    requested_count = max(2, min(12, int(payload.get("requested_count") or 2)))
    subject_scene = str(payload.get("subject_scene_text", "") or "").strip()
    existing_subjects = payload.get("existing_subjects") or []
    existing_lines = []
    if isinstance(existing_subjects, list):
        for item in existing_subjects:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name", "") or "").strip()
            description = str(item.get("description", "") or "").strip()
            if name and description:
                existing_lines.append(f"- {name}: {description}")

    scene_lines = []
    for index, scene in enumerate(cleaned_scenes, start=1):
        scene_lines.append(
            f"Scene {index}: {scene['label']}\n"
            f"concept: {scene['concept']}\n"
            f"notes: {scene['notes']}\n"
            f"director_note: {scene['director_note']}"
        )

    instruction = (
        "Extract reusable character/subject identities for reference images.\n\n"
        "Look at the scene concept prompts, notes, Director Notes, and subject/scene context. "
        "Find distinct recurring people, creatures, mascots, or main visual subjects that may need separate reference images. "
        f"The user expects about {requested_count} character references if the project supports that count.\n\n"
        "Output only simple lines in this exact format:\n"
        "1|character name|short visual description for a character reference image\n"
        "2|character name|short visual description for a character reference image\n\n"
        "Rules:\n"
        "- Do not output JSON, markdown, bullets, headings, or explanations.\n"
        "- Keep names short and stable, like blonde woman, masked man, young singer, red android.\n"
        "- Descriptions must describe identity, face/body, hair, outfit, colors, and visual consistency details.\n"
        "- Do not describe locations as characters.\n"
        "- If two characters appear together in a scene, list them as separate characters, not one combined subject.\n\n"
        f"Subject/scene context:\n{subject_scene or '(none)'}\n\n"
        f"Existing user subjects:\n{chr(10).join(existing_lines) if existing_lines else '(none)'}\n\n"
        f"Scenes:\n\n{chr(10).join(scene_lines)}"
    )
    text, run_info = _run_builder_text_llm(
        payload,
        instruction,
        temperature=float(payload.get("temperature") or 0.2),
        top_p=float(payload.get("top_p") or 0.8),
        max_new_tokens=int(payload.get("max_new_tokens") or 2200),
        label="Gemma",
    )
    subjects = _parse_subject_lines(text)
    if not subjects:
        raise ValueError("Gemma did not return any usable subjects.")
    deduped = []
    seen = set()
    for item in subjects:
        key = item["name"].lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return {
        "subjects": deduped,
        "raw_text": text,
        "used_model": run_info.get("used_model", ""),
        "runner": run_info.get("runner", "builtin"),
        "unloaded": run_info.get("unloaded", True),
    }


def _generate_flux_reference_zimage_prompt(payload):
    model_file = str(payload.get("model_file", "") or "").strip()
    reference_type = str(payload.get("reference_type", "") or "").strip().lower()
    source_text = str(payload.get("source_text", "") or "").strip()
    style_theme = str(payload.get("style_theme", "") or "").strip()
    if reference_type not in {"subject", "location"}:
        raise ValueError("Reference type must be subject or location.")
    if not model_file and _llm_runner_from_payload(payload) not in _EXTERNAL_LLM_RUNNERS:
        raise ValueError("Choose a non-vision Gemma model first.")
    if not source_text:
        raise ValueError("Enter a subject or location description first.")

    if reference_type == "subject":
        instruction = (
            "Create one text-to-image prompt for a character reference sheet.\n\n"
            "The user input may be a simple subject description or a structured character-creation brief with sections such as generation mode, subject label, reference type, existing description, lyrics, song style, gender/role, reference image notes, and extra user direction. "
            "When lyrics or song style are provided, use them to invent or refine the character's identity, wardrobe, era, mood, expression, and visual design. Do not quote lyrics or make the final prompt a lyric scene. "
            "When an existing description or reference image notes are provided, preserve those explicit identity details and use lyrics/style only as supporting visual influence.\n\n"
            "The image must contain the same character shown three times in one image, with clearly different camera distances:\n"
            "1. Left panel: extreme close-up face portrait only, from top of hair to just below the chin. The face fills 80-90% of the panel. No shoulders, chest, torso, hands, or outfit details visible except maybe a tiny neckline.\n"
            "2. Center panel: upper-body waist-up portrait, from head to waist. Face, shoulders, chest, arms, and main outfit details visible.\n"
            "3. Right panel: full-body standing view, from head to shoes. Entire outfit, body proportions, legs, and feet visible.\n\n"
            "All three views must show the same person with consistent face, hair, outfit, colors, body type, and identity. "
            "Use a clean neutral studio background. The character should face forward or mostly forward. Keep lighting clear and even. "
            "Do not make the left and center panels the same crop. Do not create a cinematic scene, action pose, environment, story moment, props, text labels, captions, logos, watermarks, or multiple different characters.\n\n"
            "Use this exact output structure:\n\n"
            "A clean three-panel character reference sheet on a neutral studio background, showing the same [subject] in all panels with consistent [face/hair/body/outfit/identity details]. "
            "Left panel: extreme close-up face-only portrait, top of hair to just below chin, face fills 80-90% of the panel, no shoulders, no chest, no torso. "
            "Center panel: upper-body waist-up portrait from head to waist, showing shoulders, chest, arms, and outfit details. "
            "Right panel: full-body standing view from head to shoes, entire outfit and feet visible. "
            "Each panel uses a clearly different camera distance: face-only close-up, waist-up portrait, full-body standing. "
            "Clear even lighting, front-facing pose, consistent outfit colors and body proportions, detailed character design, no text, no labels, no props, no environment.\n\n"
            "Rules:\n"
            "- Output only one polished text-to-image prompt.\n"
            "- Do not include markdown, labels, quotes, explanations, or multiple options.\n"
            "- Keep it as one single image containing three views of the same character.\n"
            "- The left panel must be face-only, not another upper-body portrait.\n"
            "- Preserve the subject identity from the user input.\n\n"
            f"Subject creation brief:\n{source_text}\n\n"
            f"Optional global style/theme:\n{style_theme or '(none)'}"
        )
    else:
        instruction = (
            "Create one text-to-image prompt for a reusable location reference image.\n\n"
            "The image must show only the physical environment/location. Do not include the main character, people, animals, readable text, captions, logos, watermarks, or story action.\n\n"
            "Important: if the input, style/theme, or surrounding context mentions a character reference sheet, white/neutral studio background, plain backdrop, panel layout, close-up portrait, upper-body portrait, or full-body character view, treat those as character-reference-sheet artifacts only. "
            "Do not turn those artifacts into the location. Do not create a white studio, neutral studio, seamless photo backdrop, blank room, or character-sheet background unless the user explicitly names that as the intended location.\n\n"
            "Use this exact output structure:\n\n"
            "A clear cinematic environment reference image of [location/environment], showing [layout/architecture], [important furniture/props/objects], [lighting details], [colors/materials/textures], and [atmosphere]. "
            "Wide enough framing to understand the space layout, [time of day/weather if relevant], no people, no animals, no readable text, no logos, no captions.\n\n"
            "Rules:\n"
            "- Output only one polished text-to-image prompt.\n"
            "- Do not include markdown, labels, quotes, explanations, or multiple options.\n"
            "- Do not include the main character.\n"
            "- Do not describe a music video action.\n"
            "- Keep it as a reusable setting/reference image.\n"
            "- Preserve the location identity from the user input.\n"
            "- Ignore character-sheet backgrounds, panel layouts, and portrait crops when inventing the setting.\n"
            "- Use the optional style/theme only for visual mood, lighting, color, or texture.\n\n"
            f"Location description:\n{source_text}\n\n"
            f"Optional global style/theme:\n{style_theme or '(none)'}"
        )

    temperature = float(payload.get("temperature") or 0.25)
    top_p = float(payload.get("top_p") or 0.8)
    max_new_tokens = _runner_output_token_limit(payload, int(payload.get("max_new_tokens") or 900))

    text, run_info = _run_builder_text_llm(
        payload,
        instruction,
        temperature=temperature,
        top_p=top_p,
        max_new_tokens=max_new_tokens,
        label="Gemma",
    )
    text = _clean_visual_gemma_text(text)
    _validate_builder_gemma_prompt(text, f"Flux/Klein {reference_type} reference")
    return {
        "prompt": text,
        "used_model": run_info.get("used_model", ""),
        "runner": run_info.get("runner", "builtin"),
        "unloaded": run_info.get("unloaded", True),
    }


def _gemma_choices():
    register_custom_model_root()
    from .LLM import VRGDG_SuperGemmaGGUFChat, VRGDG_QwenGGUF

    return {
        "models": VRGDG_SuperGemmaGGUFChat._list_local_gemma_gguf_choices(),
        "mmproj": VRGDG_SuperGemmaGGUFChat._list_local_mmproj_choices(),
        "qwen_models": VRGDG_QwenGGUF._list_local_qwen_gguf(),
        "qwen_mmproj": VRGDG_QwenGGUF._list_local_qwen_mmproj(),
    }


_MODEL_DEFAULT_KEYS = (
    "text_gemma_runner",
    "qwen_model_file",
    "qwen_mmproj_file",
    "gemma_model_file",
    "llm_max_tokens",
    "gemma_context_limit",
    "gemma_output_token_limit",
    "gemma_gpu_layers",
    "lm_studio_base_url",
    "lm_studio_model",
    "lm_studio_api_key",
    "lm_studio_context_limit",
    "lm_studio_output_token_limit",
    "image_model_mode",
    "zimage_settings",
    "reference_krea2_settings",
    "flux_klein_settings",
    "ernie_image_settings",
    "krea2_2pass_settings",
    "z_enhance_settings",
    "video_model_mode",
    "i2v_video_settings",
)


def _model_defaults_path():
    defaults_folder = os.path.join(folder_paths.get_output_directory(), "VRGDG_Model_Defaults")
    os.makedirs(defaults_folder, exist_ok=True)
    return os.path.join(defaults_folder, "model_defaults.json")


def _scrub_model_defaults_project_sources(defaults):
    if not isinstance(defaults, dict):
        return {}
    cleaned = json.loads(json.dumps(defaults))
    for key in ("zimage_settings", "ernie_image_settings", "krea2_2pass_settings"):
        settings = cleaned.get(key)
        if not isinstance(settings, dict):
            continue
        settings["use_image_to_image"] = False
        settings["image_to_image_path"] = ""
        settings["image_to_image_data"] = ""
        settings["image_to_image_name"] = ""
    return cleaned


def _extract_model_defaults(session):
    if not isinstance(session, dict):
        return {}
    defaults = {}
    for key in _MODEL_DEFAULT_KEYS:
        value = session.get(key)
        if value is not None:
            defaults[key] = value
    return _scrub_model_defaults_project_sources(defaults)


def _save_model_defaults(session):
    defaults = _extract_model_defaults(session)
    if not defaults:
        return ""
    target = _model_defaults_path()
    payload = {
        "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "defaults": defaults,
    }
    with open(target, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)
        handle.write("\n")
    return target


def _load_model_defaults():
    target = _model_defaults_path()
    if not os.path.isfile(target):
        return {"path": target, "defaults": {}, "saved_at": ""}
    with open(target, "r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        payload = {}
    defaults = payload.get("defaults")
    if not isinstance(defaults, dict):
        defaults = {}
    defaults = _scrub_model_defaults_project_sources(defaults)
    return {
        "path": target,
        "defaults": defaults,
        "saved_at": str(payload.get("saved_at", "") or ""),
    }


def _write_scene_notes_json(project_folder, segments):
    notes = {}
    for index, segment in enumerate(segments if isinstance(segments, list) else [], start=1):
        if isinstance(segment, dict):
            notes[f"SceneNote{index}"] = str(segment.get("timeline_note", "") or "")
    path = _scene_notes_path(project_folder)
    _atomic_write_json(path, notes)
    return path


def _load_scene_notes_json(project_folder):
    folder = os.path.abspath(str(project_folder or "").strip().strip('"'))
    if not folder:
        return {}
    path = _scene_notes_path(folder)
    if not os.path.isfile(path):
        return {}
    with open(path, "r", encoding="utf-8-sig", errors="replace") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        return {}
    notes = {}
    for raw_key, raw_value in data.items():
        match = re.search(r"(\d+)", str(raw_key or ""))
        if match:
            notes[int(match.group(1))] = str(raw_value or "").strip()
    return notes


def _save_reference_descriptions(project_folder, session):
    """Expose Reference Builder descriptions as portable project assets."""
    refs = session.get("flux_reference_builder") if isinstance(session, dict) else None
    if not isinstance(refs, dict):
        return ""
    root = os.path.join(os.path.abspath(project_folder), "subject_location")
    subject_dir = os.path.join(root, "subject")
    location_dir = os.path.join(root, "location")
    os.makedirs(subject_dir, exist_ok=True)
    os.makedirs(location_dir, exist_ok=True)
    # Keep the complete normalized catalog, including image paths and every
    # scene mapping.  The text files below remain convenient human-editable
    # exports, while this manifest is the lossless restore source.
    manifest = json.loads(json.dumps(refs, ensure_ascii=False))
    manifest.setdefault("subjects", [])
    manifest.setdefault("locations", [])
    for manifest_key, folder in (("subjects", subject_dir), ("locations", location_dir)):
        items = refs.get(manifest_key) if isinstance(refs.get(manifest_key), list) else []
        for index, item in enumerate(items, start=1):
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or f"{manifest_key[:-1].title()} {index}").strip()
            description = str(item.get("description") or "").strip()
            _atomic_write_text(os.path.join(folder, f"{_safe_project_name(name)}.txt"), description + ("\n" if description else ""))
    manifest_path = os.path.join(root, "reference_descriptions.json")
    _atomic_write_json(manifest_path, manifest)
    return manifest_path


def _write_minimax_project_index(project_folder, session):
    """Write a human-readable map of MiniMax project files and session fields."""
    if str(session.get("video_engine", "") or "").strip().lower() != "minimax_h3":
        return ""
    path = os.path.join(os.path.abspath(project_folder), "MINIMAX_PROJECT_FILES.md")
    content = """# MiniMax H3 project files

Generated by the Video Builder. The session JSON is the source of truth for MiniMax prompts and settings.

## Primary MiniMax data

- `vrgdg_builder_session.json` — project `video_engine`, `minimax_h3_settings`, two/three-pass flags, and per-scene `minimax_h3_prompt`, mode, audio mode, references, continuity, stage outputs, and render history.
- `subject_location/reference_descriptions.json` — portable character and location names, IDs, and descriptions.
- `subject_location/subject/<name>.txt` — one character/subject description per file.
- `subject_location/location/<name>.txt` — one location description per file.

## References and audio

- `project_context/flux_references/subjects/` — character reference images.
- `project_context/flux_references/locations/` — location reference images.
- `project_context/flux_references/ingredients_sheets/` — ingredient/reference sheets when used.
- `project_audio/` — project/global audio copied into the project.
- `scene_audio/` — scene audio assets, including MiniMax scene audio when applicable.
- `scene_audio_trimmed/` — trimmed scene-audio derivatives when created.

## Rendered MiniMax outputs

- `rendered_scene_videos/video_####-audio.mp4` — final per-scene clips.
- `rendered_scene_videos_backup/scene_####/` — replaced/backed-up scene clips.
- `scene_video_thumbnails/` — rendered clip thumbnails.
- `render_logs/` — MiniMax render progress and diagnostics.

## Not MiniMax-specific

- `prompts/t2i_prompts.txt` — image-generation prompts.
- `prompts/i2v_prompts.txt` — LTX image-to-video prompts; MiniMax prompts are in the session JSON.
- `builder_segments.srt`, `SceneNotes.json`, and other shared context files.
"""
    _atomic_write_text(path, content)
    return path

def _save_builder_session_unlocked(payload):
    audio_raw = str(payload.get("audio_path", "") or "").strip().strip('"')
    audio_path = _resolve_existing_file(audio_raw, "Audio file") if audio_raw else ""
    project_folder = str(payload.get("project_folder", "") or "").strip().strip('"')
    if not project_folder:
        if audio_path:
            project_folder = _default_project_folder(audio_path, payload.get("project_name", ""))
        else:
            project_name = payload.get("project_name", "") or f"VRGDG_Project_{time.strftime('%Y%m%d_%H%M%S')}"
            project_folder = os.path.join(folder_paths.get_output_directory(), _safe_project_name(project_name))
    project_folder = os.path.abspath(project_folder)
    os.makedirs(project_folder, exist_ok=True)
    os.makedirs(_images_folder(project_folder), exist_ok=True)
    os.makedirs(_prompts_folder(project_folder), exist_ok=True)
    os.makedirs(_context_folder(project_folder), exist_ok=True)

    session = dict(payload.get("session")) if isinstance(payload.get("session"), dict) else {}
    segments = session.get("segments", [])
    if not isinstance(segments, list):
        segments = []
    session_path = _session_path(project_folder)
    if isinstance(payload.get("project_context_files"), dict):
        session["project_context_files"] = dict(payload["project_context_files"])
    incoming_revision = int(session.get("builder_save_revision") or 0)
    if incoming_revision > 0 and os.path.isfile(session_path):
        try:
            with open(session_path, "r", encoding="utf-8-sig") as handle:
                existing_session = json.load(handle)
            existing_revision = int(existing_session.get("builder_save_revision") or 0) if isinstance(existing_session, dict) else 0
            if existing_revision > incoming_revision:
                print(
                    "[VRGDG Music Builder] Ignored stale session snapshot: "
                    f"incoming revision {incoming_revision} < saved revision {existing_revision}."
                )
                session = existing_session
                segments = session.get("segments", []) if isinstance(session.get("segments"), list) else []
        except (OSError, TypeError, ValueError, json.JSONDecodeError) as exc:
            print(f"[VRGDG Music Builder] Save revision check skipped: {exc}")
    # Autosave requests can race a reference-builder panel update. If the
    # incoming snapshot has a null catalog, retain the last known catalog
    # instead of turning a valid project into a prompt-only project.
    if session.get("flux_reference_builder") is None and os.path.isfile(session_path):
        try:
            with open(session_path, "r", encoding="utf-8-sig") as handle:
                previous = json.load(handle)
            previous_refs = previous.get("flux_reference_builder") if isinstance(previous, dict) else None
            if isinstance(previous_refs, dict):
                session["flux_reference_builder"] = previous_refs
        except Exception as exc:
            print(f"[VRGDG Music Builder] Previous reference-builder state could not be recovered: {exc}")
    overlay_segments = session.get("overlay_segments", [])
    if not isinstance(overlay_segments, list):
        overlay_segments = []
        session["overlay_segments"] = overlay_segments
    overlay_segments = _assign_overlay_scene_numbers(overlay_segments)
    audio_path, session = _snapshot_project_assets(project_folder, session, audio_path)
    session = {
        **session,
        "audio_path": audio_path,
        "project_folder": project_folder,
        "updated": time.time(),
        "segments": segments,
    }

    # The complete text pasted into Line Mapper/Auto Build is the project's
    # canonical lyric source. Never rebuild this file from timestamped scene
    # notes because those notes legitimately contain detected instrumental gaps
    # and may split or repeat song sections.
    lyric_mapper = session.get("lyric_mapper") if isinstance(session.get("lyric_mapper"), dict) else {}
    full_lyrics_path = _save_canonical_full_lyrics(project_folder, lyric_mapper.get("source_text"))

    srt_text = _segments_to_srt(segments)
    _backup_session_file(project_folder)
    _atomic_write_text(_srt_path(project_folder), srt_text)
    context_paths = _save_project_context_files(project_folder, session)
    reference_descriptions_path = _save_reference_descriptions(project_folder, session)
    minimax_project_index_path = _write_minimax_project_index(project_folder, session)
    model_defaults_path = _save_model_defaults(session)
    scene_notes_path = _write_scene_notes_json(project_folder, segments)

    t2i_lines = []
    i2v_lines = []
    for segment in sorted(list(segments) + list(overlay_segments), key=lambda item: float(item.get("start", 0) or 0)):
        if str(segment.get("t2i_prompt", "")).strip():
            t2i_lines.append(str(segment.get("t2i_prompt", "")).strip())
        if str(segment.get("i2v_prompt", "")).strip():
            i2v_lines.append(str(segment.get("i2v_prompt", "")).strip())
    _atomic_write_text(os.path.join(_prompts_folder(project_folder), "t2i_prompts.txt"), "\n\n".join(t2i_lines).strip() + ("\n" if t2i_lines else ""))
    _atomic_write_text(os.path.join(_prompts_folder(project_folder), "i2v_prompts.txt"), "\n\n".join(i2v_lines).strip() + ("\n" if i2v_lines else ""))
    # The session is the transaction commit marker. All derived project files
    # are atomically replaced first, then the canonical session is replaced
    # last so a failed save cannot advertise an uncommitted snapshot.
    _atomic_write_json(_session_path(project_folder), session)
    _validate_saved_project(project_folder, session, context_paths)

    return {
        "project_folder": project_folder,
        "session_path": _session_path(project_folder),
        "srt_path": _srt_path(project_folder),
        "images_folder": _images_folder(project_folder),
        "prompts_folder": _prompts_folder(project_folder),
        "context_folder": _context_folder(project_folder),
        "context_paths": context_paths,
        "full_lyrics_path": full_lyrics_path,
        "model_defaults_path": model_defaults_path,
        "scene_notes_path": scene_notes_path,
        "reference_descriptions_path": reference_descriptions_path,
        "minimax_project_index_path": minimax_project_index_path,
        "session": session,
    }


def _save_builder_session(payload):
    # Autosave, Quick Save, and Reference Builder Save share this transaction.
    # Serialize them so their individually atomic file replacements cannot
    # interleave into a mixed-generation project snapshot.
    with _BUILDER_SAVE_LOCK:
        return _save_builder_session_unlocked(payload)


def _prepare_builder_project_export(project_folder):
    project_folder = os.path.abspath(str(project_folder or "").strip().strip('"'))
    session_path = _session_path(project_folder)
    if not os.path.isdir(project_folder) or not os.path.isfile(session_path):
        raise FileNotFoundError("The Builder project or its session file was not found.")
    with open(session_path, "r", encoding="utf-8") as handle:
        session = json.load(handle)
    if not isinstance(session, dict):
        raise ValueError("The Builder project session is invalid.")

    # Pull any still-external scene assets into the project before packaging it.
    old_project_folder = str(session.get("project_folder", "") or project_folder)
    session = _copy_session_assets_to_project(project_folder, session)
    portable_folder = os.path.join(project_folder, "portable_assets")
    portable_extensions = {
        ".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp",
        ".mp4", ".mov", ".mkv", ".webm", ".avi",
        ".wav", ".mp3", ".m4a", ".flac", ".ogg",
        ".srt", ".txt", ".json", ".csv",
    }
    copied_external_paths = {}

    def localize_external_assets(value, key_path="asset"):
        if isinstance(value, dict):
            return {key: localize_external_assets(item, f"{key_path}_{key}") for key, item in value.items()}
        if isinstance(value, list):
            return [localize_external_assets(item, f"{key_path}_{index + 1}") for index, item in enumerate(value)]
        if not isinstance(value, str):
            return value
        source = value.strip().strip('"')
        if not os.path.isabs(source) or not os.path.isfile(source):
            return value
        try:
            if os.path.commonpath([project_folder, os.path.abspath(source)]) == project_folder:
                return os.path.abspath(source)
        except ValueError:
            pass
        extension = os.path.splitext(source)[1].lower()
        if extension not in portable_extensions:
            return value
        source_key = os.path.normcase(os.path.abspath(source))
        if source_key in copied_external_paths:
            return copied_external_paths[source_key]
        safe_key = re.sub(r"[^A-Za-z0-9_.-]+", "_", key_path).strip("._")[-80:] or "asset"
        safe_base = re.sub(r"[^A-Za-z0-9_.-]+", "_", os.path.basename(source)).strip("._") or f"file{extension}"
        destination = os.path.join(portable_folder, f"{len(copied_external_paths) + 1:04d}_{safe_key}_{safe_base}")
        copied = _copy_file_if_exists(source, destination)
        if copied:
            copied_external_paths[source_key] = copied
            return copied
        return value

    session = localize_external_assets(session, "session")
    session = _rebase_project_owned_paths(project_folder, old_project_folder, session)
    session["project_folder"] = project_folder
    session["updated"] = time.time()
    with open(session_path, "w", encoding="utf-8") as handle:
        json.dump(session, handle, indent=2, ensure_ascii=False)
        handle.write("\n")

    project_name = _safe_project_name(os.path.basename(project_folder))
    temp_handle = tempfile.NamedTemporaryFile(prefix="vrgdg_builder_export_", suffix=".zip", delete=False)
    zip_path = temp_handle.name
    temp_handle.close()
    try:
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as archive:
            archive.writestr("vrgdg_project_package.json", json.dumps({
                "format": "vrgdg_builder_project",
                "version": 1,
                "project_name": project_name,
                "created": time.time(),
            }, indent=2))
            for root, folders, files in os.walk(project_folder):
                folders[:] = [name for name in folders if name not in {"__pycache__"}]
                for filename in files:
                    source = os.path.join(root, filename)
                    relative = os.path.relpath(source, project_folder).replace(os.sep, "/")
                    already_compressed = os.path.splitext(filename)[1].lower() in {
                        ".mp4", ".mov", ".mkv", ".webm", ".avi", ".mp3", ".m4a", ".flac", ".ogg",
                        ".png", ".jpg", ".jpeg", ".webp", ".gif", ".zip",
                    }
                    archive.write(source, relative, compress_type=zipfile.ZIP_STORED if already_compressed else zipfile.ZIP_DEFLATED)
        return zip_path, f"{project_name}.vrgdg.zip"
    except Exception:
        try:
            os.remove(zip_path)
        except OSError:
            pass
        raise


def _safe_builder_zip_members(archive):
    members = archive.infolist()
    if not members:
        raise ValueError("The selected ZIP file is empty.")
    total_size = 0
    for member in members:
        normalized = member.filename.replace("\\", "/")
        parts = [part for part in normalized.split("/") if part not in {"", "."}]
        if normalized.startswith("/") or re.match(r"^[A-Za-z]:", normalized) or any(part == ".." for part in parts):
            raise ValueError(f"Unsafe path in project ZIP: {member.filename}")
        unix_mode = (member.external_attr >> 16) & 0o170000
        if unix_mode == 0o120000:
            raise ValueError(f"Symbolic links are not allowed in project ZIPs: {member.filename}")
        total_size += max(0, int(member.file_size or 0))
        if member.file_size > 1024 * 1024 * 1024 and member.compress_size and member.file_size > member.compress_size * 1000:
            raise ValueError(f"Suspicious compression ratio in project ZIP: {member.filename}")
    if total_size > 500 * 1024 * 1024 * 1024:
        raise ValueError("The uncompressed project is larger than the 500 GB safety limit.")
    names = {member.filename.replace("\\", "/").strip("/") for member in members}
    if "vrgdg_builder_session.json" not in names:
        raise ValueError("This ZIP is not a portable Video Builder project (vrgdg_builder_session.json is missing).")
    return members


def _import_builder_project_zip(zip_path, requested_name=""):
    with zipfile.ZipFile(zip_path, "r") as archive:
        members = _safe_builder_zip_members(archive)
        manifest = {}
        try:
            manifest = json.loads(archive.read("vrgdg_project_package.json").decode("utf-8"))
        except (KeyError, ValueError, UnicodeDecodeError):
            manifest = {}
        default_name = manifest.get("project_name") or os.path.basename(zip_path).replace(".vrgdg.zip", "").replace(".zip", "")
        project_name = _safe_project_name(requested_name or default_name)
        target = _unique_folder_path(os.path.join(folder_paths.get_output_directory(), project_name))
        os.makedirs(target, exist_ok=False)
        try:
            target_real = os.path.realpath(target)
            for member in members:
                name = member.filename.replace("\\", "/").strip("/")
                if not name or name == "vrgdg_project_package.json":
                    continue
                destination = os.path.realpath(os.path.join(target, *name.split("/")))
                if os.path.commonpath([target_real, destination]) != target_real:
                    raise ValueError(f"Unsafe path in project ZIP: {member.filename}")
                if member.is_dir():
                    os.makedirs(destination, exist_ok=True)
                    continue
                os.makedirs(os.path.dirname(destination), exist_ok=True)
                with archive.open(member, "r") as source, open(destination, "wb") as output:
                    shutil.copyfileobj(source, output, length=1024 * 1024)
            session_path = _session_path(target)
            imported_session = {}
            if os.path.isfile(session_path):
                with open(session_path, "r", encoding="utf-8-sig") as handle:
                    loaded = json.load(handle)
                if isinstance(loaded, dict):
                    imported_session = loaded
            old_folder = str(imported_session.get("project_folder", "") or "").strip().strip('"')
            imported_session = _rebase_project_owned_paths(target, old_folder, imported_session)
            imported_session["project_folder"] = target
            imported_session["updated"] = time.time()
            with open(session_path, "w", encoding="utf-8") as handle:
                json.dump(imported_session, handle, indent=2, ensure_ascii=False)
                handle.write("\n")
            result = _load_builder_session(target)
            result["imported_project_name"] = project_name
            return result
        except Exception:
            shutil.rmtree(target, ignore_errors=True)
            raise


def _save_wizard_draft(payload):
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder:
        raise ValueError("Project folder is empty.")
    os.makedirs(project_folder, exist_ok=True)
    folder = _wizard_folder(project_folder)
    os.makedirs(folder, exist_ok=True)
    draft = payload.get("draft") if isinstance(payload.get("draft"), dict) else {}
    lyrics = str(payload.get("lyrics", "") or draft.get("lyrics", "") or "").replace("\r\n", "\n").replace("\r", "\n")
    draft = {
        **draft,
        "lyrics": lyrics,
        "updated": time.time(),
    }
    with open(_wizard_draft_path(project_folder), "w", encoding="utf-8") as handle:
        json.dump(draft, handle, indent=2, ensure_ascii=False)
        handle.write("\n")
    with open(_wizard_lyrics_path(project_folder), "w", encoding="utf-8") as handle:
        handle.write(lyrics)
        if lyrics and not lyrics.endswith("\n"):
            handle.write("\n")
    raw_outputs = payload.get("raw_outputs") if isinstance(payload.get("raw_outputs"), dict) else {}
    for name, value in raw_outputs.items():
        safe_name = re.sub(r"[^a-zA-Z0-9_.-]+", "_", str(name or "").strip()).strip("._") or "raw_output"
        if not safe_name.endswith(".txt") and not safe_name.endswith(".json"):
            safe_name += ".txt"
        with open(os.path.join(folder, safe_name), "w", encoding="utf-8") as handle:
            if isinstance(value, (dict, list)):
                json.dump(value, handle, indent=2, ensure_ascii=False)
                handle.write("\n")
            else:
                handle.write(str(value or ""))
                if value and not str(value).endswith("\n"):
                    handle.write("\n")
    return {
        "wizard_folder": folder,
        "wizard_draft_path": _wizard_draft_path(project_folder),
        "wizard_lyrics_path": _wizard_lyrics_path(project_folder),
        "draft": draft,
    }


def _load_wizard_draft(payload):
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder:
        raise ValueError("Project folder is empty.")
    path = _wizard_draft_path(project_folder)
    draft = {}
    if os.path.isfile(path):
        with open(path, "r", encoding="utf-8") as handle:
            loaded = json.load(handle)
        if isinstance(loaded, dict):
            draft = loaded
    lyrics_path = _wizard_lyrics_path(project_folder)
    if os.path.isfile(lyrics_path) and not str(draft.get("lyrics", "")).strip():
        with open(lyrics_path, "r", encoding="utf-8") as handle:
            draft["lyrics"] = handle.read()
    return {
        "wizard_folder": _wizard_folder(project_folder),
        "wizard_draft_path": path,
        "wizard_lyrics_path": lyrics_path,
        "draft": draft,
        "exists": bool(draft),
    }


def _save_scene_image(payload):
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder:
        raise ValueError("Project folder is empty.")
    os.makedirs(_images_folder(project_folder), exist_ok=True)
    scene_number = int(payload.get("scene_number") or 1)

    image_data = str(payload.get("image_data", "") or "").strip()
    if image_data:
        target_path = _scene_image_path(project_folder, scene_number, ".png")
        image = _image_from_data_url(image_data)
        image.save(target_path, format="PNG")
    else:
        source_path = ""
        image_info = payload.get("image")
        if isinstance(image_info, dict):
            source_path = _resolve_comfy_image_path(image_info)
        else:
            source_path = _resolve_existing_file(payload.get("source_path", ""), "Image file")
        ext = os.path.splitext(source_path)[1] or ".png"
        target_path = _scene_image_path(project_folder, scene_number, ext)
        shutil.copy2(source_path, target_path)
    return {
        "saved_path": target_path,
        "images_folder": _images_folder(project_folder),
        "scene_number": scene_number,
    }


def _delete_project_media(payload):
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    media_path = os.path.abspath(str(payload.get("path", "") or "").strip().strip('"'))
    if not project_folder:
        raise ValueError("Project folder is empty.")
    if not media_path:
        raise ValueError("Media path is empty.")
    if not os.path.isfile(media_path):
        return {"deleted": False, "path": media_path, "reason": "File was already missing."}
    try:
        common = os.path.commonpath([project_folder, media_path])
    except ValueError:
        common = ""
    if common != project_folder:
        raise ValueError("This file is outside the current project folder, so it was not deleted.")
    os.remove(media_path)
    return {"deleted": True, "path": media_path}


def _archive_scene_image(payload):
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder:
        raise ValueError("Project folder is empty.")
    scene_number = int(payload.get("scene_number") or 1)

    image_data = str(payload.get("image_data", "") or "").strip()
    if image_data:
        target_path = _unique_preview_path(project_folder, scene_number, ".png")
        image = _image_from_data_url(image_data)
        image.save(target_path, format="PNG")
    else:
        image_info = payload.get("image")
        if isinstance(image_info, dict):
            source_path = _resolve_comfy_image_path(image_info)
        else:
            source_path = _resolve_existing_file(payload.get("source_path", ""), "Image file")
        ext = os.path.splitext(source_path)[1] or ".png"
        target_path = _unique_preview_path(project_folder, scene_number, ext)
        shutil.copy2(source_path, target_path)

    return {
        "saved_path": target_path,
        "preview_folder": _scene_preview_folder(project_folder, scene_number),
        "scene_number": scene_number,
    }


def _extract_video_final_frame_as_scene_image(payload):
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder:
        raise ValueError("Project folder is empty.")
    source_path = _resolve_existing_file(payload.get("source_path", ""), "Source video")
    try:
        common = os.path.commonpath([project_folder, source_path])
    except ValueError:
        common = ""
    if common != project_folder:
        raise ValueError("Source video must be inside the current project folder.")

    scene_number = int(payload.get("scene_number") or payload.get("target_scene_number") or 1)
    target_path = _unique_preview_path(project_folder, scene_number, ".png")
    ffmpeg_path = _find_ffmpeg_path()
    attempts = [
        ["-sseof", "-0.04"],
        ["-sseof", "-0.12"],
        ["-sseof", "-0.5"],
    ]
    last_error = ""
    for seek_args in attempts:
        cmd = [
            ffmpeg_path,
            "-y",
            *seek_args,
            "-i",
            source_path,
            "-frames:v",
            "1",
            "-update",
            "1",
            target_path,
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, errors="replace", check=False)
        if result.returncode == 0 and os.path.isfile(target_path) and os.path.getsize(target_path) > 0:
            return {
                "saved_path": target_path,
                "preview_folder": _scene_preview_folder(project_folder, scene_number),
                "scene_number": scene_number,
                "source_path": source_path,
            }
        last_error = (result.stderr or result.stdout or "ffmpeg could not extract a final frame.").strip()
        try:
            if os.path.isfile(target_path):
                os.remove(target_path)
        except Exception:
            pass
    raise RuntimeError(last_error or "ffmpeg could not extract a final frame.")


def _save_flux_reference_image(payload):
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder:
        raise ValueError("Project folder is empty.")
    reference_type = str(payload.get("reference_type", "") or "").strip().lower()
    if reference_type not in {"subject", "location", "ingredients_sheet"}:
        reference_type = "location"
    raw_name = str(payload.get("name", "") or "").strip() or reference_type
    safe_name = _safe_project_name(raw_name)
    folder_name = "ingredients_sheets" if reference_type == "ingredients_sheet" else f"{reference_type}s"
    target_dir = os.path.join(_context_folder(project_folder), "flux_references", folder_name)
    os.makedirs(target_dir, exist_ok=True)

    image_data = str(payload.get("image_data", "") or "").strip()
    if image_data:
        ext = ".png"
        target_path = _unique_file_path(os.path.join(target_dir, f"{safe_name}{ext}"))
        image = _image_from_data_url(image_data)
        image.save(target_path, format="PNG")
    else:
        image_info = payload.get("image")
        if isinstance(image_info, dict):
            source_path = _resolve_comfy_image_path(image_info)
        else:
            source_path = _resolve_existing_file(payload.get("source_path", ""), "Reference image")
        ext = os.path.splitext(source_path)[1] or ".png"
        target_path = _unique_file_path(os.path.join(target_dir, f"{safe_name}{ext}"))
        shutil.copy2(source_path, target_path)

    return {
        "saved_path": target_path,
        "reference_type": reference_type,
        "folder": target_dir,
    }


def _import_reference_subjects_from_project(payload):
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder or not os.path.isdir(project_folder):
        raise ValueError("Create or load a project first so the subject folder can be found.")

    subject_dir = os.path.join(project_folder, "subject_location", "subject")
    if not os.path.isdir(subject_dir):
        raise FileNotFoundError(f"Subject folder does not exist:\n{subject_dir}")

    image_exts = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
    subjects = []
    missing_descriptions = []
    for filename in sorted(os.listdir(subject_dir), key=lambda item: item.lower()):
        image_path = os.path.join(subject_dir, filename)
        if not os.path.isfile(image_path):
            continue
        stem, ext = os.path.splitext(filename)
        if ext.lower() not in image_exts:
            continue
        text_path = os.path.join(subject_dir, f"{stem}.txt")
        description = ""
        if os.path.isfile(text_path):
            with open(text_path, "r", encoding="utf-8", errors="ignore") as handle:
                description = handle.read().strip()
        else:
            missing_descriptions.append(f"{stem}.txt")
        preview_data = ""
        try:
            with Image.open(image_path) as preview_image:
                preview_data = _pil_image_to_data_url(preview_image, max_height=220, quality=72)
        except Exception:
            preview_data = ""
        safe_id = re.sub(r"[^a-zA-Z0-9_]+", "_", stem).strip("_") or f"subject_{len(subjects) + 1}"
        subjects.append({
            "id": f"subj_import_{len(subjects) + 1}_{safe_id}",
            "name": stem,
            "description": description,
            "image": {
                "path": image_path,
                "data": preview_data,
                "name": filename,
            },
        })

    if not subjects:
        raise ValueError(f"No subject images were found in:\n{subject_dir}")

    return {
        "folder": subject_dir,
        "subjects": subjects,
        "missing_descriptions": missing_descriptions,
    }


def _import_reference_locations_from_project(payload):
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder or not os.path.isdir(project_folder):
        raise ValueError("Create or load a project first so the location folder can be found.")

    base_dir = os.path.join(project_folder, "subject_location")
    location_dir = os.path.join(base_dir, "location")
    typo_location_dir = os.path.join(base_dir, "locaton")
    if not os.path.isdir(location_dir) and os.path.isdir(typo_location_dir):
        location_dir = typo_location_dir
    if not os.path.isdir(location_dir):
        raise FileNotFoundError(
            "Location folder does not exist:\n"
            f"{os.path.join(base_dir, 'location')}\n\n"
            "Expected folder layout:\n"
            "subject_location/location"
        )

    image_exts = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
    locations = []
    missing_descriptions = []
    for filename in sorted(os.listdir(location_dir), key=lambda item: item.lower()):
        image_path = os.path.join(location_dir, filename)
        if not os.path.isfile(image_path):
            continue
        stem, ext = os.path.splitext(filename)
        if ext.lower() not in image_exts:
            continue
        text_path = os.path.join(location_dir, f"{stem}.txt")
        description = ""
        if os.path.isfile(text_path):
            with open(text_path, "r", encoding="utf-8", errors="ignore") as handle:
                description = handle.read().strip()
        else:
            missing_descriptions.append(f"{stem}.txt")
        preview_data = ""
        try:
            with Image.open(image_path) as preview_image:
                preview_data = _pil_image_to_data_url(preview_image, max_height=220, quality=72)
        except Exception:
            preview_data = ""
        safe_id = re.sub(r"[^a-zA-Z0-9_]+", "_", stem).strip("_") or f"location_{len(locations) + 1}"
        locations.append({
            "id": f"loc_import_{len(locations) + 1}_{safe_id}",
            "name": stem,
            "description": description,
            "image": {
                "path": image_path,
                "data": preview_data,
                "name": filename,
            },
        })

    if not locations:
        raise ValueError(f"No location images were found in:\n{location_dir}")

    return {
        "folder": location_dir,
        "locations": locations,
        "missing_descriptions": missing_descriptions,
    }


def _audio_bytes_from_data_url(audio_data):
    raw = str(audio_data or "").strip()
    if not raw:
        raise ValueError("Audio data is empty.")
    if "," in raw and raw.lower().startswith("data:"):
        raw = raw.split(",", 1)[1]
    return base64.b64decode(raw)


def _save_scene_audio(payload):
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder:
        raise ValueError("Project folder is empty.")
    scene_number = int(payload.get("scene_number") or 1)
    os.makedirs(_scene_audio_folder(project_folder), exist_ok=True)

    source_name = str(payload.get("audio_name", "") or "").strip()
    source_ext = os.path.splitext(source_name)[1].lower()
    audio_data = str(payload.get("audio_data", "") or "").strip()
    if audio_data:
        target_path = _scene_audio_path(project_folder, scene_number, source_ext or ".wav")
        with open(target_path, "wb") as handle:
            handle.write(_audio_bytes_from_data_url(audio_data))
    else:
        source_path = _resolve_existing_file(payload.get("source_path", ""), "Audio file")
        target_path = _scene_audio_path(project_folder, scene_number, os.path.splitext(source_path)[1] or ".wav")
        shutil.copy2(source_path, target_path)

    audio_info = _read_audio_peaks(target_path, 600)
    return {
        "saved_path": target_path,
        "audio_folder": _scene_audio_folder(project_folder),
        "scene_number": scene_number,
        **audio_info,
    }


def _save_project_audio(payload):
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder:
        raise ValueError("Project folder is empty.")
    os.makedirs(project_folder, exist_ok=True)
    folder = os.path.join(project_folder, "project_audio")
    os.makedirs(folder, exist_ok=True)
    source_name = str(payload.get("audio_name", "") or "").strip() or "project_audio.wav"
    ext = os.path.splitext(source_name)[1].lower()
    if ext not in {".wav", ".mp3", ".flac", ".m4a", ".ogg"}:
        ext = ".wav"
    target_path = os.path.join(folder, f"project_audio{'.wav' if ext == '.m4a' else ext}")
    raw_target_path = os.path.join(folder, f"project_audio_source{ext}") if ext == ".m4a" else target_path
    audio_data = str(payload.get("audio_data", "") or "").strip()
    if audio_data:
        with open(raw_target_path, "wb") as handle:
            handle.write(_audio_bytes_from_data_url(audio_data))
    else:
        source_path = _resolve_existing_file(payload.get("source_path", ""), "Audio file")
        if ext == ".m4a":
            shutil.copy2(source_path, raw_target_path)
        else:
            shutil.copy2(source_path, target_path)
    if ext == ".m4a":
        target_path = _convert_audio_to_wav(raw_target_path, target_path)
        try:
            if os.path.abspath(raw_target_path) != os.path.abspath(target_path):
                os.remove(raw_target_path)
        except Exception:
            pass
    audio_info = _read_audio_peaks(target_path, 1600)
    beats, tempo_bpm = _estimate_beats_from_audio(
        target_path,
        audio_info.get("peaks", []),
        audio_info.get("duration", 0),
        include_tempo=True,
    )
    return {"saved_path": target_path, "audio_folder": folder, **audio_info, "beats": beats, "tempo_bpm": tempo_bpm}


def _save_project_srt(payload):
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder:
        raise ValueError("Project folder is empty.")
    os.makedirs(project_folder, exist_ok=True)
    srt_text = str(payload.get("srt_text", "") or "")
    if not srt_text.strip():
        raise ValueError("SRT text is empty.")
    path = _srt_path(project_folder)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(srt_text)
    segments = _parse_srt_segments(srt_text)
    return {"srt_path": path, "segments": segments}


def _save_single_scene_srt(payload):
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder:
        raise ValueError("Project folder is empty.")
    scene_number = int(payload.get("scene_number") or 1)
    duration = max(0.1, float(payload.get("duration") or 4))
    start_time = max(0.0, float(payload.get("start_time") or 0))
    end_time = start_time + duration
    label = str(payload.get("label") or f"Scene {scene_number}").strip()
    folder = os.path.join(project_folder, "scene_srt")
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, f"scene_{scene_number:04d}.srt")
    text = "\n".join([
        "1",
        f"{_format_srt_time(start_time)} --> {_format_srt_time(end_time)}",
        label,
        "",
    ])
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
    return {"srt_path": path, "scene_number": scene_number, "start_time": start_time, "duration": duration}


def _trim_scene_audio(payload):
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder:
        raise ValueError("Project folder is empty.")
    source_path = _resolve_existing_file(payload.get("source_path", ""), "Audio file")
    scene_number = int(payload.get("scene_number") or 1)
    start = max(0.0, float(payload.get("start") or 0))
    duration = max(0.05, float(payload.get("duration") or 0))
    source_info = _read_audio_peaks(source_path, 16)
    source_duration = float(source_info.get("duration") or 0)
    if source_duration > 0:
        remaining = source_duration - start
        if remaining <= 0.01:
            raise ValueError(
                f"Scene {scene_number} audio trim starts after the source audio ends. "
                f"Trim start: {start:.3f}s; audio length: {source_duration:.3f}s. "
                "Shorten or move the scene, load longer audio, or add silence before rendering."
            )
        duration = min(duration, max(0.05, remaining))
    folder = os.path.join(project_folder, "scene_audio_trimmed")
    os.makedirs(folder, exist_ok=True)
    target_path = os.path.join(folder, f"scene_audio_{scene_number:04d}.wav")
    cmd = [
        "ffmpeg",
        "-y",
        "-ss",
        str(start),
        "-i",
        source_path,
        "-t",
        str(duration),
        "-vn",
        "-ac",
        "2",
        "-ar",
        "44100",
        "-c:a",
        "pcm_s16le",
        target_path,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, errors="replace", check=False)
    if result.returncode != 0:
        raise RuntimeError((result.stderr or result.stdout or "ffmpeg failed to trim scene audio.").strip())
    trimmed_info = _read_audio_peaks(target_path, 16)
    trimmed_duration = float(trimmed_info.get("duration") or 0)
    if trimmed_duration <= 0.01:
        raise ValueError(
            f"Scene {scene_number} audio trim was empty. "
            f"Trim start: {start:.3f}s; requested duration: {duration:.3f}s. "
            "Shorten or move the scene, load longer audio, or add silence before rendering."
        )
    return {
        "audio_path": target_path,
        "scene_number": scene_number,
        "start": start,
        "duration": trimmed_duration,
        "requested_duration": float(payload.get("duration") or 0),
        "format": "pcm_s16le_wav",
    }


def _find_ffmpeg_path():
    try:
        subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
        return "ffmpeg"
    except Exception:
        try:
            import imageio_ffmpeg
            return imageio_ffmpeg.get_ffmpeg_exe()
        except Exception as exc:
            raise RuntimeError("ffmpeg was not found. Install ffmpeg or imageio-ffmpeg to mix scene audio.") from exc


def _concat_file_path(path):
    return os.path.abspath(path).replace("\\", "/").replace("'", "'\\''")


def _scene_audio_mix_folder(project_folder):
    return os.path.join(project_folder, "project_audio")


def _prepare_scene_audio_mix(payload):
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder:
        raise ValueError("Project folder is empty.")
    segments = payload.get("segments", [])
    if not isinstance(segments, list) or not segments:
        raise ValueError("No scenes were provided for scene audio mix.")
    allow_missing_scene_audio = bool(payload.get("allow_missing_scene_audio", False))
    global_audio_path = os.path.abspath(
        str(payload.get("global_audio_path", "") or "").strip().strip('"')
    )
    if not os.path.isfile(global_audio_path):
        global_audio_path = ""

    ffmpeg_path = _find_ffmpeg_path()
    folder = _scene_audio_mix_folder(project_folder)
    os.makedirs(folder, exist_ok=True)
    parts_folder = os.path.join(folder, "_scene_audio_mix_parts")
    if os.path.isdir(parts_folder):
        shutil.rmtree(parts_folder, ignore_errors=True)
    os.makedirs(parts_folder, exist_ok=True)

    timeline_items = []
    missing = []
    for index, segment in enumerate(segments, start=1):
        if not isinstance(segment, dict):
            missing.append(f"Scene {index}: invalid scene data.")
            continue
        path = str(segment.get("custom_audio_path", "") or "").strip().strip('"')
        if not path:
            start = max(0.0, float(segment.get("start", 0) or 0))
            end = max(start + 0.05, float(segment.get("end", start + 4) or start + 4))
            duration = max(0.05, end - start)
            if global_audio_path:
                timeline_items.append({
                    "index": index,
                    "path": global_audio_path,
                    "start": start,
                    "end": end,
                    "duration": duration,
                    "source_start": start,
                    "silent": False,
                })
                continue
            if allow_missing_scene_audio:
                timeline_items.append({
                    "index": index,
                    "path": "",
                    "start": start,
                    "end": end,
                    "duration": duration,
                    "source_start": 0.0,
                    "silent": True,
                })
                continue
            missing.append(f"Scene {index}: custom audio is missing.")
            continue
        path = os.path.abspath(path)
        if not os.path.isfile(path):
            missing.append(f"Scene {index}: custom audio file was not found: {path}")
            continue
        segment_start = max(0.0, float(segment.get("start", 0) or 0))
        segment_end = max(segment_start + 0.05, float(segment.get("end", segment_start + 4) or segment_start + 4))
        start = max(0.0, float(segment.get("custom_audio_timeline_start", segment_start) or segment_start))
        duration = float(segment.get("custom_audio_duration", 0) or 0)
        if duration <= 0:
            duration = segment_end - segment_start
        duration = max(0.05, duration)
        source_start = max(0.0, float(segment.get("custom_audio_source_start", 0) or 0))
        timeline_items.append({
            "index": index,
            "path": path,
            "start": start,
            "end": start + duration,
            "duration": duration,
            "source_start": source_start,
            "silent": False,
        })
    if missing:
        raise ValueError("\n".join(missing))

    timeline_items.sort(key=lambda item: (item["start"], item["index"]))
    concat_file = os.path.join(parts_folder, "scene_audio_mix_list.txt")
    part_paths = []
    cursor = 0.0
    part_index = 1
    for item in timeline_items:
        gap = max(0.0, item["start"] - cursor)
        if gap > 0.01:
            silence_path = os.path.join(parts_folder, f"part_{part_index:04d}_silence.wav")
            part_index += 1
            silence_cmd = [
                ffmpeg_path,
                "-y",
                "-f",
                "lavfi",
                "-i",
                "anullsrc=r=44100:cl=stereo",
                "-t",
                f"{gap:.6f}",
                "-c:a",
                "pcm_s16le",
                silence_path,
            ]
            result = subprocess.run(silence_cmd, capture_output=True, text=True, errors="replace", check=False)
            if result.returncode != 0:
                raise RuntimeError((result.stderr or result.stdout or "ffmpeg failed to create silence.").strip())
            part_paths.append(silence_path)

        clip_path = os.path.join(parts_folder, f"part_{part_index:04d}_scene_{item['index']:04d}.wav")
        part_index += 1
        if item.get("silent"):
            clip_cmd = [
                ffmpeg_path,
                "-y",
                "-f",
                "lavfi",
                "-i",
                "anullsrc=r=44100:cl=stereo",
                "-t",
                f"{item['duration']:.6f}",
                "-c:a",
                "pcm_s16le",
                clip_path,
            ]
        else:
            clip_cmd = [
                ffmpeg_path,
                "-y",
                "-ss",
                f"{item['source_start']:.6f}",
                "-i",
                item["path"],
                "-t",
                f"{item['duration']:.6f}",
                "-ac",
                "2",
                "-ar",
                "44100",
                "-c:a",
                "pcm_s16le",
                clip_path,
            ]
        result = subprocess.run(clip_cmd, capture_output=True, text=True, errors="replace", check=False)
        if result.returncode != 0:
            raise RuntimeError((result.stderr or result.stdout or f"ffmpeg failed to prepare scene {item['index']} audio.").strip())
        part_paths.append(clip_path)
        cursor = max(cursor, item["start"] + item["duration"])

    if not part_paths:
        raise ValueError("No scene audio parts were created.")

    mix_path = os.path.join(folder, "scene_audio_mix.wav")
    with open(concat_file, "w", encoding="utf-8") as handle:
        for path in part_paths:
            handle.write(f"file '{_concat_file_path(path)}'\n")
    mix_cmd = [
        ffmpeg_path,
        "-y",
        "-f",
        "concat",
        "-safe",
        "0",
        "-i",
        concat_file,
        "-c:a",
        "pcm_s16le",
        mix_path,
    ]
    result = subprocess.run(mix_cmd, capture_output=True, text=True, errors="replace", check=False)
    if result.returncode != 0:
        raise RuntimeError((result.stderr or result.stdout or "ffmpeg failed to create scene audio mix.").strip())

    srt_path = _srt_path(project_folder)
    with open(srt_path, "w", encoding="utf-8") as handle:
        text_field = "lyric_text" if str(payload.get("srt_text_field", "") or "").strip() == "lyric_text" else "label"
        handle.write(_segments_to_srt(segments, text_field=text_field))

    shutil.rmtree(parts_folder, ignore_errors=True)
    audio_info = _read_audio_peaks(mix_path, 1600)
    beats, tempo_bpm = _estimate_beats_from_audio(
        mix_path,
        audio_info.get("peaks", []),
        audio_info.get("duration", cursor),
        include_tempo=True,
    )
    return {
        "audio_path": mix_path,
        "srt_path": srt_path,
        "duration": audio_info.get("duration", cursor),
        "peaks": audio_info.get("peaks", []),
        "beats": beats,
        "tempo_bpm": tempo_bpm,
        "scene_count": len(timeline_items),
        "used_scene_audio": True,
    }


def _load_builder_session(project_folder):
    folder = os.path.abspath(str(project_folder or "").strip().strip('"'))
    if not folder:
        raise ValueError("Project folder is empty.")
    path = _session_path(folder)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Builder session was not found: {path}")
    with open(path, "r", encoding="utf-8-sig") as handle:
        session = json.load(handle)
    if not isinstance(session, dict):
        raise ValueError("Builder session is not a JSON object.")
    session = _rehydrate_builder_session(folder, session)
    scene_note_fallbacks = _load_scene_notes_json(folder)
    segments = session.get("segments", [])
    if scene_note_fallbacks and isinstance(segments, list):
        for index, segment in enumerate(segments, start=1):
            if not isinstance(segment, dict):
                continue
            if not str(segment.get("timeline_note", "") or "").strip() and scene_note_fallbacks.get(index):
                segment["timeline_note"] = scene_note_fallbacks[index]
    return {
        "project_folder": folder,
        "session_path": path,
        "srt_path": _srt_path(folder),
        "scene_notes_path": _scene_notes_path(folder),
        "session": session,
    }


def _list_builder_projects(project_root=""):
    output_dir = os.path.abspath(folder_paths.get_output_directory())
    projects = []
    roots = [output_dir]
    custom_root = str(project_root or "").strip().strip('"')
    if custom_root and os.path.isabs(custom_root):
        custom_root = os.path.abspath(custom_root)
        if os.path.normcase(custom_root) != os.path.normcase(output_dir):
            roots.append(custom_root)
    seen = set()
    for root in roots:
        if not os.path.isdir(root):
            continue
        for name in os.listdir(root):
            folder = os.path.abspath(os.path.join(root, name))
            folder_key = os.path.normcase(folder)
            if folder_key in seen or not os.path.isdir(folder):
                continue
            session_path = _session_path(folder)
            if not os.path.isfile(session_path):
                continue
            seen.add(folder_key)
            try:
                mtime = os.path.getmtime(session_path)
            except OSError:
                mtime = 0
            scene_count = 0
            try:
                with open(session_path, "r", encoding="utf-8-sig") as handle:
                    session = json.load(handle)
                segments = session.get("segments", []) if isinstance(session, dict) else []
                scene_count = len(segments) if isinstance(segments, list) else 0
            except Exception:
                scene_count = 0
            try:
                can_delete = os.path.commonpath([output_dir, folder]) == output_dir
            except ValueError:
                can_delete = False
            projects.append({
                "name": name,
                "project_folder": folder,
                "session_path": os.path.abspath(session_path),
                "updated": mtime,
                "scene_count": scene_count,
                "can_delete": can_delete,
            })
    projects.sort(key=lambda item: item.get("updated", 0), reverse=True)
    return {"projects": projects, "output_dir": output_dir, "project_roots": roots}


def _delete_builder_project(payload):
    output_dir = os.path.abspath(folder_paths.get_output_directory())
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder:
        raise ValueError("Project folder is empty.")
    try:
        common = os.path.commonpath([output_dir, project_folder])
    except ValueError:
        common = ""
    if common != output_dir:
        raise ValueError("Project is outside the ComfyUI output folder, so it was not deleted.")
    if not os.path.isdir(project_folder):
        return {"deleted": False, "project_folder": project_folder, "reason": "Project folder was already missing."}
    if not os.path.isfile(_session_path(project_folder)):
        raise ValueError("This folder does not look like a Music Video Builder project.")
    shutil.rmtree(project_folder)
    return {"deleted": True, "project_folder": project_folder}


def _builder_scene_video_thumbnail_path(video_path):
    video_path = os.path.abspath(str(video_path or "").strip().strip('"'))
    root, _ext = os.path.splitext(video_path)
    video_name = os.path.basename(root)
    current = os.path.dirname(video_path)
    while current and current != os.path.dirname(current):
        if os.path.basename(current).lower() in {"rendered_scene_videos", "rendered_scene_videos_backup"}:
            project_folder = os.path.dirname(current)
            return os.path.join(project_folder, "scene_video_thumbnails", f"{video_name}.jpg")
        current = os.path.dirname(current)
    return f"{root}.jpg"


def _builder_legacy_scene_video_thumbnail_path(video_path):
    root, _ext = os.path.splitext(os.path.abspath(str(video_path or "").strip().strip('"')))
    return f"{root}.jpg"


def _ensure_builder_scene_video_thumbnail(video_path):
    video_path = os.path.abspath(str(video_path or "").strip().strip('"'))
    if not os.path.isfile(video_path):
        return ""
    thumbnail_path = _builder_scene_video_thumbnail_path(video_path)
    if os.path.isfile(thumbnail_path):
        return thumbnail_path
    try:
        # Older Builder projects predate the dedicated thumbnail directory.
        # Their videos are still valid, but ffmpeg cannot write the recovered
        # thumbnail until its parent directory exists.
        os.makedirs(os.path.dirname(thumbnail_path), exist_ok=True)
        ffmpeg_path = _find_ffmpeg_path()
        for timestamp in ("0.5", "0"):
            cmd = [
                ffmpeg_path,
                "-y",
                "-ss",
                timestamp,
                "-i",
                video_path,
                "-frames:v",
                "1",
                "-vf",
                "scale=480:-2",
                "-q:v",
                "3",
                thumbnail_path,
            ]
            result = subprocess.run(cmd, capture_output=True, text=True, errors="replace", check=False)
            if result.returncode == 0 and os.path.isfile(thumbnail_path):
                return thumbnail_path
        error_text = (result.stderr or result.stdout or "ffmpeg could not extract a thumbnail.").strip()
        print(f"[VRGDG Music Builder] Could not create scene video thumbnail for '{video_path}': {error_text}")
    except Exception as exc:
        print(f"[VRGDG Music Builder] Could not create scene video thumbnail for '{video_path}': {exc}")
    return ""


def _ffprobe_path_for_builder(ffmpeg_path):
    if not ffmpeg_path or ffmpeg_path == "ffmpeg":
        return "ffprobe"
    folder = os.path.dirname(os.path.abspath(ffmpeg_path))
    exe_name = "ffprobe.exe" if os.name == "nt" else "ffprobe"
    candidate = os.path.join(folder, exe_name)
    return candidate if os.path.isfile(candidate) else "ffprobe"


def _probe_video_duration_seconds(video_path):
    video_path = os.path.abspath(str(video_path or "").strip().strip('"'))
    if not os.path.isfile(video_path):
        return 0.0
    try:
        ffprobe_path = _ffprobe_path_for_builder(_find_ffmpeg_path())
        result = subprocess.run(
            [
                ffprobe_path,
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                video_path,
            ],
            capture_output=True,
            text=True,
            errors="replace",
            check=False,
        )
        if result.returncode == 0:
            return max(0.0, float(str(result.stdout or "0").strip() or 0))
    except Exception as exc:
        print(f"[VRGDG Music Builder] Could not probe video duration for '{video_path}': {exc}")
    return 0.0


def _restore_scene_video(payload):
    project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
    if not project_folder:
        raise ValueError("Project folder is empty.")
    source_path = os.path.abspath(str(payload.get("source_path", "") or "").strip().strip('"'))
    if not os.path.isfile(source_path):
        raise FileNotFoundError(f"Video file was not found: {source_path}")
    if os.path.splitext(source_path)[1].lower() not in {".mp4", ".mov", ".mkv", ".webm", ".avi"}:
        raise ValueError("Choose a supported video file: .mp4, .mov, .mkv, .webm, or .avi")
    scene_number = max(1, int(payload.get("scene_number") or 1))
    duration = _probe_video_duration_seconds(source_path)
    expected_duration = max(0.0, float(payload.get("expected_duration") or 0))
    tolerance = max(0.1, float(payload.get("duration_tolerance") or 0.5))
    duration_delta = abs(duration - expected_duration) if duration and expected_duration else 0.0
    if duration_delta > tolerance and not bool(payload.get("confirm_duration_mismatch")):
        return {
            "needs_confirmation": True,
            "source_path": source_path,
            "scene_number": scene_number,
            "duration": duration,
            "expected_duration": expected_duration,
            "duration_delta": duration_delta,
            "duration_tolerance": tolerance,
        }
    target_dir = os.path.join(project_folder, "rendered_scene_videos")
    os.makedirs(target_dir, exist_ok=True)
    target_path = os.path.join(target_dir, f"video_{scene_number:04d}-audio.mp4")
    thumbnail_path = _builder_scene_video_thumbnail_path(target_path)
    legacy_thumbnail_path = _builder_legacy_scene_video_thumbnail_path(target_path)
    backup_path = ""
    backup_thumbnail_path = ""
    if os.path.isfile(target_path) and os.path.normcase(os.path.abspath(source_path)) != os.path.normcase(os.path.abspath(target_path)):
        stamp = time.strftime("%Y%m%d-%H%M%S")
        backup_dir = os.path.join(project_folder, "rendered_scene_videos_backup", f"scene_{scene_number:04d}")
        os.makedirs(backup_dir, exist_ok=True)
        backup_path = os.path.join(backup_dir, f"video_{scene_number:04d}-audio_manual_restore_{stamp}.mp4")
        shutil.move(target_path, backup_path)
        if os.path.isfile(thumbnail_path):
            backup_thumbnail_path = _builder_scene_video_thumbnail_path(backup_path)
            shutil.move(thumbnail_path, backup_thumbnail_path)
    copied = _copy_file_if_exists(source_path, target_path)
    if not copied:
        raise RuntimeError("Could not copy the selected video into the project.")
    for stale_thumbnail in (thumbnail_path, legacy_thumbnail_path):
        if os.path.isfile(stale_thumbnail):
            try:
                os.remove(stale_thumbnail)
            except OSError:
                pass
    created_thumbnail = _ensure_builder_scene_video_thumbnail(copied)
    return {
        "video_path": copied,
        "video_folder": target_dir,
        "thumbnail_path": created_thumbnail,
        "scene_number": scene_number,
        "source_path": source_path,
        "duration": duration,
        "backup_path": backup_path,
        "backup_thumbnail_path": backup_thumbnail_path,
    }


def _scan_builder_scene_videos(project_folder):
    folder = os.path.abspath(str(project_folder or "").strip().strip('"'))
    if not folder:
        raise ValueError("Project folder is empty.")
    video_folder = os.path.join(folder, "rendered_scene_videos")
    backup_root = os.path.join(folder, "rendered_scene_videos_backup")
    scratch_prefixes = (
        "image_to_video_clips",
        "text_to_video_clips",
        "reference_to_video_clips",
        "ingredients_to_video_clips",
    )
    videos = {}
    video_thumbnails = {}
    video_backups = {}
    video_backup_thumbnails = {}
    recovered_from_scratch = {}
    scene_srt_mtimes = []
    scene_srt_folder = os.path.join(folder, "scene_srt")
    if os.path.isdir(scene_srt_folder):
        srt_pattern = re.compile(r"^scene_(\d+)\.srt$", re.IGNORECASE)
        for srt_name in os.listdir(scene_srt_folder):
            match = srt_pattern.match(srt_name)
            if not match:
                continue
            srt_path = os.path.join(scene_srt_folder, srt_name)
            if not os.path.isfile(srt_path):
                continue
            try:
                scene_srt_mtimes.append((str(int(match.group(1))), os.path.getmtime(srt_path)))
            except OSError:
                continue
    scene_srt_mtimes.sort(key=lambda item: item[1])
    os.makedirs(video_folder, exist_ok=True)
    pattern = re.compile(r"^video_(\d+)-audio\.mp4$", re.IGNORECASE)
    for name in os.listdir(video_folder):
        match = pattern.match(name)
        if not match:
            continue
        path = os.path.join(video_folder, name)
        if os.path.isfile(path):
            key = str(int(match.group(1)))
            videos[key] = path
            legacy_thumbnail = _builder_legacy_scene_video_thumbnail_path(path)
            if os.path.isfile(legacy_thumbnail):
                try:
                    os.remove(legacy_thumbnail)
                except OSError:
                    pass
            thumb = _ensure_builder_scene_video_thumbnail(path)
            if thumb:
                video_thumbnails[key] = thumb
    scratch_candidates = {}
    scratch_pattern = re.compile(r"^video_(\d+)(?:[-_].*)?\.mp4$", re.IGNORECASE)
    scene_folder_pattern = re.compile(r"scene[_-](\d+)", re.IGNORECASE)
    def infer_scratch_scene_key(path, raw_key, modified):
        parts = os.path.abspath(path).split(os.sep)
        for part in reversed(parts):
            match = scene_folder_pattern.search(part)
            if match:
                return str(int(match.group(1)))
        if raw_key != "1" and raw_key not in videos:
            return raw_key
        previous_srts = [(key, mtime) for key, mtime in scene_srt_mtimes if mtime <= modified + 2.0 and key not in videos]
        if previous_srts:
            return max(previous_srts, key=lambda item: item[1])[0]
        return raw_key

    for name in os.listdir(folder):
        scratch_folder = os.path.abspath(os.path.join(folder, name))
        if not os.path.isdir(scratch_folder):
            continue
        if not any(name == prefix or name.startswith(f"{prefix}_") for prefix in scratch_prefixes):
            continue
        for root, _, names in os.walk(scratch_folder):
            try:
                if os.path.commonpath([folder, os.path.abspath(root)]) != folder:
                    continue
            except ValueError:
                continue
            for file_name in names:
                if not file_name.lower().endswith(".mp4"):
                    continue
                match = scratch_pattern.match(file_name)
                if not match:
                    continue
                path = os.path.abspath(os.path.join(root, file_name))
                if not os.path.isfile(path):
                    continue
                try:
                    size = os.path.getsize(path)
                    modified = os.path.getmtime(path)
                except OSError:
                    continue
                if size <= 0:
                    continue
                raw_key = str(int(match.group(1)))
                key = infer_scratch_scene_key(path, raw_key, modified)
                score = 100 if file_name.lower().endswith("-audio.mp4") else 0
                score += 10 if "-audio" in file_name.lower() else 0
                current = scratch_candidates.get(key)
                if not current or (score, modified) > (current[0], current[1]):
                    scratch_candidates[key] = (score, modified, path)
    for key, (_score, _modified, source_path) in scratch_candidates.items():
        if key in videos:
            continue
        try:
            scene_number = int(key)
        except ValueError:
            continue
        target_path = os.path.join(video_folder, f"video_{scene_number:04d}-audio.mp4")
        try:
            copied = _copy_file_if_exists(source_path, target_path)
        except Exception as exc:
            print(f"[VRGDG Music Builder] Could not recover scene video '{source_path}': {exc}")
            copied = ""
        if copied:
            videos[key] = copied
            recovered_from_scratch[key] = source_path
            thumb = _ensure_builder_scene_video_thumbnail(copied)
            if thumb:
                video_thumbnails[key] = thumb
    if os.path.isdir(backup_root):
        max_backups_per_scene = 12
        backup_pattern = re.compile(r"^video_(\d+)-audio_.*\.mp4$", re.IGNORECASE)
        for root, _, names in os.walk(backup_root):
            for name in names:
                match = backup_pattern.match(name)
                if not match:
                    continue
                path = os.path.join(root, name)
                if not os.path.isfile(path):
                    continue
                key = str(int(match.group(1)))
                try:
                    modified = os.path.getmtime(path)
                except OSError:
                    modified = 0
                video_backups.setdefault(key, []).append((path, modified))
        for key, pairs in list(video_backups.items()):
            pairs.sort(key=lambda item: item[1], reverse=True)
            kept = pairs[:max_backups_per_scene]
            kept.reverse()
            video_backups[key] = [item[0] for item in kept]
            video_backup_thumbnails[key] = [_ensure_builder_scene_video_thumbnail(item[0]) for item in kept]
    return {
        "project_folder": folder,
        "video_folder": video_folder,
        "videos": videos,
        "video_thumbnails": video_thumbnails,
        "video_backups": video_backups,
        "video_backup_thumbnails": video_backup_thumbnails,
        "recovered_from_scratch": recovered_from_scratch,
    }


def _ensure_music_builder_routes():
    global _VRGDG_MUSIC_BUILDER_ROUTES_REGISTERED
    if _VRGDG_MUSIC_BUILDER_ROUTES_REGISTERED:
        return
    server_instance = getattr(PromptServer, "instance", None)
    if server_instance is None:
        return
    register_lut_routes(server_instance)
    register_face_fix_routes(server_instance)

    @server_instance.routes.post("/vrgdg/music_builder/analyze_audio")
    async def vrgdg_music_builder_analyze_audio(request):
        try:
            payload = await request.json()
            audio_path = _resolve_existing_file(payload.get("audio_path", ""), "Audio file")
            project_folder = os.path.abspath(str(payload.get("project_folder", "") or "").strip().strip('"'))
            if os.path.splitext(audio_path)[1].lower() == ".m4a" and project_folder:
                audio_path = _convert_audio_to_wav(
                    audio_path,
                    os.path.join(project_folder, "project_audio", "project_audio.wav"),
                )
            result = _read_audio_peaks(audio_path, payload.get("target_peaks", 1600))
            result["beats"], result["tempo_bpm"] = _estimate_beats_from_audio(
                audio_path,
                result.get("peaks", []),
                result.get("duration", 0),
                include_tempo=True,
            )
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, "audio_path": audio_path, **result})

    @server_instance.routes.post("/vrgdg/music_builder/import_capcut_beats")
    async def vrgdg_music_builder_import_capcut_beats(request):
        try:
            payload = await request.json()
            result = _find_latest_capcut_beats(payload.get("audio_duration", 0))
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/save_session")
    async def vrgdg_music_builder_save_session(request):
        try:
            payload = await request.json()
            result = _save_builder_session(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/save_render_log")
    async def vrgdg_music_builder_save_render_log(request):
        try:
            payload = await request.json()
            result = _save_builder_render_log(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/save_wizard_draft")
    async def vrgdg_music_builder_save_wizard_draft(request):
        try:
            payload = await request.json()
            result = _save_wizard_draft(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/load_wizard_draft")
    async def vrgdg_music_builder_load_wizard_draft(request):
        try:
            payload = await request.json()
            result = _load_wizard_draft(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.get("/vrgdg/music_builder/model_defaults")
    async def vrgdg_music_builder_model_defaults(request):
        try:
            result = _load_model_defaults()
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/new_project")
    async def vrgdg_music_builder_new_project(request):
        try:
            payload = await request.json()
            result = _new_builder_project(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/save_project_as")
    async def vrgdg_music_builder_save_project_as(request):
        try:
            payload = await request.json()
            result = _save_builder_project_as(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.get("/vrgdg/music_builder/export_project")
    async def vrgdg_music_builder_export_project(request):
        zip_path = ""
        response = None
        try:
            zip_path, download_name = await asyncio.to_thread(
                _prepare_builder_project_export,
                request.query.get("project_folder", ""),
            )
            response = web.StreamResponse(status=200, headers={
                "Content-Type": "application/zip",
                "Content-Disposition": f'attachment; filename="{download_name}"',
                "Content-Length": str(os.path.getsize(zip_path)),
                "Cache-Control": "no-store",
            })
            await response.prepare(request)
            with open(zip_path, "rb") as handle:
                while True:
                    chunk = await asyncio.to_thread(handle.read, 1024 * 1024)
                    if not chunk:
                        break
                    await response.write(chunk)
            await response.write_eof()
            return response
        except Exception as exc:
            if response is not None and response.prepared:
                raise
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        finally:
            if zip_path:
                try:
                    os.remove(zip_path)
                except OSError:
                    pass

    @server_instance.routes.post("/vrgdg/music_builder/import_project")
    async def vrgdg_music_builder_import_project(request):
        temp_path = ""
        try:
            reader = await request.multipart()
            requested_name = ""
            upload = None
            async for part in reader:
                if part.name == "project_name":
                    requested_name = (await part.text()).strip()
                elif part.name == "project_zip":
                    suffix = os.path.splitext(part.filename or "project.zip")[1] or ".zip"
                    temp_handle = tempfile.NamedTemporaryFile(prefix="vrgdg_builder_import_", suffix=suffix, delete=False)
                    temp_path = temp_handle.name
                    upload = temp_handle
                    try:
                        while True:
                            chunk = await part.read_chunk(size=1024 * 1024)
                            if not chunk:
                                break
                            upload.write(chunk)
                    finally:
                        upload.close()
            if not temp_path or not os.path.isfile(temp_path):
                raise ValueError("Choose a .vrgdg.zip project package to import.")
            if not zipfile.is_zipfile(temp_path):
                raise ValueError("The selected file is not a valid ZIP project package.")
            result = await asyncio.to_thread(_import_builder_project_zip, temp_path, requested_name)
            return web.json_response({"ok": True, **result})
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        finally:
            if temp_path:
                try:
                    os.remove(temp_path)
                except OSError:
                    pass

    @server_instance.routes.post("/vrgdg/music_builder/save_scene_image")
    async def vrgdg_music_builder_save_scene_image(request):
        try:
            payload = await request.json()
            result = _save_scene_image(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/delete_project_media")
    async def vrgdg_music_builder_delete_project_media(request):
        try:
            payload = await request.json()
            result = _delete_project_media(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/archive_scene_image")
    async def vrgdg_music_builder_archive_scene_image(request):
        try:
            payload = await request.json()
            result = _archive_scene_image(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/extract_video_final_frame")
    async def vrgdg_music_builder_extract_video_final_frame(request):
        try:
            payload = await request.json()
            result = _extract_video_final_frame_as_scene_image(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/save_flux_reference_image")
    async def vrgdg_music_builder_save_flux_reference_image(request):
        try:
            payload = await request.json()
            result = _save_flux_reference_image(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/import_reference_subjects")
    async def vrgdg_music_builder_import_reference_subjects(request):
        try:
            payload = await request.json()
            result = _import_reference_subjects_from_project(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/import_reference_locations")
    async def vrgdg_music_builder_import_reference_locations(request):
        try:
            payload = await request.json()
            result = _import_reference_locations_from_project(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/save_scene_audio")
    async def vrgdg_music_builder_save_scene_audio(request):
        try:
            payload = await request.json()
            result = _save_scene_audio(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/save_project_audio")
    async def vrgdg_music_builder_save_project_audio(request):
        try:
            payload = await request.json()
            result = _save_project_audio(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/save_project_srt")
    async def vrgdg_music_builder_save_project_srt(request):
        try:
            payload = await request.json()
            result = _save_project_srt(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/save_single_scene_srt")
    async def vrgdg_music_builder_save_single_scene_srt(request):
        try:
            payload = await request.json()
            result = _save_single_scene_srt(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/trim_scene_audio")
    async def vrgdg_music_builder_trim_scene_audio(request):
        try:
            payload = await request.json()
            result = _trim_scene_audio(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/prepare_scene_audio_mix")
    async def vrgdg_music_builder_prepare_scene_audio_mix(request):
        try:
            payload = await request.json()
            result = _prepare_scene_audio_mix(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/load_session")
    async def vrgdg_music_builder_load_session(request):
        try:
            payload = await request.json()
            result = _load_builder_session(payload.get("project_folder", ""))
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.get("/vrgdg/music_builder/list_projects")
    async def vrgdg_music_builder_list_projects(request):
        try:
            result = _list_builder_projects(request.query.get("project_root", ""))
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/delete_project")
    async def vrgdg_music_builder_delete_project(request):
        try:
            payload = await request.json()
            result = _delete_builder_project(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/latent_status")
    async def vrgdg_music_builder_latent_status(request):
        try:
            payload = await request.json()
            project_folder = str(payload.get("project_folder", "") or "").strip().strip('"')
            scene_number = int(payload.get("scene_number", 1))
            result = SceneLatentManager.get_latent_info(project_folder, scene_number)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response(result)

    @server_instance.routes.post("/vrgdg/music_builder/check_latent_predecessor")
    async def vrgdg_music_builder_check_latent_predecessor(request):
        try:
            payload = await request.json()
            project_folder = str(payload.get("project_folder", "") or "").strip().strip('"')
            scene_number = int(payload.get("scene_number", 1))
            if scene_number <= 1:
                return web.json_response({
                    "ok": True,
                    "scene_number": scene_number,
                    "predecessor_needed": False,
                    "predecessor_exists": True,
                    "predecessor_scene": 0,
                    "predecessor_path": "",
                    "frame_count": 0,
                    "token_count": 0,
                    "dirty": False,
                })
            pred_scene = scene_number - 1
            info = SceneLatentManager.get_latent_info(project_folder, pred_scene)
            return web.json_response({
                "ok": True,
                "scene_number": scene_number,
                "predecessor_scene": pred_scene,
                "predecessor_needed": True,
                "predecessor_exists": info.get("exists", False),
                "predecessor_path": info.get("path", ""),
                "frame_count": info.get("frame_count", 0),
                "token_count": info.get("token_count", 0),
                "tail_padding_known": info.get("tail_padding_frames") is not None,
                "dirty": info.get("dirty", False),
            })
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)

    @server_instance.routes.post("/vrgdg/music_builder/delete_scene_latent")
    async def vrgdg_music_builder_delete_scene_latent(request):
        try:
            payload = await request.json()
            project_folder = str(payload.get("project_folder", "") or "").strip().strip('"')
            if bool(payload.get("all", False)):
                removed = SceneLatentManager.delete_all_latents(project_folder)
                return web.json_response({"ok": True, "deleted": removed > 0, "removed_files": removed, "all": True})
            scene_number = int(payload.get("scene_number", 1))
            reindex = bool(payload.get("reindex", True))
            deleted = SceneLatentManager.delete_latent(project_folder, scene_number)
            if reindex:
                SceneLatentManager.reindex_latents(project_folder, scene_number)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, "deleted": deleted, "scene_number": scene_number})

    @server_instance.routes.post("/vrgdg/music_builder/list_dirty_latents")
    async def vrgdg_music_builder_list_dirty_latents(request):
        try:
            payload = await request.json()
            project_folder = str(payload.get("project_folder", "") or "").strip().strip('"')
            dirty_scenes = SceneLatentManager.list_dirty(project_folder)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, "dirty_scenes": dirty_scenes})

    @server_instance.routes.post("/vrgdg/music_builder/scan_scene_videos")
    async def vrgdg_music_builder_scan_scene_videos(request):
        try:
            payload = await request.json()
            result = _scan_builder_scene_videos(payload.get("project_folder", ""))
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/restore_scene_video")
    async def vrgdg_music_builder_restore_scene_video(request):
        try:
            payload = await request.json()
            result = _restore_scene_video(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/load_srt")
    async def vrgdg_music_builder_load_srt(request):
        try:
            payload = await request.json()
            result = _load_srt_segments(payload.get("srt_path", ""))
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/load_prompt_json")
    async def vrgdg_music_builder_load_prompt_json(request):
        try:
            payload = await request.json()
            result = _load_prompt_json(payload.get("prompt_json_path", ""))
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/load_text_file")
    async def vrgdg_music_builder_load_text_file(request):
        try:
            payload = await request.json()
            result = _load_editable_text_file(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/save_text_file")
    async def vrgdg_music_builder_save_text_file(request):
        try:
            payload = await request.json()
            result = _save_editable_text_file(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/open_local_file")
    async def vrgdg_music_builder_open_local_file(request):
        try:
            payload = await request.json()
            path = _open_local_file(payload.get("path", ""))
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, "path": path})

    @server_instance.routes.get("/vrgdg/music_builder/default_context_paths")
    async def vrgdg_music_builder_default_context_paths(request):
        return web.json_response({"ok": True, **_default_context_paths()})

    @server_instance.routes.post("/vrgdg/music_builder/project_prompt_creator_paths")
    async def vrgdg_music_builder_project_prompt_creator_paths(request):
        try:
            payload = await request.json()
            result = _project_prompt_creator_paths(payload.get("project_folder", ""))
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/import_latest_prompt_creator_outputs")
    async def vrgdg_music_builder_import_latest_prompt_creator_outputs(request):
        try:
            payload = await request.json()
            result = _copy_latest_prompt_creator_outputs(payload.get("project_folder", ""))
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/copy_prompt_creator_outputs")
    async def vrgdg_music_builder_copy_prompt_creator_outputs(request):
        try:
            payload = await request.json()
            result = _copy_prompt_creator_outputs_from_source(
                payload.get("project_folder", ""),
                payload.get("source_project_folder", ""),
            )
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.get("/vrgdg/music_builder/default_audio_srt_paths")
    async def vrgdg_music_builder_default_audio_srt_paths(request):
        return web.json_response({"ok": True, **_default_audio_srt_paths()})

    @server_instance.routes.post("/vrgdg/music_builder/pick_path")
    async def vrgdg_music_builder_pick_path(request):
        try:
            payload = await request.json()
            path = _open_native_picker(str(payload.get("kind", "") or ""))
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, "path": path})

    @server_instance.routes.get("/vrgdg/music_builder/audio")
    async def vrgdg_music_builder_audio(request):
        raw_path = str(request.query.get("path", "") or "").strip()
        audio_path = os.path.normpath(os.path.abspath(raw_path))
        if not os.path.isfile(audio_path):
            return web.json_response({"ok": False, "error": "Audio file was not found."}, status=404)
        return web.FileResponse(audio_path)

    @server_instance.routes.get("/vrgdg/music_builder/gemma_choices")
    async def vrgdg_music_builder_gemma_choices(request):
        try:
            result = _gemma_choices()
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.get("/vrgdg/music_builder/llm_api_choices")
    async def vrgdg_music_builder_llm_api_choices(request):
        try:
            result = _llm_multi_choices()
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/test_llm_api")
    async def vrgdg_music_builder_test_llm_api(request):
        try:
            payload = await request.json()
            result = await asyncio.to_thread(_test_llm_api, payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/test_own_server")
    async def vrgdg_music_builder_test_own_server(request):
        try:
            payload = await request.json()
            result = await asyncio.to_thread(_test_own_server, payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/own_server_models")
    async def vrgdg_music_builder_own_server_models(request):
        try:
            payload = await request.json()
            result = await asyncio.to_thread(_list_own_server_models, payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/lm_studio_models")
    async def vrgdg_music_builder_lm_studio_models(request):
        try:
            payload = await request.json()
            result = _list_lm_studio_models(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/get_instruction")
    async def vrgdg_music_builder_get_instruction(request):
        try:
            payload = await request.json()
            result = _get_builder_instruction(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/save_instruction")
    async def vrgdg_music_builder_save_instruction(request):
        try:
            payload = await request.json()
            result = _save_builder_instruction(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/reset_instruction")
    async def vrgdg_music_builder_reset_instruction(request):
        try:
            payload = await request.json()
            result = _reset_builder_instruction(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/list_instruction_presets")
    async def vrgdg_music_builder_list_instruction_presets(request):
        try:
            payload = await request.json()
            result = _list_builder_instruction_presets(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/save_instruction_preset")
    async def vrgdg_music_builder_save_instruction_preset(request):
        try:
            payload = await request.json()
            result = _save_builder_instruction_preset(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/load_instruction_preset")
    async def vrgdg_music_builder_load_instruction_preset(request):
        try:
            payload = await request.json()
            result = _load_builder_instruction_preset(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=400)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/clear_memory_direct")
    async def vrgdg_music_builder_clear_memory_direct(request):
        try:
            result = await asyncio.to_thread(_clear_builder_memory_direct)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/generate_t2i")
    async def vrgdg_music_builder_generate_t2i(request):
        try:
            payload = await request.json()
            result = _generate_builder_t2i_prompt(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/agent_chat")
    async def vrgdg_music_builder_agent_chat(request):
        try:
            payload = await request.json()
            result = await asyncio.to_thread(_generate_builder_agent_reply, payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/generate_concept_prompts")
    async def vrgdg_music_builder_generate_concept_prompts(request):
        try:
            payload = await request.json()
            result = await asyncio.to_thread(_generate_builder_concept_prompts, payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/generate_motion_notes")
    async def vrgdg_music_builder_generate_motion_notes(request):
        try:
            payload = await request.json()
            result = await asyncio.to_thread(_generate_builder_motion_notes, payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/generate_i2v")
    async def vrgdg_music_builder_generate_i2v(request):
        try:
            payload = await request.json()
            result = _generate_builder_i2v_prompt(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/generate_chained_i2v")
    async def vrgdg_music_builder_generate_chained_i2v(request):
        try:
            payload = await request.json()
            result = _generate_builder_chained_i2v_prompt(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/generate_t2v")
    async def vrgdg_music_builder_generate_t2v(request):
        try:
            payload = await request.json()
            result = _generate_builder_t2v_prompt(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/enhance_video_prompt")
    async def vrgdg_music_builder_enhance_video_prompt(request):
        try:
            payload = await request.json()
            result = _enhance_builder_video_prompt(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/edit_video_prompt")
    async def vrgdg_music_builder_edit_video_prompt(request):
        try:
            payload = await request.json()
            result = _edit_builder_video_prompt(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/edit_image_prompt")
    async def vrgdg_music_builder_edit_image_prompt(request):
        try:
            payload = await request.json()
            result = _edit_builder_image_prompt(payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/generate_flux_klein_prompt")
    async def vrgdg_music_builder_generate_flux_klein_prompt(request):
        try:
            payload = await request.json()
            result = await asyncio.to_thread(_generate_flux_klein_prompt, payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/describe_reference_image")
    async def vrgdg_music_builder_describe_reference_image(request):
        try:
            payload = await request.json()
            result = await asyncio.to_thread(_generate_builder_reference_description, payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/analyze_story_references")
    async def vrgdg_music_builder_analyze_story_references(request):
        try:
            payload = await request.json()
            result = await asyncio.to_thread(_analyze_builder_story_references, payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/generate_nb_image_prompt")
    async def vrgdg_music_builder_generate_nb_image_prompt(request):
        try:
            payload = await request.json()
            result = await asyncio.to_thread(_generate_nb_image_prompt, payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/flux_reference_location_map")
    async def vrgdg_music_builder_flux_reference_location_map(request):
        try:
            payload = await request.json()
            result = await asyncio.to_thread(_generate_flux_reference_location_map, payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/flux_reference_extract_locations")
    async def vrgdg_music_builder_flux_reference_extract_locations(request):
        try:
            payload = await request.json()
            result = await asyncio.to_thread(_generate_flux_reference_locations, payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/wizard_locations_from_lyrics")
    async def vrgdg_music_builder_wizard_locations_from_lyrics(request):
        try:
            payload = await request.json()
            result = await asyncio.to_thread(_generate_wizard_locations_from_lyrics, payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/flux_reference_extract_subjects")
    async def vrgdg_music_builder_flux_reference_extract_subjects(request):
        try:
            payload = await request.json()
            result = await asyncio.to_thread(_generate_flux_reference_subjects, payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    @server_instance.routes.post("/vrgdg/music_builder/flux_reference_zimage_prompt")
    async def vrgdg_music_builder_flux_reference_zimage_prompt(request):
        try:
            payload = await request.json()
            result = await asyncio.to_thread(_generate_flux_reference_zimage_prompt, payload)
        except Exception as exc:
            return web.json_response({"ok": False, "error": str(exc)}, status=500)
        return web.json_response({"ok": True, **result})

    _VRGDG_MUSIC_BUILDER_ROUTES_REGISTERED = True


class VRGDG_MusicVideoBuilderUI:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "audio_path": ("STRING", {"default": ""}),
                "project_folder": ("STRING", {"default": ""}),
                "session_path": ("STRING", {"default": ""}),
                "srt_path": ("STRING", {"default": ""}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING")
    RETURN_NAMES = ("project_folder", "session_path", "srt_path")
    FUNCTION = "noop"
    CATEGORY = "VRGDG/UI"
    DESCRIPTION = "Prototype UI for building a music video from audio, timing segments, prompts, and approved ZImage previews."

    def noop(self, audio_path, project_folder, session_path, srt_path):
        return (project_folder, session_path, srt_path)


_ensure_music_builder_routes()


NODE_CLASS_MAPPINGS = {
    "VRGDG_MusicVideoBuilderUI": VRGDG_MusicVideoBuilderUI,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "VRGDG_MusicVideoBuilderUI": "VRGDG Music Video Builder UI",
}
