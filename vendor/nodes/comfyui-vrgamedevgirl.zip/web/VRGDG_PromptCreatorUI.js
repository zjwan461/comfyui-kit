import { app } from "../../../scripts/app.js";
import { api } from "../../../scripts/api.js";

const NODE_NAME = "VRGDG_PromptCreatorUI";
const MODAL_ID = "vrgdg-prompt-creator-ui-modal";
const TEXT_FIELDS = [
  {
    key: "full_lyrics",
    label: "Full lyrics",
    placeholder: "Enter full lyrics",
    rows: 8,
    defaultValue: `[Verse 1]
You see him too loud again
You like me small
You like me sweet
Dangled up at your feet
You like your truth diluted down
So it doesn't make a sound
But I can't whisper what I need
I won't blur what I see

[Chorus]
I'm too loud for you
Too real to dilute
And the crack in your perfect excuse
Yeah I blues, yeah I break
But I say what you won't say
I am too loud
Too loud for you

[Verse 2]
You flinch when I raise my voice
Like honesty's a choice
You call it overreacting
I call it reacting, yeah

[Chorus]
I'm too loud for you
Too sharp to down you
I'm the truth you're trying to lose
Yeah I burn, yeah I blow
Like a match in a quiet room
I am too loud
Too loud for you

[Bridge]
If loving me means silence
Then I'm too loud for you
Too loud for you`,
  },
  {
    key: "style_theme",
    label: "Style/theme",
    placeholder: "Enter style or theme notes",
    rows: 5,
    defaultValue: `Grounded cinematic realism with subtle grandeur, giving everyday moments emotional weight and visual elegance.

Neutral earth tones and soft desaturated blues with warm amber highlights, deepening into richer cinematic contrast.

Balanced framing with slow pushes and wides emphasizing scale; medium shots focused on natural human moments.

Soft natural light with gentle contrast, shifting from diffused daylight to warmer, shadow-rich tones for a calm, immersive mood.`,
  },
  {
    key: "story_idea",
    label: "Story idea",
    placeholder: "Enter the story idea",
    rows: 5,
    defaultValue: `Music Video Concept Seed: "Too Loud"

Core Visual Metaphor:
The singer exists in a perfectly controlled world populated entirely by mannequins, silent, posed, and emotionless. She's the only real, living person. As her voice grows louder and more honest, the mannequins and their artificial environment begin to crack, fall, and break apart, revealing how fragile the quiet, controlled world actually is.

Aesthetic & Mood

Color palette: Soft pastels, creams, and sterile showroom lighting at the start, slowly invaded by deep blues, reds, and harsh shadows.

Setting style: A blend of department store displays, staged living rooms, and dollhouse-like interiors.

Tone: Surreal, eerie, and increasingly empowering.

Opening Visual (Verse 1)

The video opens in what looks like a perfectly staged living room display, like something inside a department store window.

Mannequins sit around a tiny tea table in polite poses, permanently smiling.

The singer sits among them, the only real person.

The mannequins are positioned as if they're listening to her, but they never move.

Their smiles feel hollow and unsettling.

She looks uncomfortable being placed among them.

The room feels like a performance of politeness rather than a real environment.

Chorus

As she sings "I'm too loud for you", the mannequins begin reacting, but only through subtle physical effects.

Tiny fractures appear across their porcelain faces.

A mannequin's arm slowly falls off.

Glass objects begin vibrating from the force of her voice.

The environment starts losing its perfect symmetry.

Verse 2

She walks through a long hallway of staged scenes, like different showroom displays of "perfect behavior."

Examples:

A mannequin couple smiling at a dinner table.

A mannequin family sitting politely on a couch.

A mannequin office meeting frozen mid-conversation.

Each time she sings something honest:

Cracks spread across the mannequins.

Some begin tipping over.

One collapses completely.

Her voice disrupts every carefully staged scene.

Second Chorus

She enters a large, perfectly arranged dinner party display filled with mannequins.

Everything is pristine and silent.

On the line "like a match in a quiet room":

A match is struck.

Instead of fire spreading, light fractures across the mannequins, breaking them apart like porcelain statues.

Pieces fall across the table.

Bridge

The walls collapse outward, revealing the entire world is just a massive showroom or stage set.

Rows and rows of mannequins stand in darkness beyond the set, watching silently.

She sings directly toward them.

Her voice echoes through the empty warehouse-like space.

Final Image

The camera pulls back.

The staged rooms are shattered. Mannequin pieces lie scattered everywhere.

She stands alone in the middle of the wreckage.

The only living person in a world that demanded stillness.

She isn't trying to fit into the display anymore, she's broken the entire showroom.`,
  },
  {
    key: "subjects_and_scenes",
    label: "Subjects and scenes",
    placeholder: "Enter subjects and scenes",
    rows: 6,
    defaultValue: `Subjects:
A female with dark brown hair and hazel eyes
wearing a soft pastel dress

A genderless mannequin with smooth white molded hair and blank gray eyes
wearing a pastel showroom outfit

Scene:
a department store living room display with a tea table
a long showroom hallway lined with staged room displays
a staged dining room dinner party display
a staged living room family display
a staged office meeting display
a massive warehouse-like showroom filled with rows of mannequins
a shattered showroom floor scattered with mannequin pieces`,
  },
  {
    key: "text_to_image_notes",
    label: "Text to image notes",
    placeholder: "Enter text to image notes",
    rows: 5,
    defaultValue: `A female with dark brown hair and hazel eyes
wearing a soft pastel dress = image index 1
when its this women, always say "using the provided character reference image"


A genderless mannequin with smooth white molded hair and blank gray eyes
wearing a pastel showroom outfit = image index 2

when its just one character, always say "using the provided character reference image"

both characters together in a scene = image index 1,2

when its both character, always say "using the provided character reference images"

Scene:
a department store living room display with a tea table
a long showroom hallway lined with staged room displays
a staged dining room dinner party display
a staged living room family display
a staged office meeting display
a massive warehouse-like showroom filled with rows of mannequins
a shattered showroom floor scattered with mannequin pieces`,
  },
  {
    key: "image_to_video_notes",
    label: "Image to video notes",
    placeholder: "Enter image to video notes",
    rows: 5,
    defaultValue: `we must always describe the subjects when they are mentioned. 
Subjects:
A female with dark brown hair and hazel eyes
wearing a soft pastel dress

A genderless mannequin with smooth white molded hair and blank gray eyes
wearing a pastel showroom outfit

always describe the scenes: 
Scene:
a department store living room display with a tea table
a long showroom hallway lined with staged room displays
a staged dining room dinner party display
a staged living room family display
a staged office meeting display
a massive warehouse-like showroom filled with rows of mannequins
a shattered showroom floor scattered with mannequin pieces

when the female with dark brown hair and hazel eyes
wearing a soft pastel dress is mentioned in the prompt we must say "she is singing with passion" or "as she sings with passion" right away in the prompt. as soon as possible. 

if a subject is not mentioned we should not describe them at all.

never fade to black or add any type of lighting that goes darker that could cause a fade out.`,
  },
];

function getStoredFieldValue(node, field) {
  const propertyName = `vrgdg_test_popup_${field.key}`;
  if (Object.prototype.hasOwnProperty.call(node.properties || {}, propertyName)) {
    return String(node.properties[propertyName] || "");
  }
  return String(field.defaultValue || "");
}

function createButton(label, styles = "") {
  const button = document.createElement("button");
  button.textContent = label;
  button.style.cssText = `
    border-radius: 8px;
    padding: 10px 14px;
    cursor: pointer;
    font-size: 13px;
    ${styles}
  `;
  return button;
}

function createPathHint() {
  const hint = document.createElement("div");
  hint.style.cssText = `
    font-size: 12px;
    line-height: 1.4;
    color: #94a3b8;
    margin-top: 6px;
    word-break: break-all;
  `;
  return hint;
}

async function fetchConfig() {
  const response = await api.fetchApi("/vrgdg/test_popup/config", { cache: "no-store" });
  if (!response.ok) {
    throw new Error(`Config load failed (${response.status})`);
  }
  const data = await response.json();
  if (!data?.ok) {
    throw new Error(String(data?.error || "Config load failed"));
  }
  return data;
}

async function uploadAudio(file) {
  const form = new FormData();
  form.append("audio", file);

  const response = await api.fetchApi("/vrgdg/test_popup/upload_audio", {
    method: "POST",
    body: form,
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data?.ok) {
    throw new Error(String(data?.error || `Audio upload failed (${response.status})`));
  }
  return data;
}

async function saveText(payload) {
  const response = await api.fetchApi("/vrgdg/test_popup/save_text", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data?.ok) {
    throw new Error(String(data?.error || `Save failed (${response.status})`));
  }
  return data;
}

function ensureModal() {
  let overlay = document.getElementById(MODAL_ID);
  if (overlay) return overlay;

  overlay = document.createElement("div");
  overlay.id = MODAL_ID;
  overlay.style.cssText = `
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.52);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 10000;
    padding: 16px;
  `;

  const panel = document.createElement("div");
  panel.style.cssText = `
    width: min(920px, calc(100vw - 32px));
    max-height: calc(100vh - 32px);
    overflow: auto;
    background: #1f2328;
    color: #f3f4f6;
    border: 1px solid #364152;
    border-radius: 14px;
    box-shadow: 0 24px 70px rgba(0, 0, 0, 0.45);
    padding: 18px;
    font-family: Arial, sans-serif;
  `;

  const titleRow = document.createElement("div");
  titleRow.style.cssText = `
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin-bottom: 16px;
  `;

  const titleBlock = document.createElement("div");

  const title = document.createElement("div");
  title.textContent = "VRGDG Prompt Asset Editor";
  title.style.cssText = "font-size: 20px; font-weight: 700;";

  const subtitle = document.createElement("div");
  subtitle.textContent = "Save text assets and upload one audio file without running the workflow.";
  subtitle.style.cssText = "margin-top: 4px; font-size: 13px; color: #94a3b8;";

  titleBlock.append(title, subtitle);

  const closeButton = createButton(
    "Close",
    "border: 1px solid #4b5563; background: #2b3138; color: #f3f4f6;"
  );

  const audioSection = document.createElement("div");
  audioSection.style.cssText = `
    border: 1px solid #364152;
    border-radius: 12px;
    padding: 14px;
    margin-bottom: 16px;
    background: #14191f;
  `;

  const audioTitle = document.createElement("div");
  audioTitle.textContent = "Audio upload";
  audioTitle.style.cssText = "font-size: 15px; font-weight: 700; margin-bottom: 8px;";

  const audioHint = createPathHint();
  const audioFileName = document.createElement("div");
  audioFileName.style.cssText = "margin: 8px 0; font-size: 13px; color: #cbd5e1;";
  audioFileName.textContent = "No audio file selected.";

  const audioActions = document.createElement("div");
  audioActions.style.cssText = "display: flex; gap: 10px; align-items: center; flex-wrap: wrap;";

  const chooseAudioButton = createButton(
    "Choose and Upload Audio",
    "border: 1px solid #0f766e; background: #0f766e; color: white;"
  );

  const hiddenAudioInput = document.createElement("input");
  hiddenAudioInput.type = "file";
  hiddenAudioInput.accept = "audio/*,video/*";
  hiddenAudioInput.style.display = "none";

  audioActions.append(chooseAudioButton, hiddenAudioInput);
  audioSection.append(audioTitle, audioHint, audioFileName, audioActions);

  const textGrid = document.createElement("div");
  textGrid.style.cssText = `
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 14px;
  `;

  const textareas = {};
  const pathHints = {};
  for (const field of TEXT_FIELDS) {
    const section = document.createElement("div");
    section.style.cssText = `
      border: 1px solid #364152;
      border-radius: 12px;
      padding: 14px;
      background: #14191f;
    `;

    const label = document.createElement("label");
    label.textContent = field.label;
    label.style.cssText = "display: block; margin-bottom: 8px; font-size: 14px; font-weight: 700;";

    const textarea = document.createElement("textarea");
    textarea.rows = field.rows;
    textarea.placeholder = field.placeholder;
    textarea.style.cssText = `
      width: 100%;
      box-sizing: border-box;
      resize: vertical;
      padding: 10px 12px;
      border-radius: 8px;
      border: 1px solid #4b5563;
      background: #0d1217;
      color: #f3f4f6;
      font-size: 13px;
      line-height: 1.45;
    `;

    const hint = createPathHint();

    section.append(label, textarea, hint);
    textGrid.appendChild(section);
    textareas[field.key] = textarea;
    pathHints[field.key] = hint;
  }

  const status = document.createElement("div");
  status.style.cssText = `
    min-height: 20px;
    margin-top: 16px;
    margin-bottom: 14px;
    font-size: 13px;
    color: #cbd5e1;
    white-space: pre-wrap;
  `;

  const actions = document.createElement("div");
  actions.style.cssText = "display: flex; gap: 10px; justify-content: flex-end; margin-top: 8px;";

  const saveButton = createButton(
    "Save All Text Files",
    "border: 1px solid #1d4ed8; background: #2563eb; color: white;"
  );

  titleRow.append(titleBlock, closeButton);
  actions.append(saveButton);
  panel.append(titleRow, audioSection, textGrid, status, actions);
  overlay.appendChild(panel);
  document.body.appendChild(overlay);

  const state = {
    node: null,
    config: null,
    status,
    saveButton,
    chooseAudioButton,
    hiddenAudioInput,
    audioFileName,
    audioHint,
    textareas,
    pathHints,
  };

  function setStatus(message, isError = false) {
    status.textContent = message || "";
    status.style.color = isError ? "#fca5a5" : "#cbd5e1";
  }

  function closeModal() {
    overlay.style.display = "none";
    state.node = null;
    setStatus("");
  }

  function syncNodeProperties() {
    if (!state.node) return;
    state.node.properties = state.node.properties || {};
    for (const field of TEXT_FIELDS) {
      state.node.properties[`vrgdg_test_popup_${field.key}`] = String(textareas[field.key].value || "");
    }
  }

  async function ensureConfigLoaded() {
    if (state.config) return state.config;
    state.config = await fetchConfig();
    state.audioHint.textContent = `Target folder: ${String(state.config.audio_dir || "")}`;
    for (const field of TEXT_FIELDS) {
      pathHints[field.key].textContent = `Writes to: ${String(state.config.text_targets?.[field.key] || "")}`;
    }
    return state.config;
  }

  async function saveCurrentTexts() {
    saveButton.disabled = true;
    setStatus("Saving text files...");
    try {
      await ensureConfigLoaded();
      const payload = {};
      for (const field of TEXT_FIELDS) {
        payload[field.key] = String(textareas[field.key].value || "");
      }
      const data = await saveText(payload);
      syncNodeProperties();
      setStatus(`Saved ${Object.keys(data.saved_paths || {}).length} text files.`);
    } catch (error) {
      setStatus(String(error?.message || error), true);
    } finally {
      saveButton.disabled = false;
    }
  }

  async function handleAudioSelection() {
    const file = hiddenAudioInput.files?.[0];
    hiddenAudioInput.value = "";
    if (!file) return;

    chooseAudioButton.disabled = true;
    setStatus(`Uploading audio: ${file.name}`);
    try {
      await ensureConfigLoaded();
      const data = await uploadAudio(file);
      if (state.node) {
        state.node.properties = state.node.properties || {};
        state.node.properties.vrgdg_test_popup_audio_filename = String(data.filename || file.name);
      }
      audioFileName.textContent = `Current uploaded audio: ${String(data.filename || file.name)}`;
      setStatus(`Audio uploaded to ${String(data.path || "")}`);
    } catch (error) {
      setStatus(String(error?.message || error), true);
    } finally {
      chooseAudioButton.disabled = false;
    }
  }

  closeButton.addEventListener("click", closeModal);
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeModal();
  });
  saveButton.addEventListener("click", saveCurrentTexts);
  chooseAudioButton.addEventListener("click", () => hiddenAudioInput.click());
  hiddenAudioInput.addEventListener("change", handleAudioSelection);

  for (const field of TEXT_FIELDS) {
    textareas[field.key].addEventListener("input", syncNodeProperties);
  }

  overlay.__vrgdgOpenForNode = async (node) => {
    state.node = node;
    state.node.properties = state.node.properties || {};

    for (const field of TEXT_FIELDS) {
      textareas[field.key].value = getStoredFieldValue(state.node, field);
    }
    syncNodeProperties();

    const audioName = String(state.node.properties.vrgdg_test_popup_audio_filename || "");
    audioFileName.textContent = audioName ? `Current uploaded audio: ${audioName}` : "No audio file selected.";

    setStatus("");
    overlay.style.display = "flex";

    try {
      await ensureConfigLoaded();
    } catch (error) {
      setStatus(String(error?.message || error), true);
    }

    setTimeout(() => textareas.full_lyrics.focus(), 0);
  };

  return overlay;
}

function attachButton(node) {
  const buttonName = "Open Prompt Creator UI";
  const openUi = () => {
    const modal = ensureModal();
    modal.__vrgdgOpenForNode(node);
  };
  node.widgets = (node.widgets || []).filter((widget) => !(widget.type === "button" && widget.name === buttonName));

  const button = node.addWidget("button", buttonName, null, openUi);
  if (button) button.serialize = false;
}

app.registerExtension({
  name: "vrgdg." + NODE_NAME,

  loadedGraphNode(node) {
    if ((node?.comfyClass || node?.type) === NODE_NAME) attachButton(node);
  },

  async beforeRegisterNodeDef(nodeType, nodeData) {
    if (nodeData.name !== NODE_NAME) return;

    const onNodeCreated = nodeType.prototype.onNodeCreated;
    const onConfigure = nodeType.prototype.onConfigure;

    nodeType.prototype.onNodeCreated = function () {
      const result = onNodeCreated?.apply(this, arguments);
      this.serialize_widgets = true;
      this.properties = this.properties || {};
      attachButton(this);
      return result;
    };

    nodeType.prototype.onConfigure = function () {
      const result = onConfigure?.apply(this, arguments);
      this.properties = this.properties || {};
      attachButton(this);
      return result;
    };
  },
});
