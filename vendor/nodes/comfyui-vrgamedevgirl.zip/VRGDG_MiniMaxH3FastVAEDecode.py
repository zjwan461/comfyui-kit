import copy
import time
from functools import partial

import torch

import comfy.model_management as mm
from comfy.ldm.minimax.vae import MiniMaxH3VideoVAE


def tiled_decode_batched(model, z, tile_batch_size):
    height, width = z.shape[-2] * model.vae_ratio, z.shape[-1] * model.vae_ratio
    y_idx, y_len, y_overlap = model.split_tiles(height)
    x_idx, x_len, x_overlap = model.split_tiles(width)
    tiles = [(i, j, yp // model.vae_ratio, yl // model.vae_ratio,
              xp // model.vae_ratio, xl // model.vae_ratio)
             for i, (yp, yl) in enumerate(zip(y_idx, y_len))
             for j, (xp, xl) in enumerate(zip(x_idx, x_len))]
    canvas = None
    row_tails = []
    new_tails = []
    left_tail = None
    out_y = 0
    out_x = 0
    start = 0
    while start < len(tiles):
        mm.throw_exception_if_processing_interrupted()
        end = start + 1
        shape = (tiles[start][3], tiles[start][5])
        while end < min(start + tile_batch_size, len(tiles)):
            if (tiles[end][3], tiles[end][5]) != shape:
                break
            end += 1
        batch = torch.cat([z[..., yp:yp + yl, xp:xp + xl]
                           for _, _, yp, yl, xp, xl in tiles[start:end]], dim=0)
        decoded = model._decode_pixels(batch)
        for k, (i, j, _, _, _, _) in enumerate(tiles[start:end]):
            tile = decoded[k * z.shape[0]:(k + 1) * z.shape[0]]
            if i < len(y_idx) - 1:
                new_tails.append(tile[..., -y_overlap[i]:, :].clone())
            next_left_tail = tile[..., :, -x_overlap[j]:].clone() if j < len(x_idx) - 1 else None
            if i > 0:
                tile = model.blend(row_tails[j], tile, y_overlap[i - 1], dim=-2)
            if j > 0:
                tile = model.blend(left_tail, tile, x_overlap[j - 1], dim=-1)
            left_tail = next_left_tail
            if i < len(y_idx) - 1:
                tile = tile[..., :-y_overlap[i], :]
            if j < len(x_idx) - 1:
                tile = tile[..., :, :-x_overlap[j]]
            if canvas is None:
                canvas = torch.empty(*tile.shape[:-2], height, width, dtype=tile.dtype, device=tile.device)
            canvas[..., out_y:out_y + tile.shape[-2], out_x:out_x + tile.shape[-1]].copy_(tile)
            out_x += tile.shape[-1]
            if j == len(x_idx) - 1:
                row_tails = new_tails
                new_tails = []
                out_y += tile.shape[-2]
                out_x = 0
        del tile, decoded, batch
        start = end
    return canvas


class H3FastVAEDecode:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "samples": ("LATENT",),
            "vae": ("VAE",),
            "tile_batch_size": ("INT", {"default": 4, "min": 1, "max": 16,
                "tooltip": "Spatial tiles decoded together. Uses more VRAM. 1 runs stock decoding."}),
        }}

    RETURN_TYPES = ("IMAGE", "STRING")
    RETURN_NAMES = ("images", "report")
    FUNCTION = "decode"
    CATEGORY = "MiniMax H3/VAE"
    DESCRIPTION = "Experimental H3 video decode with batched spatial tiles; preserves stock temporal processing and blending."

    def decode(self, samples, vae, tile_batch_size=4):
        if not isinstance(vae.first_stage_model, MiniMaxH3VideoVAE):
            raise ValueError("H3 VAE Decode Fast requires the MiniMax H3 video VAE.")
        latent = samples["samples"]
        if latent.is_nested:
            latent = latent.unbind()[0]
        start = time.perf_counter()
        if tile_batch_size == 1:
            images = vae.decode(latent)
        else:
            work_vae = copy.copy(vae)
            work_vae.patcher = vae.patcher.clone()
            work_vae.patcher.add_object_patch("tiled_decode", partial(
                tiled_decode_batched, vae.first_stage_model, tile_batch_size=tile_batch_size))
            memory_estimate = vae.memory_used_decode
            work_vae.memory_used_decode = lambda shape, dtype: memory_estimate(shape, dtype) * tile_batch_size
            try:
                images = work_vae.decode(latent)
            finally:
                mm.unload_model_and_clones(work_vae.patcher)
                work_vae.patcher.unpatch_model(unpatch_weights=False)
        if images.ndim == 5:
            images = images.reshape(-1, *images.shape[-3:])
        if images.is_cuda:
            torch.cuda.synchronize(images.device)
        elapsed = time.perf_counter() - start
        report = f"H3 decode: {elapsed:.2f}s, {images.shape[0]} frames, tile batch {tile_batch_size} (includes loading and cleanup)."
        return images, report


NODE_CLASS_MAPPINGS = {"H3FastVAEDecode": H3FastVAEDecode}
NODE_DISPLAY_NAME_MAPPINGS = {"H3FastVAEDecode": "H3 VAE Decode Fast (Batched Tiles)"}
