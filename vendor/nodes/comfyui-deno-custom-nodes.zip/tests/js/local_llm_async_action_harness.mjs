import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(here, "..", "..");
const sourcePath = path.join(repoRoot, "web", "js", "deno_local_llm_refiner.js");
const source = fs
    .readFileSync(sourcePath, "utf8")
    .replace(/^import\s+\{[^}]+\}\s+from\s+["'][^"']+["'];\r?\n/gm, "");

const graph = {
    _nodes: [],
    getNodeById(id) {
        return this._nodes.find((node) => String(node?.id) === String(id)) || null;
    },
    setDirtyCanvas() {},
};

const context = {
    console,
    process,
    Date,
    Math,
    JSON,
    Number,
    String,
    Boolean,
    Array,
    Object,
    Set,
    Map,
    WeakMap,
    WeakSet,
    URL,
    URLSearchParams,
    AbortController,
    app: {
        graph,
        canvas: { graph },
        registerExtension(extension) {
            context.capturedExtension = extension;
        },
    },
    api: {
        addEventListener() {},
        apiURL(value) { return value; },
    },
    window: {
        addEventListener() {},
        setTimeout() { return 0; },
        requestAnimationFrame() { return 0; },
        cancelAnimationFrame() {},
    },
    queueMicrotask(callback) { callback(); },
    document: {
        addEventListener() {},
        querySelectorAll() { return []; },
        querySelector() { return null; },
    },
    LiteGraph: {
        NODE_WIDGET_HEIGHT: 24,
        WIDGET_BGCOLOR: "#222",
        WIDGET_OUTLINE_COLOR: "#555",
    },
    Image: class {},
    capturedApi: null,
    capturedExtension: null,
};
context.globalThis = context;
context.__DENO_LOCAL_LLM_REVIEWER_TEST_HOOK__ = (api) => {
    context.capturedApi = api;
};

vm.createContext(context);
vm.runInContext(source, context, { filename: sourcePath });

const api = context.capturedApi;
assert(api, "Local LLM async-action test API was not exposed");

function assert(condition, message) {
    if (!condition) {
        throw new Error(message);
    }
}

function deferred() {
    let resolve;
    let reject;
    const promise = new Promise((resolvePromise, rejectPromise) => {
        resolve = resolvePromise;
        reject = rejectPromise;
    });
    return { promise, resolve, reject };
}

function response(payload, ok = true, status = 200) {
    return {
        ok,
        status,
        async json() { return payload; },
    };
}

function makeWidget(name, value, values = []) {
    return {
        name,
        label: name,
        value,
        type: values.length ? "combo" : "text",
        options: values.length ? { values: [...values], list: [...values] } : {},
    };
}

function makeNode(id) {
    const node = {
        id,
        type: "DenoLocalLLMRefiner",
        graph,
        properties: {},
        inputs: [],
        outputs: [],
        size: [560, 300],
        __denoLocalLLMRefreshing: true,
        widgets: [
            makeWidget("provider", "Ollama", ["Ollama", "LM Studio", "llama.cpp", "vLLM", "Custom", "llama-swap", "Unsloth"]),
            makeWidget("ollama_model", "qwen3", ["qwen3"]),
            makeWidget("lm_studio_model", "google/gemma", ["google/gemma"]),
            makeWidget("custom_server_url", "http://127.0.0.1:8000/v1"),
            makeWidget("custom_model", "custom-model"),
            makeWidget("model_memory", "Unload after run", ["Unload after run", "Keep for minutes", "Keep loaded"]),
            makeWidget("keep_minutes", 5),
        ],
        addWidget(type, name, value, callback, options = {}) {
            const widget = { type, name, label: name, value, callback, options };
            this.widgets.push(widget);
            return widget;
        },
        setDirtyCanvas() {},
    };
    return node;
}

const fetchCalls = [];
context.fetch = (url, options = {}) => {
    const pending = deferred();
    fetchCalls.push({ url, options, pending });
    return pending.promise;
};

const actionNode = makeNode(10);
graph._nodes = [actionNode];
const staleRefresh = api.refreshModels(actionNode);
assert(fetchCalls.length === 1 && fetchCalls[0].url.endsWith("/models"), "Refresh must start the model-list request");
const refreshSignal = fetchCalls[0].options.signal;
const newerUnload = api.unloadLocalModel(actionNode);
assert(fetchCalls.length === 2 && fetchCalls[1].url.endsWith("/unload"), "Unload must supersede the older refresh action");
assert(refreshSignal?.aborted === true, "A superseded read-only Refresh request must be aborted");
fetchCalls[1].pending.resolve(response({ ok: true, message: "newer unload finished" }));
await newerUnload;
assert(api.getLocalLLMNodeState(actionNode).status === "LLM unloaded", "The newer Unload response must own visible state");
fetchCalls[0].pending.resolve(response({ models: [{ id: "stale-model" }] }));
await staleRefresh;
assert(api.getLocalLLMNodeState(actionNode).status === "LLM unloaded", "A late Refresh response must not overwrite a newer action");
assert(
    !actionNode.properties.denoLocalLLMModelChoicesByProvider?.Ollama,
    "A late Refresh response must not mutate provider model choices",
);

const stopNode = makeNode(14);
graph._nodes = [stopNode];
const staleStop = api.stopLocalModel(stopNode);
const staleStopCall = fetchCalls.at(-1);
const newerStopRefresh = api.refreshModels(stopNode);
const newerStopRefreshCall = fetchCalls.at(-1);
assert(staleStopCall.options.signal?.aborted === false, "Superseding a Stop must not cancel its backend side effect");
newerStopRefreshCall.pending.resolve(response({ models: [{ id: "qwen3" }] }));
await newerStopRefresh;
assert(api.getLocalLLMNodeState(stopNode).status === "1 models found", "The newer Refresh must own state after Stop");
staleStopCall.pending.resolve(response({ ok: true, message: "late stop response" }));
await staleStop;
assert(api.getLocalLLMNodeState(stopNode).status === "1 models found", "A late Stop response must not overwrite a newer Refresh");

const unloadNode = makeNode(15);
graph._nodes = [unloadNode];
const staleUnload = api.unloadLocalModel(unloadNode);
const staleUnloadCall = fetchCalls.at(-1);
const newerUnloadRefresh = api.refreshModels(unloadNode);
const newerUnloadRefreshCall = fetchCalls.at(-1);
assert(staleUnloadCall.options.signal?.aborted === false, "Superseding Unload must not cancel its backend side effect");
newerUnloadRefreshCall.pending.resolve(response({ models: [{ id: "qwen3" }] }));
await newerUnloadRefresh;
assert(api.getLocalLLMNodeState(unloadNode).status === "1 models found", "The newer Refresh must own state after Unload");
staleUnloadCall.pending.resolve(response({ ok: true, message: "late unload response" }));
await staleUnload;
assert(api.getLocalLLMNodeState(unloadNode).status === "1 models found", "A late Unload response must not overwrite a newer Refresh");

const repeatedUnloadNode = makeNode(16);
graph._nodes = [repeatedUnloadNode];
const firstUnload = api.unloadLocalModel(repeatedUnloadNode);
const firstUnloadCall = fetchCalls.at(-1);
const fetchCountBeforeRepeat = fetchCalls.length;
await api.unloadLocalModel(repeatedUnloadNode);
assert(fetchCalls.length === fetchCountBeforeRepeat, "Clicking Unload again while it is pending must not duplicate the request");
assert(firstUnloadCall.options.signal?.aborted === false, "A repeated Unload click must let the original unload finish");
firstUnloadCall.pending.resolve(response({ ok: true, message: "original unload finished" }));
await firstUnload;
assert(api.getLocalLLMNodeState(repeatedUnloadNode).status === "LLM unloaded", "The in-flight Unload result must remain visible after a repeated click");

const providerNode = makeNode(11);
graph._nodes = [providerNode];
const providerRefresh = api.refreshModels(providerNode);
const providerRefreshCall = fetchCalls.at(-1);
api.wrapProviderCallback(providerNode);
const providerWidget = api.getWidget(providerNode, "provider");
providerWidget.value = "LM Studio";
providerWidget.callback?.("LM Studio");
assert(providerRefreshCall.options.signal?.aborted === true, "Changing provider must abort its stale Refresh request");
providerRefreshCall.pending.resolve(response({ models: [{ id: "old-ollama-model" }] }));
await providerRefresh;
assert(api.getLocalLLMNodeState(providerNode).provider === "LM Studio", "A late old-provider response must not restore the previous provider");
assert(
    !providerNode.properties.denoLocalLLMModelChoicesByProvider?.Ollama,
    "A late old-provider response must not update hidden old-provider choices",
);

providerWidget.value = "llama-swap";
providerWidget.callback?.("llama-swap");
assert(
    JSON.stringify(providerWidget.options.values) === JSON.stringify([
        "Ollama",
        "LM Studio",
        "llama.cpp",
        "vLLM",
        "Custom",
        "llama-swap",
        "Unsloth",
    ]),
    "Unsloth must be appended after the existing provider order",
);
assert(
    api.getWidget(providerNode, "custom_server_url").value === "http://127.0.0.1:8080/v1",
    "A first llama-swap selection must apply its OpenAI-compatible default URL",
);
assert(
    api.getLocalLLMNodeState(providerNode).thinking.includes("llama-swap"),
    "llama-swap selection must explain its management-API memory behavior",
);
const llamaSwapMemoryWidget = api.getWidget(providerNode, "model_memory");
llamaSwapMemoryWidget.value = "Keep for minutes";
providerWidget.callback?.("llama-swap");
assert(
    api.getWidget(providerNode, "keep_minutes").hidden === true,
    "llama-swap must hide the local Keep Minutes value because its server-side timeout owns timed unload",
);
assert(
    api.getLocalLLMNodeState(providerNode).thinking.includes("server-side unload timeout"),
    "llama-swap Keep for minutes must not claim that DENO schedules a timed management-API unload",
);
llamaSwapMemoryWidget.value = "Keep loaded";
providerWidget.callback?.("llama-swap");
assert(
    api.getLocalLLMNodeState(providerNode).thinking.includes("may still unload it"),
    "llama-swap Keep loaded must not override or overpromise against the server's own timeout",
);
llamaSwapMemoryWidget.value = "Unload after run";
providerWidget.callback?.("llama-swap");
const llamaSwapRefresh = api.refreshModels(providerNode);
const llamaSwapRefreshCall = fetchCalls.at(-1);
const llamaSwapRefreshBody = JSON.parse(llamaSwapRefreshCall.options.body);
assert(
    llamaSwapRefreshBody.provider === "llama-swap" &&
        llamaSwapRefreshBody.server_url === "http://127.0.0.1:8080/v1",
    "llama-swap Refresh must reuse the shared provider and Server URL request contract",
);
llamaSwapRefreshCall.pending.resolve(response({ models: [{ id: "custom-model" }] }));
await llamaSwapRefresh;
const llamaSwapUnload = api.unloadLocalModel(providerNode);
const llamaSwapUnloadCall = fetchCalls.at(-1);
const llamaSwapUnloadBody = JSON.parse(llamaSwapUnloadCall.options.body);
assert(
    llamaSwapUnloadBody.provider === "llama-swap" &&
        llamaSwapUnloadBody.server_url === "http://127.0.0.1:8080/v1" &&
        llamaSwapUnloadBody.model === "custom-model",
    "llama-swap Unload must reuse the selected model and management-aware backend contract",
);
llamaSwapUnloadCall.pending.resolve(response({ ok: true, message: "llama-swap model unloaded" }));
await llamaSwapUnload;
assert(
    api.getLocalLLMNodeState(providerNode).status === "LLM unloaded",
    "A successful llama-swap manual unload must be visible on the node",
);

providerWidget.value = "Unsloth";
providerWidget.callback?.("Unsloth");
assert(
    api.getWidget(providerNode, "custom_server_url").value === "http://127.0.0.1:8888/v1",
    "A first Unsloth selection must apply the Unsloth Studio default URL",
);
assert(
    api.getWidget(providerNode, "custom_server_url").hidden === false &&
        api.getWidget(providerNode, "custom_model").hidden === false &&
        api.getWidget(providerNode, "ollama_model").hidden === true &&
        api.getWidget(providerNode, "lm_studio_model").hidden === true,
    "Unsloth must reuse only the OpenAI-compatible Server URL and Model rows",
);
assert(
    api.getLocalLLMNodeState(providerNode).thinking.includes("Unsloth Studio") &&
        api.getLocalLLMNodeState(providerNode).thinking.includes("management API"),
    "Unsloth selection must explain its OpenAI-compatible and management-API behavior",
);
const unslothRefresh = api.refreshModels(providerNode);
const unslothRefreshCall = fetchCalls.at(-1);
const unslothRefreshBody = JSON.parse(unslothRefreshCall.options.body);
assert(
    unslothRefreshBody.provider === "Unsloth" &&
        unslothRefreshBody.server_url === "http://127.0.0.1:8888/v1",
    "Unsloth Refresh must reuse the shared provider and Server URL request contract",
);
unslothRefreshCall.pending.resolve(response({ models: [{ id: "unsloth/Qwen3.8-27B" }] }));
await unslothRefresh;
assert(
    providerNode.properties.denoLocalLLMModelChoicesByProvider?.Unsloth?.[0]?.id === "unsloth/Qwen3.8-27B" &&
        providerNode.properties.denoLocalLLMModelChoicesByProvider?.["llama-swap"]?.[0]?.id === "custom-model",
    "OpenAI-compatible model choices must stay separated by provider",
);

api.getWidget(providerNode, "custom_server_url").value = "http://127.0.0.1:8899/v1";
providerWidget.value = "llama-swap";
providerWidget.callback?.("llama-swap");
assert(
    api.getWidget(providerNode, "custom_server_url").value === "http://127.0.0.1:8080/v1",
    "Switching back to llama-swap must restore its provider-specific URL",
);
providerWidget.value = "Unsloth";
providerWidget.callback?.("Unsloth");
assert(
    api.getWidget(providerNode, "custom_server_url").value === "http://127.0.0.1:8899/v1",
    "Switching back to Unsloth must restore its provider-specific URL",
);

api.getWidget(providerNode, "custom_model").value = "unsloth/Qwen3.8-27B";
const unslothUnload = api.unloadLocalModel(providerNode);
const unslothUnloadCall = fetchCalls.at(-1);
const unslothUnloadBody = JSON.parse(unslothUnloadCall.options.body);
assert(
    unslothUnloadBody.provider === "Unsloth" &&
        unslothUnloadBody.server_url === "http://127.0.0.1:8899/v1" &&
        unslothUnloadBody.model === "unsloth/Qwen3.8-27B",
    "Unsloth Unload must reuse the selected model and management-aware backend contract",
);
unslothUnloadCall.pending.resolve(response({ ok: true, message: "Unsloth Studio model unloaded" }));
await unslothUnload;
assert(
    api.getLocalLLMNodeState(providerNode).status === "LLM unloaded",
    "A successful Unsloth manual unload must be visible on the node",
);

const executionNode = makeNode(12);
const executionGraph = {
    _nodes: [executionNode],
    getNodeById(id) { return String(id) === "12" ? executionNode : null; },
};
executionNode.graph = executionGraph;
graph._nodes = [executionNode];
const executionRefresh = api.refreshModels(executionNode);
const executionRefreshCall = fetchCalls.at(-1);
api.rememberLocalLLMPromptGraph("prompt-12", executionGraph);
assert(
    api.invalidateLocalLLMAsyncActionsForExecutionDetail({ prompt_id: "prompt-12" }, "execution started") === 1,
    "Execution start must invalidate every Loader in the submitted workflow",
);
api.setLocalLLMNodeState(executionNode, { status: "running", provider: "Ollama", model: "qwen3" });
assert(executionRefreshCall.options.signal?.aborted === true, "Execution must abort a stale Refresh request");
executionRefreshCall.pending.resolve(response({ models: [{ id: "too-late" }] }));
await executionRefresh;
assert(api.getLocalLLMNodeState(executionNode).status === "running", "A late Refresh response must not overwrite execution state");

const removedNode = makeNode(13);
graph._nodes = [removedNode];
let previousRemovedCalls = 0;
removedNode.onRemoved = () => { previousRemovedCalls += 1; };
api.installLocalLLMNodeCleanup(removedNode);
const removedRefresh = api.refreshModels(removedNode);
const removedRefreshCall = fetchCalls.at(-1);
removedNode.onRemoved();
assert(previousRemovedCalls === 1, "Async cleanup must preserve the prior onRemoved callback");
assert(removedRefreshCall.options.signal?.aborted === true, "Removing a Loader must abort its stale Refresh request");
removedRefreshCall.pending.resolve(response({ models: [{ id: "removed-node-model" }] }));
await removedRefresh;
assert(
    !removedNode.properties.denoLocalLLMModelChoicesByProvider?.Ollama,
    "A removed node must ignore a late Refresh response",
);

const appQueueRequests = [];
context.app.queuePrompt = function () {
    const pending = deferred();
    appQueueRequests.push(pending);
    return pending.promise;
};
assert(
    api.installLocalLLMAppQueuePromptHook(context.app) === true,
    "The app-level queue hook must install at the pre-serialization boundary",
);

const queueRaceNode = makeNode(17);
graph._nodes = [queueRaceNode];
const queueRaceRefresh = api.refreshModels(queueRaceNode);
const queueRaceRefreshCall = fetchCalls.at(-1);
const queuedFailure = context.app.queuePrompt(0, 1, null).then(
    () => null,
    (error) => error,
);
assert(
    queueRaceRefreshCall.options.signal?.aborted === true,
    "Queue submission must abort stale Refresh before graph serialization and HTTP response",
);
queueRaceRefreshCall.pending.resolve(response({ models: [{ id: "queue-race-stale" }] }));
await queueRaceRefresh;
assert(
    !queueRaceNode.properties.denoLocalLLMModelChoicesByProvider?.Ollama,
    "A late Refresh response must not change model choices even when queue submission fails",
);
appQueueRequests.at(-1).reject(new Error("queue rejected"));
assert((await queuedFailure)?.message === "queue rejected", "The queue hook must preserve queue failures");

const queueStopNode = makeNode(18);
graph._nodes = [queueStopNode];
const queueStop = api.stopLocalModel(queueStopNode);
const queueStopCall = fetchCalls.at(-1);
const queuedSuccess = context.app.queuePrompt(0, 1, null);
assert(
    queueStopCall.options.signal?.aborted === false,
    "Queue submission must not cancel an in-flight Stop backend side effect",
);
queueStopCall.pending.resolve(response({ ok: true, message: "stop completed" }));
appQueueRequests.at(-1).resolve(true);
await Promise.all([queueStop, queuedSuccess]);

function configureLMStudioNode(node, model, choices = [model]) {
    const providerWidget = api.getWidget(node, "provider");
    const modelWidget = api.getWidget(node, "lm_studio_model");
    providerWidget.value = "LM Studio";
    modelWidget.value = model;
    modelWidget.options = {
        ...(modelWidget.options || {}),
        values: [...choices],
        list: [...choices],
    };
    return modelWidget;
}

const savedLMStudioModel = "google/gemma-4-12b-qat";
const canonicalSavedValues = [
    "LM Studio",
    "qwen3",
    savedLMStudioModel,
    "http://127.0.0.1:8000/v1",
    "custom-model",
    "",
    false,
    1,
    "fixed",
    "Unload after run",
    5,
    "Auto: unload only before first LLM call",
    "",
];

const unslothSavedValues = [
    "Unsloth",
    "qwen3",
    savedLMStudioModel,
    "http://127.0.0.1:8888/v1",
    "unsloth/Qwen3.8-27B",
    "",
    false,
    1,
    "fixed",
    "Unload after run",
    5,
    "Auto: unload only before first LLM call",
    "",
];
const unslothSavedValuesWithGeneratedPicker = [...unslothSavedValues];
unslothSavedValuesWithGeneratedPicker.splice(5, 0, "unsloth/Qwen3.8-27B");
assert(
    JSON.stringify(api.normalizeLocalLLMLoaderSerializedValues(unslothSavedValuesWithGeneratedPicker)) ===
        JSON.stringify(unslothSavedValues),
    "Unsloth save/reopen migration must remove only the generated picker and preserve all 13 serialized values",
);
const unslothRestoreNode = makeNode(24);
api.preserveLocalLLMLoaderSavedComboOptions(unslothRestoreNode, unslothSavedValues);
api.applyLocalLLMLoaderSavedWidgetValues(unslothRestoreNode, unslothSavedValues);
assert(
    api.getWidget(unslothRestoreNode, "provider").value === "Unsloth" &&
        api.getWidget(unslothRestoreNode, "custom_server_url").value === "http://127.0.0.1:8888/v1" &&
        api.getWidget(unslothRestoreNode, "custom_model").value === "unsloth/Qwen3.8-27B",
    "An Unsloth saved workflow must restore provider, Server URL, and Model into the existing widgets",
);
assert(
    JSON.stringify(api.localLLMLoaderSerializedValuesFromWidgets(unslothRestoreNode, unslothSavedValues)) ===
        JSON.stringify(unslothSavedValues),
    "An Unsloth save/reopen round trip must preserve the canonical 13-value payload exactly",
);

const tabRestoreNode = makeNode(19);
const tabRestoreModelWidget = configureLMStudioNode(tabRestoreNode, "", [""]);
api.preserveLocalLLMLoaderSavedComboOptions(tabRestoreNode, canonicalSavedValues);
api.applyLocalLLMLoaderSavedWidgetValues(tabRestoreNode, canonicalSavedValues);
assert(
    tabRestoreModelWidget.value === savedLMStudioModel,
    "A tab-like configure with cold LM Studio options must preserve the raw saved model id",
);
assert(
    tabRestoreModelWidget.options.values.includes(savedLMStudioModel),
    "A tab-like configure must keep the raw saved model selectable until a model refresh proves otherwise",
);

const presentRefreshNode = makeNode(20);
const presentRefreshWidget = configureLMStudioNode(presentRefreshNode, savedLMStudioModel);
graph._nodes = [presentRefreshNode];
const presentRefresh = api.refreshModels(presentRefreshNode);
fetchCalls.at(-1).pending.resolve(response({
    models: [
        { id: savedLMStudioModel },
        { id: "google/gemma-4-27b-qat" },
    ],
}));
await presentRefresh;
assert(
    presentRefreshWidget.value === savedLMStudioModel,
    "A successful authoritative refresh containing the saved model must keep its raw id selected",
);

const missingRefreshNode = makeNode(21);
const missingRefreshWidget = configureLMStudioNode(missingRefreshNode, savedLMStudioModel);
graph._nodes = [missingRefreshNode];
const missingRefresh = api.refreshModels(missingRefreshNode);
fetchCalls.at(-1).pending.resolve(response({ models: [{ id: "google/gemma-4-27b-qat" }] }));
await missingRefresh;
assert(
    missingRefreshWidget.value === `Missing saved model: ${savedLMStudioModel}`,
    "A successful authoritative refresh omitting the saved model must mark it missing",
);
assert(
    api.getLocalLLMNodeState(missingRefreshNode).status === "saved model not found",
    "An authoritative missing-model refresh must expose the saved-model-not-found state",
);

const emptyRefreshNode = makeNode(22);
const emptyRefreshWidget = configureLMStudioNode(emptyRefreshNode, savedLMStudioModel);
graph._nodes = [emptyRefreshNode];
const emptyRefresh = api.refreshModels(emptyRefreshNode);
fetchCalls.at(-1).pending.resolve(response({ models: [] }));
await emptyRefresh;
assert(
    emptyRefreshWidget.value === `Missing saved model: ${savedLMStudioModel}`,
    "A successful authoritative empty model list must mark the saved model missing",
);
assert(
    api.getLocalLLMNodeState(emptyRefreshNode).status === "saved model not found",
    "An authoritative empty model list must expose the saved-model-not-found state",
);

const failedRefreshNode = makeNode(23);
const failedRefreshChoices = [savedLMStudioModel, "google/gemma-4-27b-qat"];
const failedRefreshWidget = configureLMStudioNode(
    failedRefreshNode,
    savedLMStudioModel,
    failedRefreshChoices,
);
graph._nodes = [failedRefreshNode];
const failedRefresh = api.refreshModels(failedRefreshNode);
fetchCalls.at(-1).pending.reject(new Error("LM Studio temporarily unavailable"));
await failedRefresh;
assert(
    failedRefreshWidget.value === savedLMStudioModel,
    "A failed refresh must preserve the raw saved model instead of treating failure as proof of absence",
);
assert(
    JSON.stringify(failedRefreshWidget.options.values) === JSON.stringify(failedRefreshChoices) &&
        JSON.stringify(failedRefreshWidget.options.list) === JSON.stringify(failedRefreshChoices),
    "A failed refresh must preserve the previous model choices",
);
assert(
    api.getLocalLLMNodeState(failedRefreshNode).status === "model refresh failed",
    "A failed refresh must report model refresh failed rather than saved model not found",
);

failedRefreshWidget.value = `Missing saved model: ${savedLMStudioModel}`;
const serializedMissingModel = api.localLLMLoaderSerializedValuesFromWidgets(
    failedRefreshNode,
    canonicalSavedValues,
);
assert(
    serializedMissingModel[2] === savedLMStudioModel,
    "Workflow serialization must store the raw model id instead of the Missing display prefix",
);

console.log("local_llm_async_action_harness: ok");
