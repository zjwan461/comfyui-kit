"""Automatic speech recognition modules."""
