"""OmniShotCut model architecture."""
