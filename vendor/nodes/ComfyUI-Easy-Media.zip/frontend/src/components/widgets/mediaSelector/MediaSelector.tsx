import { useState, useEffect, useRef, useSyncExternalStore } from 'react'
import {
  Search,
  ArrowUpDown,
  LayoutList,
  LayoutGrid,
  ListChecks,
  CheckCircle2,
  FileAudio,
  FileVideo,
  Image as ImageIcon,
  File,
  Folder,
  ChevronRight,
  Link2,
  Plus,
  RefreshCw,
} from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Skeleton } from '@/components/ui/skeleton'
import { cn } from '@/lib/utils'
import { useT } from '@/lib/i18n'
import { $error } from '@/lib/comfy-api'
import { uploadInputMediaFile } from '@/lib/media-upload'
import { useDelayedIntersection } from '@/hooks/use-delayed-intersection'
import type { SlotItem } from '@/lib/timeline-utils'
import {
  getMediaList,
  getMediaListStoreRevision,
  getRecentMedia,
  getRecentMediaHistory,
  invalidateMediaListCache,
  subscribeMediaListStore,
  type MediaDirEntry,
  type MediaFileEntry,
  type MediaItem,
  type MediaListMediaType,
  type RecentMediaHistoryEntry,
} from '@/stores/media-list-store'

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type MediaType = MediaListMediaType
export type MediaTab = 'inputs' | 'outputs' | 'history' | 'local' | 'url' | 'slot'
type ViewMode = 'grid' | 'list'
type SortBy = 'name' | 'date' | 'folders'
type BrowsableMediaTab = Extract<MediaTab, 'inputs' | 'outputs' | 'local'>

interface MediaSelectorSession {
  activeTab: MediaTab
  subfolders: Partial<Record<BrowsableMediaTab, string>>
}

const mediaSelectorSessions = new Map<MediaType, MediaSelectorSession>()

const MULTIPLE_MEDIA_SEPARATOR = '|MULTIPLE|'
const MEDIA_REFRESH_COOLDOWN_MS = 2_000

interface MediaSelectorChangeEvent {
  filePath: string
  sourceType: 'input' | 'output' | 'temp' | 'local'
}

export interface MediaSelectorProps {
  value: string
  onChange: (value: string, source?: 'input' | 'output' | 'local') => void
  onSourceChange?: (event: MediaSelectorChangeEvent) => void
  mediaType?: MediaType
  /** Which tab to show initially */
  defaultTab?: MediaTab
  /** Slot items computed from the connected node graph (only for image/audio media types) */
  slotItems?: SlotItem[]
  /** History tab source: output only, or combined output + temp previews. */
  historySource?: 'outputs' | 'combined'
  /** Only render the history tab. Used by watch-output-history flows. */
  historyOnly?: boolean
  /** Enables the image-only batch selection toolbar. */
  allowMultipleSelection?: boolean
  /** Maximum number of files that can be returned in one batch. */
  maxSelectionCount?: number
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

function getFileIcon(name: string, mediaType: MediaType) {
  if (mediaType === 'audio') return FileAudio
  if (mediaType === 'image') return ImageIcon
  if (mediaType === 'video') return FileVideo
  const ext = name.split('.').pop()?.toLowerCase() ?? ''
  if (['mp3', 'wav', 'flac', 'ogg', 'm4a', 'aac', 'opus', 'wma'].includes(ext)) return FileAudio
  if (['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp', 'tiff', 'tif'].includes(ext)) return ImageIcon
  if (['mp4', 'webm', 'mov', 'mkv', 'avi', 'm4v'].includes(ext)) return FileVideo
  return File
}

function isImageFile(name: string, mediaType: MediaType): boolean {
  if (mediaType === 'image') return true
  const ext = name.split('.').pop()?.toLowerCase() ?? ''
  return ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp', 'tiff', 'tif'].includes(ext)
}

function isAudioFile(name: string, mediaType: MediaType): boolean {
  if (mediaType === 'audio') return true
  const ext = name.split('.').pop()?.toLowerCase() ?? ''
  return ['mp3', 'wav', 'flac', 'ogg', 'm4a', 'aac', 'opus', 'wma'].includes(ext)
}

function isVideoFile(name: string, mediaType: MediaType): boolean {
  if (mediaType === 'video') return true
  const ext = name.split('.').pop()?.toLowerCase() ?? ''
  return ['mp4', 'webm', 'mov', 'mkv', 'avi', 'm4v'].includes(ext)
}

function getSelectedMediaValues(value: string): Set<string> {
  if (!value) return new Set()
  return new Set(value.split(MULTIPLE_MEDIA_SEPARATOR).filter((item) => item.length > 0))
}

function getSelectedMediaParent(value: string): string {
  const firstValue = value.split(MULTIPLE_MEDIA_SEPARATOR)[0] ?? ''
  if (!firstValue || firstValue.startsWith('http') || firstValue.startsWith('__slot__:')) return ''
  const normalized = firstValue.replaceAll('\\', '/')
  return normalized.split('/').slice(0, -1).join('/')
}

function splitSubfolderPath(subfolder: string): string[] {
  return subfolder.replaceAll('\\', '/').split('/').filter(Boolean)
}

function formatMediaInfo(file: MediaFileEntry, mediaType: MediaType): string {
  if (isImageFile(file.name, mediaType) && file.width && file.height) {
    return `${file.width}×${file.height}`
  }
  return formatSize(file.size)
}

function sortFiles(files: MediaFileEntry[], sortBy: SortBy): MediaFileEntry[] {
  return [...files].sort((a, b) => {
    if (sortBy === 'date') return b.mtime - a.mtime
    return a.name.localeCompare(b.name)
  })
}

function sortDirs(dirs: MediaDirEntry[]): MediaDirEntry[] {
  return [...dirs].sort((a, b) => a.name.localeCompare(b.name))
}

function sortByLabelKey(sortBy: SortBy): string {
  if (sortBy === 'name') return 'mediaSelector.sortName'
  if (sortBy === 'date') return 'mediaSelector.sortDate'
  return 'mediaSelector.sortFolders'
}

// ---------------------------------------------------------------------------
// LazyImage — only loads src once it enters the viewport/scroll-container
// ---------------------------------------------------------------------------

function LazyImage({
  src,
  alt,
  className,
}: Readonly<{ src: string; alt: string; className?: string }>) {
  const ref = useRef<HTMLImageElement>(null)
  const visible = useDelayedIntersection(ref)

  return (
    <img
      ref={ref}
      src={visible ? src : undefined}
      alt={alt}
      className={className}
      onError={(e) => {
        ;(e.target as HTMLImageElement).style.display = 'none'
      }}
    />
  )
}

function LazyVideo({
  src,
  className,
}: Readonly<{ src: string; className?: string }>) {
  const ref = useRef<HTMLVideoElement>(null)
  const visible = useDelayedIntersection(ref)

  return (
    <video
      ref={ref}
      src={visible ? src : undefined}
      className={className}
      muted
      playsInline
      preload="metadata"
      onLoadedMetadata={(event) => {
        const video = event.currentTarget
        if (Number.isFinite(video.duration) && video.duration > 0.1) video.currentTime = 0.1
      }}
      onError={(event) => {
        event.currentTarget.style.display = 'none'
      }}
    />
  )
}

// ---------------------------------------------------------------------------
// FileThumbnail (grid)
// ---------------------------------------------------------------------------

function FileThumbnail({
  file,
  mediaType,
  isSelected,
}: Readonly<{ file: MediaFileEntry; mediaType: MediaType; isSelected: boolean }>) {
  const Icon = getFileIcon(file.name, mediaType)
  const showImage = isImageFile(file.name, mediaType) && !!file.url
  const showVideo = !showImage && isVideoFile(file.name, mediaType) && !!file.url
  const isAudio = !showImage && !showVideo && isAudioFile(file.name, mediaType)

  return (
    <div
      className={cn(
        'relative w-full aspect-square rounded overflow-hidden flex items-center justify-center bg-muted',
        isSelected && 'ring-2 ring-primary',
      )}
    >
      {showImage ? (
        <LazyImage src={file.url} alt={file.name} className="w-full h-full object-cover" />
      ) : showVideo ? (
        <LazyVideo src={file.url} className="w-full h-full object-cover" />
      ) : (
        <Icon className={`w-6 h-6 ${isAudio ? 'text-highlight' : 'text-muted-foreground'}`} />
      )}
      {isSelected && (
        <div className="absolute top-1 right-1">
          <CheckCircle2 className="w-3.5 h-3.5 text-primary fill-primary-foreground" />
        </div>
      )}
    </div>
  )
}

// ---------------------------------------------------------------------------
// Skeleton rows
// ---------------------------------------------------------------------------

function GridSkeleton() {
  return (
    <div className="grid grid-cols-4 gap-2 p-2">
      {Array.from({ length: 8 }, (_, i) => `sk-grid-${i}`).map((key) => (
        <div key={key} className="space-y-1">
          <Skeleton className="w-full aspect-square rounded" />
          <Skeleton className="h-3 w-3/4" />
          <Skeleton className="h-2.5 w-1/2" />
        </div>
      ))}
    </div>
  )
}

function ListSkeleton() {
  return (
    <div className="flex flex-col gap-1 p-2">
      {Array.from({ length: 6 }, (_, i) => `sk-list-${i}`).map((key) => (
        <div key={key} className="flex items-center gap-2 h-8">
          <Skeleton className="w-6 h-6 rounded shrink-0" />
          <Skeleton className="h-3 flex-1" />
          <Skeleton className="h-3 w-14 shrink-0" />
        </div>
      ))}
    </div>
  )
}

// ---------------------------------------------------------------------------
// Breadcrumb
// ---------------------------------------------------------------------------

function Breadcrumb({
  subfolder,
  onNavigate,
}: Readonly<{ subfolder: string; onNavigate: (path: string) => void }>) {
  if (!subfolder) return null
  const parts = splitSubfolderPath(subfolder)
  return (
    <div className="flex items-center gap-0.5 px-2 py-0.5 border-b border-border text-[11px] text-muted-foreground flex-wrap">
      <button
        type="button"
        className="hover:text-foreground transition-colors"
        onClick={() => onNavigate('')}
      >
        …
      </button>
      {parts.map((part, i) => {
        const path = parts.slice(0, i + 1).join('/')
        return (
          <span key={path} className="flex items-center gap-0.5">
            <ChevronRight className="w-3 h-3 shrink-0" />
            <button
              type="button"
              className="hover:text-foreground transition-colors truncate max-w-20"
              onClick={() => onNavigate(path)}
            >
              {part}
            </button>
          </span>
        )
      })}
    </div>
  )
}

// ---------------------------------------------------------------------------
// RemoteFileList — tree-aware, lazy images
// ---------------------------------------------------------------------------

function RemoteFileList({
  source,
  mediaType,
  localPath,
  viewMode,
  sortBy,
  searchQuery,
  value,
  historySource = 'outputs',
  onChange,
  onSourceChange,
  initialSubfolder,
  onNavigateSubfolder,
  onAddLocalFile,
  multipleSelection,
  selectionLimit,
  onToggleSelection,
  onVisibleFilesChange,
}: Readonly<{
  source: 'inputs' | 'outputs' | 'history' | 'local'
  mediaType: MediaType
  localPath: string
  viewMode: ViewMode
  sortBy: SortBy
  searchQuery: string
  value: string
  historySource?: 'outputs' | 'combined'
  onChange: (v: string, source: 'input' | 'output' | 'local') => void
  onSourceChange?: (event: MediaSelectorChangeEvent) => void
  initialSubfolder?: string
  onNavigateSubfolder?: (path: string) => void
  onAddLocalFile?: () => void
  multipleSelection: boolean
  selectionLimit: number
  onToggleSelection: (path: string, source: 'input' | 'output' | 'local') => void
  onVisibleFilesChange: (files: MediaFileEntry[]) => void
}>) {
  const t = useT()
  const [items, setItems] = useState<MediaItem[]>([])
  const [subfolder, setSubfolder] = useState(initialSubfolder ?? '')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const cacheRevision = useSyncExternalStore(
    subscribeMediaListStore,
    getMediaListStoreRevision,
    getMediaListStoreRevision,
  )
  const selectedValues = getSelectedMediaValues(value)

  // Reset to root when the source or local path changes
  const rootKey = source === 'history' ? 'history' : `${source}|${localPath}`
  const prevRootKeyRef = useRef(rootKey)

  useEffect(() => {
    const prevKey = prevRootKeyRef.current
    prevRootKeyRef.current = rootKey
    if (prevKey !== rootKey) {
      setSubfolder('')
      setItems([])
    }
  }, [rootKey])

  useEffect(() => {
    if (source === 'local' && !localPath) {
      setLoading(false)
      return
    }

    setLoading(true)
    setError(null)

    let cancelled = false
    const request = source === 'history'
      ? historySource === 'combined'
        ? getRecentMediaHistory(mediaType, 48, 50)
        : getRecentMedia({ source: 'outputs', mediaType, hours: 48, limit: 50 })
      : getMediaList({ source, mediaType, localPath, subfolder })
    request
      .then((list) => {
        if (!cancelled) setItems(list)
      })
      .catch((e: unknown) => {
        if (!cancelled) setError(e instanceof Error ? e.message : JSON.stringify(e))
      })
      .finally(() => { if (!cancelled) setLoading(false) })

    return () => { cancelled = true }
  }, [source, historySource, mediaType, localPath, subfolder, cacheRevision])

  const dirs = sortDirs(items.filter((i): i is MediaDirEntry => i.type === 'dir'))
  const files = sortFiles(
    (items.filter((i): i is MediaFileEntry => i.type === 'file') as MediaFileEntry[])
      .filter((f) => f.name.toLowerCase().includes(searchQuery.toLowerCase())),
    sortBy,
  )

  const filteredDirs = dirs.filter((d) =>
    searchQuery ? d.name.toLowerCase().includes(searchQuery.toLowerCase()) : true,
  )

  useEffect(() => {
    onVisibleFilesChange(files)
  }, [files, onVisibleFilesChange])

  if (loading) return viewMode === 'grid' ? <GridSkeleton /> : <ListSkeleton />

  if (error) {
    return (
      <div className="flex items-center justify-center h-24 text-destructive text-xs">
        {t('mediaSelector.error', { msg: error })}
      </div>
    )
  }

  const isEmpty = filteredDirs.length === 0 && files.length === 0
  const selectedFiles = files.filter((file) => selectedValues.has(file.path))
  const sortedItems: MediaItem[] = sortBy === 'folders'
    ? [...filteredDirs, ...files]
    : [...files, ...filteredDirs]
  const unselectedItems = sortedItems.filter((item) => item.type === 'dir' || !selectedValues.has(item.path))

  function navigateSubfolder(path: string) {
    if (path === subfolder) return
    setItems([])
    setLoading(true)
    onVisibleFilesChange([])
    setSubfolder(path)
    onNavigateSubfolder?.(path)
  }

  function fileSourceType(file: MediaFileEntry): 'input' | 'output' | 'temp' | 'local' {
    if (source === 'history') {
      const historyType = (file as RecentMediaHistoryEntry).source_type
      return historyType === 'temp' ? 'temp' : 'output'
    }
    return source === 'outputs' ? 'output' : source === 'local' ? 'local' : 'input'
  }

  function selectFile(file: MediaFileEntry) {
    const actualSource = fileSourceType(file)
    onChange(file.path, actualSource === 'temp' ? 'output' : actualSource)
    onSourceChange?.({ filePath: file.path, sourceType: actualSource })
  }

  function renderGridFile(file: MediaFileEntry, selected: boolean) {
    const sourceType = fileSourceType(file)
    const selectionDisabled = multipleSelection && !selected && selectedValues.size >= selectionLimit
    return (
      <div
        key={file.path}
        role="button"
        tabIndex={selectionDisabled ? -1 : 0}
        aria-disabled={selectionDisabled}
        className={cn(
          'relative flex flex-col gap-1 text-left hover:opacity-80 transition-opacity',
          selectionDisabled && 'cursor-not-allowed opacity-50',
        )}
        onClick={() => multipleSelection
          ? onToggleSelection(file.path, sourceType === 'temp' ? 'output' : sourceType)
          : selectFile(file)}
        onKeyDown={(event) => {
          if (event.target !== event.currentTarget) return
          if (event.key !== 'Enter' && event.key !== ' ') return
          event.preventDefault()
          if (multipleSelection) onToggleSelection(file.path, sourceType === 'temp' ? 'output' : sourceType)
          else selectFile(file)
        }}
      >
        <FileThumbnail file={file} mediaType={mediaType} isSelected={selected && !multipleSelection} />
        {multipleSelection && (
          <Checkbox
            checked={selected}
            disabled={selectionDisabled}
            aria-label={t('mediaSelector.selectFile', { name: file.name })}
            className="absolute right-1 top-1 z-10 bg-background/80"
            onClick={(event) => event.stopPropagation()}
            onCheckedChange={() => onToggleSelection(file.path, sourceType === 'temp' ? 'output' : sourceType)}
          />
        )}
        <span className="text-[10px] truncate leading-tight max-w-full" title={file.name}>
          {file.name}
        </span>
        <span className="text-[10px] text-muted-foreground truncate leading-tight max-w-full">
          {formatMediaInfo(file, mediaType)}
        </span>
      </div>
    )
  }

  function renderListFile(file: MediaFileEntry, selected: boolean) {
    const Icon = getFileIcon(file.name, mediaType)
    const showThumb = isImageFile(file.name, mediaType) && !!file.url
    const showVideoThumb = !showThumb && isVideoFile(file.name, mediaType) && !!file.url
    const showAudioIcon = !showThumb && !showVideoThumb && isAudioFile(file.name, mediaType)
    const sourceType = fileSourceType(file)
    const selectionDisabled = multipleSelection && !selected && selectedValues.size >= selectionLimit

    return (
      <div
        key={file.path}
        role="button"
        tabIndex={selectionDisabled ? -1 : 0}
        aria-disabled={selectionDisabled}
        className={cn(
          'flex items-center gap-2 px-2 py-1 text-left hover:bg-accent transition-colors',
          selected && 'bg-accent',
          selectionDisabled && 'cursor-not-allowed opacity-50',
        )}
        onClick={() => multipleSelection
          ? onToggleSelection(file.path, sourceType === 'temp' ? 'output' : sourceType)
          : selectFile(file)}
        onKeyDown={(event) => {
          if (event.target !== event.currentTarget) return
          if (event.key !== 'Enter' && event.key !== ' ') return
          event.preventDefault()
          if (multipleSelection) onToggleSelection(file.path, sourceType === 'temp' ? 'output' : sourceType)
          else selectFile(file)
        }}
      >
        {multipleSelection && (
          <Checkbox
            checked={selected}
            disabled={selectionDisabled}
            aria-label={t('mediaSelector.selectFile', { name: file.name })}
            onClick={(event) => event.stopPropagation()}
            onCheckedChange={() => onToggleSelection(file.path, sourceType === 'temp' ? 'output' : sourceType)}
          />
        )}
        {showThumb && (
          <div className="w-4 h-4 rounded overflow-hidden shrink-0 bg-muted">
            <LazyImage src={file.url} alt={file.name} className="w-full h-full object-cover" />
          </div>
        )}
        {showVideoThumb && (
          <div className="w-4 h-4 rounded overflow-hidden shrink-0 bg-muted">
            <LazyVideo src={file.url} className="w-full h-full object-cover" />
          </div>
        )}
        {showAudioIcon && (
          <div className="w-4 h-4 rounded flex items-center justify-center bg-[#34d399] shrink-0">
            <Icon className="w-3 h-3 text-white" />
          </div>
        )}
        {!showThumb && !showVideoThumb && !showAudioIcon && (
          <Icon className="w-4 h-4 text-muted-foreground shrink-0" />
        )}
        <span className="flex-1 text-xs truncate min-w-0" title={file.name}>
          {file.name}
        </span>
        <span className="text-[10px] text-muted-foreground shrink-0">
          {formatMediaInfo(file, mediaType)}
        </span>
        {selected && !multipleSelection && <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />}
      </div>
    )
  }

  function renderGridDir(dir: MediaDirEntry) {
    return (
      <button
        key={dir.path}
        type="button"
        className="flex flex-col gap-1 text-left hover:opacity-80 transition-opacity"
        onClick={() => navigateSubfolder(dir.path)}
      >
        <div className="relative w-full aspect-square rounded overflow-hidden bg-muted flex items-center justify-center">
          <Folder className="w-6 h-6 text-warning" />
        </div>
        <span className="text-[10px] truncate leading-tight max-w-full" title={dir.name}>
          {dir.name}
        </span>
      </button>
    )
  }

  function renderListDir(dir: MediaDirEntry) {
    return (
      <button
        key={dir.path}
        type="button"
        className="flex items-center gap-2 px-2 py-1 text-left hover:bg-accent transition-colors"
        onClick={() => navigateSubfolder(dir.path)}
      >
        <div className="w-4 h-4 rounded flex items-center justify-center bg-muted shrink-0">
          <Folder className="w-3 h-3 text-warning" />
        </div>
        <span className="flex-1 text-xs truncate min-w-0" title={dir.name}>
          {dir.name}
        </span>
      </button>
    )
  }

  function renderGridItem(item: MediaItem) {
    return item.type === 'dir'
      ? renderGridDir(item)
      : renderGridFile(item, selectedValues.has(item.path))
  }

  function renderListItem(item: MediaItem) {
    return item.type === 'dir'
      ? renderListDir(item)
      : renderListFile(item, selectedValues.has(item.path))
  }

  function renderGrid() {
    return (
      <div className="grid grid-cols-4 gap-2 p-2 overflow-y-auto flex-1">
        {/* Local file button */}
        {onAddLocalFile && (
          <button
            key="__add_local__"
            type="button"
            className="flex flex-col gap-1 text-left hover:opacity-80 transition-opacity"
            onClick={onAddLocalFile}
          >
            <div className="relative w-full aspect-square rounded overflow-hidden bg-muted flex items-center justify-center border-2 border-dashed border-muted-foreground/50">
              <Plus className="w-6 h-6 text-muted-foreground" />
            </div>
            <span className="text-[10px] truncate leading-tight max-w-full text-muted-foreground">
              {t('mediaSelector.addLocal')}
            </span>
          </button>
        )}
        {selectedFiles.map((file) => renderGridFile(file, true))}
        {unselectedItems.map(renderGridItem)}
      </div>
    )
  }

  function renderList() {
    return (
      <div className="flex flex-col overflow-y-auto flex-1">
        {/* Local file button */}
        {onAddLocalFile && (
          <button
            key="__add_local__"
            type="button"
            className="flex items-center gap-2 px-2 py-1 text-left hover:bg-accent transition-colors text-muted-foreground"
            onClick={onAddLocalFile}
          >
            <div className="w-4 h-4 rounded flex items-center justify-center bg-muted shrink-0">
              <Plus className="w-3 h-3" />
            </div>
            <span className="flex-1 text-xs truncate min-w-0">
              {t('mediaSelector.addLocal')}
            </span>
          </button>
        )}
        {selectedFiles.map((file) => renderListFile(file, true))}
        {unselectedItems.map(renderListItem)}
      </div>
    )
  }

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      {source !== 'history' ? (
        <Breadcrumb subfolder={subfolder} onNavigate={navigateSubfolder} />
      ) : null}
      {isEmpty && (
        <div className="flex items-center justify-center h-24 text-muted-foreground text-xs">
          {t('mediaSelector.empty')}
        </div>
      )}
      {!isEmpty && viewMode === 'grid' && renderGrid()}
      {!isEmpty && viewMode !== 'grid' && renderList()}
    </div>
  )
}

// ---------------------------------------------------------------------------
// MediaSelector
// ---------------------------------------------------------------------------

export function MediaSelector({
  value,
  onChange,
  onSourceChange,
  mediaType = 'all',
  defaultTab = 'inputs',
  slotItems = [],
  historySource = 'outputs',
  historyOnly = false,
  allowMultipleSelection = false,
  maxSelectionCount = 9,
}: Readonly<MediaSelectorProps>) {
  const t = useT()
  const showSlotTab = mediaType === 'image' || mediaType === 'audio' || mediaType === 'video'
  const initialSession = mediaSelectorSessions.get(mediaType)
  const initialSubfolders = value && ['inputs', 'outputs', 'local'].includes(defaultTab)
    ? { ...initialSession?.subfolders, [defaultTab]: getSelectedMediaParent(value) }
    : initialSession?.subfolders ?? {}
  const [activeTab, setActiveTab] = useState<MediaTab>(
    historyOnly ? 'history' : value ? defaultTab : initialSession?.activeTab ?? defaultTab,
  )
  const [subfolders, setSubfolders] = useState<Partial<Record<BrowsableMediaTab, string>>>(
    initialSubfolders,
  )
  const [viewMode, setViewMode] = useState<ViewMode>('grid')
  const [sortBy, setSortBy] = useState<SortBy>('name')
  const [searchQuery, setSearchQuery] = useState('')
  const [localPath, setLocalPath] = useState('')
  const [urlInput, setUrlInput] = useState(activeTab === 'url' ? value : '')
  const [urlChecking, setUrlChecking] = useState(false)
  const [multipleSelection, setMultipleSelection] = useState(false)
  const [draftSelectedValues, setDraftSelectedValues] = useState<Set<string>>(() => new Set())
  const [visibleFiles, setVisibleFiles] = useState<MediaFileEntry[]>([])
  const [refreshCoolingDown, setRefreshCoolingDown] = useState(false)
  const lastRefreshAtRef = useRef<number | null>(null)
  const refreshCooldownTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const normalizedSelectionLimit = Number.isFinite(maxSelectionCount)
    ? Math.max(1, Math.floor(maxSelectionCount))
    : 9
  const supportsMultipleSelection = mediaType === 'image'
    && allowMultipleSelection
  const effectiveValue = multipleSelection
    ? [...draftSelectedValues].join(MULTIPLE_MEDIA_SEPARATOR)
    : value
  const selectedValues = getSelectedMediaValues(effectiveValue)

  const previousDefaultTabRef = useRef(defaultTab)

  // Sync defaultTab when it changes after mount (e.g. a mounted selector targets another segment).
  useEffect(() => {
    if (historyOnly) return
    if (previousDefaultTabRef.current === defaultTab) return
    previousDefaultTabRef.current = defaultTab
    setActiveTab(defaultTab)
    setSearchQuery('')
  }, [defaultTab, historyOnly])

  useEffect(() => () => {
    if (refreshCooldownTimerRef.current !== null) {
      clearTimeout(refreshCooldownTimerRef.current)
    }
  }, [])

  function rememberSession(nextTab: MediaTab, nextSubfolders = subfolders) {
    mediaSelectorSessions.set(mediaType, { activeTab: nextTab, subfolders: nextSubfolders })
  }

  function handleTabChange(nextTab: MediaTab) {
    setActiveTab(nextTab)
    setSearchQuery('')
    setVisibleFiles([])
    if (multipleSelection) {
      setDraftSelectedValues(new Set())
      setMultipleSelection(false)
    }
    rememberSession(nextTab)
  }

  function handleSubfolderChange(tab: BrowsableMediaTab, path: string) {
    const nextSubfolders = { ...subfolders, [tab]: path }
    setSubfolders(nextSubfolders)
    rememberSession(activeTab, nextSubfolders)
    setSearchQuery('')
  }

  function cycleSortBy() {
    setSortBy((prev) => {
      if (prev === 'name') return 'date'
      if (prev === 'date') return 'folders'
      return 'name'
    })
  }

  function handleRefresh() {
    const now = Date.now()
    if (
      lastRefreshAtRef.current !== null
      && now - lastRefreshAtRef.current < MEDIA_REFRESH_COOLDOWN_MS
    ) return

    lastRefreshAtRef.current = now
    setRefreshCoolingDown(true)
    const source = activeTab === 'outputs' || activeTab === 'history'
      ? 'outputs'
      : activeTab === 'local'
        ? 'local'
        : 'inputs'
    invalidateMediaListCache(source)

    if (refreshCooldownTimerRef.current !== null) {
      clearTimeout(refreshCooldownTimerRef.current)
    }
    refreshCooldownTimerRef.current = setTimeout(() => {
      refreshCooldownTimerRef.current = null
      setRefreshCoolingDown(false)
    }, MEDIA_REFRESH_COOLDOWN_MS)
  }

  function handleFileChange(
    filePath: string,
    source: 'input' | 'output' | 'temp' | 'local',
  ) {
    onChange(filePath, source === 'temp' ? 'output' : source)
    onSourceChange?.({ filePath, sourceType: source })
  }

  function handleVisibleFilesChange(nextFiles: MediaFileEntry[]) {
    setVisibleFiles((current) => {
      const currentPaths = current.map((file) => file.path).join('\n')
      const nextPaths = nextFiles.map((file) => file.path).join('\n')
      return currentPaths === nextPaths ? current : nextFiles
    })
  }

  function beginMultipleSelection() {
    setDraftSelectedValues(new Set(
      [...getSelectedMediaValues(value)].slice(0, normalizedSelectionLimit),
    ))
    setMultipleSelection(true)
  }

  function cancelMultipleSelection() {
    setDraftSelectedValues(new Set())
    setMultipleSelection(false)
  }

  function handleToggleSelection(filePath: string) {
    setDraftSelectedValues((current) => {
      const next = new Set(current)
      if (next.has(filePath)) {
        next.delete(filePath)
      } else if (next.size < normalizedSelectionLimit) {
        next.add(filePath)
      }
      return next
    })
  }

  function handleSelectAll() {
    setDraftSelectedValues((current) => {
      const next = new Set(current)
      for (const file of visibleFiles) {
        if (next.size >= normalizedSelectionLimit) break
        next.add(file.path)
      }
      return next
    })
  }

  function confirmMultipleSelection() {
    if (draftSelectedValues.size === 0) return
    const source = activeTab === 'outputs' || activeTab === 'history'
      ? 'output'
      : activeTab === 'local'
        ? 'local'
        : 'input'
    handleFileChange([...draftSelectedValues].join(MULTIPLE_MEDIA_SEPARATOR), source)
    setMultipleSelection(false)
  }

  async function handleUrlConfirm() {
    if (urlChecking) return
    setUrlChecking(true)
    try {
      const img = new globalThis.Image()
      await new Promise((resolve, reject) => {
        img.onload = resolve
        img.onerror = () => reject(new Error('Image load failed'))
        img.src = urlInput
      })
      onChange(urlInput)
    } catch {
      await downloadViaBackend()
    } finally {
      setUrlChecking(false)
    }
  }

  async function downloadViaBackend() {
    try {
      const res = await fetch('/easy-media/download-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: urlInput }),
      })
      if (!res.ok) {
        $error(t('mediaSelector.urlErrorTitle'), t('mediaSelector.urlErrorNotFound'))
        return
      }
      const data = await res.json() as { source_type: 'url' | 'input'; url?: string; file_name?: string }
      if (data.source_type === 'url') {
        onChange(data.url!)
      } else {
        invalidateMediaListCache('inputs')
        onChange(data.file_name!)
      }
    } catch {
      onChange(urlInput)
    }
  }

  function handleAddLocalFile() {
    const input = document.createElement('input')
    input.type = 'file'
    const accept = mediaType === 'image'
      ? 'image/*'
      : mediaType === 'audio'
        ? 'audio/*'
        : mediaType === 'video'
          ? 'video/*'
          : '*/*'
    input.accept = accept
    input.multiple = true
    input.onchange = async () => {
      if (!input.files || input.files.length === 0) return

      // For single file, select it directly
      if (input.files.length === 1) {
        const file = input.files[0]
        try {
          const uploaded = await uploadInputMediaFile(file, subfolders.inputs ?? '')
          invalidateMediaListCache('inputs')
          onChange(uploaded)
        } catch (err) {
          console.error('[MediaSelector] upload failed:', err)
        }
        return
      }

      // For multiple files, select all of them (caller handles distribution)
      const paths: string[] = []
      for (const file of input.files) {
        try {
          const uploaded = await uploadInputMediaFile(file, subfolders.inputs ?? '')
          paths.push(uploaded)
        } catch (err) {
          console.error('[MediaSelector] upload failed:', err)
        }
      }
      if (paths.length > 0) {
        invalidateMediaListCache('inputs')
        // Select first file for single selection, but indicate multiple were uploaded
        onChange(paths.join(MULTIPLE_MEDIA_SEPARATOR))
      }
    }
    input.click()
  }

  return (
    <div data-media-selector="" className="flex flex-col w-80 h-80 text-xs select-none">
      <Tabs value={activeTab} onValueChange={(v) => handleTabChange(v as MediaTab)} className="flex flex-col flex-1 overflow-hidden">
        {/* Tab header */}
        <TabsList className="w-full rounded-none rounded-t-md h-7 p-0.5 gap-0.5 shrink-0">
          {historyOnly ? (
            <TabsTrigger value="history" className="flex-1 h-full text-[11px] px-1">
              {t('mediaSelector.tabHistory')}
            </TabsTrigger>
          ) : (
            <>
              <TabsTrigger value="inputs" className="flex-1 h-full text-[11px] px-1">
                {t('mediaSelector.tabInputs')}
              </TabsTrigger>
              <TabsTrigger value="outputs" className="flex-1 h-full text-[11px] px-1">
                {t('mediaSelector.tabOutputs')}
              </TabsTrigger>
              <TabsTrigger value="history" className="flex-1 h-full text-[11px] px-1">
                {t('mediaSelector.tabHistory')}
              </TabsTrigger>
              {/* <TabsTrigger value="local" className="flex-1 h-full text-[11px] px-1">
                {t('mediaSelector.tabLocal')}
              </TabsTrigger> */}
              <TabsTrigger value="url" className="flex-1 h-full text-[11px] px-1">
                {t('mediaSelector.tabUrl')}
              </TabsTrigger>
              {showSlotTab && (
                <TabsTrigger value="slot" className="flex-1 h-full text-[11px] px-1">
                  {t('mediaSelector.tabSlot')}
                </TabsTrigger>
              )}
            </>
          )}
        </TabsList>

        {/* Search + view controls (shared across inputs/outputs/local) */}
        {activeTab !== 'url' && activeTab !== 'slot' && (
          <div className="flex items-center gap-1 px-2 py-1 border-b border-border shrink-0">
            <div className="relative flex-1">
              <Search className="absolute left-1.5 top-1/2 -translate-y-1/2 w-3 h-3 text-muted-foreground pointer-events-none" />
              <Input
                className="h-6 pl-6 text-[11px]"
                placeholder={t('mediaSelector.searchPlaceholder')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            {supportsMultipleSelection && !multipleSelection && (
              <Button
                variant="ghost"
                size="sm"
                className="h-6 gap-1 px-1.5 text-[11px]"
                title={t('mediaSelector.filter')}
                onClick={beginMultipleSelection}
              >
                <ListChecks className="w-3 h-3" />
                {t('mediaSelector.filter')}
              </Button>
            )}
            {multipleSelection ? (
              <>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  title={t('mediaSelector.cancelFilter')}
                  onClick={cancelMultipleSelection}
                >
                  <ListChecks className="w-3 h-3" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 px-1.5 text-[11px]"
                  disabled={visibleFiles.length === 0 || draftSelectedValues.size >= normalizedSelectionLimit}
                  onClick={handleSelectAll}
                >
                  {t('mediaSelector.selectAll')}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 px-1.5 text-[11px]"
                  disabled={draftSelectedValues.size === 0}
                  onClick={confirmMultipleSelection}
                >
                  {t('mediaSelector.confirm')}
                </Button>
              </>
            ) : null}
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              title={t('mediaSelector.sort', { by: t(sortByLabelKey(sortBy)) })}
              onClick={cycleSortBy}
            >
              <ArrowUpDown className="w-3 h-3" />
            </Button>
            {!multipleSelection && (
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                title={t(viewMode === 'grid' ? 'mediaSelector.viewList' : 'mediaSelector.viewGrid')}
                onClick={() => setViewMode((current) => current === 'grid' ? 'list' : 'grid')}
              >
                {viewMode === 'grid'
                  ? <LayoutList className="w-3 h-3" />
                  : <LayoutGrid className="w-3 h-3" />}
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              title={t('mediaSelector.refresh')}
              aria-label={t('mediaSelector.refresh')}
              disabled={refreshCoolingDown}
              onClick={handleRefresh}
            >
              <RefreshCw className="w-3 h-3" />
            </Button>
          </div>
        )}

        {/* Tab panels */}
        <TabsContent value="inputs" className="mt-0 flex-1 overflow-hidden flex flex-col">
          <RemoteFileList
            source="inputs"
            mediaType={mediaType}
            localPath=""
            viewMode={viewMode}
            sortBy={sortBy}
            searchQuery={searchQuery}
            value={effectiveValue}
            onChange={(path) => handleFileChange(path, 'input')}
            initialSubfolder={subfolders.inputs}
            onNavigateSubfolder={(path) => handleSubfolderChange('inputs', path)}
            onAddLocalFile={handleAddLocalFile}
            multipleSelection={multipleSelection}
            selectionLimit={normalizedSelectionLimit}
            onToggleSelection={handleToggleSelection}
            onVisibleFilesChange={handleVisibleFilesChange}
          />
        </TabsContent>

        <TabsContent value="outputs" className="mt-0 flex-1 overflow-hidden flex flex-col">
          <RemoteFileList
            source="outputs"
            mediaType={mediaType}
            localPath=""
            viewMode={viewMode}
            sortBy={sortBy}
            searchQuery={searchQuery}
            value={effectiveValue}
            onChange={(path) => handleFileChange(path, 'output')}
            initialSubfolder={subfolders.outputs}
            onNavigateSubfolder={(path) => handleSubfolderChange('outputs', path)}
            multipleSelection={multipleSelection}
            selectionLimit={normalizedSelectionLimit}
            onToggleSelection={handleToggleSelection}
            onVisibleFilesChange={handleVisibleFilesChange}
          />
        </TabsContent>

        <TabsContent value="history" className="mt-0 flex-1 overflow-hidden flex flex-col">
          <RemoteFileList
            source="history"
            mediaType={mediaType}
            localPath=""
            viewMode={viewMode}
            sortBy={sortBy}
            searchQuery={searchQuery}
            value={effectiveValue}
            historySource={historySource}
            onChange={(path, source) => handleFileChange(path, source)}
            onSourceChange={onSourceChange}
            initialSubfolder=""
            multipleSelection={multipleSelection}
            selectionLimit={normalizedSelectionLimit}
            onToggleSelection={handleToggleSelection}
            onVisibleFilesChange={handleVisibleFilesChange}
          />
        </TabsContent>

        <TabsContent value="local" className="mt-0 flex-1 overflow-hidden flex flex-col">
          {/* Local path input */}
          <div className="flex gap-1 px-2 pt-1 pb-1 border-b border-border">
            <Input
              className="h-6 text-[11px] flex-1"
              placeholder={t('mediaSelector.localPathPlaceholder')}
              value={localPath}
              onChange={(e) => setLocalPath(e.target.value)}
            />
          </div>
          <RemoteFileList
            source="local"
            mediaType={mediaType}
            localPath={localPath}
            viewMode={viewMode}
            sortBy={sortBy}
            searchQuery={searchQuery}
            value={effectiveValue}
            onChange={(path) => handleFileChange(path, 'local')}
            initialSubfolder={subfolders.local}
            onNavigateSubfolder={(path) => handleSubfolderChange('local', path)}
            multipleSelection={multipleSelection}
            selectionLimit={normalizedSelectionLimit}
            onToggleSelection={handleToggleSelection}
            onVisibleFilesChange={handleVisibleFilesChange}
          />
        </TabsContent>

        <TabsContent value="url" className="mt-0 flex-1 p-2">
          <div className="space-y-2">
            <p className="text-muted-foreground text-[11px]">{t('mediaSelector.urlHint')}</p>
            <Input
              className="h-7 text-[11px]"
              placeholder="https://..."
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleUrlConfirm() }}
            />
            <Button
              size="sm"
              className="h-6 text-[11px] w-full"
              disabled={!urlInput.startsWith('http') || urlChecking}
              onClick={handleUrlConfirm}
            >
              {urlChecking ? t('mediaSelector.urlChecking') : t('mediaSelector.urlConfirm')}
            </Button>
          </div>
        </TabsContent>

        {showSlotTab && (
          <TabsContent value="slot" className="mt-0 flex-1 overflow-hidden flex flex-col">
            {slotItems.length === 0 ? (
              <div className="flex-1 flex items-center justify-center text-muted-foreground text-[11px]">
                {t('mediaSelector.slotEmpty')}
              </div>
            ) : (
              <div className="flex flex-col overflow-y-auto flex-1">
                {slotItems
                  .map((item, index) => ({ item, index }))
                  .sort((a, b) => Number(selectedValues.has(b.item.value)) - Number(selectedValues.has(a.item.value)))
                  .map(({ item, index }) => {
                  const selected = selectedValues.has(item.value)
                  const isImage = item.value.startsWith('__slot__:image')
                  const isAudio = item.value.startsWith('__slot__:audio')
                  const isVideo = item.value.startsWith('__slot__:video')
                  const displayLabel = isImage
                    ? t('mediaSelector.slotImage', { n: index + 1 })
                    : isAudio
                      ? t('mediaSelector.slotAudio', { n: index + 1 })
                      : isVideo
                        ? t('mediaSelector.slotVideo', { n: index + 1 })
                        : item.label
                  return (
                    <button
                      key={item.value}
                      type="button"
                      className={cn(
                        'flex items-center gap-2 px-2 py-1 text-left hover:bg-accent transition-colors',
                        selected && 'bg-accent',
                      )}
                      onClick={() => onChange(item.value)}
                    >
                      {item.img ? (
                        <img
                          src={item.img}
                          alt={displayLabel}
                          className="w-8 h-8 object-cover rounded shrink-0 bg-muted"
                        />
                      ) : isAudio ? (
                        <div className="w-8 h-8 rounded flex items-center justify-center bg-[#34d399] shrink-0">
                          <FileAudio className="w-4 h-4 text-white" />
                        </div>
                      ) : isVideo ? (
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded bg-muted">
                          <FileVideo className="h-4 w-4 text-muted-foreground" />
                        </div>
                      ) : (
                        <Link2 className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                      )}
                      <span className="flex-1 text-xs truncate min-w-0">{displayLabel}</span>
                      {isAudio && item.audio_name && (
                        <span className="text-[10px] text-muted-foreground truncate max-w-24" title={item.audio_name}>
                          {item.audio_name}
                        </span>
                      )}
                      {selected && <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />}
                    </button>
                  )
                })}
              </div>
            )}
          </TabsContent>
        )}
      </Tabs>
    </div>
  )
}
