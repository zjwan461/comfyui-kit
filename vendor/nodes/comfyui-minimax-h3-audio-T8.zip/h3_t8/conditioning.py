from __future__ import annotations

import inspect
import math

import torch

import node_helpers
from comfy.ldm.minimax.model import PackedLayout
from comfy.model_base import MiniMaxH3 as MiniMaxH3BaseModel

from .core import (
    CANVAS_MULTIPLE,
    FPS,
    REFERENCE_PIXEL_AREA,
    REF_IMAGE_SHORT_EDGE,
    adapt_canvas,
    align_frame_count_down,
    empty_av_latent,
    encode_audio_once,
    fit_audio_latent,
    nested_av_parts,
    replace_audio_latent,
    reference_video_frame_warnings,
    resize_image,
    sorted_autogrow_items,
    sorted_autogrow_values,
)
from .prompt_tags import media_map_json, prepare_prompt


HYBRID_KEYFRAME_SENTINEL = "t8_keyframe_latent"
HYBRID_LAYOUT_LEGACY_SENTINEL = "legacy_sentinel"
HYBRID_LAYOUT_NATIVE_CONCAT = "native_concat"
NATIVE_GUIDE_PACKED_LAYOUT_SHA256 = (
    "1124904e8835c6db068e61e304490d93784e6a8da6ca6b38afd93975611b3af4"
)
NATIVE_GUIDE_EXTRA_CONDS_SHA256 = (
    "5a6d7d0a5963c96c12f0e04a400f6c45e8f6df632e343be6c86b6ac4ccbc8a46"
)
NATIVE_GUIDE_EXTRA_CONDS_SHA256S = {
    NATIVE_GUIDE_EXTRA_CONDS_SHA256,
    # ComfyUI 187eda8: native keyframe+reference concatenation is unchanged;
    # extra_conds additionally forwards the new video/audio denoise masks.
    "e43a26358405187d5a9556c158843d9ffe150ac52591d1034f3cce422e565974",
}


def build_packed_layout(
    text_len,
    latent_t,
    latent_h,
    latent_w,
    audio_t,
    *,
    keyframes=None,
    refs=None,
    frame_count=None,
):
    kwargs = {"keyframes": keyframes, "refs": refs}
    parameters = inspect.signature(PackedLayout.__init__).parameters
    if "frame_count" in parameters:
        kwargs["frame_count"] = frame_count
    return PackedLayout(
        text_len,
        latent_t,
        latent_h,
        latent_w,
        audio_t,
        **kwargs,
    )


def _native_hybrid_layout_is_valid(layout, keyframe) -> bool:
    try:
        kinds = [kind for _start, _stop, kind in layout.segments]
        if kinds != ["text", "cond", "ref_img", "audio", "video"]:
            return False
        cond_start = next(
            start for start, _stop, kind in layout.segments if kind == "cond"
        )
        audio_start = next(
            start for start, _stop, kind in layout.segments if kind == "audio"
        )
        target_origin_t = float(layout.position_ids[audio_start, 0])
        expected_t = (
            target_origin_t
            + (5.0 / 3.0) * keyframe["resolved_frame_index"]
        )
        return math.isclose(float(layout.position_ids[cond_start, 0]), expected_t)
    except (AttributeError, IndexError, KeyError, StopIteration, TypeError, ValueError):
        return False


def _build_packed_layout_with_init(init, keyframe, image_ref):
    layout = object.__new__(PackedLayout)
    kwargs = {"keyframes": [keyframe], "refs": [image_ref]}
    if "frame_count" in inspect.signature(init).parameters:
        kwargs["frame_count"] = 5
    init(layout, 1, 2, 2, 2, 1, **kwargs)
    return layout


def _bypass_verified_obsolete_layout_patch(keyframe, image_ref) -> bool:
    """Remove an obsolete Painter-style wrapper only after probing its original.

    Older ComfyUI builds needed this marked process-global patch. Newer builds include
    the corrected ordering natively, so the old wrapper either passes a removed
    ``frame_count`` argument or offsets the timeline twice. Keep working old wrappers;
    bypass only a failing marked wrapper whose enclosed original passes the native
    Hybrid layout contract on its own.
    """
    active_init = PackedLayout.__init__
    if not getattr(active_init, "_minimax_kfref_layout_patched", False):
        return False

    compatible_originals = []
    for cell in active_init.__closure__ or ():
        try:
            candidate = cell.cell_contents
        except ValueError:
            continue
        if not callable(candidate) or candidate is active_init:
            continue
        try:
            layout = _build_packed_layout_with_init(candidate, keyframe, image_ref)
        except Exception:
            continue
        if _native_hybrid_layout_is_valid(layout, keyframe):
            compatible_originals.append(candidate)

    if len(compatible_originals) != 1:
        return False
    PackedLayout.__init__ = compatible_originals[0]
    return True


def assert_hybrid_layout_contract() -> str:
    """Return the verified legacy or native keyframe-plus-reference route.

    Old ComfyUI replaces keyframe cond latents with the ref latent list, so it needs
    the sentinel route. Current native-guide ComfyUI concatenates both payloads and
    must not receive sentinels, which would duplicate visual condition latents.
    """
    keyframe_latent = torch.zeros((1, 24, 1, 2, 2))
    reference_latent = torch.ones((1, 24, 1, 2, 2))
    keyframe = {
        "resolved_frame_index": 2,
        "latent": keyframe_latent,
    }
    image_ref = {
        "kind": "image",
        "latent_h": 2,
        "latent_w": 2,
        "latent": reference_latent,
    }

    # Source hashes are useful for diagnostics, but process-global patches from
    # other custom nodes can wrap these methods without changing their behavior.
    # Probe the actual payload contract instead of rejecting every unknown wrapper.
    probe_model = object.__new__(MiniMaxH3BaseModel)
    probe_model.concat_keys = ()
    probe_model.latent_shapes = None
    try:
        probe_output = MiniMaxH3BaseModel.extra_conds(
            probe_model,
            minimax_keyframes=[keyframe],
            minimax_refs=[image_ref],
            seed=0,
        )
        payload = probe_output["minimax_payload"].cond
        video_latents = payload.get("cond_video_latents", [])
    except Exception as exc:
        raise RuntimeError(
            "The active MiniMax H3 conditioning implementation rejected the Hybrid "
            "compatibility probe. An external custom-node patch may target a different "
            "ComfyUI version."
        ) from exc

    native_concat = (
        len(video_latents) == 2
        and video_latents[0] is keyframe_latent
        and video_latents[1] is reference_latent
    )
    legacy_overwrite = (
        len(video_latents) == 1 and video_latents[0] is reference_latent
    )
    if not native_concat and not legacy_overwrite:
        raise RuntimeError(
            "The active MiniMax H3 conditioning implementation returned an unknown "
            "keyframe/reference order; the T8 Hybrid path was disabled to prevent "
            "corrupt conditioning."
        )

    if native_concat:
        layout = None
        try:
            # Probe the live Core constructor, not the public convenience helper.
            # HJL's legacy helper wrapper rewrites middle anchors to zero even on
            # native Core. It must not change this probe's input. Actual Core
            # constructor patches are still exercised and position-validated.
            layout = _build_packed_layout_with_init(
                PackedLayout.__init__, keyframe, image_ref,
            )
        except Exception:
            pass
        if layout is None or not _native_hybrid_layout_is_valid(layout, keyframe):
            if _bypass_verified_obsolete_layout_patch(keyframe, image_ref):
                layout = _build_packed_layout_with_init(
                    PackedLayout.__init__, keyframe, image_ref,
                )
        if layout is None or not _native_hybrid_layout_is_valid(layout, keyframe):
            raise RuntimeError(
                "The active MiniMax H3 PackedLayout implementation is incompatible "
                "with this ComfyUI build. An external custom-node layout patch may need "
                "to be updated or disabled before using T8 Hybrid."
            )
        return HYBRID_LAYOUT_NATIVE_CONCAT

    sentinel_ref = {
        "kind": HYBRID_KEYFRAME_SENTINEL,
        "latent": keyframe_latent,
    }
    # This probe checks concatenation/sentinel semantics, not middle-keyframe
    # support. Older native layouts accept only first/last anchors; probing a
    # middle anchor here falsely identifies a clean legacy Core as patched.
    legacy_keyframe = {**keyframe, "resolved_frame_index": 0}
    try:
        sentinel_output = MiniMaxH3BaseModel.extra_conds(
            probe_model,
            minimax_keyframes=[legacy_keyframe],
            minimax_refs=[sentinel_ref, image_ref],
            seed=0,
        )
        sentinel_latents = sentinel_output["minimax_payload"].cond.get(
            "cond_video_latents", []
        )
    except Exception as exc:
        raise RuntimeError(
            "The legacy MiniMax H3 conditioning implementation rejected the guarded "
            "Hybrid compatibility payload."
        ) from exc
    if not (
        len(sentinel_latents) == 2
        and sentinel_latents[0] is keyframe_latent
        and sentinel_latents[1] is reference_latent
    ):
        raise RuntimeError(
            "The legacy MiniMax H3 conditioning implementation cannot reconstruct the "
            "keyframe/reference order; the T8 Hybrid path was disabled."
        )

    try:
        baseline = build_packed_layout(
            1,
            2,
            2,
            2,
            1,
            keyframes=[legacy_keyframe],
            refs=[image_ref],
            frame_count=5,
        )
        hybrid = build_packed_layout(
            1,
            2,
            2,
            2,
            1,
            keyframes=[legacy_keyframe],
            refs=[sentinel_ref, image_ref],
            frame_count=5,
        )
    except Exception as exc:
        raise RuntimeError(
            "The active MiniMax H3 PackedLayout implementation rejected the guarded "
            "legacy Hybrid compatibility probe."
        ) from exc
    layouts_match = (
        baseline.segments == hybrid.segments
        and baseline.seq_len == hybrid.seq_len
        and torch.equal(baseline.position_ids, hybrid.position_ids)
        and torch.equal(baseline.img_pos, hybrid.img_pos)
        and torch.equal(baseline.audio_pos, hybrid.audio_pos)
    )
    if not layouts_match:
        raise RuntimeError(
            "This ComfyUI build changed MiniMax H3 PackedLayout reference handling; "
            "the T8 exact-keyframe + reference compatibility path is disabled to prevent corrupt conditioning."
        )
    return HYBRID_LAYOUT_LEGACY_SENTINEL


def resolve_task_type(task_type: str, first_frame, last_frame, has_refs: bool) -> str:
    first = first_frame is not None
    last = last_frame is not None
    requested = (task_type or "auto").lower()
    if requested == "auto":
        if has_refs and (first or last):
            return "hybrid"
        if has_refs:
            return "ref2va"
        if first and last:
            return "fl2va"
        if first:
            return "i2va"
        if last:
            return "l2va"
        return "t2va"

    requirements = {
        "t2va": (False, False, False),
        "i2va": (True, False, False),
        "fl2va": (True, True, False),
        "l2va": (False, True, False),
        "ref2va": (False, False, True),
        "hybrid": (None, None, True),
    }
    if requested not in requirements:
        raise ValueError(f"Unknown MiniMax H3 task type: {task_type}")
    need_first, need_last, need_refs = requirements[requested]
    if need_first is not None and first != need_first:
        raise ValueError(f"{requested.upper()} first_frame connection does not match the selected task")
    if need_last is not None and last != need_last:
        raise ValueError(f"{requested.upper()} last_frame connection does not match the selected task")
    if need_refs and not has_refs:
        raise ValueError(f"{requested.upper()} requires at least one reference media input")
    if requested == "hybrid" and not (first or last):
        raise ValueError("HYBRID requires first_frame and/or last_frame")
    if requested not in {"ref2va", "hybrid"} and has_refs:
        raise ValueError(f"{requested.upper()} cannot include reference media; use Auto or Hybrid")
    return requested


def _resize_reference_image(image, width: int, height: int, ref_image_size: str):
    h, w = int(image.shape[1]), int(image.shape[2])
    if ref_image_size == "match":
        scale = min(1.0, math.sqrt((width * height) / (w * h)))
    else:
        scale = min(1.0, REF_IMAGE_SHORT_EDGE / min(w, h))
    target_width = max(CANVAS_MULTIPLE, round(w * scale / CANVAS_MULTIPLE) * CANVAS_MULTIPLE)
    target_height = max(CANVAS_MULTIPLE, round(h * scale / CANVAS_MULTIPLE) * CANVAS_MULTIPLE)
    return resize_image(image[:1], target_width, target_height), target_width, target_height


def _encode_reference_audio(audio_vae, audio: dict):
    latent = encode_audio_once(audio_vae, audio)
    return latent, int(latent.shape[-1])


def build_conditioning(
    clip,
    video_vae,
    audio_vae,
    prompt: str,
    width: int,
    height: int,
    length: int,
    task_type: str = "auto",
    audio_mode: str = "lock_source",
    audio_denoise_strength: float = 0.35,
    add_source_as_reference: bool = True,
    prompt_primary_audio_ordinal: int = 1,
    strict_prompt_tags: bool = True,
    ref_image_size: str = "match",
    reference_video_policy: str = "official_2_to_15s",
    drive_audio=None,
    final_audio=None,
    first_frame=None,
    last_frame=None,
    ref_images=None,
    ref_videos=None,
    ref_video_audios=None,
    ref_audios=None,
    *,
    return_details: bool = False,
    allow_above_reference_area: bool = False,
    semantic_bridge=None,
):
    if width % 32 or height % 32:
        raise ValueError("MiniMax H3 width and height must be divisible by 32")
    canvas_pixels = width * height
    exceeds_reference_area = canvas_pixels > REFERENCE_PIXEL_AREA
    if not 0.0 <= audio_denoise_strength <= 1.0:
        raise ValueError("audio_denoise_strength must be between 0 and 1")

    ref_image_values = sorted_autogrow_values(ref_images)
    ref_video_entries = sorted_autogrow_items(ref_videos)
    ref_video_values = [value for _, value in ref_video_entries]
    ref_audio_values = sorted_autogrow_values(ref_audios)
    ref_video_audio_by_ordinal = dict(sorted_autogrow_items(ref_video_audios))
    if len(ref_image_values) > 9 or len(ref_video_values) > 3 or len(ref_audio_values) > 3:
        raise ValueError("MiniMax H3 reference limits are 9 pictures, 3 videos, and 3 standalone audios")
    video_ordinals = {ordinal for ordinal, _ in ref_video_entries}
    orphan_soundtracks = sorted(set(ref_video_audio_by_ordinal) - video_ordinals)
    if orphan_soundtracks:
        raise ValueError(
            "Reference-video soundtrack(s) have no same-numbered video: "
            + ", ".join(map(str, orphan_soundtracks))
        )

    mode = audio_mode.lower()
    if mode not in {"native", "reference_only", "lock_source", "remix_source"}:
        raise ValueError(f"Unknown audio mode: {audio_mode}")
    if mode != "native" and drive_audio is None:
        raise ValueError(f"Audio mode {audio_mode} requires drive_audio")
    if drive_audio is None and add_source_as_reference:
        add_source_as_reference = False

    latent, frame_count = empty_av_latent(width, height, length)
    _, template_audio = nested_av_parts(latent)

    keyframes = []
    keyframe_images = []
    picture_labels: list[str] = []
    if first_frame is not None:
        image = resize_image(first_frame[:1], width, height, "disabled")
        keyframe_images.append(image)
        picture_labels.append("first_frame (exact frame 0)")
        keyframes.append({"resolved_frame_index": 0, "latent": video_vae.encode(image)})
    if last_frame is not None:
        image = resize_image(last_frame[:1], width, height, "center")
        keyframe_images.append(image)
        picture_labels.append(f"last_frame (exact frame {frame_count - 1})")
        keyframes.append({"resolved_frame_index": frame_count - 1, "latent": video_vae.encode(image)})

    real_ref_items: list[dict] = []
    real_ref_blocks: list[dict] = []
    video_labels: list[str] = []
    audio_labels: list[str] = []
    reference_frame_warnings: list[str] = []

    for index, image in enumerate(ref_image_values, 1):
        resized, ref_width, ref_height = _resize_reference_image(image, width, height, ref_image_size)
        encoded = video_vae.encode(resized)
        real_ref_items.append({"type": "image", "data": resized})
        real_ref_blocks.append(
            {
                "kind": "image",
                "latent_h": ref_height // 16,
                "latent_w": ref_width // 16,
                "latent": encoded,
            }
        )
        picture_labels.append(f"ref_image_{index}")

    for index, (video_ordinal, frames) in enumerate(ref_video_entries, 1):
        if frames.ndim != 4 or frames.shape[0] < 5:
            raise ValueError(f"ref_video_{index} must contain at least 5 IMAGE frames")
        input_frame_count = int(frames.shape[0])
        reference_frame_warnings.extend(reference_video_frame_warnings(input_frame_count, index, reference_video_policy))
        source_height, source_width = int(frames.shape[1]), int(frames.shape[2])
        canvas_width, canvas_height = adapt_canvas(source_width, source_height)
        if source_width * source_height < canvas_width * canvas_height:
            canvas_width = max(CANVAS_MULTIPLE, round(source_width / CANVAS_MULTIPLE) * CANVAS_MULTIPLE)
            canvas_height = max(CANVAS_MULTIPLE, round(source_height / CANVAS_MULTIPLE) * CANVAS_MULTIPLE)
        frames = resize_image(frames, canvas_width, canvas_height)
        frames = frames[:frame_count]
        aligned_count = align_frame_count_down(int(frames.shape[0]))
        if aligned_count < 5:
            raise ValueError(f"ref_video_{index} is too short after 17n+5 alignment")
        frames = frames[:aligned_count]
        encoded_video = video_vae.encode(frames)

        soundtrack = ref_video_audio_by_ordinal.get(video_ordinal)
        encoded_soundtrack, soundtrack_t = None, 0
        if soundtrack is not None:
            encoded_soundtrack, soundtrack_t = _encode_reference_audio(audio_vae, soundtrack)
            real_ref_items.append({"type": "audio"})
            audio_labels.append(f"ref_video_audio_{video_ordinal}")
        sample_indices = list(range(0, frames.shape[0], FPS // 2))
        real_ref_items.append(
            {
                "type": "video",
                "data": frames[sample_indices],
                "timestamps": [sample_index / FPS for sample_index in sample_indices],
            }
        )
        real_ref_blocks.append(
            {
                "kind": "video_audio" if soundtrack_t else "video",
                "latent_t": int(encoded_video.shape[2]),
                "latent_h": canvas_height // 16,
                "latent_w": canvas_width // 16,
                "ref_audio_t": soundtrack_t,
                "latent": encoded_video,
                "audio_latent": encoded_soundtrack,
            }
        )
        video_labels.append(f"ref_video_{video_ordinal}")

    encoded_source = None
    source_audio_ordinal = 0
    if drive_audio is not None:
        encoded_source = fit_audio_latent(encode_audio_once(audio_vae, drive_audio), template_audio)
        if add_source_as_reference:
            real_ref_items.append({"type": "audio"})
            real_ref_blocks.append(
                {
                    "kind": "audio",
                    "ref_audio_t": int(encoded_source.shape[-1]),
                    "audio_latent": encoded_source,
                }
            )
            audio_labels.append("drive_audio (primary source)")
            source_audio_ordinal = len(audio_labels)

    for index, audio in enumerate(ref_audio_values, 1):
        encoded_audio, audio_t = _encode_reference_audio(audio_vae, audio)
        real_ref_items.append({"type": "audio"})
        real_ref_blocks.append({"kind": "audio", "ref_audio_t": audio_t, "audio_latent": encoded_audio})
        audio_labels.append(f"ref_audio_{index}")

    has_refs = bool(real_ref_blocks)
    resolved_task = resolve_task_type(task_type, first_frame, last_frame, has_refs)
    counts = {"pictures": len(picture_labels), "videos": len(video_labels), "audios": len(audio_labels)}
    conditioned_prompt, prompt_warnings = prepare_prompt(
        prompt,
        counts,
        source_audio_ordinal=source_audio_ordinal,
        prompt_primary_audio_ordinal=prompt_primary_audio_ordinal,
        strict=strict_prompt_tags,
    )

    if keyframes and real_ref_blocks:
        hybrid_route = assert_hybrid_layout_contract()
        ref_items = [{"type": "image", "data": image} for image in keyframe_images] + real_ref_items
        if hybrid_route == HYBRID_LAYOUT_LEGACY_SENTINEL:
            refs = [
                {"kind": HYBRID_KEYFRAME_SENTINEL, "latent": keyframe["latent"]}
                for keyframe in keyframes
            ] + real_ref_blocks
        else:
            refs = real_ref_blocks
        tokens = clip.tokenize(conditioned_prompt, minimax_ref_items=ref_items)
    elif real_ref_blocks:
        refs = real_ref_blocks
        tokens = clip.tokenize(conditioned_prompt, minimax_ref_items=real_ref_items)
    else:
        refs = []
        tokens = clip.tokenize(conditioned_prompt, images=keyframe_images)

    conditioning = clip.encode_from_tokens_scheduled(tokens)
    values = {}
    if keyframes:
        values.update({"minimax_keyframes": keyframes, "minimax_frame_count": frame_count})
    if refs:
        values["minimax_refs"] = refs
    if values:
        conditioning = node_helpers.conditioning_set_values(conditioning, values)

    bridge_report = None
    if semantic_bridge is not None and semantic_bridge.active:
        from .semantic_bridge import apply_bridge
        conditioning, bridge_report = apply_bridge(
            conditioning, semantic_bridge,
            encoding_source=f"native_h3:{resolved_task}:clip.encode_from_tokens_scheduled",
        )

    if mode == "lock_source":
        latent = replace_audio_latent(latent, encoded_source, 0.0)
    elif mode == "remix_source":
        latent = replace_audio_latent(latent, encoded_source, audio_denoise_strength)

    media_map = media_map_json(picture_labels, video_labels, audio_labels, source_audio_ordinal)
    report_lines = [
        f"task={resolved_task}",
        f"audio_mode={mode}",
        f"frames={frame_count} ({frame_count / FPS:.3f}s at 24fps)",
        f"canvas={width}x{height} ({canvas_pixels:,} pixels)",
        f"pictures={len(picture_labels)}, videos={len(video_labels)}, audios={len(audio_labels)}",
        f"source_audio_tag={'<Audio ' + str(source_audio_ordinal) + '>' if source_audio_ordinal else 'none'}",
    ]
    if exceeds_reference_area:
        report_lines.append(
            "warning: canvas exceeds the 1920x1088 reference area; execution remains allowed "
            "and VRAM/runtime risk is owned by the user"
        )
    report_lines.extend(f"warning: {warning}" for warning in [*prompt_warnings, *reference_frame_warnings])
    if bridge_report is not None:
        from .semantic_bridge import canonical
        report_lines.append("semantic_bridge=" + canonical(bridge_report))
    output_audio = final_audio if final_audio is not None else drive_audio
    result = (
        conditioning,
        latent,
        output_audio,
        conditioned_prompt,
        media_map,
        "\n".join(report_lines),
    )
    if not return_details:
        return result
    details = {
        "tokens": tokens,
        "keyframes": keyframes,
        "refs": refs,
        "resolved_task": resolved_task,
        "frame_count": frame_count,
        "audio_mode": mode,
        "canvas_pixels": canvas_pixels,
        "exceeds_reference_area": exceeds_reference_area,
        "allow_above_reference_area": bool(allow_above_reference_area),
        "reference_area_policy": "warning_only_no_area_gate",
    }
    return (*result, details)
