from __future__ import annotations

from comfy_api.latest import ComfyExtension, io
from .nodes_director import MiniMaxH3DirectorProjectT8
from .nodes_fiveview_exp import FIVE_VIEW_EXP_NODE_CLASSES
from .nodes_hyperflow_advanced import HYPERFLOW_ADVANCED_NODE_CLASSES
from .director_routes import register_director_routes
from .nodes_semantic_bridge import BridgeIO, SEMANTIC_BRIDGE_NODE_CLASSES
from .nodes_h3_ltx_latent_adapter import MiniMaxH3LTXLatentAdapterEXPT8
from .nodes_readable_audio import READABLE_AUDIO_NODE_CLASSES
from .nodes_avatar_progressive import MiniMaxH3AvatarProgressiveEXPT8
from .nodes_taeh3_preview import MiniMaxH3TAEH3SamplingPreviewEXPT8
from .nodes_prompt_relay_window_text_exp import MiniMaxH3PromptRelayWindowTextEXPT8
from .nodes_meridian import MERIDIAN_NODE_CLASSES
from .nodes_audio_integrity_advanced import (
    AUDIO_INTEGRITY_ADVANCED_NODE_CLASSES,
    AUDIO_PERCEPTUAL_DRIFT_ADVANCED_NODE_CLASSES,
)
from .nodes_attention_hooks_advanced import ATTENTION_HOOKS_ADVANCED_NODE_CLASSES
from .nodes_forward_sync_advanced import FORWARD_SYNC_ADVANCED_NODE_CLASSES
from .nodes_tiled_vae_coordinates_advanced import TILED_VAE_COORDINATES_ADVANCED_NODE_CLASSES
from .nodes_h3_fun_control_advanced import H3_FUN_CONTROL_ADVANCED_NODE_CLASSES
from .nodes_long_video_voice_context_advanced import (
    LONG_VIDEO_VOICE_CONTEXT_ADVANCED_NODE_CLASSES,
)
from .nodes_long_video_seam_drift_advanced import (
    LONG_VIDEO_SEAM_DRIFT_ADVANCED_NODE_CLASSES,
)
from .nodes_residency_strategy_advanced import (
    RESIDENCY_STRATEGY_ADVANCED_NODE_CLASSES,
)
from .nodes_creator_segment_cache_advanced import (
    CREATOR_SEGMENT_CACHE_ADVANCED_NODE_CLASSES,
)
from .nodes_community_diagnostics_advanced import (
    COMMUNITY_DIAGNOSTICS_ADVANCED_NODE_CLASSES,
)
from .nodes_activation_chunk_advanced import ACTIVATION_CHUNK_ADVANCED_NODE_CLASSES
from .nodes_av_decode_safety_advanced import AV_DECODE_SAFETY_ADVANCED_NODE_CLASSES
from .nodes_av_latent_builder_advanced import AV_LATENT_BUILDER_ADVANCED_NODE_CLASSES
from .nodes_context_ir_advanced import CONTEXT_IR_ADVANCED_NODE_CLASSES
from .nodes_creator_workspace_advanced import CREATOR_WORKSPACE_ADVANCED_NODE_CLASSES
from .nodes_creator_runtime_advanced import (
    CREATOR_RETENTION_ADVANCED_NODE_CLASSES,
    CREATOR_RUNTIME_ADVANCED_NODE_CLASSES,
)
from .nodes_qwen_prefix_cache_advanced import (
    QWEN_PREFIX_CACHE_ADVANCED_NODE_CLASSES,
)
from .nodes_raven_streaming_advanced import RAVEN_STREAMING_ADVANCED_NODE_CLASSES
from .nodes_nfe_resume_advanced import NFE_RESUME_ADVANCED_NODE_CLASSES
from .nodes_nfe_run_contract_advanced import NFE_RUN_CONTRACT_ADVANCED_NODE_CLASSES
from .nodes_skin_finish import SKIN_FINISH_NODE_CLASSES
from .nodes_skin_finish_p1 import SKIN_FINISH_P1_NODE_CLASSES
from .nodes_skin_finish_p2 import SKIN_FINISH_P2_NODE_CLASSES
from .nodes_skin_finish_parser import SKIN_FINISH_PARSER_NODE_CLASSES
from .nodes_skin_finish_multiface_parser import (
    SKIN_FINISH_MULTIFACE_PARSER_NODE_CLASSES,
)
from .nodes_skin_finish_person_profiles import (
    SKIN_FINISH_PERSON_PROFILE_NODE_CLASSES,
)
from .nodes_skin_finish_profile_crop import (
    SKIN_FINISH_PROFILE_CROP_NODE_CLASSES,
)
from .nodes_skin_finish_safety_audit import (
    SKIN_FINISH_SAFETY_AUDIT_NODE_CLASSES,
)
from .nodes_skin_finish_frequency import SKIN_FINISH_FREQUENCY_NODE_CLASSES
from .nodes_skin_finish_timeline import SKIN_FINISH_TIMELINE_NODE_CLASSES
from .nodes_skin_finish_stream_quality import (
    SKIN_FINISH_QUALITY_STREAM_NODE_CLASSES,
)
from .nodes_skin_finish_specular_frequency import (
    SKIN_FINISH_SPECULAR_FREQUENCY_NODE_CLASSES,
)
from .nodes_skin_finish_surface import SKIN_FINISH_SURFACE_NODE_CLASSES
from .nodes_skin_finish_dichromatic import (
    SKIN_FINISH_DICHROMATIC_NODE_CLASSES,
)
from .nodes_audio_refine_advanced import (
    AUDIO_REFINE_ADVANCED_NODE_CLASSES,
    AUDIO_REFINE_COMPAT_ADVANCED_NODE_CLASSES,
)
from .nodes_h3_lora_compat_advanced import H3_LORA_COMPAT_ADVANCED_NODE_CLASSES
from .nodes_timed_references_advanced import TIMED_REFERENCES_ADVANCED_NODE_CLASSES
from .nodes_chunked_two_pass_upscale_advanced import (
    CHUNKED_TWO_PASS_UPSCALE_ADVANCED_NODE_CLASSES,
)
from .nodes_h16_chunked_pass2 import H16_CHUNKED_PASS2_NODE_CLASSES
from .nodes_fast_h3_advanced import FAST_H3_ADVANCED_NODE_CLASSES
from .nodes_fast_h3_v2_advanced import FAST_H3_V2_NODE_CLASSES
from .sol_attn_minimax_v2 import SolAttnMiniMax
from .nodes_sol_engine_h3_super_advanced import (
    SOL_ENGINE_H3_SUPER_ADVANCED_NODE_CLASSES,
)
from .nodes_mv_lipsync_advanced import (
    MV_LIPSYNC_ADVANCED_NODE_CLASSES,
    MV_LIPSYNC_V2_ADVANCED_NODE_CLASSES,
    MV_LIPSYNC_V3_ADVANCED_NODE_CLASSES,
)
from .nodes_flashvsr_advanced import FLASHVSR_ADVANCED_NODE_CLASSES
from .nodes_creator_artifact_quarantine_advanced import (
    CREATOR_ARTIFACT_QUARANTINE_ADVANCED_NODE_CLASSES,
)
from .nodes_prompt_semantic_audit_advanced import (
    PROMPT_SEMANTIC_AUDIT_ADVANCED_NODE_CLASSES,
)
from .nodes_prompt_relay_advanced import PROMPT_RELAY_ADVANCED_NODE_CLASSES
from .nodes_prompt_relay_long_video_advanced import (
    PROMPT_RELAY_LONG_VIDEO_ADVANCED_NODE_CLASSES,
)
from .nodes_prompt_relay_packet_advanced import (
    PROMPT_RELAY_PACKET_ADVANCED_NODE_CLASSES,
)
from .nodes_prompt_relay_preview_advanced import (
    PROMPT_RELAY_PREVIEW_ADVANCED_NODE_CLASSES,
)
from .nodes_prompt_relay_resource_estimate_advanced import (
    PROMPT_RELAY_RESOURCE_ESTIMATE_ADVANCED_NODE_CLASSES,
)
from .nodes_prompt_rewriter_8b_advanced import (
    PROMPT_REWRITER_8B_ADVANCED_NODE_CLASSES,
)
from .nodes_prompt_budget_advanced import PROMPT_BUDGET_ADVANCED_NODE_CLASSES
from .nodes_prompt_provider_advanced import PROMPT_PROVIDER_ADVANCED_NODE_CLASSES
from .nodes_repair_execution_advanced import (
    REPAIR_EXECUTION_ADVANCED_NODE_CLASSES,
)
from .nodes_reel_delivery_advanced import (
    REEL_DELIVERY_ADVANCED_NODE_CLASSES,
)
from .nodes_scheduled_audio_injection_advanced import (
    SCHEDULED_AUDIO_INJECTION_ADVANCED_NODE_CLASSES,
)
from .nodes_studio_advanced import STUDIO_ADVANCED_NODE_CLASSES
from .nodes_trajectory_probe_advanced import (
    TRAJECTORY_PROBE_ADVANCED_NODE_CLASSES,
)
from .nodes_motion_quality_advanced import MOTION_QUALITY_ADVANCED_NODE_CLASSES
from .nodes_motion_recovery_advanced import MOTION_RECOVERY_ADVANCED_NODE_CLASSES
from .nodes_latent_upscale import LATENT_UPSCALE_NODE_CLASSES
from .nodes_lanpaint_av_advanced import LANPAINT_AV_ADVANCED_NODE_CLASSES
from .nodes_learned_latent_upscale_advanced import (
    LEARNED_LATENT_AUDIO_AUDIT_ADVANCED_NODE_CLASSES,
    LEARNED_LATENT_UPSCALE_ADVANCED_NODE_CLASSES,
)

from .audio_ops import decode_av_latent, inject_audio_latent, mix_audio, trim_av_output
from .conditioning import build_conditioning
from .nodes_dialogue_audio_exp import DIALOGUE_AUDIO_NODE_CLASSES
from .nodes_environment_audit_advanced import ENVIRONMENT_AUDIT_ADVANCED_NODE_CLASSES
from .nodes_external_blockswap_advanced import EXTERNAL_BLOCKSWAP_ADVANCED_NODE_CLASSES
from .nodes_external_compatibility_advanced import (
    EXTERNAL_COMPATIBILITY_ADVANCED_NODE_CLASSES,
)
from .nodes_enhance_a_video_advanced import ENHANCE_A_VIDEO_ADVANCED_NODE_CLASSES
from .nodes_face_refine_advanced import FACE_REFINE_ADVANCED_NODE_CLASSES
from .nodes_face_refine_parity_advanced import FACE_REFINE_PARITY_ADVANCED_NODE_CLASSES
from .nodes_face_refine_sampler_mask_advanced import (
    FACE_REFINE_SAMPLER_MASK_ADVANCED_NODE_CLASSES,
)
from .nodes_face_refine_window_advanced import FACE_REFINE_WINDOW_ADVANCED_NODE_CLASSES
from .nodes_face_refine_window_studio_advanced import (
    FACE_REFINE_WINDOW_STUDIO_ADVANCED_NODE_CLASSES,
)
from .nodes_multiface_refine_advanced import MULTIFACE_REFINE_ADVANCED_NODE_CLASSES
from .nodes_dynamic_guidance_advanced import DYNAMIC_GUIDANCE_ADVANCED_NODE_CLASSES
from .nodes_detail_sampling_advanced import (
    DETAIL_SAMPLING_ADVANCED_NODE_CLASSES,
    TWO_PASS_DETAIL_ADVANCED_NODE_CLASSES,
)
from .nodes_speed_advanced import SPEED_ADVANCED_NODE_CLASSES
from .nodes_hybrid_compatibility_advanced import (
    HYBRID_COMPATIBILITY_ADVANCED_NODE_CLASSES,
)
from .nodes_hybrid_model_advanced import (
    HYBRID_MODEL_ADVANCED_NODE_CLASSES,
    HYBRID_MODEL_MAINTENANCE_ADVANCED_NODE_CLASSES,
)
from .nodes_multirate_exp import MiniMaxH3MultiRateSamplerEXPT8
from .nodes_native_latent_timeline_advanced import (
    NATIVE_LATENT_CONTINUATION_ADVANCED_NODE_CLASSES,
    NATIVE_LATENT_RESUME_ADVANCED_NODE_CLASSES,
    NATIVE_LATENT_TIMELINE_ADVANCED_NODE_CLASSES,
)
from .nodes_native_latent_checkpoint_advanced import (
    NATIVE_LATENT_CHECKPOINT_ADVANCED_NODE_CLASSES,
)
from .nodes_native_masked_context_advanced import (
    NATIVE_MASKED_CONTEXT_ADVANCED_NODE_CLASSES,
)
from .nodes_long_video_color_match_advanced import (
    LONG_VIDEO_COLOR_MATCH_ADVANCED_NODE_CLASSES,
)
from .nodes_vdn_h3_advanced import VDN_H3_ADVANCED_NODE_CLASSES
from .nodes_vdn_two_pass import MiniMaxH3VDNRefinePlanT8Advanced
from .nodes_h3_av_delivery import MiniMaxH3SafeAVSaveT8Advanced
from .nodes_progressive_sampling import MiniMaxH3ProgressiveSamplerEXPT8
from .nodes_tst import MiniMaxH3TSTModelEXPT8
from .nodes_progressive_long_video import PROGRESSIVE_LONG_VIDEO_NODE_CLASSES
from .nodes_dlss_fi import MiniMaxH3DLSSFrameInterpolationEXPT8
from .nodes_trt_vae import TRT_VAE_NODE_CLASSES
from .nodes_dlss_nr_advanced import DLSS_NR_ADVANCED_NODE_CLASSES
from .nodes_h3_world_advanced import H3_WORLD_ADVANCED_NODE_CLASSES
from .nodes_multikeyframe_advanced import MULTIKEYFRAME_ADVANCED_NODE_CLASSES
from .nodes_long_video_exp import (
    MiniMaxH3LongVideoConditioningT8,
    MiniMaxH3LongVideoContextLoadT8,
    MiniMaxH3LongVideoContextSaveT8,
    MiniMaxH3LongVideoPlannerT8,
)
from .nodes_long_video_delivery_exp import (
    MiniMaxH3LongVideoAcceptedContextLoadT8,
    MiniMaxH3LongVideoAcceptCandidateT8,
    MiniMaxH3LongVideoAutoQueueT8,
    MiniMaxH3LongVideoBackgroundStartT8,
    MiniMaxH3LongVideoCandidateSaveT8,
    MiniMaxH3LongVideoComposeAcceptedT8,
    MiniMaxH3LongVideoOrchestratorT8,
)
from .nodes_long_video_in_node_loop_advanced import (
    LONG_VIDEO_IN_NODE_LOOP_ADVANCED_NODE_CLASSES,
)
from .nodes_long_video_dual_model import MiniMaxH3DualModelLongVideoEXPT8
from .nodes_dance_motion import MiniMaxH3DanceMotionSourceEXPT8
from .nodes_topaz import TOPAZ_NODE_CLASSES
from .nodes_prepared_generation import PREPARED_GENERATION_NODE_CLASSES
from .nodes_long_video_in_node_loop_effects_advanced import (
    LONG_VIDEO_IN_NODE_LOOP_EFFECTS_ADVANCED_NODE_CLASSES,
)
from .nodes_long_video_sampling_plan_advanced import (
    LONG_VIDEO_SAMPLING_PLAN_ADVANCED_NODE_CLASSES,
)
from .nodes_chunked_two_pass_global_noise_advanced import (
    CHUNKED_TWO_PASS_GLOBAL_NOISE_ADVANCED_NODE_CLASSES,
)
from .nodes_subject_safe_rgb_composite_advanced import (
    SUBJECT_SAFE_RGB_COMPOSITE_ADVANCED_NODE_CLASSES,
)
from .long_video_routes import register_long_video_background_routes
from .nodes_still_exp import (
    MiniMaxH3StillConditioningT8,
    MiniMaxH3StillDecodeT8,
    MiniMaxH3StillPreflightT8,
)
from .nodes_speech_exp import SPEECH_NODE_CLASSES
from .nodes_source_av_exp import SOURCE_AV_NODE_CLASSES
from .nodes_sla_attention_advanced import SLA_ATTENTION_ADVANCED_NODE_CLASSES
from .nodes_sla_profile_router_advanced import (
    SLA_PROFILE_ROUTER_ADVANCED_NODE_CLASSES,
)
from .nodes_sla_precision_v2_advanced import (
    SLA_PRECISION_V2_ADVANCED_NODE_CLASSES,
)
from .nodes_pdd_advanced import PDD_ADVANCED_NODE_CLASSES
from .nodes_visual_reference_exp import MiniMaxH3VisualReferenceStrengthEXPT8
from .nodes_vram_policy_advanced import VRAM_POLICY_ADVANCED_NODE_CLASSES
from .nodes_optical_flow_advanced import OPTICAL_FLOW_ADVANCED_NODE_CLASSES
from .nodes_trajectory_control_advanced import TRAJECTORY_CONTROL_ADVANCED_NODE_CLASSES
from .nodes_realbasicvsr_advanced import REALBASICVSR_ADVANCED_NODE_CLASSES
from .nodes_freenoise_advanced import FREENOISE_ADVANCED_NODE_CLASSES
from .nodes_ays_schedule_advanced import AYS_SCHEDULE_ADVANCED_NODE_CLASSES
from .nodes_cads_visual_advanced import CADS_VISUAL_ADVANCED_NODE_CLASSES
from .nodes_video_outpaint import VIDEO_OUTPAINT_DRAFT_NODE_CLASSES
from .nodes_video_outpaint_preview import MiniMaxH3VideoOutpaintGeometryPreviewT8
from .nodes_video_outpaint_candidates import (
    VIDEO_OUTPAINT_CANDIDATE_DRAFT_NODE_CLASSES,
)
from .nodes_video_outpaint_reload import MiniMaxH3VideoOutpaintLoadPreparedT8
from .nodes_video_outpaint_guidance import VIDEO_OUTPAINT_GUIDANCE_DRAFT_NODE_CLASSES
from .nodes_h3_memory_advanced import H3_MEMORY_ADVANCED_NODE_CLASSES
from .preflight import run_preflight
from .prompt_tags import prepare_prompt
from .sampling import (
    DEFAULT_SAMPLER_NAME,
    DEFAULT_SCHEDULER_NAME,
    SAMPLER_OPTIONS,
    SCHEDULER_OPTIONS,
    setup_dual_clock_sampling,
)
from .timing import make_timing_plan, window_audio


CATEGORY = "T8/MiniMax H3/Audio"
MAX_RESOLUTION = 16384


class MiniMaxH3AudioConditioningT8(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="MiniMaxH3AudioConditioningT8",
            display_name="MiniMax H3 Audio Conditioning (T8)",
            description="Unified native H3 T2VA/I2VA/FL2VA/L2VA/Ref2VA/hybrid conditioning with correct media tags and source-audio control.",
            category=CATEGORY,
            inputs=[
                io.Clip.Input("clip", tooltip="Native MiniMax H3 Qwen3-VL CLIP."),
                io.Vae.Input("video_vae", tooltip="MiniMax H3 video VAE."),
                io.Vae.Input("audio_vae", tooltip="MiniMax H3 audio VAE."),
                io.String.Input("prompt", multiline=True, dynamic_prompts=True),
                io.Int.Input("width", default=1344, min=32, max=MAX_RESOLUTION, step=32),
                io.Int.Input("height", default=768, min=32, max=MAX_RESOLUTION, step=32),
                io.Int.Input("length", default=124, min=5, max=None, step=17, tooltip="24fps; snapped up to the 17n+5 H3 grid."),
                io.Combo.Input("task_type", options=["auto", "T2VA", "I2VA", "FL2VA", "L2VA", "Ref2VA", "Hybrid"], default="auto"),
                io.Combo.Input("audio_mode", options=["lock_source", "remix_source", "reference_only", "native"], default="lock_source", tooltip="lock_source preserves source latent; remix_source denoises it; reference_only/native generate target audio."),
                io.Float.Input("audio_denoise_strength", default=0.35, min=0.0, max=1.0, step=0.01, advanced=True),
                io.Boolean.Input("add_source_as_reference", default=True, tooltip="Presents drive_audio to Qwen/DiT as an official <Audio N> reference."),
                io.Int.Input("prompt_primary_audio_ordinal", default=1, min=0, max=9, step=1, tooltip="Prompt audio ordinal intended as the primary source; remapped after video soundtracks. Use 0 to disable.", advanced=True),
                io.Boolean.Input("strict_prompt_tags", default=True, advanced=True),
                io.Combo.Input("ref_image_size", options=["match", "max"], default="match", advanced=True),
                io.Combo.Input("reference_video_policy", options=["official_2_to_15s", "model_minimum"], default="official_2_to_15s", advanced=True),
                io.Audio.Input("drive_audio", optional=True),
                io.Audio.Input("final_audio", optional=True, tooltip="Optional clean/stem track passed through for final mux; defaults to drive_audio."),
                io.Image.Input("first_frame", optional=True),
                io.Image.Input("last_frame", optional=True),
                io.Autogrow.Input("ref_images", optional=True, template=io.Autogrow.TemplatePrefix(input=io.Image.Input("ref_image"), prefix="ref_image_", min=0, max=9)),
                io.Autogrow.Input("ref_videos", optional=True, template=io.Autogrow.TemplatePrefix(input=io.Image.Input("ref_video", tooltip="IMAGE frame batch at 24fps."), prefix="ref_video_", min=0, max=3)),
                io.Autogrow.Input("ref_video_audios", optional=True, template=io.Autogrow.TemplatePrefix(input=io.Audio.Input("ref_video_audio"), prefix="ref_video_audio_", min=0, max=3)),
                io.Autogrow.Input("ref_audios", optional=True, template=io.Autogrow.TemplatePrefix(input=io.Audio.Input("ref_audio"), prefix="ref_audio_", min=0, max=3)),
                io.Boolean.Input(
                    "allow_above_reference_area",
                    default=True,
                    optional=True,
                    advanced=True,
                    tooltip=(
                        "Legacy workflow compatibility input. Canvases above the 1920x1088 "
                        "reference area are now allowed regardless of this value and only emit "
                        "a VRAM/runtime warning."
                    ),
                ),
                BridgeIO.Input("semantic_bridge", optional=True),
            ],
            outputs=[
                io.Conditioning.Output(display_name="positive"),
                io.Latent.Output(display_name="av_latent"),
                io.Audio.Output(display_name="mux_audio"),
                io.String.Output(display_name="conditioned_prompt"),
                io.String.Output(display_name="media_map_json"),
                io.String.Output(display_name="report"),
            ],
        )

    @classmethod
    def execute(cls, clip, video_vae, audio_vae, prompt, width, height, length, task_type, audio_mode,
                audio_denoise_strength, add_source_as_reference, prompt_primary_audio_ordinal,
                strict_prompt_tags, ref_image_size, reference_video_policy, drive_audio=None,
                final_audio=None, first_frame=None, last_frame=None, ref_images=None, ref_videos=None,
                ref_video_audios=None, ref_audios=None, allow_above_reference_area=True, semantic_bridge=None):
        return io.NodeOutput(*build_conditioning(
            clip, video_vae, audio_vae, prompt, width, height, length, task_type, audio_mode,
            audio_denoise_strength, add_source_as_reference, prompt_primary_audio_ordinal,
            strict_prompt_tags, ref_image_size, reference_video_policy, drive_audio, final_audio,
            first_frame, last_frame, ref_images, ref_videos, ref_video_audios, ref_audios,
            allow_above_reference_area=allow_above_reference_area,
            semantic_bridge=semantic_bridge,
        ))


class MiniMaxH3AudioLatentControlT8(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="MiniMaxH3AudioLatentControlT8",
            display_name="MiniMax H3 Audio Latent Control (T8)",
            description="Injects source audio once and preserves an existing video noise mask.",
            category=CATEGORY,
            inputs=[
                io.Latent.Input("av_latent"), io.Audio.Input("source_audio"), io.Vae.Input("audio_vae"),
                io.Combo.Input("mode", options=["lock", "remix"], default="lock"),
                io.Float.Input("strength", default=0.35, min=0.0, max=1.0, step=0.01),
            ],
            outputs=[io.Latent.Output(display_name="av_latent"), io.Audio.Output(display_name="source_audio")],
        )

    @classmethod
    def execute(cls, av_latent, source_audio, audio_vae, mode, strength):
        return io.NodeOutput(*inject_audio_latent(av_latent, source_audio, audio_vae, mode, strength))


class MiniMaxH3DurationPlannerT8(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="MiniMaxH3DurationPlannerT8",
            display_name="MiniMax H3 Duration Planner (T8)",
            category=CATEGORY,
            inputs=[
                io.Float.Input("scene_start_seconds", default=0.0, min=0.0, max=86400.0, step=0.01),
                io.Float.Input("scene_duration_seconds", default=5.0, min=0.04, max=None, step=0.01),
                io.Float.Input("warmup_seconds", default=0.0, min=0.0, max=60.0, step=0.01),
                io.Float.Input("cooldown_seconds", default=0.0, min=0.0, max=60.0, step=0.01),
                io.Boolean.Input("ensure_minimum_context", default=True),
                io.Float.Input("source_duration_seconds", default=0.0, min=0.0, max=None, step=0.01, advanced=True, tooltip="0 means unknown; the Audio Window node reads it from AUDIO."),
            ],
            outputs=[
                io.Int.Output("length"), io.Float.Output("render_duration_seconds"),
                io.Float.Output("source_slice_start_seconds"), io.Float.Output("source_slice_duration_seconds"),
                io.Float.Output("final_trim_start_seconds"), io.Float.Output("final_duration_seconds"),
                io.String.Output("prompt_timing_note"), io.String.Output("report_json"),
            ],
        )

    @classmethod
    def execute(cls, scene_start_seconds, scene_duration_seconds, warmup_seconds, cooldown_seconds,
                ensure_minimum_context, source_duration_seconds):
        plan = make_timing_plan(scene_start_seconds, scene_duration_seconds, warmup_seconds,
                                cooldown_seconds, ensure_minimum_context, source_duration_seconds)
        return io.NodeOutput(plan.frame_count, plan.render_duration_seconds, plan.source_slice_start_seconds,
                             plan.source_slice_duration_seconds, plan.final_trim_start_seconds,
                             plan.final_duration_seconds, plan.prompt_note(), plan.report())


class MiniMaxH3AudioWindowT8(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="MiniMaxH3AudioWindowT8",
            display_name="MiniMax H3 Audio Window (T8)",
            description="Slices/pads source AUDIO to an aligned H3 context and returns exact final trim metadata.",
            category=CATEGORY,
            inputs=[
                io.Audio.Input("audio"),
                io.Float.Input("scene_start_seconds", default=0.0, min=0.0, max=86400.0, step=0.01),
                io.Float.Input("scene_duration_seconds", default=5.0, min=0.04, max=None, step=0.01),
                io.Float.Input("warmup_seconds", default=0.0, min=0.0, max=60.0, step=0.01),
                io.Float.Input("cooldown_seconds", default=0.0, min=0.0, max=60.0, step=0.01),
                io.Boolean.Input("ensure_minimum_context", default=True),
            ],
            outputs=[io.Audio.Output("context_audio"), io.Int.Output("length"),
                     io.Float.Output("final_trim_start_seconds"), io.Float.Output("final_duration_seconds"),
                     io.String.Output("prompt_timing_note"), io.String.Output("report_json")],
        )

    @classmethod
    def execute(cls, audio, scene_start_seconds, scene_duration_seconds, warmup_seconds, cooldown_seconds,
                ensure_minimum_context):
        source_duration = audio["waveform"].shape[-1] / int(audio["sample_rate"])
        plan = make_timing_plan(scene_start_seconds, scene_duration_seconds, warmup_seconds,
                                cooldown_seconds, ensure_minimum_context, source_duration)
        return io.NodeOutput(window_audio(audio, plan), plan.frame_count, plan.final_trim_start_seconds,
                             plan.final_duration_seconds, plan.prompt_note(), plan.report())


class MiniMaxH3PromptTagsT8(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="MiniMaxH3PromptTagsT8", display_name="MiniMax H3 Prompt Tags (T8)", category=CATEGORY,
            inputs=[
                io.String.Input("prompt", multiline=True, dynamic_prompts=True),
                io.Int.Input("picture_count", default=0, min=0, max=11),
                io.Int.Input("video_count", default=0, min=0, max=3),
                io.Int.Input("audio_count", default=1, min=0, max=9),
                io.Int.Input("source_audio_ordinal", default=1, min=0, max=9),
                io.Int.Input("prompt_primary_audio_ordinal", default=1, min=0, max=9),
                io.Boolean.Input("strict", default=True),
            ], outputs=[io.String.Output("prompt"), io.String.Output("report")],
        )

    @classmethod
    def execute(cls, prompt, picture_count, video_count, audio_count, source_audio_ordinal,
                prompt_primary_audio_ordinal, strict):
        normalized, warnings = prepare_prompt(prompt, {"pictures": picture_count, "videos": video_count,
                                                       "audios": audio_count}, source_audio_ordinal,
                                              prompt_primary_audio_ordinal, strict)
        return io.NodeOutput(normalized, "OK" if not warnings else "\n".join(warnings))


class MiniMaxH3AVDecodeT8(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="MiniMaxH3AVDecodeT8", display_name="MiniMax H3 AV Decode (T8)", category=CATEGORY,
            inputs=[io.Latent.Input("av_latent"), io.Vae.Input("video_vae"), io.Vae.Input("audio_vae")],
            outputs=[io.Image.Output("frames"), io.Audio.Output("generated_audio"),
                     io.Latent.Output("video_latent"), io.Latent.Output("audio_latent")],
        )

    @classmethod
    def execute(cls, av_latent, video_vae, audio_vae):
        return io.NodeOutput(*decode_av_latent(av_latent, video_vae, audio_vae))


class MiniMaxH3AudioMixT8(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="MiniMaxH3AudioMixT8", display_name="MiniMax H3 Audio Mix (T8)", category=CATEGORY,
            inputs=[
                io.Audio.Input("source_audio"), io.Audio.Input("generated_audio"),
                io.Float.Input("source_gain_db", default=0.0, min=-60.0, max=24.0, step=0.1),
                io.Float.Input("generated_gain_db", default=-6.0, min=-60.0, max=24.0, step=0.1),
                io.Float.Input("duck_generated", default=0.5, min=0.0, max=1.0, step=0.01),
                io.Combo.Input("output_sample_rate", options=["source", "generated", "48000", "44100", "32000"], default="source"),
                io.Float.Input("peak_limit_dbfs", default=-1.0, min=-12.0, max=0.0, step=0.1),
            ], outputs=[io.Audio.Output("mixed_audio")],
        )

    @classmethod
    def execute(cls, source_audio, generated_audio, source_gain_db, generated_gain_db,
                duck_generated, output_sample_rate, peak_limit_dbfs):
        return io.NodeOutput(mix_audio(source_audio, generated_audio, source_gain_db, generated_gain_db,
                                       duck_generated, output_sample_rate, peak_limit_dbfs))


class MiniMaxH3OutputTrimT8(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="MiniMaxH3OutputTrimT8", display_name="MiniMax H3 Output Trim (T8)", category=CATEGORY,
            description="Applies Duration Planner trim metadata to decoded IMAGE frames and optional AUDIO.",
            inputs=[
                io.Image.Input("frames"),
                io.Float.Input("start_seconds", default=0.0, min=0.0, max=900.0, step=0.001),
                io.Float.Input("duration_seconds", default=5.0, min=0.04, max=None, step=0.001),
                io.Float.Input("fps", default=24.0, min=1.0, max=240.0, step=0.001, advanced=True),
                io.Audio.Input("audio", optional=True),
            ],
            outputs=[io.Image.Output("frames"), io.Audio.Output("audio"), io.String.Output("report_json")],
        )

    @classmethod
    def execute(cls, frames, start_seconds, duration_seconds, fps, audio=None):
        return io.NodeOutput(*trim_av_output(frames, start_seconds, duration_seconds, audio, fps))


class MiniMaxH3PreflightT8(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="MiniMaxH3PreflightT8", display_name="MiniMax H3 Preflight (T8)", category=CATEGORY,
            inputs=[
                io.Int.Input("width", default=1344, min=32, max=MAX_RESOLUTION, step=32),
                io.Int.Input("height", default=768, min=32, max=MAX_RESOLUTION, step=32),
                io.Int.Input("length", default=124, min=5, max=None),
                io.Combo.Input("audio_mode", options=["lock_source", "remix_source", "reference_only", "native"], default="lock_source"),
                io.Model.Input("model", optional=True), io.Vae.Input("video_vae", optional=True),
                io.Vae.Input("audio_vae", optional=True), io.Audio.Input("drive_audio", optional=True),
                io.Autogrow.Input("ref_images", optional=True, template=io.Autogrow.TemplatePrefix(input=io.Image.Input("ref_image"), prefix="ref_image_", min=0, max=9)),
                io.Autogrow.Input("ref_videos", optional=True, template=io.Autogrow.TemplatePrefix(input=io.Image.Input("ref_video"), prefix="ref_video_", min=0, max=3)),
                io.Autogrow.Input("ref_audios", optional=True, template=io.Autogrow.TemplatePrefix(input=io.Audio.Input("ref_audio"), prefix="ref_audio_", min=0, max=3)),
            ], outputs=[io.Boolean.Output("ready"), io.Int.Output("warning_count"), io.String.Output("report_json")],
        )

    @classmethod
    def execute(cls, width, height, length, audio_mode, model=None, video_vae=None, audio_vae=None,
                drive_audio=None, ref_images=None, ref_videos=None, ref_audios=None):
        return io.NodeOutput(*run_preflight(width, height, length, audio_mode, model, video_vae, audio_vae,
                                            drive_audio, ref_images, ref_videos, ref_audios))


class MiniMaxH3DualClockSamplerT8(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="MiniMaxH3DualClockSamplerT8",
            display_name="MiniMax H3 Dual-Clock Sampler (T8)",
            description=(
                "MiniMax H3 sampling setup with separate video/audio clocks. "
                "The default dual_clock_euler + native_flow path is unchanged; other ComfyUI "
                "samplers use native FLOW_AV support."
            ),
            category=CATEGORY,
            inputs=[
                io.Model.Input("model"),
                io.Latent.Input("av_latent"),
                io.Int.Input("steps", default=4, min=1, max=1000),
                io.Float.Input("shift_video", default=12.0, min=0.01, max=100.0, step=0.01, advanced=True),
                io.Float.Input("shift_audio", default=3.0, min=0.01, max=100.0, step=0.01, advanced=True),
                io.Combo.Input(
                    "sampler_name",
                    options=SAMPLER_OPTIONS,
                    default=DEFAULT_SAMPLER_NAME,
                    optional=True,
                    display_name="sampler / 采样器",
                    tooltip=(
                        "dual_clock_euler preserves the original T8 explicit dual-clock path. "
                        "Other choices use ComfyUI's native MiniMax H3 FLOW_AV protocol."
                    ),
                ),
                io.Combo.Input(
                    "scheduler",
                    options=SCHEDULER_OPTIONS,
                    default=DEFAULT_SCHEDULER_NAME,
                    optional=True,
                    display_name="scheduler / 调度器",
                    tooltip=(
                        "native_flow preserves the original shifted uniform H3 flow schedule. "
                        "beta57 uses ComfyUI's beta scheduler with alpha=0.5 and beta=0.7. "
                        "Other choices use ComfyUI's built-in scheduler implementation."
                    ),
                ),
            ],
            outputs=[
                io.Model.Output(display_name="model"),
                io.Sampler.Output(display_name="sampler"),
                io.Sigmas.Output(display_name="sigmas"),
            ],
        )

    @classmethod
    def execute(
        cls,
        model,
        av_latent,
        steps,
        shift_video,
        shift_audio,
        sampler_name=DEFAULT_SAMPLER_NAME,
        scheduler=DEFAULT_SCHEDULER_NAME,
    ):
        return io.NodeOutput(*setup_dual_clock_sampling(
            model,
            av_latent,
            steps,
            shift_video,
            shift_audio,
            sampler_name,
            scheduler,
        ))


class MiniMaxH3AudioT8Extension(ComfyExtension):
    async def get_node_list(self):
        register_long_video_background_routes()
        register_director_routes()
        return [MiniMaxH3AudioConditioningT8, MiniMaxH3AudioLatentControlT8,
                MiniMaxH3DurationPlannerT8, MiniMaxH3AudioWindowT8, MiniMaxH3PromptTagsT8,
                MiniMaxH3AVDecodeT8, MiniMaxH3AudioMixT8, MiniMaxH3OutputTrimT8,
                MiniMaxH3PreflightT8, MiniMaxH3DualClockSamplerT8,
                MiniMaxH3MultiRateSamplerEXPT8, MiniMaxH3StillConditioningT8,
                MiniMaxH3StillPreflightT8, MiniMaxH3StillDecodeT8,
                MiniMaxH3LongVideoPlannerT8, MiniMaxH3LongVideoContextLoadT8,
                MiniMaxH3LongVideoConditioningT8, MiniMaxH3LongVideoContextSaveT8,
                MiniMaxH3LongVideoCandidateSaveT8, MiniMaxH3LongVideoAcceptCandidateT8,
                MiniMaxH3LongVideoAcceptedContextLoadT8,
                MiniMaxH3LongVideoComposeAcceptedT8,
                MiniMaxH3LongVideoOrchestratorT8,
                MiniMaxH3LongVideoBackgroundStartT8,
                MiniMaxH3LongVideoAutoQueueT8,
                *SPEECH_NODE_CLASSES[:10],
                MiniMaxH3VisualReferenceStrengthEXPT8,
                *SPEECH_NODE_CLASSES[10:],
                *SOURCE_AV_NODE_CLASSES,
                *DIALOGUE_AUDIO_NODE_CLASSES,
                *MULTIKEYFRAME_ADVANCED_NODE_CLASSES,
                *HYBRID_MODEL_ADVANCED_NODE_CLASSES,
                *VRAM_POLICY_ADVANCED_NODE_CLASSES,
                *HYBRID_MODEL_MAINTENANCE_ADVANCED_NODE_CLASSES,
                *HYBRID_COMPATIBILITY_ADVANCED_NODE_CLASSES,
                *ENVIRONMENT_AUDIT_ADVANCED_NODE_CLASSES,
                *ACTIVATION_CHUNK_ADVANCED_NODE_CLASSES,
                *QWEN_PREFIX_CACHE_ADVANCED_NODE_CLASSES,
                *STUDIO_ADVANCED_NODE_CLASSES,
                *REPAIR_EXECUTION_ADVANCED_NODE_CLASSES,
                *SCHEDULED_AUDIO_INJECTION_ADVANCED_NODE_CLASSES,
                *AV_DECODE_SAFETY_ADVANCED_NODE_CLASSES,
                *CONTEXT_IR_ADVANCED_NODE_CLASSES,
                *REEL_DELIVERY_ADVANCED_NODE_CLASSES,
                *TRAJECTORY_PROBE_ADVANCED_NODE_CLASSES,
                *MOTION_QUALITY_ADVANCED_NODE_CLASSES,
                *FACE_REFINE_ADVANCED_NODE_CLASSES,
                *LATENT_UPSCALE_NODE_CLASSES,
                *FACE_REFINE_PARITY_ADVANCED_NODE_CLASSES,
                *MULTIFACE_REFINE_ADVANCED_NODE_CLASSES,
                *DYNAMIC_GUIDANCE_ADVANCED_NODE_CLASSES,
                *DETAIL_SAMPLING_ADVANCED_NODE_CLASSES,
                *SPEED_ADVANCED_NODE_CLASSES,
                *LEARNED_LATENT_UPSCALE_ADVANCED_NODE_CLASSES,
                *TWO_PASS_DETAIL_ADVANCED_NODE_CLASSES,
                *PROMPT_RELAY_ADVANCED_NODE_CLASSES,
                *PROMPT_RELAY_LONG_VIDEO_ADVANCED_NODE_CLASSES,
                *PROMPT_RELAY_PACKET_ADVANCED_NODE_CLASSES,
                *PROMPT_RELAY_PREVIEW_ADVANCED_NODE_CLASSES,
                *PROMPT_RELAY_RESOURCE_ESTIMATE_ADVANCED_NODE_CLASSES,
                *LEARNED_LATENT_AUDIO_AUDIT_ADVANCED_NODE_CLASSES,
                *ENHANCE_A_VIDEO_ADVANCED_NODE_CLASSES,
                *MOTION_RECOVERY_ADVANCED_NODE_CLASSES,
                # Append-only compatibility rule: new node classes stay after all
                # previously released IDs so old frontend widget serialization and
                # registration-order contracts remain untouched.
                *EXTERNAL_BLOCKSWAP_ADVANCED_NODE_CLASSES,
                *LANPAINT_AV_ADVANCED_NODE_CLASSES,
                *PROMPT_REWRITER_8B_ADVANCED_NODE_CLASSES,
                *SLA_ATTENTION_ADVANCED_NODE_CLASSES,
                *AUDIO_INTEGRITY_ADVANCED_NODE_CLASSES,
                *PROMPT_BUDGET_ADVANCED_NODE_CLASSES,
                *CREATOR_WORKSPACE_ADVANCED_NODE_CLASSES,
                *EXTERNAL_COMPATIBILITY_ADVANCED_NODE_CLASSES,
                *NATIVE_LATENT_TIMELINE_ADVANCED_NODE_CLASSES,
                *AUDIO_PERCEPTUAL_DRIFT_ADVANCED_NODE_CLASSES,
                *CREATOR_RUNTIME_ADVANCED_NODE_CLASSES,
                *PROMPT_PROVIDER_ADVANCED_NODE_CLASSES,
                *CREATOR_RETENTION_ADVANCED_NODE_CLASSES,
                *NATIVE_LATENT_RESUME_ADVANCED_NODE_CLASSES,
                *NATIVE_LATENT_CHECKPOINT_ADVANCED_NODE_CLASSES,
                *NATIVE_LATENT_CONTINUATION_ADVANCED_NODE_CLASSES,
                *RAVEN_STREAMING_ADVANCED_NODE_CLASSES,
                *NFE_RESUME_ADVANCED_NODE_CLASSES,
                *CREATOR_ARTIFACT_QUARANTINE_ADVANCED_NODE_CLASSES,
                *PROMPT_SEMANTIC_AUDIT_ADVANCED_NODE_CLASSES,
                *NFE_RUN_CONTRACT_ADVANCED_NODE_CLASSES,
                *SKIN_FINISH_NODE_CLASSES,
                *SKIN_FINISH_P1_NODE_CLASSES,
                *SKIN_FINISH_P2_NODE_CLASSES,
                *SKIN_FINISH_PARSER_NODE_CLASSES,
                *SKIN_FINISH_MULTIFACE_PARSER_NODE_CLASSES,
                *SKIN_FINISH_PERSON_PROFILE_NODE_CLASSES,
                *SKIN_FINISH_PROFILE_CROP_NODE_CLASSES,
                *SKIN_FINISH_SAFETY_AUDIT_NODE_CLASSES,
                *SKIN_FINISH_FREQUENCY_NODE_CLASSES,
                *SKIN_FINISH_TIMELINE_NODE_CLASSES,
                *SKIN_FINISH_QUALITY_STREAM_NODE_CLASSES,
                *SKIN_FINISH_SPECULAR_FREQUENCY_NODE_CLASSES,
                *SKIN_FINISH_SURFACE_NODE_CLASSES,
                *SKIN_FINISH_DICHROMATIC_NODE_CLASSES,
                *SLA_PROFILE_ROUTER_ADVANCED_NODE_CLASSES,
                *PDD_ADVANCED_NODE_CLASSES,
                *AUDIO_REFINE_ADVANCED_NODE_CLASSES,
                *LONG_VIDEO_IN_NODE_LOOP_ADVANCED_NODE_CLASSES,
                *LONG_VIDEO_IN_NODE_LOOP_EFFECTS_ADVANCED_NODE_CLASSES,
                *AV_LATENT_BUILDER_ADVANCED_NODE_CLASSES,
                *ATTENTION_HOOKS_ADVANCED_NODE_CLASSES,
                *FORWARD_SYNC_ADVANCED_NODE_CLASSES,
                *TILED_VAE_COORDINATES_ADVANCED_NODE_CLASSES,
                *H3_FUN_CONTROL_ADVANCED_NODE_CLASSES,
                *LONG_VIDEO_VOICE_CONTEXT_ADVANCED_NODE_CLASSES,
                *LONG_VIDEO_SEAM_DRIFT_ADVANCED_NODE_CLASSES,
                *RESIDENCY_STRATEGY_ADVANCED_NODE_CLASSES,
                *CREATOR_SEGMENT_CACHE_ADVANCED_NODE_CLASSES,
                *COMMUNITY_DIAGNOSTICS_ADVANCED_NODE_CLASSES,
                *OPTICAL_FLOW_ADVANCED_NODE_CLASSES,
                *TRAJECTORY_CONTROL_ADVANCED_NODE_CLASSES,
                *REALBASICVSR_ADVANCED_NODE_CLASSES,
                *FREENOISE_ADVANCED_NODE_CLASSES,
                *AYS_SCHEDULE_ADVANCED_NODE_CLASSES,
                *CADS_VISUAL_ADVANCED_NODE_CLASSES,
                *AUDIO_REFINE_COMPAT_ADVANCED_NODE_CLASSES,
                # 2026-08-29 community-update batch. Keep these at the tail so
                # every previously released registration position remains stable.
                *H3_LORA_COMPAT_ADVANCED_NODE_CLASSES,
                *TIMED_REFERENCES_ADVANCED_NODE_CLASSES,
                *CHUNKED_TWO_PASS_UPSCALE_ADVANCED_NODE_CLASSES,
                *FAST_H3_ADVANCED_NODE_CLASSES,
                *SOL_ENGINE_H3_SUPER_ADVANCED_NODE_CLASSES,
                *FLASHVSR_ADVANCED_NODE_CLASSES,
                *LONG_VIDEO_SAMPLING_PLAN_ADVANCED_NODE_CLASSES,
                 *CHUNKED_TWO_PASS_GLOBAL_NOISE_ADVANCED_NODE_CLASSES,
                 *SUBJECT_SAFE_RGB_COMPOSITE_ADVANCED_NODE_CLASSES,
                # 2026-09-01 all-local MV/lip-sync batch. Append-only: never move
                # any previously released node registration above this point.
                *MV_LIPSYNC_ADVANCED_NODE_CLASSES,
                # Vocal Lock V2 fixes the assessability gap without changing the
                # released V1 node schemas or registration positions.
                *MV_LIPSYNC_V2_ADVANCED_NODE_CLASSES,
                # V3 is append-only after the released V2 positions. It adds a
                # strict single-subject visual contract and an independent resume schema.
                *MV_LIPSYNC_V3_ADVANCED_NODE_CLASSES,
                # SLA Precision V2 is append-only after every v1.64.0 node. It
                # never changes the three legacy SLA nodes or Profile Router.
                *SLA_PRECISION_V2_ADVANCED_NODE_CLASSES,
                # Native Masked Video Context is an isolated Plan B after every
                # v1.65.0 node. It only overlays a target LATENT when explicitly wired.
                *NATIVE_MASKED_CONTEXT_ADVANCED_NODE_CLASSES,
                # Default-on RGB seam matching is append-only after Plan B and
                # leaves all previously released schemas and positions unchanged.
                *LONG_VIDEO_COLOR_MATCH_ADVANCED_NODE_CLASSES,
                # OpenVDN MiniMax H3 is an isolated T2VA architecture backend.
                # Append-only after every v1.66.0 node; legacy schemas stay untouched.
                *VDN_H3_ADVANCED_NODE_CLASSES,
                # DLSS-NR is a separately governed Windows/RTX post-processing Plan B.
                # Runtime Audit is the first append-only node; no proprietary file is bundled.
                *DLSS_NR_ADVANCED_NODE_CLASSES,
                # H3-World is an isolated action-conditioned I2VA route.
                # Append-only after every v1.70.0 node; no legacy schema moves.
                *H3_WORLD_ADVANCED_NODE_CLASSES,
                # Roadmap 29 adds source-bound, shot-local Face Refine windows and
                # explicit human acceptance after every v1.72.0 node. The GPU branch
                # remains user-wired and serial; these nodes never auto-queue it.
                *FACE_REFINE_WINDOW_ADVANCED_NODE_CLASSES,
                # P1 reuses the existing background queue, retry, cancellation and OS
                # lease implementation. A next window is queued only after an explicit
                # durable accept/reject decision; source media is never overwritten.
                *FACE_REFINE_WINDOW_STUDIO_ADVANCED_NODE_CLASSES,
                # Upstream FaceRefine v1.1.1 sampler-mask correction. Append-only after
                # every v1.73.0 node; old node schemas and registration positions stay fixed.
                *FACE_REFINE_SAMPLER_MASK_ADVANCED_NODE_CLASSES,
                # H3 Video Outpaint is append-only after every v1.74.0 node. It keeps
                # existing workflows untouched and requires explicit human selection
                # before a reviewed candidate can continue or be composed.
                *VIDEO_OUTPAINT_DRAFT_NODE_CLASSES,
                MiniMaxH3VideoOutpaintGeometryPreviewT8,
                *VIDEO_OUTPAINT_CANDIDATE_DRAFT_NODE_CLASSES,
                MiniMaxH3VideoOutpaintLoadPreparedT8,
                *VIDEO_OUTPAINT_GUIDANCE_DRAFT_NODE_CLASSES,
                MiniMaxH3VDNRefinePlanT8Advanced,
                MiniMaxH3SafeAVSaveT8Advanced,
                MiniMaxH3ProgressiveSamplerEXPT8,
                MiniMaxH3DLSSFrameInterpolationEXPT8,
                *TRT_VAE_NODE_CLASSES,
                MiniMaxH3DualModelLongVideoEXPT8,
                MiniMaxH3DanceMotionSourceEXPT8,
            *TOPAZ_NODE_CLASSES,
            *PREPARED_GENERATION_NODE_CLASSES,
                MiniMaxH3TSTModelEXPT8,
                *PROGRESSIVE_LONG_VIDEO_NODE_CLASSES,
                # Independent T8 H3 activation-memory nodes. Append-only after
                # every v1.80.0 ID; they do not move or modify legacy schemas.
                *H3_MEMORY_ADVANCED_NODE_CLASSES,
                *FAST_H3_V2_NODE_CLASSES,
                SolAttnMiniMax,
                *SEMANTIC_BRIDGE_NODE_CLASSES,
                MiniMaxH3LTXLatentAdapterEXPT8,
                *READABLE_AUDIO_NODE_CLASSES,
                MiniMaxH3AvatarProgressiveEXPT8,
                MiniMaxH3TAEH3SamplingPreviewEXPT8,
                MiniMaxH3PromptRelayWindowTextEXPT8,
                *MERIDIAN_NODE_CLASSES,
                MiniMaxH3DirectorProjectT8,
                # H16-3 optional audio-refined PASS 2 adapter. Append-only so
                # every published registration position above remains stable.
                *H16_CHUNKED_PASS2_NODE_CLASSES,
                # Five image slots use a dedicated conditioning/decode protocol;
                # never change Still or ordinary video node registrations.
                *FIVE_VIEW_EXP_NODE_CLASSES,
                # Dedicated two-clock endpoint and trained grid, never the
                # generic Turbo/PDD loader or the legacy 4+4 sampler.
                *HYPERFLOW_ADVANCED_NODE_CLASSES,
            ]


def comfy_entrypoint():
    return MiniMaxH3AudioT8Extension()
